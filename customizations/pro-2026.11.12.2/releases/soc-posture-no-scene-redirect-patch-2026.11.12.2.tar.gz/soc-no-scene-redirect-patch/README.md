# SOC workspace navigation redirect fix

Target: Flocks Pro 2026.11.12.2, enhancement 1.14.9, branch `fix/process_11.12_en`.

When a SOC workspace route is considered disabled, locked, or unavailable, the layout must not redirect to `/scenes/suites`. Other scene workspaces retain the existing fallback to Scene Management.

Apply from repository root:

```sh
patch -p1 < webui/src/components/layout/Layout.tsx.patch
```

Per request, runtime testing was skipped for this delivery.
