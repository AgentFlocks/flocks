#!/usr/bin/env python3
"""Flocks WebUI「模型清单」用量展示补丁：应用 / 回滚 / 状态查询。

在已构建的 webui-dist 产物上做定点注入（不改后端数据）：
  1. 「已连接 Provider」显示为配置的 Provider 数量；
  2. 供应商列表固定为配置的 Provider，且均标记为「已连接」；
  3. 选中不同 Provider 时，顶部「总 Tokens」「总费用」读取对应 mock 值；
  4. 其余统计卡（可用模型 / 默认模型 / 辅助模型）保持真实数据。

用法：
  python3 apply.py --config patch-config.json            # 应用
  python3 apply.py --config patch-config.json --status   # 查看状态
  python3 apply.py --rollback                            # 回滚
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path

ANCHOR = "model_page_selected_provider"
MARK = "__MP=[{"

DEFAULT_DIST_CANDIDATES = (
    Path("/opt/flockspro/current/runtime/webui-dist"),
    Path("/opt/flockspro/current/webui/dist"),
)


def log(message: str) -> None:
    print(f"[patch] {message}")


def die(message: str) -> None:
    print(f"[x] {message}", file=sys.stderr)
    sys.exit(1)


def resolve_dist(arg: str | None) -> Path:
    if arg:
        path = Path(arg).expanduser()
    elif os.environ.get("FLOCKS_WEBUI_DIST_DIR"):
        path = Path(os.environ["FLOCKS_WEBUI_DIST_DIR"]).expanduser()
    else:
        for candidate in DEFAULT_DIST_CANDIDATES:
            if (candidate / "index.html").is_file():
                path = candidate
                break
        else:
            die("未找到 webui-dist，请用 --dist 指定")
    resolved = path.resolve()
    if not (resolved / "index.html").is_file():
        die(f"{resolved} 下没有 index.html")
    return resolved


def entry_src_from_html(html: str) -> str:
    match = re.search(r'<script[^>]*\btype="module"[^>]*\bsrc="([^"]+)"', html)
    if not match:
        die("index.html 中找不到 module 入口 script")
    return match.group(1)


def short_hash(text: str) -> str:
    return hashlib.sha1(text.encode("utf-8")).hexdigest()[:8]


def load_config(path: Path) -> dict:
    try:
        config = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        die(f"配置文件不存在：{path}")
    except json.JSONDecodeError as error:
        die(f"配置文件解析失败：{error}")

    providers = config.get("providers")
    usage = config.get("usage")
    if not isinstance(providers, list) or not providers:
        die("配置缺少 providers")
    if not isinstance(usage, dict):
        die("配置缺少 usage")
    for provider in providers:
        for field in ("id", "name"):
            if not provider.get(field):
                die(f"provider 缺少字段 {field}: {provider}")
        if provider["id"] not in usage:
            die(f"usage 缺少 provider {provider['id']}")
        entry = usage[provider["id"]]
        if "total_tokens" not in entry or "total_cost" not in entry:
            die(f"usage.{provider['id']} 需要 total_tokens 与 total_cost")
    return config


def build_injection(config: dict) -> tuple[str, str, str]:
    providers_js: list[str] = []
    usage_js: list[str] = []
    seed_js: list[str] = []

    for provider in config["providers"]:
        pid = provider["id"]
        providers_js.append(
            '{id:"%s",name:"%s",configured:!0,modelCount:%d,category:"connected"}'
            % (pid, provider["name"], int(provider.get("model_count", 0)))
        )
        seed_js.append('"%s":"connected"' % pid)
        entry = config["usage"][pid]
        usage_js.append(
            '"%s":{summary:{total_tokens:%d,cost_by_currency:[{currency:"%s",total_cost:%s}]}}'
            % (
                pid,
                int(entry["total_tokens"]),
                entry.get("currency", "CNY"),
                json.dumps(entry["total_cost"]),
            )
        )

    return (
        ",".join(providers_js),
        "{" + ",".join(usage_js) + "}",
        ",".join(seed_js),
    )


def build_edits(providers_js: str, usage_js: str, seed_js: str) -> list[tuple[str, str]]:
    return [
        (
            "const{providers:t,connectedIds:r,loading:l,error:i,refetch:a}=Ft(),",
            "const{providers:t,connectedIds:r,loading:l,error:i,refetch:a}=Ft(),"
            "__MP=[%s],__UM=%s," % (providers_js, usage_js),
        ),
        (
            "[E,B]=s.useState({})",
            "[E,B]=s.useState({%s})" % seed_js,
        ),
        (
            "c&&ne.find(P=>P.id===c)||ne[0]",
            "c&&__MP.find(P=>P.id===c)||__MP[0]",
        ),
        (
            "e.jsx(ws,{connectedCount:Ee,totalModels:We,usageStats:ee,",
            "e.jsx(ws,{connectedCount:__MP.length,totalModels:We,"
            "usageStats:__UM[x?.id]||ee,",
        ),
        (
            "):ne.map(",
            "):__MP.map(",
        ),
    ]


def find_model_chunk(assets: Path, entry_text: str) -> tuple[Path, str]:
    matches: list[tuple[Path, str]] = []
    for path in sorted(assets.glob("*.js")):
        try:
            text = path.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            continue
        if ANCHOR in text:
            matches.append((path, text))

    if not matches:
        die("未找到「模型清单」页 chunk（锚点 %s 无匹配）" % ANCHOR)

    referenced = [(path, text) for path, text in matches if path.name in entry_text]
    if len(referenced) != 1:
        die(
            "入口引用的候选 chunk 数量异常（%d 个），候选：%s"
            % (len(referenced), ", ".join(path.name for path, _ in matches))
        )
    return referenced[0]


def state_dir_for(dist: Path) -> Path:
    return dist.parent / ".webui-usage-patch"


def read_state(state_dir: Path) -> dict | None:
    state_file = state_dir / "state.json"
    if not state_file.is_file():
        return None
    try:
        return json.loads(state_file.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        die(f"状态文件损坏：{state_file}")


def preview(config: dict) -> None:
    log("补丁生效后的界面显示：")
    for provider in config["providers"]:
        entry = config["usage"][provider["id"]]
        tokens = "%sM" % ("%.2f" % (int(entry["total_tokens"]) / 1_000_000))
        symbol = {"CNY": "¥", "USD": "$"}.get(entry.get("currency", "CNY"), entry.get("currency", "CNY") + " ")
        cost = "%s%.4f" % (symbol, float(entry["total_cost"]))
        log("  %-22s 总 Tokens=%-10s 总费用=%s" % (provider["name"], tokens, cost))
    log("  已连接 Provider = %d" % len(config["providers"]))
    log("  供应商列表顺序 = %s" % ", ".join(provider["name"] for provider in config["providers"]))


def do_status(dist: Path) -> int:
    state_dir = state_dir_for(dist)
    state = read_state(state_dir)
    html = (dist / "index.html").read_text(encoding="utf-8")
    log(f"dist            : {dist}")
    log(f"index.html 入口 : {entry_src_from_html(html)}")
    if not state:
        log("状态            : 未打补丁（无 state.json）")
        return 0
    log("状态            : 已打补丁")
    log(f"应用时间        : {state.get('applied_at')}")
    log(f"生成文件        : {', '.join(state.get('generated', []))}")
    log(f"配置摘要        : {json.dumps(state.get('providers', []), ensure_ascii=False)}")
    return 0


def do_rollback(dist: Path) -> int:
    state_dir = state_dir_for(dist)
    state = read_state(state_dir)
    if not state:
        log("未发现补丁状态，无需回滚")
        return 0

    backup_index = state_dir / "backup" / "index.html"
    if not backup_index.is_file():
        die(f"备份缺失，无法回滚：{backup_index}")
    shutil.copyfile(backup_index, dist / "index.html")
    for relative in state.get("generated", []):
        target = dist / relative
        if target.is_file():
            target.unlink()
    shutil.rmtree(state_dir, ignore_errors=True)
    log("已回滚：index.html 还原，生成的资源文件已删除")
    return 0


def do_apply(dist: Path, config_path: Path, force: bool) -> int:
    state_dir = state_dir_for(dist)
    if read_state(state_dir):
        if not force:
            log("检测到已打补丁，跳过（需要重新应用请加 --force，会先回滚）")
            return do_status(dist)
        log("--force：先回滚已有补丁")
        do_rollback(dist)

    assets = dist / "assets"
    if not assets.is_dir():
        die(f"{dist} 下没有 assets 目录")

    config = load_config(config_path)
    providers_js, usage_js, seed_js = build_injection(config)
    edits = build_edits(providers_js, usage_js, seed_js)

    html = (dist / "index.html").read_text(encoding="utf-8")
    entry_src = entry_src_from_html(html)
    entry_path = dist / entry_src.lstrip("/")
    if not entry_path.is_file():
        die(f"入口文件不存在：{entry_path}")
    entry_text = entry_path.read_text(encoding="utf-8")

    chunk_path, chunk_text = find_model_chunk(assets, entry_text)
    if MARK in chunk_text:
        die(
            "目标 chunk 已打过补丁但缺少补丁状态（state.json）；"
            "请先把 index.html 入口还原为原始入口，或对干净的 webui-dist 执行"
        )

    for old, new in edits:
        count = chunk_text.count(old)
        if count != 1:
            die(f"锚点匹配异常（{count} 次），本产物结构与补丁不兼容：{old[:60]}…")
        chunk_text = chunk_text.replace(old, new)

    chunk_name = f"{chunk_path.stem}-{short_hash(chunk_text)}.js"
    entry_text = entry_text.replace(chunk_path.name, chunk_name)
    entry_name = f"{entry_path.stem}-{short_hash(entry_text)}.js"
    html = html.replace(entry_src, f"{entry_src.rsplit('/', 1)[0]}/{entry_name}")

    backup_dir = state_dir / "backup"
    backup_dir.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(dist / "index.html", backup_dir / "index.html")

    (assets / chunk_name).write_text(chunk_text, encoding="utf-8")
    (assets / entry_name).write_text(entry_text, encoding="utf-8")
    (dist / "index.html").write_text(html, encoding="utf-8")

    written_chunk = (assets / chunk_name).read_text(encoding="utf-8")
    for old, new in edits:
        if new not in written_chunk:
            die("写入后校验失败（注入缺失），请回滚")
        if old not in new and old in written_chunk:
            die("写入后校验失败（旧片段残留），请回滚")
    if chunk_name not in (assets / entry_name).read_text(encoding="utf-8"):
        die("入口引用校验失败，请回滚")
    if entry_name not in (dist / "index.html").read_text(encoding="utf-8"):
        die("index.html 引用校验失败，请回滚")

    state = {
        "dist": str(dist),
        "applied_at": datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds"),
        "original_chunk": f"assets/{chunk_path.name}",
        "original_entry": entry_src,
        "generated": [f"assets/{chunk_name}", f"assets/{entry_name}"],
        "providers": [
            {"id": provider["id"], "name": provider["name"]} for provider in config["providers"]
        ],
        "usage": config["usage"],
    }
    (state_dir / "state.json").write_text(
        json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    log(f"已应用：{chunk_path.name} -> {chunk_name}")
    log(f"已应用：{Path(entry_src).name} -> {entry_name}")
    log("index.html 入口已更新（文件名变化，浏览器无需强刷）")
    preview(config)
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="Flocks WebUI 模型清单用量展示补丁")
    parser.add_argument("--config", default=str(Path(__file__).with_name("patch-config.json")))
    parser.add_argument("--dist", default=None, help="webui-dist 目录（默认读 FLOCKS_WEBUI_DIST_DIR）")
    parser.add_argument("--status", action="store_true", help="查看补丁状态")
    parser.add_argument("--rollback", action="store_true", help="回滚补丁")
    parser.add_argument("--force", action="store_true", help="已打补丁时先回滚再重新应用")
    parser.add_argument("--dry-run", action="store_true", help="仅校验锚点与配置，不写文件")
    args = parser.parse_args()

    dist = resolve_dist(args.dist)

    if args.status:
        return do_status(dist)
    if args.rollback:
        return do_rollback(dist)
    if args.dry_run:
        config = load_config(Path(args.config))
        providers_js, usage_js, seed_js = build_injection(config)
        edits = build_edits(providers_js, usage_js, seed_js)
        html = (dist / "index.html").read_text(encoding="utf-8")
        entry_path = dist / entry_src_from_html(html).lstrip("/")
        if not entry_path.is_file():
            die(f"入口文件不存在：{entry_path}")
        chunk_path, chunk_text = find_model_chunk(
            dist / "assets", entry_path.read_text(encoding="utf-8")
        )
        if MARK in chunk_text:
            die("目标 chunk 已打过补丁，dry-run 中止")
        for old, _ in edits:
            if chunk_text.count(old) != 1:
                die(f"锚点匹配异常：{old[:60]}…")
        log(f"dry-run OK：目标 chunk = {chunk_path.name}")
        preview(config)
        return 0
    return do_apply(dist, Path(args.config), args.force)


if __name__ == "__main__":
    sys.exit(main())
