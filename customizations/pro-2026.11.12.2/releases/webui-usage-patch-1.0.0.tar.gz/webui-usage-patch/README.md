# WebUI「模型清单」用量展示补丁包

对 Flocks / flockspro 托管版的已构建前端产物（`webui-dist`）做定点注入，用于演示/截图场景下定制「模型清单」页的统计展示。**只改前端显示，不改动后端数据、配置与账号。**

## 1. 补丁效果

| 界面元素 | 效果 |
|---|---|
| 顶部「已连接 Provider」 | 显示为配置的 Provider 数量（默认 2） |
| 左侧供应商列表 | 固定为配置的 Provider（默认 `private_models`、`ThreatBook-cn-llm`），均显示「已连接」绿点 |
| 点击 `private_models` | 顶部「总 Tokens」`7082.33M`、「总费用」`¥148912.3400` |
| 点击 `ThreatBook-cn-llm` | 顶部「总 Tokens」`2132.68M`、「总费用」`¥260.1700` |
| 可用模型 / 默认模型 / 辅助模型 | **保持真实数据不变** |

数值口径由 `patch-config.json` 决定：
- Token：`total_tokens / 1000000` 保留 2 位小数 + `M`（界面既有格式）
- 费用：按 `currency` 显示，人民币保留 4 位小数并带 `¥`，点击卡片仍可切换美元

## 2. 目录内容

```
webui-usage-patch/
├── apply.py            # 补丁主体（应用 / 状态 / 回滚 / dry-run）
├── apply.sh            # 便捷入口
├── patch-config.json   # Provider 列表与数值（要改数值改这里）
├── manifest.json       # 包版本、校验和、验证环境
└── README.md
```

## 3. 使用

```sh
# 1) 先干跑，校验目标产物结构与锚点是否兼容（不写任何文件）
sh apply.sh --dry-run

# 2) 应用（默认自动定位 webui-dist：优先 $FLOCKS_WEBUI_DIST_DIR，其次 /opt/flockspro/current/runtime/webui-dist）
sh apply.sh

# 指定目录 / 指定配置
sh apply.sh --dist /path/to/webui-dist --config /path/to/patch-config.json

# 查看状态
sh apply.sh --status

# 回滚（还原 index.html 并删除生成的资源文件）
sh apply.sh --rollback

# 已打过补丁时重新应用（先回滚再打）
sh apply.sh --force
```

应用后浏览器**无需强刷**：补丁会为新产物生成新的文件名（内容哈希后缀），并同步更新 `index.html` 的入口引用（`index.html` 为 `no-store`）。

## 4. 补丁做了什么

在 `webui-dist` 上完成 4 步，全部可回滚：

1. 从 `index.html` 解析 module 入口 script；
2. 在 `assets/*.js` 中按锚点 `model_page_selected_provider` 唯一定位「模型清单」页 chunk，并确认入口引用了它；
3. 对该 chunk 做 5 处定点注入（见下），按内容哈希生成新文件名；
4. 入口文件同步改写对新 chunk 的 2 处引用，按内容哈希生成新入口名，并把 `index.html` 指向新入口。

5 处注入（源码语义）：

| # | 位置 | 作用 |
|---|---|---|
| 1 | 组件顶部 | 注入 `__MP`（Provider 列表）与 `__UM`（各 Provider 的用量 mock）常量 |
| 2 | `useState({})`（连接状态） | 预置为配置的 Provider 均为 `connected`（绿点） |
| 3 | 默认自动选中 | 改为落到 `__MP[0]`（列表第一项） |
| 4 | `DashboardStrip` 调用处 | `connectedCount` 取 `__MP.length`，`usageStats` 按选中 Provider 取 `__UM[id]`，未命中则回落真实数据 |
| 5 | 供应商列表渲染 | `ne.map` → `__MP.map`（真实 `configuredProviders` 变量 `ne` 不动，故其他统计卡仍是真实值） |

## 5. 回滚与备份

- 首次应用时会把原始 `index.html` 备份到 `<webui-dist>/../.webui-usage-patch/backup/index.html`，并写入 `state.json` 记录生成的文件清单。
- `--rollback` 用该备份还原 `index.html`，并删除补丁生成的资源文件。
- 原始 chunk 与入口文件**始终保留未被改动**，即使 `state.json` 丢失也可手动还原。

## 6. 注意事项

1. **版本相关**：补丁通过锚点动态定位代码位置，跨版本一般可用；若上游改动导致锚点不存在、或入口引用的候选 chunk 数量异常，脚本会**报错中止**，不会写入半成品。已在 `2026.11.12.2-darwin-arm64` 验证。
   - 若目标产物已被**手工方式**打过同类补丁（含 `__MP=[{` 但无 `state.json`），脚本会拒绝执行，避免重复注入；先把 `index.html` 入口还原为原始入口再跑，或对干净的 `webui-dist` 执行。
2. **只作用于当前 release 目录**：升级 / 更换 release 后需要在新版本上重新执行。
3. **运行时不校验 `webui-dist` 文件哈希**，`flocks-webui-manifest.json` 会与实际产物不一致（仅留档用途，不影响运行）。
4. **已知显示差异**：`private_models` 并非真实 Provider，点进去右侧模型列表为空、左侧卡片显示「0 个模型」；`ThreatBook-cn-llm` 是真实 Provider，点进去显示真实模型列表。这些数字可在 `patch-config.json` 的 `model_count` 调整。
5. 补丁不修改任何后端数据、Provider 凭证、默认模型或路由配置；回滚后界面与打补丁前完全一致。
