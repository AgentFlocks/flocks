#!/bin/sh
set -e
DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
PY="${PYTHON:-python3}"
exec "$PY" "$DIR/apply.py" --config "$DIR/patch-config.json" "$@"
