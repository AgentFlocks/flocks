#!/usr/bin/env python3
"""定点补丁：在场景管理侧显式排除「工作台快捷入口」（默认「SOC 态势」）。

目标文件（自动探测，可用 --target 指定）：
    /opt/flockspro/releases/<版本>/runtime/flocks/flocks/server/routes/webui.py

四处定点插入（模式定位，不写死行号）：
    A  EXCLUDED_SCENE_WORKSPACE_IDS / EXCLUDED_SCENE_WORKSPACE_TITLES 常量 + _scene_excluded()
    B  _attach_scene_suites() 循环开头命中即保留工作区、suiteId 置 None
    C  去重日志集合 _scene_excluded_logged
    D  _attach_scene_suites() docstring 补充说明

安全设计：
    * 模式匹配唯一性检查；结构漂移直接中止，不做任何修改
    * 幂等：已打过补丁返回退出码 2，不重复写入
    * 写盘前备份（包内 backups/ 与目标同目录 .bak-<ts>）
    * 写盘后自校验：四处标记齐备 + 括号配平 + py_compile 语法校验，任一失败自动回滚
    * 可选 --workspace-id / --title 生成排除名单，用于其他环境的真实 id

退出码：0 成功或已是最新，2 无事可做，3 模式不匹配/校验失败（已回滚），4 环境问题。
"""

from __future__ import annotations

import argparse
import glob
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

DEFAULT_IDS = ("soc_posture_ui",)
DEFAULT_TITLES = ("SOC 态势", "SOC Posture")
DEFAULT_WORKSPACE_ID = "soc_posture_ui"
DEFAULT_TITLE = "SOC 态势"
DEFAULT_TITLE_EN = "SOC Posture"
DEFAULT_PAGE_ID = "soc-posture-dashboard"

ROUTE_RELATIVE = "runtime/flocks/flocks/server/routes/webui.py"

FUNC_ANCHOR = "def _attach_scene_suites(workspaces: list[WebUIWorkspaceListItem]) -> list[WebUIWorkspaceListItem]:\n"
LOOP_ANCHOR = (
    "    result: list[WebUIWorkspaceListItem] = []\n"
    "    for workspace in workspaces:\n"
    "        suite_id = owners.get(workspace.id)\n"
)
LOG_SET_ANCHOR = "_hidden_scene_workspaces_logged: set[str] = set()\n"
DOC_ANCHOR = '    which are not scenes.\n    """\n'

BLOCK_HEADER = """# The scene manager's explicit exclusion list: these entries are workbench
# shortcuts (the "SOC 态势" card on the workbench opens the SOC workspace
# posture page), not part of a scene suite. A match is never treated as a
# scene: it is not hidden as an unowned scene workspace and it is not tagged
# with a suite, so the scene manager neither manages nor blocks it.
"""

HELPER = """

def _scene_excluded(workspace: WebUIWorkspaceListItem) -> bool:
    \"\"\"True when the scene manager must leave this entry alone.\"\"\"
    if workspace.id in EXCLUDED_SCENE_WORKSPACE_IDS:
        return True
    return any(
        label is not None and label.strip() in EXCLUDED_SCENE_WORKSPACE_TITLES
        for label in (workspace.title, workspace.titleEn)
    )


"""

GUARD = """        if _scene_excluded(workspace):
            if workspace.id not in _scene_excluded_logged:
                _scene_excluded_logged.add(workspace.id)
                log.info("webui.workspaces.scene_excluded", {"workspaceId": workspace.id})
            result.append(workspace.model_copy(update={"suiteId": None}))
            continue
"""

LOG_SET_ADDED = "_scene_excluded_logged: set[str] = set()\n"

DOC_INSERT = (
    "    which are not scenes.\n"
    "\n"
    "    Entries on the explicit exclusion list are neither scenes nor leftovers:\n"
    "    they stay reachable and are reported with no suite.\n"
    '    """\n'
)

MARKERS = (
    "EXCLUDED_SCENE_WORKSPACE_IDS",
    "EXCLUDED_SCENE_WORKSPACE_TITLES",
    "def _scene_excluded(",
    "_scene_excluded_logged",
)


def log(message: str) -> None:
    print(message, flush=True)


def sha256_of(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def build_ids_literal(values) -> str:
    return "{" + ", ".join(f'"{value}"' for value in values) + "}"


def render_block(ids, titles) -> str:
    return (
        BLOCK_HEADER
        + f"EXCLUDED_SCENE_WORKSPACE_IDS: frozenset[str] = frozenset({build_ids_literal(ids)})\n"
        + f"EXCLUDED_SCENE_WORKSPACE_TITLES: frozenset[str] = frozenset({build_ids_literal(titles)})\n"
        + HELPER
    )


def detect_release_root(explicit: str | None) -> Path | None:
    if explicit:
        candidate = Path(explicit).expanduser()
        return candidate if candidate.is_dir() else None
    env = os.environ.get("FLOCKS_RELEASE_ROOT")
    if env and Path(env).is_dir():
        return Path(env)
    roots = [Path(p) for p in glob.glob("/opt/flockspro/releases/*")]
    roots = [path for path in roots if (path / ROUTE_RELATIVE).is_file()]
    if not roots:
        return None
    roots.sort(key=lambda path: path.stat().st_mtime, reverse=True)
    return roots[0]


def resolve_target(args) -> Path:
    if args.target:
        return Path(args.target).expanduser()
    root = detect_release_root(args.release_root)
    if root is None:
        raise SystemExit("环境问题：未找到 release 目录或 webui.py，请用 --target 显式指定")
    return root / ROUTE_RELATIVE


def configured_ids(text: str) -> tuple[list[str], list[str]]:
    def parse(name: str) -> list[str]:
        prefix = f"{name}: frozenset[str] = frozenset("
        for line in text.splitlines():
            stripped = line.strip()
            if stripped.startswith(prefix):
                body = stripped[len(prefix):]
                inner = body[body.find("{") + 1:body.rfind("}")]
                return [item.strip().strip('"') for item in inner.split(",") if item.strip()]
        return []
    return parse("EXCLUDED_SCENE_WORKSPACE_IDS"), parse("EXCLUDED_SCENE_WORKSPACE_TITLES")


def patched_state(text: str) -> str:
    present = [marker for marker in MARKERS if marker in text]
    if not present:
        return "clean"
    return "patched" if len(present) == len(MARKERS) else "partial"


def anchor_positions(text: str, block_needed: str) -> dict:
    anchors = {
        "func": FUNC_ANCHOR,
        "loop": LOOP_ANCHOR,
        "log_set": LOG_SET_ANCHOR,
        "doc": DOC_ANCHOR,
    }
    if block_needed:
        anchors["block"] = ""
    result = {}
    for name, anchor in anchors.items():
        if anchor:
            result[name] = text.count(anchor)
    return result


def compile_check(path: Path, python: str | None) -> tuple[bool, str]:
    interpreter = python or sys.executable
    try:
        completed = subprocess.run(
            [interpreter, "-m", "py_compile", str(path)],
            capture_output=True, text=True, timeout=120,
        )
    except Exception as exc:  # pragma: no cover - environment dependent
        return False, f"无法执行语法校验: {exc}"
    if completed.returncode != 0:
        return False, (completed.stderr or completed.stdout).strip()
    return True, "py_compile OK"


def balanced(text: str) -> bool:
    pairs = {"{": "}", "(": ")", "[": "]"}
    stack = []
    for char in text:
        if char in pairs:
            stack.append(char)
        elif char in pairs.values():
            if not stack or pairs[stack.pop()] != char:
                return False
    return not stack


def backup_target(target: Path, backup_dir: Path) -> tuple[Path, Path]:
    stamp = time.strftime("%Y%m%dT%H%M%SZ", time.gmtime())
    sidecar = target.with_name(f"{target.name}.bak-{stamp}")
    shutil.copy2(target, sidecar)
    backup_dir.mkdir(parents=True, exist_ok=True)
    packaged = backup_dir / f"webui.py.bak-{stamp}"
    shutil.copy2(target, packaged)
    return sidecar, packaged


def apply_patch(args) -> int:
    target = resolve_target(args)
    if not target.is_file():
        log(f"环境问题：目标文件不存在 {target}")
        return 4

    text = target.read_text(encoding="utf-8")
    state = patched_state(text)
    if state == "patched":
        ids, titles = configured_ids(text)
        log(f"补丁已应用，无需修改：{target}")
        log(f"  排除 id     : {ids}")
        log(f"  排除 title  : {titles}")
        return 2
    if state == "partial":
        log("模式不匹配：文件中只出现部分补丁标记，疑似手工改动或版本漂移，未做任何修改")
        return 3

    counts = anchor_positions(text, block_needed=True)
    missing = [name for name, count in counts.items() if count != 1]
    if missing:
        log(f"模式不匹配：锚点出现次数异常 {missing}（期望各 1 次），未做任何修改")
        return 3

    block = render_block(args.workspace_id, args.title)
    patched = text
    patched = patched.replace(DOC_ANCHOR, DOC_INSERT, 1)
    patched = patched.replace(LOG_SET_ANCHOR, LOG_SET_ANCHOR + LOG_SET_ADDED, 1)
    patched = patched.replace(
        FUNC_ANCHOR, block + FUNC_ANCHOR, 1
    )
    patched = patched.replace(
        LOOP_ANCHOR,
        "    result: list[WebUIWorkspaceListItem] = []\n"
        "    for workspace in workspaces:\n"
        + GUARD
        + "        suite_id = owners.get(workspace.id)\n",
        1,
    )

    expected_growth = len(DOC_INSERT) - len(DOC_ANCHOR) + len(LOG_SET_ADDED) + len(block) + len(GUARD)
    if len(patched) - len(text) != expected_growth:
        log("自校验失败：写入长度与预期不符，未做任何修改")
        return 3
    if not balanced(patched):
        log("自校验失败：括号配平异常，未做任何修改")
        return 3
    if patched_state(patched) != "patched":
        log("自校验失败：补丁标记不齐，未做任何修改")
        return 3

    if args.dry_run:
        log(f"[dry-run] 将对 {target} 应用补丁")
        log(f"  - 新增排除 id    : {list(args.workspace_id)}")
        log(f"  - 新增排除 title : {list(args.title)}")
        log(f"  - 文件将增长 {expected_growth} 字节（{len(text)} -> {len(patched)}）")
        return 0

    before_sha = sha256_of(target)
    sidecar, packaged = backup_target(target, Path(args.backup_dir))
    log(f"已备份: {sidecar}")
    log(f"已备份: {packaged}")

    try:
        target.write_text(patched, encoding="utf-8")
        written = target.read_text(encoding="utf-8")
        if written != patched:
            raise RuntimeError("写盘后内容与预期不一致")
        if not balanced(written):
            raise RuntimeError("写盘后括号配平异常")
        if patched_state(written) != "patched":
            raise RuntimeError("写盘后补丁标记不齐")
        if not balanced(written):
            raise RuntimeError("写盘后括号配平异常")
        if args.verify_compile:
            ok, detail = compile_check(target, args.python)
            if not ok:
                raise RuntimeError(f"语法校验失败: {detail}")
            log(f"语法校验: {detail}")
    except Exception as exc:
        shutil.copy2(sidecar, target)
        log(f"校验失败，已回滚：{exc}")
        log(f"回滚后 sha256: {sha256_of(target)}")
        return 3

    after_sha = sha256_of(target)
    log("补丁已应用")
    log(f"  {target}")
    log(f"  sha256 {before_sha} -> {after_sha}")
    log(f"  size   {len(text)} -> {len(written)}")
    log("重启生效: flocks restart --server-only")
    return 0


def check_patch(args) -> int:
    target = resolve_target(args)
    if not target.is_file():
        log(f"环境问题：目标文件不存在 {target}")
        return 4
    text = target.read_text(encoding="utf-8")
    state = patched_state(text)
    log(f"目标文件: {target}")
    log(f"sha256   : {sha256_of(target)}")
    if state == "patched":
        ids, titles = configured_ids(text)
        log("状态     : patched（补丁已应用）")
        log(f"排除 id  : {ids}")
        log(f"排除 title: {titles}")
        return 0
    if state == "partial":
        log("状态     : partial（只剩部分标记，疑似手工改动或版本漂移）")
        return 3
    log("状态     : clean（未打补丁）")
    counts = anchor_positions(text, block_needed=True)
    log(f"锚点命中 : {counts}")
    return 2


def revert_patch(args) -> int:
    target = resolve_target(args)
    if not target.is_file():
        log(f"环境问题：目标文件不存在 {target}")
        return 4

    candidates = []
    packaged_orig = Path(__file__).resolve().parent / "orig" / "webui.py"
    if packaged_orig.is_file():
        candidates.append(packaged_orig)
    candidates.extend(sorted(target.parent.glob(f"{target.name}.bak-*"), reverse=True))
    if not candidates:
        log("环境问题：找不到原始备份（包内 orig/webui.py 或同目录 .bak-*）")
        return 4

    source = candidates[0]
    text = target.read_text(encoding="utf-8")
    if patched_state(text) == "clean":
        log(f"当前未打补丁，无需回滚: {target}")
        return 2
    if args.dry_run:
        log(f"[dry-run] 将用 {source} 覆盖 {target}")
        return 0

    shutil.copy2(target, target.with_name(f"{target.name}.pre-revert-{time.strftime('%Y%m%dT%H%M%SZ', time.gmtime())}"))
    shutil.copy2(source, target)
    log(f"已回滚: {target} <- {source}")
    log(f"sha256: {sha256_of(target)}")
    log("重启生效: flocks restart --server-only")
    return 0


def render_data_files(args) -> dict:
    workspace = {
        "id": args.workspace_id[0],
        "version": "1.0.0",
        "title": args.title[0],
        "titleEn": args.title_en,
        "icon": "ShieldCheck",
        "order": 20,
        "enabled": True,
        "placement": "aiWorkbench",
        "defaultPageId": args.page_id,
        "sections": [
            {
                "id": "posture",
                "label": args.section_label,
                "labelEn": args.section_label_en,
                "pageIds": [args.page_id],
                "defaultPageId": args.page_id,
                "contentPadding": "none",
            }
        ],
    }
    manifest = {
        "id": args.page_id,
        "title": args.title[0],
        "titleEn": args.title_en,
        "route": f"/contracts/webui/pages/{args.page_id}",
        "icon": "ShieldCheck",
        "order": 10,
        "enabled": True,
        "placement": "home.after",
        "entry": "src/index.tsx",
        "updatedAt": 0,
    }
    index_tsx = "import Page from './Page';\n\nexport default Page;\n"
    page_tsx = (
        "import { Card } from '@flocks/webui-contract-sdk';\n\n"
        "export default function Page() {\n"
        "  return (\n"
        f'    <Card title="{args.title[0]}">\n'
        f"      {args.title[0]}入口：指向 SOC 工作区（soc_ui）的态势页面。\n"
        "    </Card>\n"
        "  );\n"
        "}\n"
    )
    return {
        f"{args.workspace_id[0]}/workspace.json": json.dumps(workspace, ensure_ascii=False, indent=2) + "\n",
        f"{args.workspace_id[0]}/{args.page_id}/manifest.json": json.dumps(manifest, ensure_ascii=False, indent=2) + "\n",
        f"{args.workspace_id[0]}/{args.page_id}/src/index.tsx": index_tsx,
        f"{args.workspace_id[0]}/{args.page_id}/src/Page.tsx": page_tsx,
    }


def install_data(args) -> int:
    root = Path(args.data_root).expanduser()
    files = render_data_files(args)
    written, skipped = [], []
    for relative, content in files.items():
        destination = root / relative
        if destination.exists():
            existing = destination.read_text(encoding="utf-8")
            if existing == content:
                skipped.append(str(destination))
                continue
            skipped.append(f"{destination}（已存在且内容不同，保留原文件）")
            continue
        written.append((destination, content))

    log(f"数据根目录: {root}")
    if not written:
        log("入口数据已就绪，无需写入")
        for item in skipped:
            log(f"  保留 {item}")
        return 2
    for destination, content in written:
        log(f"  写入 {destination}")
    if args.dry_run:
        log("[dry-run] 未写入任何文件")
        return 0
    for destination, content in written:
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_text(content, encoding="utf-8")
    log("已安装入口数据（placement=aiWorkbench，左侧「工作台」卡片入口，无需重启）")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="场景管理侧显式排除工作台快捷入口（SOC 态势）")
    parser.add_argument("--target", help="webui.py 路径（默认自动探测最新 release）")
    parser.add_argument("--release-root", help="release 根目录，例如 /opt/flockspro/releases/<版本>")
    parser.add_argument("--backup-dir", default=str(Path(__file__).resolve().parent / "backups"))
    parser.add_argument("--workspace-id", action="append", default=None, help="要排除的工作区 id（可重复）")
    parser.add_argument("--title", action="append", default=None, help="要排除的工作区标题（可重复）")
    parser.add_argument("--python", help="用于 py_compile 校验的解释器")
    parser.add_argument("--check", action="store_true", help="只报告状态")
    parser.add_argument("--revert", action="store_true", help="回滚到原始文件")
    parser.add_argument("--dry-run", action="store_true", help="预演，不写盘")
    parser.add_argument("--install-data", action="store_true", help="安装入口数据（SOC 态势 工作台卡片）")
    parser.add_argument("--data-root", default=str(Path.home() / ".flocks" / "plugins" / "contracts" / "webui"))
    parser.add_argument("--title-en", default=DEFAULT_TITLE_EN)
    parser.add_argument("--page-id", default=DEFAULT_PAGE_ID)
    parser.add_argument("--section-label", default="态势")
    parser.add_argument("--section-label-en", default="Posture")
    parser.add_argument("--no-verify-compile", dest="verify_compile", action="store_false")
    parser.set_defaults(verify_compile=True)
    args = parser.parse_args()

    args.workspace_id = args.workspace_id or list(DEFAULT_IDS)
    args.title = args.title or list(DEFAULT_TITLES)

    if args.install_data:
        return install_data(args)
    if args.check:
        return check_patch(args)
    if args.revert:
        return revert_patch(args)
    return apply_patch(args)


if __name__ == "__main__":
    sys.exit(main())
