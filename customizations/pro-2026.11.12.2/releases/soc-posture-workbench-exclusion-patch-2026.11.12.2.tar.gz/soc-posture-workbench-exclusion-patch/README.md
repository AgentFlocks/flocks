# 补丁包：场景管理侧显式排除「SOC 态势」工作台入口

左侧「工作台」卡片列表里的「SOC 态势」入口是 **SOC 工作区的快捷方式**，不应与「场景管理」产生关联。

**根因**：入口工作区若是 `placement=sceneWorkspace` 且没有任何场景套件认领（非 `native`），后端
`_attach_scene_suites()` 会把它当作「无人认领的场景工作区」从导航列表里直接隐藏；前端 Layout
随后命中兜底重定向 `navigate('/scenes/suites')` —— 表现就是「点击后跳到场景管理」。

本补丁包给两处收口：
1. **入口定位（数据层）**：入口工作区 `placement=aiWorkbench`，前端路由归属 `agent`（工作台模块），
   不再命中场景重定向，也不会出现在场景管理页。
2. **显式排除（后端代码层）**：`_attach_scene_suites()` 增加显式排除名单，命中即不隐藏、不挂场景套件，
   作为「就算有人把它改回 `sceneWorkspace`，场景管理也不接管」的保险。

## 适用对象

托管安装的 Flocks（`/opt/flockspro`）。目标文件：

```
/opt/flockspro/releases/<版本>/runtime/flocks/flocks/server/routes/webui.py
```

本包在 `2026.11.12.2-darwin-arm64` 上验证（原始 sha256 `cd3bcdec…1109`，补丁后 `d8222455…0ba9`）。

## 快速使用

```bash
./check.sh                        # 看状态（不改文件）
./apply.sh --dry-run              # 预演，只看会插入什么
sudo ./apply.sh                   # 应用（自动备份 + 写盘自校验 + py_compile）
sudo ./install_data.sh            # 安装「SOC 态势」入口数据（默认写用户插件目录）
sudo ./revert.sh                  # 回滚（校验后还原原始文件）
```

自动探测最新 release；多版本并存时显式指定：

```bash
sudo ./apply.sh --target /opt/flockspro/releases/<版本>/runtime/flocks/flocks/server/routes/webui.py
```

其他环境如果入口不是这个 id/标题，生成排除名单时直接覆盖：

```bash
sudo ./apply.sh --workspace-id <真实工作区id> --title "<真实标题>" --title "<English 标题>"
sudo ./install_data.sh --workspace-id <真实工作区id> --title "<真实标题>" --data-root <数据根目录>
```

## 改了哪几处

目标文件里定位的是**模式**，不写死行号（行号会随版本漂移）：

**A. 排除名单 + 判定函数**（插在 `def _attach_scene_suites(...)` 之前）

```python
EXCLUDED_SCENE_WORKSPACE_IDS: frozenset[str] = frozenset({"soc_posture_ui"})
EXCLUDED_SCENE_WORKSPACE_TITLES: frozenset[str] = frozenset({"SOC 态势", "SOC Posture"})

def _scene_excluded(workspace: WebUIWorkspaceListItem) -> bool:
    """True when the scene manager must leave this entry alone."""
    ...
```

**B. `_attach_scene_suites()` 循环开头命中即放行**

```python
for workspace in workspaces:
    if _scene_excluded(workspace):
        ...
        log.info("webui.workspaces.scene_excluded", {"workspaceId": workspace.id})
        result.append(workspace.model_copy(update={"suiteId": None}))
        continue
    suite_id = owners.get(workspace.id)
```

**C. 去重日志集合** `_scene_excluded_logged: set[str] = set()`（`_hidden_scene_workspaces_logged` 之后）

**D. 函数 docstring** 补充一句：排除名单内的入口既不是场景也不是残留，保持可达且不挂套件。

## 数据层：为什么无需重启

入口数据 `~/.flocks/plugins/contracts/webui/<id>/workspace.json` 的 `placement` 是**运行时读盘**的，
改成 `aiWorkbench` 后立即生效：

- 左侧「工作台」卡片列表取 `placement==='aiWorkbench' && enabled && !locked` 的工作区页面 → 入口出现；
- 前端 `resolveNavRoute` 对 `aiWorkbench` 工作区判为 `agent` 模块 → 不触发 `/scenes/suites` 重定向；
- 场景管理页只列 `/api/hub/scene-suites` 的套件 → 该入口没有套件，自然不出现。

后端代码层（A~D）**必须重启**才载入：`flocks restart --server-only`。

## 安全设计

- **匹配唯一性**：四个锚点各必须出现 1 次，否则报错退出，不做任何修改（结构漂移样本已实测）。
- **幂等**：已打补丁返回「无需修改」，退出码 2，不重复写入。
- **备份**：写盘前备份到包内 `backups/` 和目标同目录 `.bak-<UTC 时间戳>`。
- **写盘后自校验**：四处标记齐备、括号配平、内容与预期一致；再跑 `py_compile` 语法校验，任一失败**自动回滚**。
- **长度校验**：写盘前后字节差必须等于预期插入长度，防止替换越界。
- **回滚**：优先用包内 `orig/webui.py`，退化为同目录最新 `.bak-*`；回滚前先留一份 `.pre-revert-*`。
- **数据安装幂等**：目标文件存在且内容相同→跳过；内容不同→保留原文件并提示，不覆盖。

退出码：`0` 成功/已最新，`2` 无事可做，`3` 模式不匹配或校验失败（已回滚），`4` 环境问题。

## 验证（本机自测记录 2026-11-12）

```bash
PY=/opt/flockspro/releases/2026.11.12.2-darwin-arm64/runtime/python/bin/python3
$PY patch.py --check                                  # patched（线上现状）
$PY patch.py --target <原始副本> --backup-dir <tmp>    # 应用后与线上补丁文件 sha256 完全一致
$PY patch.py --target <原始副本>                       # 二次执行：退出码 2，未改文件
$PY patch.py --target <原始副本> --revert              # 回滚后 sha256 == 原始 cd3bcdec…1109
$PY patch.py --target <漂移样本>                       # 退出码 3，文件未改
$PY patch.py --install-data --data-root <tmp>          # 生成的入口数据与线上逐字节一致（除构建产物 dist/）
$PY tools/check_scene_exclusion.py                     # 后端排除名单回归：5 项断言全 PASS
$PY tools/check_workbench_shortcut.py                  # 工作台入口定位：6 项断言全 PASS
```

## 注意事项

- 后端改动需重启生效；重启会中断当前会话，请自行选择时机。
- 升级到新 release 会生成新的 release 目录，补丁失效，需对新版本重新执行 `./apply.sh`。
- 本包**不修改**前端产物 `runtime/webui-dist`；如需再加一道前端守卫（命中排除名单不重定向
  `/scenes/suites`），另行打补丁。
- 入口页面的 `dist/` 构建产物由 Flocks 服务自动生成，本包只投源码与清单。
