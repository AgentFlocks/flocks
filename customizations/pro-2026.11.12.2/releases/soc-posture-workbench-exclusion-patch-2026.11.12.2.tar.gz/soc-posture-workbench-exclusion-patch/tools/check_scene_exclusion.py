from __future__ import annotations

import json
import sys

from flocks.contracts.webui.models import WebUIWorkspaceListItem
from flocks.contracts.webui.store import WebUIPagesStore, get_webui_pages_root
from flocks.hub.catalog import scene_suite_workspace_owners
from flocks.server.routes.webui import _attach_scene_suites


def show(title: str, workspaces) -> None:
    print(f"--- {title}")
    for workspace in workspaces:
        print(
            "   ",
            json.dumps(
                {
                    "id": workspace.id,
                    "title": workspace.title,
                    "placement": workspace.placement,
                    "enabled": workspace.enabled,
                    "native": workspace.native,
                    "suiteId": workspace.suiteId,
                },
                ensure_ascii=False,
            ),
        )


def main() -> int:
    root = get_webui_pages_root()
    print("webui pages root:", root)
    store = WebUIPagesStore()
    raw = store.list_workspaces()
    show("list_workspaces (raw, before _attach_scene_suites)", raw)

    print("owners:", json.dumps(scene_suite_workspace_owners(), ensure_ascii=False))
    attached = _attach_scene_suites(raw)
    show("after _attach_scene_suites (what the WebUI navigation receives)", attached)

    ids = {item.id for item in attached}
    print("soc_posture_ui visible to navigation:", "soc_posture_ui" in ids)
    print("soc_posture_ui listed as a scene suite owner:", "soc_posture_ui" in scene_suite_workspace_owners().values())

    synthetic = [
        WebUIWorkspaceListItem(
            id="soc_posture_ui",
            title="SOC 态势",
            route="/contracts/webui/workspaces/soc_posture_ui",
            icon="ShieldCheck",
            order=20,
            enabled=True,
            placement="sceneWorkspace",
            native=False,
            suiteId=None,
        ),
        WebUIWorkspaceListItem(
            id="unmanaged_demo_ui",
            title="无人认领演示场景",
            route="/contracts/webui/workspaces/unmanaged_demo_ui",
            icon="ShieldCheck",
            order=21,
            enabled=True,
            placement="sceneWorkspace",
            native=False,
            suiteId=None,
        ),
        WebUIWorkspaceListItem(
            id="soc_ui",
            title="SOC 工作区",
            route="/contracts/webui/workspaces/soc_ui",
            icon="ShieldCheck",
            order=10,
            enabled=True,
            placement="sceneWorkspace",
            native=False,
            suiteId=None,
        ),
        WebUIWorkspaceListItem(
            id="workbench_shortcut_ui",
            title="工作台快捷入口",
            route="/contracts/webui/workspaces/workbench_shortcut_ui",
            icon="ShieldCheck",
            order=30,
            enabled=True,
            placement="aiWorkbench",
            native=False,
            suiteId=None,
        ),
    ]
    result = _attach_scene_suites(synthetic)
    show("synthetic case", result)
    surviving = {item.id: item for item in result}
    checks = [
        ("excluded 入口被保留", "soc_posture_ui" in surviving),
        ("excluded 入口不挂场景套件", surviving.get("soc_posture_ui") is not None and surviving["soc_posture_ui"].suiteId is None),
        ("无人认领场景仍被隐藏", "unmanaged_demo_ui" not in surviving),
        ("有套件认领的场景被保留并挂 suiteId", surviving.get("soc_ui") is not None and surviving["soc_ui"].suiteId == "soc-workspace"),
        ("工作台放置的工作区不受影响", "workbench_shortcut_ui" in surviving),
    ]
    failed = 0
    print("--- checks")
    for name, ok in checks:
        print(("    PASS  " if ok else "    FAIL  ") + name)
        failed += 0 if ok else 1
    print("RESULT:", "PASS" if failed == 0 else f"FAIL ({failed})")
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
