from __future__ import annotations

import json
import sys

from flocks.contracts.webui.store import WebUIPagesStore
from flocks.hub.catalog import scene_suite_workspace_owners
from flocks.server.routes.webui import _attach_scene_suites

WORKSPACE_ID = "soc_posture_ui"

# Mirrors of the shipped WebUI navigation rules (runtime/webui-dist/assets/index-DjHPPRaw.js):
#   workbench section items = workspaces.filter(placement === 'aiWorkbench' && enabled && !locked)
#                             .flatMap(pages.filter(enabled && buildStatus === 'ready'))
#   open scene workspaces  = workspaces.filter(placement === 'sceneWorkspace' && enabled && !locked)
#   Layout redirect        = route resolves to 'scene:<id>' && <id> not in open scene workspaces
#                            -> navigate('/scenes/suites')
def route_workspace_of(placement: str) -> str:
    return "agent" if placement == "aiWorkbench" else f"scene:{WORKSPACE_ID}"


def main() -> int:
    workspaces = _attach_scene_suites(WebUIPagesStore().list_workspaces())
    by_id = {item.id: item for item in workspaces}
    workspace = by_id.get(WORKSPACE_ID)
    if workspace is None:
        print("FAIL: workspace missing from the navigation list")
        return 1

    print("workspace:", json.dumps(
        {
            "id": workspace.id,
            "title": workspace.title,
            "placement": workspace.placement,
            "enabled": workspace.enabled,
            "locked": workspace.locked,
            "suiteId": workspace.suiteId,
        },
        ensure_ascii=False,
    ))

    ready_pages = [
        json.dumps({"id": page.id, "title": page.title, "enabled": page.enabled, "buildStatus": page.buildStatus}, ensure_ascii=False)
        for page in workspace.pages
        if page.enabled and page.buildStatus == "ready"
    ]
    print("workbench card entries from this workspace:", ready_pages or "NONE")

    is_workbench_entry = workspace.placement == "aiWorkbench" and workspace.enabled and not workspace.locked
    is_open_scene = workspace.placement == "sceneWorkspace" and workspace.enabled and not workspace.locked
    route_owner = route_workspace_of(workspace.placement)
    redirects_to_scene_manager = route_owner.startswith("scene:") and not is_open_scene
    listed_as_scene_suite = WORKSPACE_ID in scene_suite_workspace_owners()

    checks = [
        ("入口出现在左侧「工作台」卡片列表（placement=aiWorkbench & enabled & !locked）", is_workbench_entry),
        ("入口页面可渲染（至少 1 个 enabled & buildStatus=ready 页面）", bool(ready_pages)),
        ("路由归属为工作台模块（agent），不是 scene:<id>", route_owner == "agent"),
        ("点击后不会命中「场景打不开」重定向到 /scenes/suites", not redirects_to_scene_manager),
        ("场景管理（/api/hub/scene-suites）中不含该入口", not listed_as_scene_suite),
        ("后端仍显式排除该入口（suiteId 为空、未被当作无人认领场景隐藏）", by_id.get(WORKSPACE_ID) is not None and workspace.suiteId is None),
    ]

    failed = 0
    print("--- checks")
    for name, ok in checks:
        print(("    PASS  " if ok else "    FAIL  ") + name)
        failed += 0 if ok else 1
    print("RESULT:", "PASS" if failed == 0 else f"FAIL ({failed})")
    return 0 if failed == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
