# Hide Knowledge and Memory sidebar entries

Target: Flocks Pro 2026.11.12.2, `fix/process_11.12_en` source tree.

This patch removes the “Knowledge Base” and “Memory” entries and their “Knowledge and Memory” group from the Agent Workshop sidebar. It leaves the underlying workspace tabs and direct routes unchanged.

Apply from the repository root:

```sh
patch -p1 < webui/src/components/layout/Layout.tsx.patch
```

Then rebuild the Pro WebUI using the matching Core and Pro extension registry and the repository's locked dependencies. No runtime environment retest was performed for this delivery, per request.
