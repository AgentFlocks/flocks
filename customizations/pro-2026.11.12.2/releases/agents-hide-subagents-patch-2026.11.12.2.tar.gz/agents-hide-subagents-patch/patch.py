#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Flocks 源码补丁：隐藏「Agent 车间 → 智能体」列表中的两个子智能体。

改动对象是 flocks 源码仓库（https://github.com/AgentFlocks/flocks）中随包发布的
默认插件定义：

  .flocks/plugins/agents/device-inspector/agent.yaml   设备巡检智能体
  .flocks/plugins/agents/ti-analyst/agent.yaml         威胁情报智能体

两处均只改一个顶层字段：`hidden: false` -> `hidden: true`。

为什么用 git 补丁：
  补丁由 `git format-patch` 生成，既可以 `git apply` 落到工作区，也可以 `git am`
  保留提交信息与作者，便于向上游提 PR / 合并。

语义提醒（重要）：
  `hidden: true` 会让后端列表接口（flocks/server/routes/agent.py 的 list_agents）
  跳过该 agent，同时 `flocks/agent/registry.py:is_delegatable()` 返回 false ——
  即「智能体」页不再展示，Rex 也不再自动委派「设备巡检 / 威胁情报」任务。
  若只想隐藏 UI 而保留委派能力，请改用 `tags: [system]`
  （与 explore / oracle / librarian 等系统子智能体一致）。

用法：
  python3 patch.py                     # 应用补丁（先 --check，再 git apply）
  python3 patch.py --dry-run           # 只做 --check，不写入
  python3 patch.py --check             # 只报告当前状态
  python3 patch.py --revert            # 反向应用
  python3 patch.py --am                # 用 git am 应用（保留提交信息）
  python3 patch.py --repo <dir>        # 指定 flocks 源码仓库
  python3 patch.py --patch <file>      # 指定 .patch 文件

退出码：0 成功（或状态正常）；2 无事可做（已应用 / 未应用）；3 补丁不适用或状态漂移；4 环境问题。
"""
from __future__ import annotations

import argparse
import os
import subprocess
import sys

TARGETS = (
    ".flocks/plugins/agents/device-inspector/agent.yaml",
    ".flocks/plugins/agents/ti-analyst/agent.yaml",
)
PATCH_SUBJECT_PREFIX = "fix(agents): hide device-inspector"


def log(msg):
    sys.stdout.write(msg + "\n")
    sys.stdout.flush()


def die(msg, code=3):
    sys.stderr.write("ERROR: " + msg + "\n")
    sys.exit(code)


def git(repo, *args):
    return subprocess.run(
        ["git", *args],
        cwd=repo,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
    )


def resolve_repo(explicit):
    start = explicit or os.environ.get("FLOCKS_SRC_REPO") or os.getcwd()
    start = os.path.abspath(start)
    if not os.path.isdir(start):
        die("仓库目录不存在: %s" % start, 4)
    d = start
    while True:
        if os.path.exists(os.path.join(d, ".git")) and os.path.isfile(os.path.join(d, TARGETS[0])):
            return d
        parent = os.path.dirname(d)
        if parent == d:
            die(
                "未找到 flocks 源码仓库（需同时含 .git 与 %s）；请用 --repo 指定" % TARGETS[0],
                4,
            )
        d = parent


def resolve_patch(explicit, script_dir):
    if explicit:
        if not os.path.isfile(explicit):
            die("补丁文件不存在: %s" % explicit, 4)
        return os.path.abspath(explicit)
    cands = sorted(
        os.path.join(script_dir, n) for n in os.listdir(script_dir) if n.endswith(".patch")
    )
    if len(cands) != 1:
        die("脚本目录内 .patch 数量为 %d，请用 --patch 指定一个: %s" % (len(cands), script_dir), 4)
    return cands[0]


def can_apply(repo, patch, reverse=False):
    args = ["apply", "--check"]
    if reverse:
        args.append("--reverse")
    args.append(patch)
    return git(repo, *args).returncode == 0


def patch_state(repo, patch):
    if can_apply(repo, patch, reverse=True):
        return "applied"
    if can_apply(repo, patch):
        return "pristine"
    return "drift"


def hidden_value(path):
    if not os.path.isfile(path):
        return "<missing>"
    with open(path, encoding="utf-8") as fh:
        for line in fh:
            if line.startswith("hidden:"):
                return line.strip()
    return "<no hidden key>"


def report_targets(repo):
    for t in TARGETS:
        log("  %-52s %s" % (t, hidden_value(os.path.join(repo, t))))


def cmd_check(repo, patch):
    st = patch_state(repo, patch)
    log("repo  : %s" % repo)
    log("patch : %s" % patch)
    log("state : %s" % st)
    report_targets(repo)
    if st == "drift":
        log("--- git apply --check --verbose ---")
        log(git(repo, "apply", "--check", "--verbose", patch).stdout.rstrip())
        return 3
    return 0


def cmd_apply(repo, patch, dry_run, use_am):
    st = patch_state(repo, patch)
    if st == "applied":
        log("无需修改：补丁已应用")
        return 2
    if st == "drift":
        log("补丁无法干净应用，目标文件可能已被改动：")
        log(git(repo, "apply", "--check", "--verbose", patch).stdout.rstrip())
        return 3
    if dry_run:
        log("dry-run：--check 通过，未写入任何文件")
        report_targets(repo)
        return 0

    if use_am:
        proc = git(repo, "am", patch)
        if proc.returncode != 0:
            git(repo, "am", "--abort")
            die("git am 失败，已 abort：\n%s" % proc.stdout.rstrip(), 3)
    else:
        proc = git(repo, "apply", patch)
        if proc.returncode != 0:
            die("git apply 失败：\n%s" % proc.stdout.rstrip(), 3)

    for t in TARGETS:
        if hidden_value(os.path.join(repo, t)) != "hidden: true":
            if not use_am:
                git(repo, "apply", "--reverse", patch)
            die("写盘后自校验失败（%s 未变成 hidden: true），已回滚" % t, 3)

    log("已应用（%s）" % ("git am" if use_am else "git apply"))
    if use_am:
        log(git(repo, "show", "--stat", "--oneline", "HEAD").stdout.rstrip())
    else:
        log(git(repo, "diff", "--stat").stdout.rstrip())
    log("提示：这只改了源码/默认副本。运行中的 Flocks 还需重装或同步")
    log("      <FLOCKS_HOME>/plugins/agents/<name>/agent.yaml，再到「智能体」页点刷新。")
    return 0


def cmd_revert(repo, patch):
    st = patch_state(repo, patch)
    if st == "pristine":
        log("无需回滚：补丁未应用")
        return 2
    if st == "drift":
        log("状态漂移：补丁既不适用也无法反向应用，未做任何修改")
        return 3

    proc = git(repo, "apply", "--reverse", patch)
    if proc.returncode != 0:
        die("git apply --reverse 失败：\n%s" % proc.stdout.rstrip(), 3)

    for t in TARGETS:
        if hidden_value(os.path.join(repo, t)) != "hidden: false":
            die("回滚后校验失败（%s 未恢复 hidden: false）" % t, 3)

    log("已回滚")
    log(git(repo, "diff", "--stat").stdout.rstrip() or "(工作区已干净)")
    head = git(repo, "log", "-1", "--format=%s").stdout.strip()
    if head.startswith(PATCH_SUBJECT_PREFIX):
        log("注意：HEAD 仍是补丁提交（%s）。" % head)
        log("      要用 --am 应用后彻底撤销提交，请另执行：git reset --hard <base-commit>")
    return 0


def main():
    ap = argparse.ArgumentParser(
        description="Flocks 源码补丁：隐藏 device-inspector / ti-analyst 子智能体"
    )
    ap.add_argument("--repo", help="flocks 源码仓库路径；默认从当前目录向上探测，或 $FLOCKS_SRC_REPO")
    ap.add_argument("--patch", help=".patch 文件；默认脚本目录下的唯一 .patch")
    ap.add_argument("--dry-run", action="store_true", help="只做 git apply --check，不写入")
    ap.add_argument("--check", action="store_true", help="只报告当前状态")
    ap.add_argument("--revert", action="store_true", help="反向应用")
    ap.add_argument("--am", action="store_true", help="用 git am 应用（保留提交信息与作者）")
    args = ap.parse_args()

    script_dir = os.path.dirname(os.path.abspath(__file__))
    repo = resolve_repo(args.repo)
    patch = resolve_patch(args.patch, script_dir)

    if args.check:
        return cmd_check(repo, patch)
    if args.revert:
        return cmd_revert(repo, patch)
    return cmd_apply(repo, patch, args.dry_run, args.am)


if __name__ == "__main__":
    sys.exit(main())
