# Flocks 源码补丁：隐藏「智能体」列表中的设备巡检 / 威胁情报子智能体

把 flocks 源码仓库中随包发布的两个安全子智能体的默认定义标记为 `hidden: true`，
使它们不再出现在 **Agent车间 → 能力编排 → 智能体** 页面的子智能体列表里。

- `.flocks/plugins/agents/device-inspector/agent.yaml` —— 设备巡检智能体
- `.flocks/plugins/agents/ti-analyst/agent.yaml` —— 威胁情报智能体

改的是一个顶层字段：`hidden: false` → `hidden: true`（两文件各 1 行）。

## 适用对象

flocks 源码仓库（`https://github.com/AgentFlocks/flocks`，本补丁基线 `main@6dd8470`）。
补丁由 `git format-patch` 生成，既可 `git apply` 落到工作区，也可 `git am` 保留提交信息用于提 PR。

依赖：`git`（≥ 2.x）与 `python3`（脚本仅用标准库，已在 3.9.6 验证）。

## 快速使用

```bash
# 0) 指定源码仓库；也可在仓库目录内直接运行（自动向上探测），或设 $FLOCKS_SRC_REPO
REPO=/path/to/flocks

# 1) 先看状态（不改文件）
./check.sh --repo "$REPO"

# 2) 预演，只做 git apply --check
./apply.sh --repo "$REPO" --dry-run

# 3) 应用（落到工作区，不产生提交）
./apply.sh --repo "$REPO"

# 3b) 或保留提交信息应用（便于提 PR / 合并）
./apply.sh --repo "$REPO" --am

# 4) 回滚
./revert.sh --repo "$REPO"
```

不带参数时，脚本从当前目录向上查找「同时含 `.git` 与 `.flocks/plugins/agents/device-inspector/agent.yaml`」的目录作为仓库根。

## 改了哪两处

```diff
--- a/.flocks/plugins/agents/device-inspector/agent.yaml
+++ b/.flocks/plugins/agents/device-inspector/agent.yaml
@@ -11,7 +11,7 @@ description_cn: >-
 mode: subagent
 strategy: react
 delegatable: true
-hidden: false
+hidden: true
 tags:
```

```diff
--- a/.flocks/plugins/agents/ti-analyst/agent.yaml
+++ b/.flocks/plugins/agents/ti-analyst/agent.yaml
@@ -12,7 +12,7 @@ description_cn: >-
 mode: subagent
-hidden: false
+hidden: true
 color: "#E74C3C"
 delegatable: true
```

## 语义与副作用（务必确认）

后端 `GET /api/agents` 会跳过 `hidden: true` 的 agent（`flocks/server/routes/agent.py` 的 `list_agents`），
因此「智能体」页不再展示；同时 `flocks/agent/registry.py` 的 `is_delegatable()`
要求 `not agent.hidden`，所以 **Rex 也不再自动委派「设备巡检 / 威胁情报」这两类任务**，
会话内也不可再选中它们（`flocks/server/routes/session.py`）。

> 如果只想 **隐藏 UI 入口、但保留委派能力**，请改用 `tags: [system]`
> （前端 `webui/src/pages/Agent/index.tsx` 过滤 `mode!=='primary' && !tags.includes('system')`）。
> 这与内置的 explore / oracle / librarian 等系统子智能体一致。

## 生效路径（源码补丁只是第一步）

本补丁只改 **源码 / 默认定义**。要让 **运行中的** Flocks 生效，需要：

1. 重新打包/安装 release（内置副本 `.flocks/plugins/agents/...` → 安装时落到
   `<FLOCKS_HOME>/plugins/agents/<name>/agent.yaml`）；或
2. 直接同步运行实例：把 `<FLOCKS_HOME>/plugins/agents/<name>/agent.yaml` 里的
   `hidden` 改为 `true`（本机即 `/var/root/.flocks/plugins/agents/<name>/agent.yaml`）；
3. 无论哪条路，改完都要在 **Agent车间 → 智能体** 页点「刷新」
   （`POST /api/agents/refresh`）或重启服务，注册表缓存才会重载。

## 安全设计

- **不写死行号**：靠 `git apply --check` 与补丁上下文定位；行号漂移不影响。
- **状态机**：`pristine`（未应用）/ `applied`（已应用）/ `drift`（既不适用也无法反向应用）。
  `drift` 一律退出码 3，**不做任何修改**。
- **写入后自校验**：`git apply` 后逐文件确认 `hidden: true` 出现，否则自动 `git apply --reverse` 回滚。
- **幂等**：重复执行返回「无需修改」，退出码 2，不改文件。
- **可回滚**：`revert.sh` 反向应用后逐文件确认恢复 `hidden: false`；用 `--am` 应用时另提示 `git reset --hard <base>`。

退出码：`0` 成功或状态正常，`2` 无事可做，`3` 补丁不适用/状态漂移，`4` 环境问题。

## 本机验证记录（2026-11-12）

对 `main@6dd8470` 的干净 worktree 实测：

| 用例 | 预期 | 实测 |
|---|---|---|
| `check.sh`（干净库） | state: pristine，rc=0 | 通过 |
| `apply.sh --dry-run` | rc=0，工作区无改动 | 通过（`git status` 空） |
| `apply.sh` | rc=0，两文件变 `hidden: true` | 通过 |
| `check.sh`（已应用） | state: applied | 通过 |
| `apply.sh` 二次执行 | rc=2「无需修改」，文件不变 | 通过 |
| `revert.sh` | rc=0，`git diff` 对基线为空 | 通过（逐字节一致） |
| 漂移样本（改 `hidden` 行） | state: drift，rc=3，文件未改 | 通过 |
| `apply.sh --am` | rc=0，产生提交并保留提交信息 | 通过（HEAD 为补丁提交） |
| `--am` 后 `revert.sh` | rc=0，并提示 HEAD 仍是补丁提交 | 通过 |

补丁基线 `6dd8470` → 提交 `3b54d0c`
（subject：`fix(agents): hide device-inspector and ti-analyst from the agents UI`）。

## 注意事项

- 基线是 `main@6dd8470`。上游这两个文件若有改动，补丁可能判定为 `drift`（rc=3），
  此时需基于新基线重新生成补丁，不要强行应用。
- `--am` 需要 git 已配置 `user.name` / `user.email`（或设置 `GIT_AUTHOR_*` / `GIT_COMMITTER_*`）；
  未配置会失败并自动 `git am --abort`。
- `--am` 应用后 `revert.sh` 只回滚工作区内容，补丁提交仍在 HEAD；彻底撤销用
  `git reset --hard <base-commit>`（基线即 `6dd8470`）。
- 本机（release `2026.11.12.2-darwin-arm64`）的运行实例此前已直接改过
  `/var/root/.flocks/plugins/agents/<name>/agent.yaml`；本补丁面向源码/其他环境。
- 补丁只动这两个 YAML，不改任何工具、权限或提示词。
