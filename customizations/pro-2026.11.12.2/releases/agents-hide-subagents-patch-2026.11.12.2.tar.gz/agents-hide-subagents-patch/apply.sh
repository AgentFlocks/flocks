#!/usr/bin/env bash
# 应用补丁：隐藏 Agent 车间「智能体」列表里的 device-inspector / ti-analyst
# 用法： ./apply.sh [--repo <flocks 源码目录>] [--patch <file>] [--dry-run] [--am]
set -euo pipefail
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
exec python3 "$DIR/patch.py" "$@"
