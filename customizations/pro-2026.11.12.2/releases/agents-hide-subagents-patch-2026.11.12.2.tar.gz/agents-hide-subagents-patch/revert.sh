#!/usr/bin/env bash
# 回滚：反向应用补丁（git apply --reverse）
# 用法： ./revert.sh [--repo <flocks 源码目录>] [--patch <file>]
set -euo pipefail
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
exec python3 "$DIR/patch.py" --revert "$@"
