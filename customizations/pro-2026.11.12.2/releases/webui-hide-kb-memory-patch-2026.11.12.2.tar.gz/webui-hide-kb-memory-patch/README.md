# WebUI 补丁：隐藏 Agent 车间「知识与记忆」

在 Flocks WebUI 上隐藏「Agent 车间」侧边栏的 **知识与记忆** 分组（含「知识库」「记忆」两个入口），
同时让 `/workspace?tab=knowledge|memory` 这两个标签页**留在「工作目录」（工作台）模块内**打开，
不再跳到 Agent 车间。

「工作目录」页本身不动：`/workspace` 顶部的 `文件管理 / 记忆文件 / 知识库` 三个标签页保持原样。

## 适用对象

托管安装的 Flocks（`/opt/flockspro`）：线上界面由固定目录 `runtime/webui-dist` 提供，
补丁直接作用在该目录的 Vite 入口 chunk 上。

> 重要：release 里随附的源码树 `runtime/flocks/webui/src` 与线上产物**不同源**
> （产物含源码中不存在的企业版模块：`voice` 语音输入、`consoleUpgrade` 托管升级流、
> `ProDialogShell`、`LegacyRedirect`）。**不要**用那份源码 `npm run build` 重建前端，
> 会静默丢失企业版功能。所以补丁走产物定点裁剪。

## 快速使用

```bash
# 1) 先看当前状态（不改文件）
./check.sh

# 2) 预演，只看会删掉哪两段
./apply.sh --dry-run

# 3) 应用（自动备份 + 写盘后自校验 + 语法校验）
sudo ./apply.sh

# 4) 回滚（用最近一次 .bak-* 备份）
sudo ./revert.sh
```

自动探测 `webui-dist`，顺序：`--dist` 参数 → `$FLOCKS_WEBUI_DIST_DIR` →
`/opt/flockspro/releases/<版本>/runtime/webui-dist`（版本倒序）→ `/opt/flockspro/current/runtime/webui-dist`。
多版本并存时建议显式指定：`./apply.sh --dist /opt/flockspro/releases/<版本>/runtime/webui-dist`。

## 改了哪两处

入口 chunk 文件名带内容哈希、跨版本会变，因此脚本按**模式**定位，不写死文件名。

**A. 删除侧边栏分组对象**（`workshopSections` 中 id 为 `knowledge-memory` 的对象）

```js
{id:"knowledge-memory",name:a("knowledgeAndMemory"),items:[{name:a("knowledgeBase"),href:"/workspace?tab=knowledge",icon:ma},{name:a("memory"),href:"/workspace?tab=memory",icon:_r}]},
```

正则：`\{id:"knowledge-memory",name:[^{}\[\]]*,items:\[[^\[\]]*\]\}`（连带清理多余的逗号）

**B. 删除 `/workspace` 标签页的模块归属判定子句**（`resolveNavRoute`）

```js
if(bS.some(a)||s.some(u=>a(u.split("?")[0]))||n==="/workspace"&&(i==="knowledge"||i==="memory"))
  return{kind:"workspace",workspace:"agent-workshop"};
```

正则：`\|\|[A-Za-z_$][\w$]*==="/workspace"&&\([A-Za-z_$][\w$]*==="knowledge"\|\|[A-Za-z_$][\w$]*==="memory"\)`

删掉后 `/workspace`（含 `?tab=knowledge|memory`）走默认分支 `{kind:"workspace",workspace:"agent"}`，
与 `?tab=files` 行为一致，侧边栏保持「工作台」且高亮「工作目录」。
浏览器里可能残留的「Agent 车间 上次访问路径 = /workspace?tab=knowledge」会在下次加载时自动失效重算。

## 安全设计

- **匹配不到就中止**：A/B 都匹配不到时报告「无需修改」；只匹配到 `knowledge-memory` 字样但对象结构不符时直接报错退出，不做任何修改。
- **写盘前校验**：删除前后 `{} () []` 计数必须一致，否则判定匹配越界并中止。
- **写盘后校验**：重读磁盘，确认字节数等于原大小减去被删片段、括号计数一致、两处模式均已消失；任一不满足自动回滚备份。
- **语法校验**：能找到 `esbuild` 时（同目录 `../flocks/webui/node_modules/.bin/esbuild`、`$ESBUILD_BIN` 或 PATH）解析入口文件，失败即自动回滚；找不到则跳过并提示。
- **幂等**：重复执行返回「补丁已应用」，退出码 2，不改文件。

退出码：`0` 成功或已是最新，`2` 无事可做，`3` 模式不匹配/校验失败，`4` 环境问题。

## 验证

```bash
./check.sh                        # state: patched
grep -c knowledge-memory <dist>/assets/<entry>.js   # 0
```

浏览器侧：因为入口文件名不变、服务端对 assets 下发 `immutable, max-age=31536000` 缓存头，
**已打开过的浏览器需要硬刷新一次**（Cmd/Ctrl+Shift+R）才会生效；新会话/新浏览器无此问题。
服务端按请求从磁盘读文件，**不需要重启 Flocks**。

## 注意事项

- 升级到新版本会生成新的 release 目录，补丁失效，需对新版本再次执行 `./apply.sh`。
- `flocks-webui-manifest.json` 记录的是原始构建信息，补丁不改它；该文件不被运行时校验使用，仅意味着其中该 chunk 的摘要与实际文件不一致。
- 仅适用于通过 `/workspace` 页面进入的场景：`/workspace?tab=knowledge|memory` 直接输 URL 仍可访问（这是刻意的，标签页保留）。
- 脚本以文件方式修改前端产物，属受控变更；请在生产前先 `--dry-run` 并在测试环境验证。

## 本机验证记录（2026-11-12）

- 目标版本：`2026.11.12.2-darwin-arm64`，入口 chunk `runtime/webui-dist/assets/index-DjHPPRaw.js`
- 原产物 `431392` 字节 `sha256 574cdcf1…4320dc` → 打完 `431158` 字节 `sha256 7dc452fb…41a23`
- 自测：对原产物副本执行本脚本，结果与线上已手工打的补丁**逐字节一致**；二次执行返回「已应用」；`--revert` 后与原始文件逐字节一致。
