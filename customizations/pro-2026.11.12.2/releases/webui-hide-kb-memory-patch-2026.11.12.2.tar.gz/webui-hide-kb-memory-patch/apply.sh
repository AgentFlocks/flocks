#!/usr/bin/env bash
# 应用补丁：隐藏 Agent 车间「知识与记忆」分组 + 修正 /workspace tab 模块归属
# 用法： ./apply.sh [--dist <webui-dist>] [--dry-run]
set -euo pipefail
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
exec python3 "$DIR/patch.py" "$@"
