#!/usr/bin/env bash
# 查看当前状态（不改动任何文件）
# 用法： ./check.sh [--dist <webui-dist>]
set -euo pipefail
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
exec python3 "$DIR/patch.py" --check "$@"
