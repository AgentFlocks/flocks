#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Flocks WebUI 补丁：隐藏「Agent 车间」侧边栏的「知识与记忆」分组，
并让 /workspace?tab=knowledge|memory 归属「工作目录」（工作台）模块。

改动对象是线上实际提供的构建产物：
  <webui-dist>/index.html 引用的 Vite 入口 chunk（通常是 assets/index-*.js）

入口 chunk 的文件名带内容哈希，不同版本会变，所以本脚本按「模式」定位要删除的
片段，不写死文件名与哈希；匹配不到就中止，不做任何修改。

两处删除（均为可逆、幂等的纯文本删除）：
  A. workshopSections 里 id 为 "knowledge-memory" 的分组对象（含「知识库」「记忆」两项）
  B. resolveNavRoute 里 "/workspace + tab=knowledge|memory 归 agent-workshop" 的判定子句

用法：
  python3 patch.py                # 应用补丁（自动备份 + 自校验）
  python3 patch.py --dry-run      # 只看会删什么，不落盘
  python3 patch.py --check        # 只报告当前状态
  python3 patch.py --revert       # 用最近一次备份还原
  python3 patch.py --dist <dir>   # 指定 webui-dist 目录（默认自动探测）

退出码：0 成功（或已是最新）；2 无事可做；3 模式不匹配/校验失败；4 环境问题。
"""
from __future__ import annotations

import argparse
import datetime
import hashlib
import os
import re
import shutil
import subprocess
import sys

SECTION_RE = re.compile(r'\{id:"knowledge-memory",name:[^{}\[\]]*,items:\[[^\[\]]*\]\}')
ROUTE_RE = re.compile(
    r'\|\|[A-Za-z_$][\w$]*==="/workspace"&&'
    r'\([A-Za-z_$][\w$]*==="knowledge"\|\|[A-Za-z_$][\w$]*==="memory"\)'
)
ENTRY_RE = re.compile(r'<script[^>]*type="module"[^>]*src="([^"]+\.js)"')
BRACKETS = "{}()[]"

DEFAULT_DIST = "/opt/flockspro/current/runtime/webui-dist"
RELEASES_ROOT = "/opt/flockspro/releases"


def log(msg):
    sys.stdout.write(msg + "\n")
    sys.stdout.flush()


def die(msg, code=3):
    sys.stderr.write("ERROR: " + msg + "\n")
    sys.exit(code)


def sha256_file(path):
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def bracket_counts(text):
    return dict((c, text.count(c)) for c in BRACKETS)


def bracket_balance(text):
    return dict((pair, text.count(pair[0]) - text.count(pair[1])) for pair in ("{}", "()", "[]"))


def find_dist(explicit):
    candidates = []
    if explicit:
        candidates.append(explicit)
    env = os.environ.get("FLOCKS_WEBUI_DIST_DIR")
    if env:
        candidates.append(env)
    if os.path.isdir(RELEASES_ROOT):
        try:
            for name in sorted(os.listdir(RELEASES_ROOT), reverse=True):
                candidates.append(os.path.join(RELEASES_ROOT, name, "runtime", "webui-dist"))
        except OSError:
            pass
    candidates.append(DEFAULT_DIST)
    for cand in candidates:
        if cand and os.path.isfile(os.path.join(cand, "index.html")):
            return os.path.realpath(cand)
    return None


def find_entry(dist):
    index_html = os.path.join(dist, "index.html")
    try:
        with open(index_html, "r", encoding="utf-8", errors="replace") as fh:
            html = fh.read()
    except OSError as exc:
        die("无法读取 %s: %s" % (index_html, exc), 4)
    matches = ENTRY_RE.findall(html)
    if not matches:
        die("%s 里找不到 <script type=\"module\" src=...>，不像是 Flocks 的 webui-dist" % index_html, 4)
    entry = os.path.join(dist, matches[0].lstrip("/"))
    if not os.path.isfile(entry):
        die("index.html 引用的入口 chunk 不存在: %s" % entry, 4)
    return entry


def read_text(path):
    with open(path, "rb") as fh:
        raw = fh.read()
    try:
        return raw.decode("utf-8")
    except UnicodeDecodeError as exc:
        die("%s 不是 UTF-8 文本，拒绝修改: %s" % (path, exc), 4)


def drop_section(text):
    """删除 knowledge-memory 分组对象，并连带清理多余的那个逗号。"""
    m = SECTION_RE.search(text)
    if not m:
        return text, None
    start, end = m.span()
    if text[end:end + 1] == ",":
        end += 1
    elif start > 0 and text[start - 1:start] == ",":
        start -= 1
    return text[:start] + text[end:], text[start:end]


def drop_route_clause(text):
    m = ROUTE_RE.search(text)
    if not m:
        return text, None
    return text[:m.start()] + text[m.end():], m.group(0)


def probe(text):
    return bool(SECTION_RE.search(text)), bool(ROUTE_RE.search(text))


def state_of(text):
    has_section, has_route = probe(text)
    has_marker = "knowledge-memory" in text
    if has_section and has_route:
        return "pristine"
    if not has_section and not has_route and not has_marker:
        return "patched"
    return "partial"


def esbuild_parse_check(entry, dist):
    candidates = []
    explicit = os.environ.get("ESBUILD_BIN")
    if explicit:
        candidates.append(explicit)
    found = shutil.which("esbuild")
    if found:
        candidates.append(found)
    candidates.append(os.path.join(os.path.dirname(dist), "flocks", "webui", "node_modules", ".bin", "esbuild"))
    for cand in candidates:
        if cand and os.path.isfile(cand) and os.access(cand, os.X_OK):
            try:
                proc = subprocess.run(
                    [cand, entry, "--outfile=" + os.devnull, "--log-level=warning"],
                    stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                )
            except OSError:
                continue
            if proc.returncode == 0:
                return cand, None
            return cand, proc.stdout.decode("utf-8", "replace").strip()
    return None, None


def newest_backup(entry):
    folder = os.path.dirname(entry)
    base = os.path.basename(entry) + ".bak-"
    found = [os.path.join(folder, n) for n in os.listdir(folder) if n.startswith(base)]
    if not found:
        return None
    return max(found, key=os.path.getmtime)


def cmd_check(dist, entry, text):
    state = state_of(text)
    has_section, has_route = probe(text)
    log("dist    : %s" % dist)
    log("entry   : %s" % entry)
    log("size    : %d bytes" % len(text.encode("utf-8")))
    log("sha256  : %s" % sha256_file(entry))
    log("state   : %s" % state)
    log("  A 分组对象(knowledge-memory) 存在: %s" % has_section)
    log("  B /workspace tab 路由子句  存在: %s" % has_route)
    backup = newest_backup(entry)
    if backup:
        log("最近备份: %s" % backup)
    return 0 if state in ("patched", "pristine") else 3


def cmd_revert(entry):
    backup = newest_backup(entry)
    if not backup:
        die("找不到备份文件 %s.bak-*，无法还原" % entry, 4)
    shutil.copy2(backup, entry)
    text = read_text(entry)
    log("已从备份还原: %s -> %s" % (backup, entry))
    log("还原后 state: %s" % state_of(text))
    return 0


def cmd_apply(dist, entry, text, dry_run):
    before_bytes = len(text.encode("utf-8"))
    before_balance = bracket_balance(text)

    patched, removed_a = drop_section(text)
    patched, removed_b = drop_route_clause(patched)

    if removed_a is None and removed_b is None:
        if "knowledge-memory" in text:
            die("检测到 knowledge-memory 但对象结构与预期不符（该版本可能被改过），已中止，未做任何修改", 3)
        log("无需修改：补丁已应用，或该版本本就没有这个分组")
        return 2

    log("将删除的片段：")
    if removed_a is not None:
        log("  A (%d 字符): %s" % (len(removed_a), removed_a))
    else:
        log("  A: 未匹配（保持原样）")
    if removed_b is not None:
        log("  B (%d 字符): %s" % (len(removed_b), removed_b))
    else:
        log("  B: 未匹配（保持原样）")

    after_balance = bracket_balance(patched)
    if after_balance != before_balance:
        die("括号配平在删除后发生变化（%s -> %s），说明匹配越界，已中止" % (before_balance, after_balance), 3)

    if dry_run:
        log("dry-run：未写入任何文件")
        return 0

    stamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    backup = "%s.bak-%s" % (entry, stamp)
    shutil.copy2(entry, backup)
    log("已备份: %s" % backup)

    with open(entry, "w", encoding="utf-8") as fh:
        fh.write(patched)

    # 校验：重新读取磁盘内容
    fresh = read_text(entry)
    expect_bytes = before_bytes - sum(len(x.encode("utf-8")) for x in (removed_a, removed_b) if x is not None)
    fresh_bytes = len(fresh.encode("utf-8"))
    has_section, has_route = probe(fresh)
    if fresh_bytes != expect_bytes or bracket_balance(fresh) != before_balance or has_section or has_route:
        shutil.copy2(backup, entry)
        die("写盘后自校验失败（字节数/括号/残留检查），已自动还原备份", 3)

    tool, err = esbuild_parse_check(entry, dist)
    if tool and err:
        shutil.copy2(backup, entry)
        die("语法校验失败，已自动还原备份：\n%s" % err, 3)

    log("写入完成")
    log("  entry : %s" % entry)
    log("  size  : %d -> %d bytes" % (before_bytes, fresh_bytes))
    log("  sha256: %s" % sha256_file(entry))
    log("  语法  : %s" % ("esbuild 解析通过 (%s)" % tool if tool else "未找到 esbuild，已跳过（括号配平校验通过）"))
    log("state : %s" % state_of(fresh))
    log("注意  : assets 原有 immutable 缓存头不变，文件名也未变；已打开过的浏览器需要硬刷新一次(Cmd/Ctrl+Shift+R)")
    return 0


def main():
    ap = argparse.ArgumentParser(description="Flocks WebUI: 隐藏 Agent 车间「知识与记忆」并修正 /workspace tab 归属")
    ap.add_argument("--dist", help="webui-dist 目录；默认自动探测 /opt/flockspro")
    ap.add_argument("--dry-run", action="store_true", help="只打印将要删除的片段，不写盘")
    ap.add_argument("--check", action="store_true", help="只报告当前状态")
    ap.add_argument("--revert", action="store_true", help="用最近一次 .bak-* 备份还原")
    args = ap.parse_args()

    dist = find_dist(args.dist)
    if not dist:
        die("找不到 webui-dist 目录；请用 --dist 指定", 4)
    entry = find_entry(dist)

    if args.revert:
        return cmd_revert(entry)

    text = read_text(entry)
    if args.check:
        return cmd_check(dist, entry, text)
    return cmd_apply(dist, entry, text, args.dry_run)


if __name__ == "__main__":
    sys.exit(main())
