#!/usr/bin/env bash
# 回滚：用最近一次 .bak-* 备份还原入口 chunk
# 用法： ./revert.sh [--dist <webui-dist>]
set -euo pipefail
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
exec python3 "$DIR/patch.py" --revert "$@"
