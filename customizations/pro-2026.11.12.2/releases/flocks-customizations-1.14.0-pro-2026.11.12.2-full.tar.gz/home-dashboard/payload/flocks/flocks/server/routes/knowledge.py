"""Read-only Knowledge Center APIs for curated outputs and memory files."""

from __future__ import annotations

import asyncio
import mimetypes
import os
import re
import stat as stat_module
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Literal

from fastapi import APIRouter, HTTPException, Query, Request
from fastapi.responses import FileResponse

from flocks.project.project import Project
from flocks.server.auth import require_user
from flocks.workspace.manager import WorkspaceManager
from flocks.server.routes import knowledge_catalog


router = APIRouter()

_DATE_DIRECTORY = re.compile(r"^\d{4}-\d{2}-\d{2}$")
_MAX_TREE_DEPTH = 8
_MAX_TREE_NODES = 5000
_DEFAULT_MAX_READ_BYTES = 2 * 1024 * 1024
_INLINE_MEDIA_TYPES = {
    "application/pdf",
    "image/png",
    "image/jpeg",
    "image/gif",
    "image/webp",
}


@dataclass(frozen=True)
class _OutputRoot:
    id: str
    label: str
    path: Path


def _max_read_bytes() -> int:
    return int(os.getenv("FLOCKS_WORKSPACE_MAX_READ_BYTES", str(_DEFAULT_MAX_READ_BYTES)))


def _path_parts(value: str) -> tuple[str, ...]:
    normalized = value.replace("\\", "/")
    if normalized.startswith("/"):
        raise ValueError("Absolute paths are not allowed")
    parts = tuple(normalized.split("/"))
    if not parts or any(part in {"", ".", ".."} for part in parts):
        raise ValueError("Invalid relative path")
    if any(part.startswith(".") for part in parts):
        raise ValueError("Hidden paths are not available")
    return parts


def _safe_target(root: Path, relative_path: str) -> Path:
    parts = _path_parts(relative_path)
    root_resolved = root.expanduser().resolve(strict=False)
    candidate = root.joinpath(*parts)
    cursor = root
    for part in parts:
        cursor = cursor / part
        if cursor.is_symlink():
            raise ValueError("Symbolic links are not available")
    target = candidate.expanduser().resolve(strict=False)
    try:
        target.relative_to(root_resolved)
    except ValueError as error:
        raise ValueError("Path escapes the allowed root") from error
    return target


def _visible_children(directory: Path) -> list[Path]:
    if not directory.is_dir():
        return []
    return [
        child
        for child in directory.iterdir()
        if not child.name.startswith(".") and not child.is_symlink()
    ]


def _output_roots(user: Any, manager: WorkspaceManager) -> list[_OutputRoot]:
    workspace_root = manager.get_workspace_dir()
    roots = [
        _OutputRoot(
            id="personal",
            label="personal",
            path=manager.get_user_workspace_dir(user.username) / "outputs",
        ),
        _OutputRoot(
            id="shared",
            label="shared",
            path=manager.get_workspace_dir(shared=True) / "outputs",
        ),
    ]
    if user.role == "admin":
        roots.append(_OutputRoot(id="legacy", label="legacy", path=workspace_root / "outputs"))
    return roots


def _node_sort_key(node: dict[str, Any]) -> tuple[int, float, str]:
    return (
        0 if node["type"] == "directory" else 1,
        -float(node.get("modified_at") or 0),
        str(node["name"]).casefold(),
    )


def _build_output_node(
    path: Path,
    root: _OutputRoot,
    budget: list[int],
    depth: int = 0,
) -> dict[str, Any] | None:
    if budget[0] <= 0 or path.name.startswith(".") or path.is_symlink():
        return None
    try:
        raw_stat = path.stat()
    except OSError:
        return None
    budget[0] -= 1
    is_dir = stat_module.S_ISDIR(raw_stat.st_mode)
    node: dict[str, Any] = {
        "name": path.name,
        "path": path.relative_to(root.path).as_posix(),
        "root": root.id,
        "root_label": root.label,
        "type": "directory" if is_dir else "file",
        "modified_at": raw_stat.st_mtime,
    }
    if not is_dir:
        node["size"] = raw_stat.st_size
        node["is_text_file"] = WorkspaceManager.is_text_file(path)
        return node
    children: list[dict[str, Any]] = []
    if depth < _MAX_TREE_DEPTH:
        for child in _visible_children(path):
            child_node = _build_output_node(child, root, budget, depth + 1)
            if child_node is not None:
                children.append(child_node)
    node["children"] = sorted(children, key=_node_sort_key)
    return node


def _count_files(nodes: list[dict[str, Any]]) -> int:
    total = 0
    for node in nodes:
        if node["type"] == "file":
            total += 1
        else:
            total += _count_files(node.get("children", []))
    return total


def _list_outputs_sync(roots: list[_OutputRoot]) -> dict[str, Any]:
    by_date: dict[str, list[dict[str, Any]]] = {}
    other: list[dict[str, Any]] = []
    budget = [_MAX_TREE_NODES]
    for root in roots:
        if not root.path.is_dir() or root.path.is_symlink():
            continue
        for child in _visible_children(root.path):
            if child.is_dir() and _DATE_DIRECTORY.fullmatch(child.name):
                entries: list[dict[str, Any]] = []
                for date_child in _visible_children(child):
                    node = _build_output_node(date_child, root, budget)
                    if node is not None:
                        entries.append(node)
                if entries:
                    by_date.setdefault(child.name, []).extend(entries)
            else:
                node = _build_output_node(child, root, budget)
                if node is not None:
                    other.append(node)
            if budget[0] <= 0:
                break
        if budget[0] <= 0:
            break

    groups = []
    for day in sorted(by_date, reverse=True):
        entries = sorted(by_date[day], key=_node_sort_key)
        groups.append({"date": day, "file_count": _count_files(entries), "entries": entries})
    return {
        "groups": groups,
        "other": sorted(other, key=_node_sort_key),
        "truncated": budget[0] <= 0,
    }


def _memory_file_node(path: Path, memory_root: Path) -> dict[str, Any] | None:
    if not path.is_file() or path.is_symlink() or path.name.startswith("."):
        return None
    try:
        raw_stat = path.stat()
    except OSError:
        return None
    return {
        "name": path.name,
        "path": path.relative_to(memory_root).as_posix(),
        "root": "memory",
        "root_label": "memory",
        "type": "file",
        "size": raw_stat.st_size,
        "modified_at": raw_stat.st_mtime,
        "is_text_file": WorkspaceManager.is_text_file(path),
    }


def _list_memory_sync(memory_root: Path, project_ids: set[str]) -> dict[str, Any]:
    sections: list[dict[str, Any]] = []
    for section_id, filename in (("profile", "USER.md"), ("global", "MEMORY.md")):
        node = _memory_file_node(memory_root / filename, memory_root)
        if node is not None:
            sections.append({"id": section_id, "entries": [node]})

    project_entries: list[dict[str, Any]] = []
    projects_root = memory_root / "projects"
    for project_id in sorted(project_ids):
        project_file = projects_root / project_id / "MEMORY.md"
        node = _memory_file_node(project_file, memory_root)
        if node is not None:
            project_entries.append({
                "name": project_id,
                "path": f"projects/{project_id}",
                "root": "memory",
                "root_label": "memory",
                "type": "directory",
                "modified_at": node["modified_at"],
                "children": [node],
            })
    if project_entries:
        sections.append({"id": "projects", "entries": project_entries})

    daily_entries: list[dict[str, Any]] = []
    daily_root = memory_root / "daily"
    if daily_root.is_dir() and not daily_root.is_symlink():
        daily_paths = sorted(
            (
                child for child in _visible_children(daily_root)
                if child.is_file() and child.suffix.casefold() == ".md"
            ),
            key=lambda child: child.stem,
            reverse=True,
        )
        for child in daily_paths:
            node = _memory_file_node(child, memory_root)
            if node is not None:
                daily_entries.append(node)
    if daily_entries:
        sections.append({"id": "daily", "entries": daily_entries})
    return {"sections": sections}


def _resolve_output_target(request: Request, root_id: str, path: str) -> Path:
    user = require_user(request)
    manager = WorkspaceManager.get_instance()
    roots = {root.id: root for root in _output_roots(user, manager)}
    root = roots.get(root_id)
    if root is None:
        raise HTTPException(status_code=403, detail="Output root is not available")
    try:
        return _safe_target(root.path, path)
    except ValueError as error:
        raise HTTPException(status_code=400, detail=str(error)) from error


def _resolve_memory_target(request: Request, path: str) -> Path:
    user = require_user(request)
    manager = WorkspaceManager.get_instance()
    try:
        parts = _path_parts(path)
    except ValueError as error:
        raise HTTPException(status_code=400, detail=str(error)) from error
    allowed = (
        parts in {("USER.md",), ("MEMORY.md",)}
        or (len(parts) == 2 and parts[0] == "daily" and parts[1].endswith(".md"))
        or (
            len(parts) == 3
            and parts[0] == "projects"
            and parts[1] in Project.registered_project_ids(user.id)
            and parts[2] == "MEMORY.md"
        )
    )
    if not allowed:
        raise HTTPException(status_code=403, detail="Memory path is not available")
    try:
        return _safe_target(manager.get_memory_dir(), path)
    except ValueError as error:
        raise HTTPException(status_code=400, detail=str(error)) from error


def _resolve_target(
    request: Request,
    source: Literal["outputs", "memory"],
    root: str,
    path: str,
) -> Path:
    if source == "outputs":
        return _resolve_output_target(request, root, path)
    return _resolve_memory_target(request, path)


def _ensure_file(target: Path, path: str) -> None:
    if not target.exists():
        raise HTTPException(status_code=404, detail=f"File not found: {path}")
    if not target.is_file():
        raise HTTPException(status_code=400, detail=f"Not a file: {path}")


@router.get("/outputs", summary="List visible knowledge outputs")
async def list_outputs(request: Request):
    user = require_user(request)
    manager = WorkspaceManager.get_instance()
    manager.ensure_dirs()
    return await asyncio.to_thread(_list_outputs_sync, _output_roots(user, manager))


@router.get("/memory", summary="List visible memory files")
async def list_memory(request: Request):
    user = require_user(request)
    manager = WorkspaceManager.get_instance()
    manager.ensure_dirs()
    memory_root = manager.get_memory_dir()
    if not memory_root.is_dir() or memory_root.is_symlink():
        return {"sections": []}
    project_ids = Project.registered_project_ids(user.id)
    return await asyncio.to_thread(_list_memory_sync, memory_root, project_ids)


async def _catalog_index(request: Request, refresh: bool = False):
    user = require_user(request)
    manager = WorkspaceManager.get_instance()
    roots = [(root.id, root.path) for root in _output_roots(user, manager)]
    return await asyncio.to_thread(knowledge_catalog.get_index, roots, refresh)


@router.get("/catalog", summary="List classified output categories")
async def list_catalog(request: Request, refresh: bool = False, include_process: bool = False):
    index = await _catalog_index(request, refresh)
    return await asyncio.to_thread(knowledge_catalog.summary, index, include_process)


@router.get("/catalog/files", summary="Search and paginate classified outputs")
async def list_catalog_files(
    request: Request, category: str = "", subcategory: str = "",
    query: str = Query("", max_length=300), tag: str = "", extension: str = "",
    after: str = Query("", pattern=r"^(?:\d{4}-\d{2}-\d{2})?$"),
    before: str = Query("", pattern=r"^(?:\d{4}-\d{2}-\d{2})?$"),
    topic: str = "", latest: bool = True, include_process: bool = False, with_evidence: bool = False,
    offset: int = Query(0, ge=0, le=1000000), limit: int = Query(50, ge=1, le=100),
):
    index = await _catalog_index(request)
    return await asyncio.to_thread(knowledge_catalog.query_files, index,
        category=category, subcategory=subcategory, query=query, tag=tag, extension=extension,
        after=after, before=before, topic=topic, latest=latest, include_process=include_process,
        with_evidence=with_evidence, offset=offset, limit=limit)


@router.get("/catalog/context", summary="Find classification and evidence for an output")
async def catalog_context(request: Request, root: str, path: str):
    # Repeat root and path authorization even when a cached index is available.
    target = _resolve_output_target(request, root, path)
    _ensure_file(target, path)
    index = await _catalog_index(request)
    return await asyncio.to_thread(knowledge_catalog.file_context, index, root, path)


@router.get("/output-entry", summary="Locate an output beyond the daily tree display limit")
async def output_entry(request: Request, root: str, path: str):
    target = _resolve_output_target(request, root, path)
    _ensure_file(target, path)
    info = target.stat()
    return {"name": target.name, "path": path, "root": root, "root_label": root,
            "type": "file", "size": info.st_size, "modified_at": info.st_mtime,
            "is_text_file": WorkspaceManager.is_text_file(target)}


@router.get("/file", summary="Read a visible knowledge text file")
async def read_file(
    request: Request,
    source: Literal["outputs", "memory"] = Query(...),
    path: str = Query(...),
    root: str = Query("personal"),
):
    target = _resolve_target(request, source, root, path)
    _ensure_file(target, path)
    if not WorkspaceManager.is_text_file(target):
        raise HTTPException(status_code=400, detail="Binary file — use the preview or download endpoint")
    max_bytes = _max_read_bytes()

    def read_limited() -> tuple[str, bool]:
        with target.open("rb") as handle:
            data = handle.read(max_bytes + 1)
        truncated = len(data) > max_bytes
        return data[:max_bytes].decode("utf-8", errors="replace"), truncated

    content, truncated = await asyncio.to_thread(read_limited)
    return {
        "path": path,
        "content": content,
        "truncated": truncated,
        "size": target.stat().st_size,
        "preview_limit_bytes": max_bytes,
    }


@router.get("/preview", summary="Preview a visible knowledge binary file")
async def preview_file(
    request: Request,
    source: Literal["outputs", "memory"] = Query(...),
    path: str = Query(...),
    root: str = Query("personal"),
):
    target = _resolve_target(request, source, root, path)
    _ensure_file(target, path)
    media_type = mimetypes.guess_type(target.name)[0] or "application/octet-stream"
    if media_type not in _INLINE_MEDIA_TYPES:
        raise HTTPException(status_code=415, detail="This file type cannot be previewed inline")
    return FileResponse(target, media_type=media_type, headers={"Content-Disposition": "inline"})


@router.get("/download", summary="Download a visible knowledge file")
async def download_file(
    request: Request,
    source: Literal["outputs", "memory"] = Query(...),
    path: str = Query(...),
    root: str = Query("personal"),
):
    target = _resolve_target(request, source, root, path)
    _ensure_file(target, path)
    return FileResponse(target, filename=target.name, media_type="application/octet-stream")
