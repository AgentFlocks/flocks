"""Lifecycle manager for syslog listeners → workflow runs."""

from __future__ import annotations

import asyncio
import threading
import sqlite3
import time
import uuid
from typing import Any, Dict, List, Optional

from flocks.hooks.execution import execute_with_hooks
from flocks.hooks.pipeline import HookPipeline
from flocks.utils.log import Log
from flocks.workflow.execution_store import (
    compact_outputs_for_storage,
    create_execution_record,
    ExecutionStepRecorder,
    record_execution_result,
    resolve_execution_outcome,
)
from flocks.workflow.execution_plan import build_workflow_execution_plan
from flocks.workflow.fs_store import read_workflow_from_fs
from flocks.workflow.models import Workflow
from flocks.workflow.runner import run_workflow
from flocks.workflow.store import WorkflowStore, sqlite_error_fields
from flocks.workflow.ownership import abandon_execution, execution_cancelled
from flocks.workflow.tool_context import (
    build_workflow_tool_context,
    cleanup_workflow_tool_context,
)

from flocks.ingest.syslog.constants import WORKFLOW_SYSLOG_CONFIG_PREFIX
from flocks.ingest.syslog.listener import run_tcp_syslog_server, run_udp_syslog_server
from flocks.workflow.triggers.compat import legacy_syslog_trigger_from_config
from flocks.workflow.triggers.dispatcher import EventDispatcher, TriggerDispatchError, build_trigger_event
from flocks.workflow.triggers.models import (
    TriggerDefinition,
    workflow_json_declares_triggers,
    workflow_trigger_definitions_from_json,
)

from flocks.workflow import soc_diagnostics as soc_diag

log = Log.create(service="syslog.manager")


# Maximum concurrent workflow executions per workflow to avoid FD exhaustion and SQLite write contention
_MAX_CONCURRENT_EXECUTIONS = 8
# Maximum number of buffered syslog messages per workflow; excess messages are dropped with a warning.
# Increased from 200 to 1000 to absorb larger inbound bursts before the worker pool catches up.
_MAX_QUEUE_SIZE = 1000
# Maximum time we wait for the listener to either bind successfully or fail
# during ``restart_workflow``.  Any value <0.5s makes the call too aggressive
# under busy event-loops; anything >5s would make the HTTP save endpoint feel
# hung when the user makes a typo.
_BIND_WAIT_TIMEOUT_S = 3.0
# Minimum interval between two ``syslog.queue_full_dropped`` warnings; a
# sustained queue overflow is aggregated into a single warning per window.
_DROP_LOG_WINDOW_S = 1.0


def _worker_count_for_trigger(trigger: TriggerDefinition) -> int:
    return min(_MAX_CONCURRENT_EXECUTIONS, max(1, int(trigger.concurrency.maxParallel)))


def _queue_size_for_trigger(trigger: TriggerDefinition) -> int:
    return min(_MAX_QUEUE_SIZE, max(1, int(trigger.concurrency.queueSize)))


class _DropWarningThrottle:
    """Aggregate per-workflow ``QueueFull`` drops into windowed warnings.

    The listener's ``on_msg`` callback runs synchronously from the UDP
    protocol layer; without throttling, each dropped datagram emits its own
    log record, which (a) drowns out the surrounding logs and (b) can make
    the very logging itself a bottleneck.  This helper keeps a small running
    tally and emits at most one warning per ``window_s`` seconds, plus an
    explicit ``flush`` for the trailing count when the flood stops.
    """

    def __init__(
        self,
        workflow_id: str,
        queue: asyncio.Queue,
        window_s: float = _DROP_LOG_WINDOW_S,
    ) -> None:
        self._workflow_id = workflow_id
        self._queue = queue
        self._window_s = float(window_s)
        self._count: int = 0
        self._last_log: float = 0.0

    @property
    def count(self) -> int:
        """Current un-flushed drop count (useful for tests)."""
        return self._count

    def record_drop(self) -> None:
        """Account for one dropped datagram; emit if the window elapsed."""
        self._count += 1
        if time.monotonic() - self._last_log >= self._window_s:
            self._flush(trigger="threshold")

    def maybe_flush(self) -> None:
        """Emit a warning if the trailing count has waited long enough."""
        if self._count > 0 and time.monotonic() - self._last_log >= self._window_s:
            self._flush(trigger="flush")

    def flush_remaining(self, trigger: str = "shutdown") -> None:
        """Emit any leftover count regardless of window; used on shutdown."""
        if self._count > 0:
            self._flush(trigger=trigger)

    def _flush(self, *, trigger: str) -> None:
        log.warning(
            "syslog.queue_full_dropped",
            {
                "workflow_id": self._workflow_id,
                "queue_size": self._queue.qsize(),
                "queue_capacity": self._queue.maxsize,
                "dropped_in_window": int(self._count),
                "trigger": trigger,
            },
        )
        self._count = 0
        self._last_log = time.monotonic()


class _ExecutionCreateFailed(Exception):
    """Only this failure is safe to retry: no workflow node has run yet."""
    def __init__(self, cause):
        super().__init__(str(cause))
        self.sqlite_errorcode = getattr(cause, "sqlite_errorcode", None)
        self.sqlite_errorname = getattr(cause, "sqlite_errorname", None)


class SyslogManager:
    """One async listener task per workflow id (when enabled).

    The listener / consumer fan-out is built around bounded primitives so a
    syslog flood cannot translate into unbounded asyncio.Task growth:

    * A bounded ``asyncio.Queue`` (``_MAX_QUEUE_SIZE``) absorbs spikes; the
      listener uses ``put_nowait`` and drops excess messages with a warning.
    * A fixed pool of ``_MAX_CONCURRENT_EXECUTIONS`` worker coroutines drains
      the queue and runs ``_trigger_workflow`` serially per worker.  This is
      stronger than a per-task ``Semaphore``: the previous design called
      ``create_task`` for every queued message and only awaited the semaphore
      *inside* the task, which let pending coroutines accumulate without
      bound while the queue was emptied immediately.
    """

    def __init__(self) -> None:
        self._tasks: dict[str, asyncio.Task] = {}
        self._abort_events: dict[str, asyncio.Event] = {}
        # Per-workflow bounded message queue for backpressure
        self._queues: dict[str, asyncio.Queue] = {}
        # Per-workflow fixed worker pool draining the queue
        self._worker_pools: dict[str, List[asyncio.Task]] = {}
        # One cancellation event per listener generation. It is installed
        # before any worker starts, so stop cannot miss a run that is still
        # creating its execution record or tool context.
        self._generation_cancel_events: dict[str, threading.Event] = {}
        self._draining_workers: dict[str, set[asyncio.Task]] = {}
        # Per-workflow listener runtime status for the syslog-status API.
        # Possible state values: "binding" | "listening" | "failed" | "stopped".
        self._listener_status: dict[str, Dict[str, Any]] = {}
        # Per-workflow event signalled when the listener has either bound
        # successfully or failed.  Used by ``restart_workflow`` so the HTTP
        # save endpoint can report bind failures synchronously.
        self._listener_ready: dict[str, asyncio.Event] = {}
        self._dispatcher = EventDispatcher()
        # Restart and stop of one workflow happen one at a time: two of them
        # interleaving (two saves of its config, say) would leave a listener
        # that nothing tracks any more.
        self._dispatch_status: dict[str, Dict[str, Any]] = {}
        self._workflow_locks: dict[str, asyncio.Lock] = {}
        self._stopped = False

    def _lock_for(self, workflow_id: str) -> asyncio.Lock:
        lock = self._workflow_locks.get(workflow_id)
        if lock is None:
            lock = self._workflow_locks[workflow_id] = asyncio.Lock()
        return lock

    @staticmethod
    def _config_key(workflow_id: str) -> str:
        return f"{WORKFLOW_SYSLOG_CONFIG_PREFIX}{workflow_id}"

    @staticmethod
    def _default_trigger_from_config(data: Dict[str, Any]) -> TriggerDefinition:
        trigger = legacy_syslog_trigger_from_config(data)
        if trigger is None:
            return TriggerDefinition.model_validate(
                {
                    "id": "syslog-default",
                    "type": "syslog",
                    "enabled": bool(data.get("enabled")),
                    "source": {
                        "protocol": data.get("protocol") or "udp",
                        "host": data.get("host") or "0.0.0.0",
                        "port": int(data.get("port") or 5140),
                        "format": data.get("format") or "auto",
                    },
                    "mapping": {
                        str(data.get("inputKey") or "syslog_message"): "$.body",
                    },
                    "updatedAt": data.get("updatedAt"),
                }
            )
        return trigger

    def _resolve_active_trigger(self, workflow_json: Dict[str, Any], data: Dict[str, Any]) -> TriggerDefinition:
        if workflow_json_declares_triggers(workflow_json):
            triggers = workflow_trigger_definitions_from_json(workflow_json)
            trigger = next((item for item in triggers if item.type == "syslog"), None)
            if trigger is not None:
                return trigger
        return self._default_trigger_from_config(data)

    async def start_all(self) -> None:
        self._stopped = False
        try:
            configs = await WorkflowStore.list_configs(kind="workflow_syslog_config")
        except Exception as exc:
            log.warning("syslog.list_configs_failed", {"error": str(exc)})
            return

        for workflow_id, data in configs:
            if not workflow_id:
                continue
            if isinstance(data, dict) and data.get("enabled"):
                try:
                    await self.restart_workflow(workflow_id, startup=True)
                except Exception as exc:
                    self._listener_status[workflow_id] = {
                        "state": "failed",
                        "error": str(exc),
                    }
                    log.warning(
                        "syslog.start_failed",
                        {"workflow_id": workflow_id, "error": str(exc)},
                    )

    async def stop_all(self) -> None:
        # A restart still under way (reading its config, say) has registered
        # nothing yet: every workflow that ever took its lock is visited, so
        # stopping waits for that restart, which then sees ``_stopped`` and
        # starts nothing (see _restart_locked).
        self._stopped = True
        for workflow_id in sorted(set(self._tasks) | set(self._workflow_locks)):
            await self.stop_workflow(workflow_id)

    def get_listener_status(self, workflow_id: str) -> Dict[str, Any]:
        """Return a snapshot of the listener runtime state for ``workflow_id``.

        Result shape::

            {"state": "binding|listening|failed|stopped", "error": "..." | None,
             "host": "...", "port": 5140, "protocol": "udp|tcp",
             "queueSize": 12, "queueCapacity": <queue.maxsize>,
             "workerCount": <_MAX_CONCURRENT_EXECUTIONS>}

        ``queueCapacity`` always mirrors the runtime ``asyncio.Queue.maxsize``
        of the active listener (currently ``_MAX_QUEUE_SIZE``).
        """
        status = dict(self._listener_status.get(workflow_id) or {"state": "stopped"})
        q = self._queues.get(workflow_id)
        if q is not None:
            status["queueSize"] = q.qsize()
            status["queueCapacity"] = q.maxsize
        pool = self._worker_pools.get(workflow_id)
        if pool is not None:
            status["workerCount"] = sum(1 for t in pool if not t.done())
        status.update(self._dispatch_status.get(workflow_id, {}))
        return status

    def _track_draining_workers(
        self,
        workflow_id: str,
        workers: set[asyncio.Task],
    ) -> None:
        if not workers:
            return
        bucket = self._draining_workers.setdefault(workflow_id, set())
        bucket.update(workers)

        def _discard(done: asyncio.Task) -> None:
            current = self._draining_workers.get(workflow_id)
            if current is None:
                return
            current.discard(done)
            if not current:
                self._draining_workers.pop(workflow_id, None)

        for worker in workers:
            worker.add_done_callback(_discard)

    def _active_draining_workers(self, workflow_id: str) -> set[asyncio.Task]:
        workers = self._draining_workers.get(workflow_id, set())
        active = {worker for worker in workers if not worker.done()}
        if active:
            self._draining_workers[workflow_id] = active
        else:
            self._draining_workers.pop(workflow_id, None)
        return active

    async def stop_workflow(self, workflow_id: str) -> None:
        async with self._lock_for(workflow_id):
            await self._stop_workflow_locked(workflow_id)

    async def _stop_workflow_locked(self, workflow_id: str) -> None:
        cancel_event = self._generation_cancel_events.pop(workflow_id, None)
        if cancel_event is not None:
            cancel_event.set()
        ev = self._abort_events.pop(workflow_id, None)
        if ev is not None:
            ev.set()
        task = self._tasks.pop(workflow_id, None)
        if task is not None and not task.done():
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass
        # Let workers drain their current ``to_thread`` workflow after the
        # cooperative cancel signal. Pending workers stay tracked instead of
        # becoming invisible orphan threads.
        pool = self._worker_pools.pop(workflow_id, None)
        if pool:
            _, pending = await asyncio.wait(pool, timeout=5.0)
            self._track_draining_workers(workflow_id, pending)
        self._queues.pop(workflow_id, None)
        self._listener_ready.pop(workflow_id, None)
        if workflow_id in self._listener_status:
            self._listener_status[workflow_id] = {"state": "stopped", "error": None}

    async def restart_workflow(
        self,
        workflow_id: str,
        *,
        startup: bool = False,
    ) -> Dict[str, Any]:
        """Restart the listener and return its post-bind runtime status.

        This call blocks until the underlying socket either binds successfully,
        the bind fails (OSError such as ``EADDRINUSE``), or
        ``_BIND_WAIT_TIMEOUT_S`` elapses.  Callers (e.g. the HTTP
        ``save_syslog_config`` route) can therefore surface bind errors to the
        user instead of silently leaving the listener in a failed state.
        """
        async with self._lock_for(workflow_id):
            return await self._restart_locked(workflow_id, startup=startup)

    async def _restart_locked(self, workflow_id: str, *, startup: bool = False) -> Dict[str, Any]:
        await self._stop_workflow_locked(workflow_id)
        if self._active_draining_workers(workflow_id):
            error = "previous_workers_still_draining"
            self._listener_status[workflow_id] = {"state": "failed", "error": error}
            return {"state": "failed", "error": error}
        try:
            data = await WorkflowStore.get_config(workflow_id, kind="workflow_syslog_config")
        except Exception as exc:
            log.warning("syslog.restart_read_failed", {"workflow_id": workflow_id, "error": str(exc)})
            return {"state": "failed", "error": str(exc)}
        if self._stopped:
            # The manager was stopped while the config was read.
            self._listener_status[workflow_id] = {"state": "stopped", "error": None}
            return {"state": "stopped", "error": None}
        if not isinstance(data, dict) or not data.get("enabled"):
            self._listener_status[workflow_id] = {"state": "stopped", "error": None}
            return {"state": "stopped", "error": None}

        # Load and cache the workflow JSON once; avoids a disk read per message
        wf_data = read_workflow_from_fs(workflow_id)
        if not wf_data:
            err = "workflow_not_found"
            if startup:
                self._listener_status[workflow_id] = {"state": "stopped", "error": err}
                log.info(
                    "syslog.workflow_not_found_on_start",
                    {
                        "workflow_id": workflow_id,
                        "action": "stale_config_skipped",
                    },
                )
                return {"state": "stopped", "error": err}
            self._listener_status[workflow_id] = {"state": "failed", "error": err}
            log.warning("syslog.workflow_not_found", {"workflow_id": workflow_id})
            return {"state": "failed", "error": err}
        workflow_json = wf_data.get("workflowJson")
        if not workflow_json:
            err = "workflow_json_missing"
            self._listener_status[workflow_id] = {"state": "failed", "error": err}
            log.warning("syslog.workflow_json_missing_on_start", {"workflow_id": workflow_id})
            return {"state": "failed", "error": err}

        trigger = self._resolve_active_trigger(workflow_json, data)
        try:
            workflow_plan = build_workflow_execution_plan(Workflow.from_dict(workflow_json))
        except Exception as exc:
            err = f"workflow_plan_failed: {exc}"
            self._listener_status[workflow_id] = {"state": "failed", "error": err}
            log.warning("syslog.workflow_plan_failed", {"workflow_id": workflow_id, "error": str(exc)})
            return self.get_listener_status(workflow_id)

        host = str(data.get("host") or "0.0.0.0")
        port = int(data.get("port") or 5140)
        protocol = str(data.get("protocol") or "udp").lower()
        queue_capacity = _queue_size_for_trigger(trigger)
        worker_count = _worker_count_for_trigger(trigger)
        queue: asyncio.Queue = asyncio.Queue(maxsize=queue_capacity)
        self._queues[workflow_id] = queue

        abort = asyncio.Event()
        self._abort_events[workflow_id] = abort
        generation_cancel_event = threading.Event()
        self._generation_cancel_events[workflow_id] = generation_cancel_event

        ready = asyncio.Event()
        self._listener_ready[workflow_id] = ready

        self._listener_status[workflow_id] = {
            "state": "binding",
            "error": None,
            "host": host,
            "port": port,
            "protocol": protocol,
        }

        # Spin up the trigger-configured worker pool within service safety caps.
        workers: List[asyncio.Task] = []
        for i in range(worker_count):
            workers.append(
                asyncio.create_task(
                    self._worker_loop(
                        workflow_id,
                        workflow_plan,
                        trigger,
                        queue,
                        abort,
                        generation_cancel_event,
                    ),
                    name=f"syslog-worker-{workflow_id}-{i}",
                )
            )
        self._worker_pools[workflow_id] = workers

        task = asyncio.create_task(
            self._listener_loop(workflow_id, data, queue, abort, ready),
            name=f"syslog-{workflow_id}",
        )
        self._tasks[workflow_id] = task

        # Wait briefly for the listener to bind (or fail) so the caller can
        # decide whether to surface a 502/Conflict instead of pretending the
        # listener is up.
        try:
            await asyncio.wait_for(ready.wait(), timeout=_BIND_WAIT_TIMEOUT_S)
        except asyncio.TimeoutError:
            # Listener hasn't reported bind result; treat as best-effort
            # "scheduled" so we don't tear it down on slow boxes, but mark the
            # state explicitly so the UI can show "pending".
            current = self._listener_status.get(workflow_id) or {}
            if current.get("state") == "binding":
                self._listener_status[workflow_id] = {
                    **current,
                    "state": "binding",
                    "error": "bind_pending_timeout",
                }
            log.warning("syslog.bind_pending_timeout", {"workflow_id": workflow_id})

        log.info("syslog.listener_scheduled", {"workflow_id": workflow_id})
        return self.get_listener_status(workflow_id)

    async def _listener_loop(
        self,
        workflow_id: str,
        config: Dict[str, Any],
        queue: asyncio.Queue,
        abort: asyncio.Event,
        ready: asyncio.Event,
    ) -> None:
        host = str(config.get("host") or "0.0.0.0")
        port = int(config.get("port") or 5140)
        protocol = str(config.get("protocol") or "udp").lower()
        format_hint = str(config.get("format") or "auto")

        # Aggregate per-window drop warnings so a sustained queue overflow
        # does not turn into its own log flood.  The trailing count is
        # flushed by a 1-second polling task plus a shutdown best-effort.
        throttle = _DropWarningThrottle(workflow_id, queue)

        # NOTE: keep this callback synchronous so the UDP protocol layer can
        # invoke it inline from datagram_received() without creating an
        # asyncio task per packet. That preserves the queue-based backpressure.
        def on_msg(parsed: dict) -> None:
            soc_diag.record(workflow_id, "received")
            try:
                queue.put_nowait(parsed)
                soc_diag.record(workflow_id, "enqueued", queue_size=queue.qsize(), queue_capacity=queue.maxsize)
            except asyncio.QueueFull:
                throttle.record_drop()
                soc_diag.record(workflow_id, "queue_full", queue_size=queue.qsize())

        on_msg._diagnostic_workflow_id = workflow_id

        async def _periodic_drop_flush() -> None:
            """Flush leftover drop count when the flood stops."""
            while not abort.is_set():
                try:
                    await asyncio.wait_for(abort.wait(), timeout=_DROP_LOG_WINDOW_S)
                    return  # abort signalled
                except asyncio.TimeoutError:
                    pass
                throttle.maybe_flush()
                soc_diag.record(workflow_id, "listener.heartbeat", queue_size=queue.qsize(),
                                worker_count=sum(not t.done() for t in self._worker_pools.get(workflow_id, [])))

        async def _bind_and_serve() -> None:
            """Serve the socket and flip ``ready`` once the bind really happened.

            ``run_udp_syslog_server`` / ``run_tcp_syslog_server`` invoke
            ``on_bound`` right after the endpoint exists.  Guessing with "one
            event-loop tick" was wrong whenever the loop had to resolve the
            host first (hostnames, malformed literals such as ``999.1.1.1``):
            the bind result arrived later than the tick and the route
            reported ``listening`` for a socket that then failed.  Bind
            failures are caught by the outer ``try`` below and reported back
            as ``state="failed"``.
            """
            flush_task = asyncio.create_task(_periodic_drop_flush())
            try:
                if protocol == "tcp":
                    await run_tcp_syslog_server(
                        host, port, format_hint, on_msg, abort_event=abort, on_bound=_mark_listening
                    )
                else:
                    await run_udp_syslog_server(
                        host, port, format_hint, on_msg, abort_event=abort, on_bound=_mark_listening
                    )
            finally:
                if not flush_task.done():
                    flush_task.cancel()
                # Best-effort: emit any leftover drop count on shutdown so a
                # tail of dropped messages isn't silently lost.
                throttle.flush_remaining()

        def _mark_listening() -> None:
            if not ready.is_set():
                self._listener_status[workflow_id] = {
                    "state": "listening",
                    "error": None,
                    "host": host,
                    "port": port,
                    "protocol": protocol,
                }
                ready.set()

        try:
            await _bind_and_serve()
        except asyncio.CancelledError:
            raise
        except OSError as exc:
            soc_diag.record(workflow_id, "listener.bind_failed", error_type=type(exc).__name__)
            self._listener_status[workflow_id] = {
                "state": "failed",
                "error": str(exc),
                "host": host,
                "port": port,
                "protocol": protocol,
            }
            ready.set()
            log.error(
                "syslog.bind_failed",
                {"workflow_id": workflow_id, "error": str(exc), "host": host, "port": port, "protocol": protocol},
            )
        except Exception as exc:
            self._listener_status[workflow_id] = {
                "state": "failed",
                "error": str(exc),
                "host": host,
                "port": port,
                "protocol": protocol,
            }
            ready.set()
            soc_diag.record(workflow_id, "listener.failed", error_type=type(exc).__name__)
            log.error("syslog.listener_error", {"workflow_id": workflow_id, "error": str(exc)})

    async def _worker_loop(
        self,
        workflow_id: str,
        workflow_plan: Any,
        trigger: TriggerDefinition,
        queue: asyncio.Queue,
        abort: asyncio.Event,
        generation_cancel_event: Optional[threading.Event] = None,
    ) -> None:
        """One worker drains the queue serially.

        The worker pool size is the *only* concurrency knob; we deliberately
        do not spawn additional asyncio.Tasks per message so the total number
        of in-flight workflow runs is exactly ``_MAX_CONCURRENT_EXECUTIONS``.
        """
        run_cancel_event = (
            generation_cancel_event or self._generation_cancel_events.get(workflow_id) or threading.Event()
        )
        while not abort.is_set():
            try:
                msg = await asyncio.wait_for(queue.get(), timeout=0.5)
            except asyncio.TimeoutError:
                continue
            except asyncio.CancelledError:
                return
            for attempt in range(3):
                try:
                    await self._trigger_workflow(
                        workflow_id, workflow_plan, msg,
                        next(iter(trigger.mapping or {}), "syslog_message"),
                        trigger=trigger,
                        source=f"{(trigger.source or {}).get('protocol', 'udp')}://{(trigger.source or {}).get('host', '0.0.0.0')}:{(trigger.source or {}).get('port', 5140)}",
                        generation_cancel_event=run_cancel_event,
                    )
                    self._dispatch_status[workflow_id] = {"dispatchState": "ready", "dispatchError": None}
                    break
                except asyncio.CancelledError:
                    return
                except Exception as exc:
                    # Never replay a workflow after nodes may have started. Only
                    # creation failures retain this message for a bounded retry.
                    delay = min(30.0, 2.0 ** (attempt + 1)) if isinstance(exc, _ExecutionCreateFailed) else 2.0
                    self._dispatch_status[workflow_id] = {
                        "dispatchState": "backoff", "dispatchError": str(exc),
                        "dispatchRetryAt": time.time() + delay,
                        **sqlite_error_fields(exc),
                    }
                    soc_diag.record(workflow_id, "dispatch.backoff", backoff_seconds=delay, **sqlite_error_fields(exc))
                    log.warning("syslog.worker_dispatch_failed", {"workflow_id": workflow_id, "error": str(exc), "retry_seconds": delay, **sqlite_error_fields(exc)})
                    try:
                        await asyncio.wait_for(abort.wait(), timeout=delay)
                        return
                    except asyncio.TimeoutError:
                        pass
                    if not isinstance(exc, _ExecutionCreateFailed) or attempt == 2:
                        soc_diag.record(workflow_id, "dispatch.abandoned", count=1, **sqlite_error_fields(exc))
                        self._dispatch_status[workflow_id]["dispatchState"] = "error"
                        break

    @soc_diag.traced("syslog.dispatch")
    async def _trigger_workflow(
        self,
        workflow_id: str,
        workflow_plan: Any,
        syslog_msg: dict,
        input_key: str,
        *,
        trigger: Optional[TriggerDefinition] = None,
        source: Optional[str] = None,
        generation_cancel_event: Optional[threading.Event] = None,
    ) -> None:
        run_cancel_event = generation_cancel_event or threading.Event()
        trigger = trigger or TriggerDefinition.model_validate(
            {
                "id": "syslog-default",
                "type": "syslog",
                "enabled": True,
                "mapping": {input_key: "$.body"},
            }
        )
        event = build_trigger_event(
            workflow_id=workflow_id,
            trigger=trigger,
            body=syslog_msg,
            raw=syslog_msg,
            source=source or "syslog",
            delivery_id=f"syslog-{uuid.uuid4().hex}",
        )

        async def _executor(mapped_inputs: Dict[str, Any]) -> Dict[str, Any]:
            summarized_inputs = {"_trigger": trigger.type}
            summarized_inputs.update(mapped_inputs)

            soc_diag.progress("execution.create")
            try:
                exec_data = await create_execution_record(workflow_id, input_params=summarized_inputs)
            except sqlite3.Error as exc:
                raise _ExecutionCreateFailed(exc) from exc
            exec_id = exec_data["id"]
            # Every way out of here ends the run: one whose end was not recorded (a
            # cancel while its context is cleaned up, say) is let go, not left live.
            try:
                step_recorder = ExecutionStepRecorder()
                start_time = time.time()
                trigger_meta = mapped_inputs.get("_flocks", {}).get("trigger", {})
                tool_context = None
                try:
                    soc_diag.progress("context.prepare", execution=exec_id)
                    tool_context = await build_workflow_tool_context(
                        workflow_id=workflow_id,
                        action_name=f"trigger:{trigger.type}",
                    )
                    soc_diag.progress("runner.queued", execution=exec_id)
                    result = await asyncio.to_thread(
                        run_workflow,
                        workflow=workflow_plan,
                        inputs=mapped_inputs,
                        run_id=exec_id,
                        trace=False,
                        execution_profile="high_frequency",
                        cancel=lambda: run_cancel_event.is_set() or execution_cancelled(exec_id),
                        on_step_complete=step_recorder.on_step_complete,
                        tool_context=tool_context,
                    )
                    status, error_msg = resolve_execution_outcome(result)
                    duration = time.time() - start_time
                    step_count = step_recorder.step_count or result.steps
                    exec_data.update(step_recorder.summary)
                    exec_data.update(
                        {
                            "status": status,
                            "outputResults": compact_outputs_for_storage(result.outputs),
                            "finishedAt": int(time.time() * 1000),
                            "duration": duration,
                            "errorMessage": error_msg,
                            "executionLog": [],
                            "stepCount": step_count,
                            "currentNodeId": result.last_node_id,
                            "currentPhase": status,
                            "currentStepIndex": step_count,
                            "triggerId": trigger.id,
                            "triggerType": trigger.type,
                            "deliveryId": trigger_meta.get("deliveryId"),
                            "attempt": trigger_meta.get("attempt"),
                            "triggerSource": trigger_meta.get("source"),
                        }
                    )
                except Exception as exc:
                    duration = time.time() - start_time
                    log.error(
                        "syslog.workflow_run_failed",
                        {"workflow_id": workflow_id, "exec_id": exec_id, "error": str(exc)},
                    )
                    exec_data.update(step_recorder.summary)
                    exec_data.update(
                        {
                            "status": "error",
                            "errorMessage": str(exc),
                            "finishedAt": int(time.time() * 1000),
                            "duration": duration,
                            "executionLog": [],
                            "currentPhase": "error",
                            "triggerId": trigger.id,
                            "triggerType": trigger.type,
                            "deliveryId": trigger_meta.get("deliveryId"),
                            "attempt": trigger_meta.get("attempt"),
                            "triggerSource": trigger_meta.get("source"),
                        }
                    )
                finally:
                    steps = step_recorder.take_steps()
                    soc_diag.progress("context.cleanup", execution=exec_id)
                    await cleanup_workflow_tool_context(tool_context)
                    try:
                        soc_diag.progress("execution.persist", execution=exec_id)
                        await record_execution_result(
                            workflow_id,
                            exec_id,
                            exec_data,
                            steps=steps,
                        )
                    except Exception as exc:
                        soc_diag.progress("execution.persist_failed", **sqlite_error_fields(exc))
                        log.warning("syslog.exec_record_failed", {"exec_id": exec_id, "error": str(exc)})
                        raise RuntimeError(f"execution_persist_failed: {exc}") from exc
                return exec_data
            finally:
                await abandon_execution(exec_id)

        try:
            soc_diag.progress("ingress.hooks")
            action_payload = {
                "operation": "workflow.trigger.syslog",
                "transport": "headless",
                # Internal adapter contract; never derive permission-carrier
                # fields from the untrusted message body.
                "legacy_compat": True,
                "workflow_id": workflow_id,
                "trigger": trigger,
                "event": event,
                # The listener itself is the authenticated ingress here.
                "evidence": {
                    "auth_scheme": "syslog",
                    "trigger_id": trigger.id,
                    "trigger_type": trigger.type,
                },
                "metadata": {
                    "legacy_compat": True,
                    "trigger_type": "syslog",
                },
            }
            await execute_with_hooks(
                action_payload,
                lambda: self._dispatcher.dispatch(
                    trigger=trigger,
                    event=event,
                    executor=_executor,
                ),
                before=HookPipeline.run_ingress_before,
                after=HookPipeline.run_ingress_after,
            )
        except TriggerDispatchError as exc:
            soc_diag.progress("dispatch.error", error_type=type(exc).__name__)
            log.warning(
                "syslog.trigger_dispatch_failed",
                {"workflow_id": workflow_id, "trigger_id": trigger.id, "error": str(exc)},
            )


default_manager = SyslogManager()
