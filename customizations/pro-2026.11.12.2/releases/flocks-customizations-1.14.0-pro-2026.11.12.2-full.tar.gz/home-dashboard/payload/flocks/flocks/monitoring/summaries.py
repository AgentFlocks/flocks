"""Deterministic, bounded plain-text step summaries from already queried facts."""
from dataclasses import dataclass, field
import re
import unicodedata

MAX_DETAILS = 48_000
ENTITY_LABELS = {'host': '主机', 'file': '文件', 'process': '进程', 'ip': '外部 IP', 'innerip': '内部 IP', 'dns': '域名',
                 'proof': '事件举证与时间线', 'alerts': '关联告警基本信息', 'alert_proof': '告警请求、响应及举证'}
STATUS_LABELS = {0: '待处置', 10: '处置中', 30: '已防护', 40: '处置完成', 50: '已挂起', 60: '忽略', 70: '已遏制'}


@dataclass
class Summary:
    text: str
    details: str = ''
    success: bool = True
    sections: list[dict[str, str]] = field(default_factory=list)
    packets: list[dict] = field(default_factory=list)


def step_purpose(name, params):
    """Explain the actual requested operation, never invent model reasoning."""
    event = f"事件 {label(params['event'], limit=100)}：" if params.get('event') else ''
    if name == '查询 XDR 事件':
        source = f"从设备「{label(params['device_name'])}」" if params.get('device_name') else ''
        return source + f"查询第 {label(params.get('page_num'), '1')} 页待处置、处置中且未加白或部分加白的事件，核对分页完整性与重复记录。"
    if name == '确认数据源与协作能力':
        return event + '检查本项目已接入且允许使用的查询工具、设备和安全协作智能体。'
    if name in ('监测运营智能体：选择下一步', '协作智能体分析'):
        return event + '根据已取得的证据选择补查、协作或总结；建议须经程序核验后才执行。'
    if name.startswith('调查取证：'):
        kind = ENTITY_LABELS.get(params.get('entity'), {'proof': '举证', 'related': '跨设备关联'}.get(params.get('entity'), '关联'))
        return event + f"通过 {label(params.get('tool'))} 查询{kind}证据，并保存来源、时间及完整性。"
    if name == '智能体调查结果':
        return event + '汇总已经查询到的事实、调查结论和未解决的问题。'
    if name in {'调查等待人工核对', '调查等待恢复', '调查等待重试'}:
        return event + '本轮未执行此事件调查；展示已保存的状态和恢复安排，不重复调用查询或模型。'
    if name == '关联分析':
        return '整理本轮事件的设备与主机关联，分别统计已完成调查、待办和初筛结果；本步骤完成只表示结果汇总完成，不代表每条事件都已调查成功。'
    if name == '发送告警通知':
        return event + '将这一条事件及核对依据发给配置的责任人，并记录本次投递结果。'
    if name == '解读回信并跟进状态':
        return '读取此前保存的责任人回信，定位原通知和事件，按实际反馈核对状态；含糊内容留待人工确认。'
    if name == '按责任人回信标记 XDR 状态':
        return event + '按已核验的反馈写入目标状态，随后重新查询确认。'
    if name == '回查事件当前状态':
        return event + '按原事件编号重新查询 XDR，核对实际状态是否与反馈目标一致。'
    return event + name + '；结果以下方实际返回的事实为准。'


def label(value, fallback='未提供', limit=160):
    if type(value) not in (str, int):
        return fallback
    text = ' '.join(''.join(c for c in str(value).replace('\n', ' ').replace('\r', ' ') if not unicodedata.category(c).startswith('C')).split())
    if not text:
        return fallback
    return text if len(text) <= limit else text[:limit] + '…（已截短）'


def detail_lines(lines, total):
    kept, length = [], 0
    for line in lines:
        if length + len(line) + 1 > MAX_DETAILS:
            break
        kept.append(line)
        length += len(line) + 1
    if len(kept) < total:
        kept.append(f'还有 {total - len(kept)} 条明细未在此摘要中展开；以上不是全部记录，统计包含全部返回数据。')
    return '\n'.join(kept)


def event_label(event):
    source = f"设备「{label(event['device_name'])}」· " if event.get('device_name') else ''
    return source + f"{label(event.get('name'), '名称未提供')}（ID：{label(event.get('uuId') or event.get('id'), limit=100)}）"


def failure_stage_label(stage):
    """Name a recorded execution boundary, without guessing from provider text."""
    return {'model': '调查模型请求', 'query': '关联取证查询',
            'query_time': '关联查询时间参数校验', 'internal': '调查程序执行'}.get(stage, '事件调查')


def investigation_failure_summary(outcome):
    """Render safe structured failures; raw exception bodies never belong here."""
    reason = label(outcome.get('reason'), '调查尚未完成，已有证据和待办保留', 600)
    stage = outcome.get('failure_stage')
    if stage not in {'model', 'query', 'query_time', 'internal'}:
        return reason  # Older persisted records retain their original explanation.
    source = label(outcome.get('failure_source'), '', 100)
    tool = label(outcome.get('failure_tool'), '', 100)
    target = ' / '.join(value for value in (source, tool) if value)
    text = failure_stage_label(stage) + (f'（{target}）' if target else '') + '：' + reason
    status = outcome.get('http_status')
    if type(status) is int and 100 <= status <= 599 and f'HTTP {status}' not in reason:
        text += f'；HTTP {status}'
    error_type = outcome.get('error_type')
    if (stage in {'query', 'internal'} and isinstance(error_type, str)
            and re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]{0,79}', error_type) and error_type not in reason):
        text += f'；异常类型：{error_type}'
    return text


def investigation_progress_summary(result, events):
    """Separate a completed inconclusive assessment from work that never finished."""
    recorded = any(isinstance(event.get('investigation'), dict) for event in events)
    supplied = result.get('investigation_incomplete')
    if not recorded and type(supplied) is not int:
        return ''  # Legacy records cannot establish which unknowns were uninvestigated.
    def state(event):
        value = event.get('investigation')
        return value.get('state') if isinstance(value, dict) else None
    incomplete = (max(0, supplied) if type(supplied) is int else
                  sum(state(event) != 'ready' and event.get('risk') == 'unknown'
                      and not event.get('assessment', {}).get('ended') for event in events))
    inconclusive = (sum(state(event) == 'ready' and event.get('risk') == 'unknown'
                        for event in events) if recorded else max(0, result.get('unknown', 0) - incomplete))
    return f'已完成调查但证据不足 {inconclusive} 条；调查未完成 {incomplete} 条。'


def incident_type(event):
    native = [label(event.get(key), '', 80) for key in ('incidentThreatClass', 'incidentThreatType')]
    return ' / '.join(value for value in native if value) or label(event.get('type') or event.get('incidentType') or event.get('eventType'), '类型未提供', 80)


def page_summary(page, items, cumulative, complete, *, selection=None, received=None, counts=None):
    if selection is not None:
        text = (f'本地筛选条件：{selection}。第 {page} 页原始返回 {received} 条，'
                f'符合条件 {len(items)} 条，排除 {received - len(items)} 条。'
                f"本轮原始累计去重 {counts['source_unique']} 条，符合条件 {cumulative} 条，"
                f"排除 {counts['excluded_unique']} 条；重复返回 {counts['duplicates']} 条。")
        if complete:
            text += f'分页已完整结束。本轮 XDR 安全事件符合条件 {cumulative} 条。'
    else:
        text = f'第 {page} 页查询到 {len(items)} 条事件，本轮累计去重 {cumulative} 条。'
    if complete and selection is None:
        text += f'分页已完整结束。本轮 XDR 安全事件查询到 {cumulative} 条事件。'
    elif not complete:
        text += '分页尚未结束，暂不保存本批事件和上次查询进度。'
    lines = (f"{i}. {event_label(event)}；类型：{incident_type(event)}；主机：{label(event.get('hostIp'), '未提供', 100)}。"
             for i, event in enumerate(items, 1))
    return Summary(text, detail_lines(lines, len(items)), sections=[
        {'label': '本步目的', 'text': '获取符合查询条件的事件，并检查本页与已读页面是否重复。'},
        {'label': '实际发现', 'text': text},
        {'label': '下一步', 'text': '本批查询完整，可以保存事件及查询进度，进入调查。' if complete else '继续查询下一页；本批尚不提交事件或推进查询进度。'},
    ])


def hosts_summary(event, hosts):
    missing = sum(not any(host.get(key) for key in ('id', 'hostId', 'hostIp', 'ip', 'name')) for host in hosts)
    text = f'针对事件 {event_label(event)}，查询到 {len(hosts)} 条关联主机记录。'
    if missing:
        text += f'其中 {missing} 条未提供主机标识，不能据此确认具体主机。'
    elif not hosts:
        text += '该事件本次未返回关联主机。'
    lines = (f"{i}. 名称：{label(host.get('name'))}；标识：{label(host.get('hostId') or host.get('id'), limit=100)}；地址：{label(host.get('hostIp') or host.get('ip'), limit=100)}。"
             for i, host in enumerate(hosts, 1))
    return Summary(text, detail_lines(lines, len(hosts)))


def event_sources_summary(result, total):
    """Describe known query/backlog counts; older saved results lack this split."""
    if not all(type(result.get(key)) is int for key in ('query_events', 'resumed_events', 'query_resumed_overlap')):
        return f'读取 {total} 条事件'
    text = (f"本轮查询未完整成功，已保存查询结果 {result['query_events']} 条" if result.get('query_complete') is False else
            f"本轮查询返回 {result['query_events']} 条")
    text += f"，纳入历史待办 {result['resumed_events']} 条"
    if result['query_resumed_overlap']:
        text += f"（其中 {result['query_resumed_overlap']} 条也被本轮查询命中，已合并去重）"
    if result.get('rechecked_events'):
        text += f"，另核验历史事件 {result['rechecked_events']} 条"
    return text + f'，本轮共纳入 {total} 条事件'


def analysis_summary(result, events, groups):
    related = [keys for keys in groups.values() if len(keys) > 1]
    if not events and result['errors']:
        return Summary('关联分析已跳过：事件查询未完整成功，没有可分析的完整事件批次。不能将此次失败理解为查询到 0 条事件。此前收到的回信是否完成跟进，以本轮回信及回查记录为准。')
    text = f"关联结果已整理：{event_sources_summary(result, len(events))}，形成 {len(related)} 个同设备、同主机关联组，涉及 {sum(map(len, related))} 条事件；确认风险 {result['risk']} 条、无风险 {result.get('benign', 0)} 条、待判定 {result['unknown']} 条。"
    text += f"其中 {result.get('analyzed', 0)} 条已有调查结论。"
    text += investigation_progress_summary(result, events)
    if result['errors']:
        text += f"有 {len(result['errors'])} 项查询或调查未完成，结果不完整；请查看对应失败步骤。"
        text += '本步骤完成只表示结果汇总完成，不代表事件调查全部成功；程序故障不能当作证据不足或无风险结论。'
    if len(events) == 1:
        text += '本轮只有一条事件，因此没有多事件关联组；这不表示没有关联主机。'
    text += '只有当前版本、引用实际行为证据且高置信确认的风险才通知责任人；无风险和证据不足分别在事件列表保留，后者尚未排除风险。处置完成以 XDR 回查事实为准。'
    by_key = {event['key']: event for event in events}
    lines = (f"{i}. 主机：{label(by_key[keys[0]].get('host'), limit=100)}；关联事件：" + '；'.join(event_label(by_key[key]) for key in keys[:20]) + (f'；另 {len(keys)-20} 条事件见上方各页查询明细' if len(keys) > 20 else '') + '。'
             for i, keys in enumerate(related, 1))
    lines = list(lines) + [f"事件：{event_label(event)}；研判说明：{label(event.get('reason'), limit=500)}；与本轮同设备、同主机的其他事件关联 {len(event.get('related', []))} 条。" for event in events]
    return Summary(text, detail_lines(lines, len(lines)))


def evidence_summary(event, decision, *, development=False):
    evidence = decision.evidence
    failed = evidence['failedQueries']
    value = evidence['gptResult']
    verdict = ('属于规则识别的恶意结论' if value in {10, 20, 110, 115, 120} else
               '属于规则识别的误报结论，仍须核对实体证据' if value in {40, 160} else '本组件无法仅凭该值确认恶意或误报')
    lines = [f'事件：{event_label(event)}', f"XDR 研判：{verdict}（gptResult：{label(value, '未提供')}）。"]
    for kind, name in ENTITY_LABELS.items():
        data = evidence['entities'].get(kind)
        if kind in failed or data is None:
            reason = label(evidence.get('failedReasons', {}).get(kind), '未取得可用实体结果', 300)
            lines.append(f'{name}：证据未取得或结构不符合约定；原因：{reason}。不能当作零条或安全。')
        else:
            malicious = sum(x['level'] == 3 for x in data['items'])
            safe = sum(x['level'] == 1 for x in data['items'])
            unknown = len(data['items']) - malicious - safe
            lines.append(f"{name}：{data['count']} 条" + (f"，隔离确认：{'是' if data['isolated'] else '否'}。" if kind == 'host' else
                         f'；恶意 {malicious} 条、安全 {safe} 条、待判定 {unknown} 条。'))
    conclusion = ('证据不完整，无法给出完整风险结论。' if failed else
                  'XDR 误报结论与业务或实体证据一致，满足忽略建议条件。' if decision.target == 60 else
                  '已返回证据仅作为跟进依据，不能把等级或既有状态当作威胁已消除。')
    text = f'证据核对完成：{conclusion}规则建议：{decision.reason.replace("标为", "建议标为")}。此处尚未修改 XDR。'
    if development:
        text += '本次为邮件链路测试，无论是否需要处置，都向已配置的责任人发送一封测试通知；风险结论保持原样。'
    return Summary(text, '\n'.join(lines))


def operation_summary(event, params, value):
    """Summarize only whitelisted facts; never persist raw entity payloads."""
    from time import time
    from .adapter import page_items, response_items
    from .status_rules import entities
    action = params['action']
    prefix = f'事件：{event_label(event)}。'
    if action == 'list':
        items, _ = page_items(value)
        details = '\n'.join(f"{event_label(item)}；当前状态：{STATUS_LABELS.get(item.get('dealStatus'), '未知')}；主机：{label(item.get('hostIp'))}。" for item in items[:5])
        return {'matches': len(items)}, Summary(prefix + f'按事件编号精确查询返回 {len(items)} 条。' + ('用来确认仍是原事件及当前状态，查询本身不会修改状态。' if items else '未返回目标事件，本次不继续发送或写入；保留记录供核对。'), details)
    if action == 'get_entities':
        kind = params['entity_type']
        data = entities(kind, value, int(time()))
        source = response_items(value.get('data'))
        lines = []
        for index, item in enumerate(source):
            identifiers = '；'.join(f'{key}：{label(item[key])}' for key in ('id', 'name', 'hostIp', 'fileName', 'md5', 'sha256', 'processName', 'ip', 'domain') if type(item.get(key)) in (str, int))
            fact = data['items'][index] if kind != 'host' else {}
            lines.append(f"{index + 1}. {identifiers or '未提供可展示的名称或标识'}；" + (f"威胁判定：{ {1: '安全', 3: '恶意'}.get(fact.get('level'), '待判定')}；控制成功证据：{'有' if fact.get('controlled') else '未确认'}。" if kind != 'host' else '主机隔离证据在分析步骤统一核对。'))
        details = f"工具动作：get_entities；关联字段：uuid；实体类型：{kind}。\n" + detail_lines(lines, len(source))
        return data, Summary(prefix + f"查询关联{ENTITY_LABELS.get(kind, kind)}，得到 {data['count']} 条。" + ('没有返回该类实体，不代表事件没有风险。' if not data['count'] else '这些是该事件自身的关联证据，用于后续核对。'), details)
    return {'request_completed': True}, Summary(prefix + '状态标记接口已返回，接下来重新查询 XDR；只有回查状态一致才算确认。')


def round_summary(status, result, observed, feedback, notification, enabled, development):
    text = f"本轮{ {'completed': '完成', 'failed': '失败'}[status]}：{event_sources_summary(result, len(observed))}，确认风险 {result['risk']} 条，无风险 {result.get('benign', 0)} 条，待判定 {result['unknown']} 条。"
    if status == 'completed':
        text += '本轮执行已结束；告警是否需要跟进、是否已闭环分别记录。'
    text += f"其中 {result.get('analyzed', 0)} 条已有调查结论。"
    text += investigation_progress_summary(result, observed)
    if result.get('deferred'):
        text += f"另有 {result['deferred']} 条已保存待后续轮次调查。"
    if result['errors']:
        text += '\n待跟进事项：' + '；'.join(result['errors']) + '。已有证据和待办保留，不据此判定无风险。'
    if not observed:
        text += ('查询未完整成功，不能据此说没有告警；请检查失败步骤后重试。' if not result.get('query_complete', not result['errors']) else
                 '当前时间范围和筛选条件下没有可分析事件，因此未生成新的告警通知；后续轮次继续查询。')
    for event in observed[:5]:
        investigation = event.get('investigation')
        if investigation:
            state = {'ready': '已形成调查结论', 'pending': '已保存，待续查', 'deferred': '本轮额度用完，已延期',
                     'system_wait': '系统故障，调查尚未恢复', 'needs_review': '需人工核对，不再自动续查'}.get(investigation['state'], '待核对')
            if investigation.get('error_kind') == 'model_cooldown':
                state = '模型退避中，本轮未重复调查'
            elif investigation.get('error_kind') == 'query_time':
                state = '时间参数待修复，调查未完成'
            reason = investigation_failure_summary(investigation) if investigation['state'] != 'ready' else investigation.get('reason', '')
            text += f"\n智能体调查：{event_label(event)} · {state}。{reason}"
            if investigation['state'] in {'pending', 'deferred'}:
                text += (f"已保存退避计划；不早于 {label(investigation.get('next_retry_at'), '后续计划监测')} 再次尝试。"
                         if investigation.get('error_kind') == 'model_cooldown' else '下一轮优先读取已有证据继续调查。')
            elif investigation['state'] == 'system_wait':
                text += ('等待正式 XDR 查询提供合法时间窗口后重新调查；不会重复发送错误参数。'
                         if investigation.get('error_kind') == 'query_time' else
                         '自动恢复次数已用完；请修复依赖后暂停并重新启动监测，再次尝试。' if investigation.get('retry_exhausted') else
                         f"已保存恢复计划；不早于 {label(investigation.get('next_retry_at'), '下一次计划监测')} 再次尝试。")
    backlog = result.get('investigation_backlog', {})
    if any(backlog.get(key) for key in ('pending', 'deferred', 'system_wait', 'needs_review')):
        text += ('\n历史与当前未完成调查：'
                 f"待续查 {backlog.get('pending', 0)} 条、额度延期 {backlog.get('deferred', 0)} 条、"
                 f"系统故障 {backlog.get('system_wait', 0)} 条、业务待人工核对 {backlog.get('needs_review', 0)} 条。")
        parameter_blocked = backlog.get('query_time_blocked', 0)
        stopped = max(0, backlog.get('retry_exhausted', 0) - parameter_blocked)
        if parameter_blocked:
            text += f"其中 {parameter_blocked} 条等待正式 XDR 查询修复时间窗口，不重复发送错误参数。"
        if stopped:
            text += f"其中 {stopped} 条已停止自动恢复，需修复后手动重新启动。"
        if backlog.get('system_wait') and status == 'completed':
            text += '本轮没有新增调查故障；上述历史故障待恢复，不代表本轮再次失败。'
        if backlog.get('needs_review'):
            text += '业务待人工核对不会在下轮自动续查。'
    lifecycle = result.get('followup', {})
    if lifecycle:
        text += f"\n状态跟进：本轮核验前轮意图 {lifecycle.get('processed', 0)} 条，回查确认 {lifecycle.get('verified', 0)} 条；新产生的忽略意图留待下一轮执行。中低风险证据不足默认观察 {lifecycle.get('observation_rounds', 6)} 轮，高风险存疑持续保留。"
        if lifecycle.get('reconciliation', {}).get('external_closed'):
            text += f"按原事件编号确认 {lifecycle['reconciliation']['external_closed']} 条已由外部处置结束。"
        if lifecycle.get('reconciliation', {}).get('monitoring_ended'):
            text += (f"完整 XDR 查询未再返回 {lifecycle['reconciliation']['monitoring_ended']} 条历史事件，已归档；"
                     '保留原研判与历史记录，不再自动观察或跟进。')
        warnings = lifecycle.get('errors', []) + lifecycle.get('reconciliation', {}).get('errors', [])
        if warnings:
            text += '\n跟进待核验：' + '；'.join(warnings[:5])
    if enabled:
        sent = '发送计数暂不可用' if notification.get('unavailable') else f"发送 {notification['sent']} 封"
        received = ('回信处理进度暂不可用' if feedback.get('unavailable') else
                    f"处理回信 {feedback['processed']} 封，{feedback['verified']} 封已回查确认，{feedback['pending']} 封待自动核验")
        text += f'\n邮件：{sent}；{received}。邮件状态与是否收到回信不决定本轮任务成败。'
        text += '\n' + '\n'.join(notification.get('explanations', [])[:5]) if notification.get('explanations') else ''
        if notification['sent']:
            text += '\n下一步：请回复测试处理结果；回信先保存，下一轮解读并核对原事件，明确完成后标记忽略并回查。' if development else '\n下一步：等待责任人回信，下一轮解读并核对原事件，再标记状态和回查。'
        elif feedback['pending'] or notification['pending']:
            text += '\n下一步：已收到的回信由程序继续核验；发送结果未知时不会自动重发。发信失败或尚未收到回信时，可在发信记录更新处置状态。'
        elif observed:
            text += '\n未新增邮件不等于没有风险；请按上方通知判断查看去重或未发送原因。'
        mail = result.get('mail', {})
        health = mail.get('health', {})
        warnings = mail.get('warnings', [])
        if warnings:
            text += '\n邮件跟进提示（不影响本轮任务结果）：' + '；'.join(warnings)
        if health.get('errors'):
            if not warnings:
                text += '\n邮件跟进提示（不影响本轮任务结果）：' + '；'.join(health['errors'])
            text += '。当前不能把处理回信 0 封解释为没有新回信。'
    else:
        text += '\n邮件跟进未启用，本轮不发送责任人邮件；忽略或处置是否已执行，以本轮状态跟进和 XDR 回查记录为准。需要邮件协同时，请配置责任人邮箱并启用邮件跟进。'
    if development:
        text += '\n本轮仅统计随机样本，不代表全部告警；测试标记忽略不代表威胁已消除。'
    return text
