"""Fast, daily-frozen knowledge snapshots from bounded, authorized excerpts.

No source file is changed. Metadata cursors and day seals live in the same
atomic current record as the summary, never in a separately advanced cursor.
"""
from __future__ import annotations

import asyncio
import codecs
import html
import os
import re
import stat
from datetime import datetime, timezone
from html.parser import HTMLParser
from zoneinfo import ZoneInfo

MAX_CANDIDATE_READS = 100


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _today(settings: dict) -> str:
    return _now().astimezone(ZoneInfo(settings["dailyTimezone"])).date().isoformat()


def publication_date(settings: dict) -> str:
    """Called inside the actual commit worker, not before it is queued."""
    return _today(settings)


def _published(record: dict | None) -> bool:
    return bool(record and record.get("version") and isinstance(record.get("content"), str) and record["content"].strip())


def _sealed_date(record: dict | None, settings: dict) -> str | None:
    if not _published(record):
        return None
    state = record.get("daily_state") or {}
    if state.get("sealed_date"):
        return state["sealed_date"]
    try:
        return datetime.fromisoformat(record["updated_at"].replace("Z", "+00:00")).astimezone(
            ZoneInfo(settings["dailyTimezone"])).date().isoformat()
    except (ValueError, TypeError, KeyError):
        return None


def _daily(record: dict | None, settings: dict, *, historical: bool = False) -> dict:
    state = (record or {}).get("daily_state") or {}
    available = len((record or {}).get("sources", []))
    result = {
        "enabled": True, "locked": not historical and _sealed_date(record, settings) == _today(settings),
        "date": (_sealed_date(record, settings) or _today(settings)) if historical else _today(settings), "timezone": settings["dailyTimezone"],
        "mode": state.get("mode", "reused" if _published(record) else "initial"),
        "sample_count": state.get("sample_count", 0),
        "sample_limit": state.get("sample_limit", settings["initialSampleSize"]),
        "available_count": state.get("available_count", available),
        "pending_count": state.get("pending_count", 0),
        "base_version": state.get("base_version"),
        "generation_method": state.get("generation_method", "model" if _published(record) else "reused"),
        "scan_incomplete": bool(state.get("scan_incomplete", False)),
    }
    if state.get("generation_note"):
        result["generation_note"] = state["generation_note"]
    return result


def read(engine, context: dict, category: dict, config: dict, version: str | None = None) -> dict:
    if version is not None and not engine._VERSION.fullmatch(version):
        raise engine.ExperienceNotFound("知识版本不存在。")
    relative = f"{category['id']}/history/{version}.json" if version else f"{category['id']}/current.json"
    record = engine._read_json(context, relative)
    if version and record is None:
        raise engine.ExperienceNotFound("知识版本不存在。")
    value = engine._empty(category)
    value["daily"] = _daily(record, context["settings"], historical=version is not None)
    if _published(record):
        value.update({key: record[key] for key in ("content", "updated_at", "version", "coverage", "changes")})
        value.update(status="ready", sources=[engine._public_source(source) for source in record.get("sources", [])])
        diagnostics = (record.get("daily_state") or {}).get("diagnostics")
        if diagnostics:
            value["diagnostics"] = engine._safe_diagnostics(diagnostics)
    # Day freezes take precedence over old failures and other domains' running
    # jobs. No catalogue scan or source content/hash read occurs on this path.
    if version is not None or value["daily"]["locked"]:
        return value
    attempt = engine._read_json(context, f"{category['id']}/attempt.json")
    if attempt and attempt.get("read_notice"):
        value.update(status="stale" if _published(record) else "empty", error=attempt["read_notice"],
                     last_attempt_at=attempt.get("updated_at"), pending_coverage=attempt.get("coverage"))
    if attempt and attempt.get("error"):
        value.update(status="stale" if _published(record) else "failed",
                     error=engine._attempt_message(attempt["error"], _published(record)),
                     diagnostics=engine._safe_diagnostics(attempt.get("diagnostics")),
                     last_attempt_at=attempt.get("updated_at"), pending_coverage=attempt.get("coverage"))
    if engine._is_running(context):
        value["status"] = "running"
    return value


class _PlainText(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.parts = []
        self.blocked = 0

    def handle_starttag(self, tag, attrs):
        if tag.lower() in {"script", "style", "iframe", "object"}:
            self.blocked += 1
        elif not self.blocked:
            self.parts.append(" ")

    def handle_endtag(self, tag):
        if tag.lower() in {"script", "style", "iframe", "object"} and self.blocked:
            self.blocked -= 1

    def handle_data(self, data):
        if not self.blocked:
            self.parts.append(data)


def _clean(text: str) -> str:
    parser = _PlainText()
    parser.feed(text)
    parser.close()
    text = "".join(parser.parts)
    text = re.sub(r"!?\[([^\]\n]*)\]\([^\n)]*\)", r"\1（链接已隐藏）", text)
    text = re.sub(r"(?:https?://|javascript:)[^\s<>\]\)]+", "（外链已隐藏）", text, flags=re.I)
    text = re.sub(r"\[S-[^\]\n]+\]", "", text)
    text = re.sub(r"(?i)\bBearer\s+[A-Za-z0-9._~+/=-]+", "Bearer（已隐藏）", text)
    text = re.sub(r"(?i)([\"']?(?:api[_-]?key|access[_-]?token|refresh[_-]?token|password|passwd|secret|client_secret|authorization|token)[\"']?\s*[:=]\s*)(?:\"[^\"]*\"|'[^']*'|[^\s,;}]+)",
                  r"\1（已隐藏）", text)
    text = re.sub(r"((?:密码|口令|密钥|令牌)\s*[:：=]\s*)[^\s,，;；]+", r"\1（已隐藏）", text)
    text = re.sub(r"\bsk-[A-Za-z0-9_-]{16,}\b", "（密钥已隐藏）", text)
    return "".join(character for character in text if character in "\n\t" or ord(character) >= 32).strip()


def _quote(text: str) -> str:
    # Deterministic fallback renders source text literally, not as executable
    # HTML/links/images or model-generated source-reference syntax.
    text = html.escape(_clean(text), quote=False)
    return re.sub(r"([\\`*_{}\[\]()#+\-!|>])", r"\\\1", text)


def _bounded(text: str, maximum: int) -> str:
    if len(text) <= maximum:
        return text
    marker = "\n（中间内容未纳入本轮摘录）\n"
    budget = max(0, maximum - len(marker))
    head = budget * 2 // 3
    return text[:head] + marker[:maximum] + (text[-(budget - head):] if budget > head else "")


def _key(node: dict) -> str:
    return node["root"] + ":" + node["path"]


def _signature(engine, node: dict) -> str:
    return engine._hash([node.get("size", 0), node.get("modified_at", 0)])


def _excerpt(engine, context: dict, node: dict) -> tuple[dict, str]:
    parts = engine.knowledge._path_parts(node["path"])
    limit = context["settings"]["excerptChars"]
    root = context["roots"][node["root"]]
    with engine._directory(root, "/".join(parts[:-1])) as directory:
        fd = os.open(parts[-1], os.O_RDONLY | os.O_NOFOLLOW | getattr(os, "O_NONBLOCK", 0), dir_fd=directory)
        with os.fdopen(fd, "rb") as stream:
            before = os.fstat(stream.fileno())
            if not stat.S_ISREG(before.st_mode):
                raise ValueError("not a regular source")
            byte_limit = limit * 4 + 4
            if before.st_size <= byte_limit:
                raw = stream.read(byte_limit + 1)
                text = raw.decode("utf-8-sig", errors="strict")
                truncated = len(text) > limit
                text = _bounded(text, limit)
            else:
                head_raw = stream.read(byte_limit)
                stream.seek(max(0, before.st_size - byte_limit))
                tail_raw = stream.read(byte_limit)
                head = codecs.getincrementaldecoder("utf-8-sig")("strict").decode(head_raw, final=False)
                tail = None
                for offset in range(4):
                    try:
                        tail = tail_raw[offset:].decode("utf-8", errors="strict")
                        break
                    except UnicodeError:
                        continue
                if tail is None:
                    raise UnicodeError("source is not UTF-8")
                text = _bounded(head + tail, limit)
                truncated = True
            after = os.fstat(stream.fileno())
            fields = lambda item: (item.st_dev, item.st_ino, item.st_size, item.st_mtime_ns, item.st_ctime_ns)
            if fields(before) != fields(after) or "\x00" in text:
                raise ValueError("source changed or is binary")
    cleaned = _clean(text)
    if not cleaned:
        raise ValueError("no usable source text")
    metadata = {**node, "size": before.st_size, "modified_at": before.st_mtime}
    source = {key: node[key] for key in ("root", "path", "name", "date")}
    source.update(id=engine._source_id(node["root"], node["path"]), metadata_signature=_signature(engine, metadata), excerpt=truncated)
    return source, cleaned


def _extractive(category: dict, selected: list[tuple[dict, str]], previous_text: str) -> str:
    lines = ["## 资料要点摘编（自动整理）", "本次采用有限资料摘录，未进行模型归纳，不代表已覆盖全部历史资料或已确认处置结论。"]
    if previous_text:
        lines += ["### 沿用上版要点（节选）", _quote(_bounded(previous_text, 400))]
    lines.append("### 本轮资料中的要点")
    for source, excerpt in selected:
        lines += ["#### " + _quote(source["name"]) + "（" + _quote(str(source["date"] or "日期未记录")) + "）",
                  "> " + _quote(_bounded(excerpt, 300)).replace("\n", "\n> "), "来源： [" + source["id"] + "]"]
    lines += ["### 使用边界", "以上是原文节选，建议、异常描述和待确认事项保留原意；不能据此声称问题已解决，请结合来源全文复核。"]
    return "\n\n".join(lines)


def _seal_reused(engine, context: dict, category_id: str, record: dict) -> None:
    record = {**record, "daily_state": {**record["daily_state"], "sealed_date": publication_date(context["settings"])}}
    engine._write_json(context, f"{category_id}/current.json", record)


def _legacy_baseline(engine, saved: dict, nodes: list[dict], complete: bool) -> dict:
    """Adopt prior full summaries without hashing/reprocessing their old files."""
    try:
        cutoff = datetime.fromisoformat(saved["updated_at"].replace("Z", "+00:00")).timestamp()
    except (ValueError, TypeError, KeyError):
        cutoff = _now().timestamp()
    old_sources = {_key(source): source for source in saved.get("sources", [])}
    seen = {}
    for node in nodes:
        key = _key(node)
        old = old_sources.get(key)
        signature = old.get("signature") if old else None
        if isinstance(signature, list) and len(signature) >= 4:
            unchanged = (node.get("size") == signature[2] and
                         abs(float(node.get("modified_at", 0)) - float(signature[3]) / 1000000000) < 0.001)
            seen[key] = _signature(engine, node) if unchanged else ""
        elif float(node.get("modified_at") or 0) <= cutoff:
            seen[key] = _signature(engine, node)
    return {"seen": seen, "baseline_at": cutoff, "baseline_complete": complete, "generation_method": "model"}


async def update(engine, user, summarize, category=None, *, authorize=None, context=None) -> dict:
    context = context or engine._context(user)
    settings = context["settings"]
    config = engine.knowledge_catalog.load_config()
    categories = [engine._category(config, category)] if category else config["categories"]
    counts = {"updated": 0, "failed": 0, "unchanged": 0, "extractive": 0, "frozen": 0, "reused": 0}
    results = []
    model = engine._Model(summarize, context, authorize)
    with engine._user_lock(context) as acquired:
        if not acquired:
            return {"status": "running", "results": [], "calls": 0, **counts}
        await model.reauthorize()
        pending = []
        for definition in categories:
            saved = engine._read_json(context, f"{definition['id']}/current.json")
            if _sealed_date(saved, settings) == _today(settings):
                counts["unchanged"] += 1
                counts["frozen"] += 1
                results.append(read(engine, context, definition, config))
            else:
                pending.append((definition, saved))
        # Same-day retries never scan sources, even when the files changed.
        index = await asyncio.to_thread(engine._scan, context, config) if pending else None
        for definition, saved in pending:
            model.stage, model.source_id, model.prompt_chars = "inventory", None, 0
            model.last_validation_error_code = None
            state = (saved or {}).get("daily_state") or {}
            nodes = [node for node in index["files"] if node["category"] == definition["id"] and
                     node["kind"] != "process" and node["is_text_file"]]
            nodes.sort(key=lambda node: (str(node.get("date") or ""), float(node.get("modified_at") or 0), node["root"], node["path"]), reverse=True)
            if _published(saved) and not isinstance(state.get("seen"), dict):
                state = _legacy_baseline(engine, saved, nodes, not index["truncated"])
            initial = not isinstance(state.get("seen"), dict)
            seen = dict(state.get("seen") or {})
            baseline_at = float(state.get("baseline_at", _now().timestamp()))
            candidates = nodes if initial else [node for node in nodes if
                (_key(node) in seen and seen[_key(node)] != _signature(engine, node)) or
                (_key(node) not in seen and (state.get("baseline_complete", False) or float(node.get("modified_at") or 0) > baseline_at))]
            limit = settings["initialSampleSize"] if initial else settings["dailySampleSize"]
            base_version = saved.get("version") if _published(saved) else None
            coverage = {"total": len(candidates), "processed": 0, "skipped": 0, "failed": 0,
                        "unsupported": 0, "too_large": 0, "incomplete": bool(index["truncated"])}
            selected = []
            failed_keys = set()
            try:
                await model.reauthorize()
                if not candidates and _published(saved):
                    next_seen = {**seen, **{_key(node): _signature(engine, node) for node in nodes}}
                    next_state = {**state, "seen": next_seen,
                                  "baseline_at": baseline_at, "sealed_date": _today(settings), "mode": "reused",
                                  "baseline_complete": bool(state.get("baseline_complete", False) or not index["truncated"]),
                                  "sample_count": 0, "sample_limit": limit, "available_count": len(nodes),
                                  "pending_count": 0, "base_version": base_version,
                                  "generation_method": state.get("generation_method", "model"),
                                  "scan_incomplete": bool(index["truncated"])}
                    updated = {**saved, "daily_state": next_state}
                    engine._check_read_scope(user, context)
                    await engine._commit_locked_write(_seal_reused, engine, context, definition["id"], updated)
                    counts["unchanged"] += 1
                    counts["reused"] += 1
                    results.append(read(engine, context, definition, config))
                    continue
                attempted = 0
                for node in candidates[:MAX_CANDIDATE_READS]:
                    if len(selected) >= limit:
                        break
                    attempted += 1
                    try:
                        selected.append(await asyncio.to_thread(_excerpt, engine, context, node))
                    except (OSError, ValueError, UnicodeError):
                        coverage["failed"] += 1
                        failed_keys.add(_key(node))
                if not selected:
                    # No invented content and no day seal: newly arriving files
                    # can be retried immediately, even on the same local day.
                    notice = (f"本轮已尝试读取 {attempted} 份文本资料，未找到可用内容；请检查文件编码或读取权限后重试。"
                              if attempted else "当前没有可读取的文本资料，未生成经验；可在资料可用后重试。")
                    await engine._commit_locked_write(engine._write_json, context, f"{definition['id']}/attempt.json",
                        engine._record(context, updated_at=engine._now(), error=None, read_notice=notice, coverage=coverage))
                    empty = engine._empty(definition)
                    empty.update(daily=_daily(None, settings), error=notice)
                    empty["daily"]["available_count"] = len(nodes)
                    if _published(saved):
                        empty = read(engine, context, definition, config)
                        empty["error"] = notice
                    counts["unchanged"] += 1
                    results.append(empty)
                    continue
                previous_text = _bounded(_clean(saved["content"]), settings["previousSummaryChars"]) if _published(saved) else ""
                pieces = [{"text": excerpt, "ids": [source["id"]], "name": _clean(source["name"]),
                           "date": source["date"], "sampled_excerpt": True} for source, excerpt in selected]
                if previous_text:
                    pieces.append({"text": previous_text, "ids": [], "kind": "previous_summary", "base_version": base_version})
                method, diagnostics = "model", None
                model.stage, model.source_id = "domain_merge", None
                try:
                    content = (await model.run(definition, engine.DAILY_OVERVIEW_MODE, pieces, fast=True))["text"]
                except engine._ModelFailure as error:
                    if not model.authorized or error.code == "model_cancelled":
                        raise
                    if error.code in {"model_auth", "model_not_configured", "model_unavailable", "model_connection",
                                      "model_timeout", "model_deadline_exceeded", "model_rate_limit"}:
                        model.fast_disabled_code = error.code
                    diagnostics = model.diagnostics(error)
                    method = "extractive"
                    content = _extractive(definition, selected, previous_text)
                await model.reauthorize()
                engine._check_read_scope(user, context)
                if initial:
                    next_seen = {_key(node): "" if _key(node) in failed_keys else _signature(engine, node) for node in nodes}
                else:
                    next_seen = dict(seen)
                    if not index["truncated"] and not state.get("baseline_complete", False):
                        candidate_keys = {_key(node) for node in candidates}
                        next_seen.update({_key(node): _signature(engine, node) for node in nodes if _key(node) not in candidate_keys})
                for source, _ in selected:
                    next_seen[_key(source)] = source["metadata_signature"]
                remaining = sum(_key(node) not in next_seen or next_seen[_key(node)] != _signature(engine, node) for node in candidates)
                coverage["processed"] = len(selected)
                sources = [source for source, _ in selected]
                daily_state = {"seen": next_seen, "baseline_at": baseline_at, "sealed_date": _today(settings),
                               "baseline_complete": bool(state.get("baseline_complete", False) or not index["truncated"]),
                               "mode": "initial" if initial else "incremental", "sample_count": len(selected),
                               "sample_limit": limit, "available_count": len(nodes), "pending_count": remaining,
                               "base_version": base_version, "generation_method": method,
                               "scan_incomplete": bool(index["truncated"])}
                if method == "extractive":
                    daily_state.update(generation_note="模型未完成本轮归纳，已使用真实资料摘录进行本地自动整理。", diagnostics=diagnostics)
                changes = {"added": sum(_key(source) not in seen for source in sources),
                           "modified": sum(_key(source) in seen for source in sources), "removed": 0}
                model.stage = "publish"
                await engine._commit_publication(context, definition, content, sources, coverage, changes,
                                                 engine._hash(["daily-sampled", daily_state["sealed_date"], next_seen]), daily_state)
                counts["updated"] += 1
                counts["extractive"] += int(method == "extractive")
                results.append(read(engine, context, definition, config))
            except (engine.ExperienceError, OSError) as error:
                counts["failed"] += 1
                message = engine._attempt_message(str(error) if isinstance(error, engine.ExperienceError) else "知识存储暂时不可用。", _published(saved))
                diagnostics = model.diagnostics(error)
                if model.authorized:
                    try:
                        await engine._commit_locked_write(engine._write_json, context, f"{definition['id']}/attempt.json",
                            engine._record(context, updated_at=engine._now(), error=message, coverage=coverage, diagnostics=diagnostics))
                    except (OSError, engine.ExperienceError):
                        pass
                results.append({**engine._empty(definition), "status": "failed", "error": message,
                                "daily": _daily(saved, settings), "diagnostics": diagnostics})
                if not model.authorized:
                    break
        engine._check_read_scope(user, context)
    status = "partial" if counts["failed"] and counts["updated"] else "failed" if counts["failed"] else "ready" if counts["updated"] else "unchanged"
    return {"status": status, "results": results, "calls": model.calls, **counts}
