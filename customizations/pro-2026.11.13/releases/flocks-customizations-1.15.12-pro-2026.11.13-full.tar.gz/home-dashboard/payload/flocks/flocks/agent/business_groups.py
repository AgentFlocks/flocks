"""Business defaults for the known security specialists and legacy installs.

Only legacy catalog labels are upgraded in memory. User config overlays are
applied afterwards by the registry; files, capabilities and visibility stay put.
"""
from flocks.agent.agent import AgentInfo

# name: (business group, legacy catalog group)
BUSINESS_GROUPS = {
    "rex": ("安全任务统筹", "系统辅助"),
    "api-security": ("网络与应用安全", "安全研判"),
    "ndr-analyst": ("网络与应用安全", "安全研判"),
    "host-forensics": ("主机安全", "安全研判"),
    "host-forensics-fast": ("主机安全", "安全研判"),
    "asset-survey": ("资产暴露面", "威胁情报"),
    "hrti-threat-intelligence": ("威胁与漏洞情报", "威胁情报"),
    "vul-threat-intelligence": ("威胁与漏洞情报", "威胁情报"),
    "ti-analyst": ("威胁与漏洞情报", "威胁情报"),
    "phishing-detector": ("邮件安全", "安全研判"),
    "device-inspector": ("运行保障", "平台集成"),
    "flocks-troubleshooter": ("运行保障", "运行保障"),
}


def with_business_group(agent: AgentInfo) -> AgentInfo:
    default = BUSINESS_GROUPS.get(agent.name)
    if default is None or agent.group not in (None, "", default[1]):
        return agent
    return agent.model_copy(update={"group": default[0]})
