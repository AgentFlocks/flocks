"""
Agent Registry — simplified 4-step loader.

Replaces the old flocks.agent.core.registry module (kept as a shim).

Loading order:
  ① Collect context: tools and skills
  ② scan_and_load() — built-in YAML agents + plugin YAML agents
  ③ Python plugin agents via PluginLoader + cfg.agent user overrides
  ④ inject_dynamic_prompts() — phase-2 dynamic prompt injection

Merged from flocks.agent.metadata:
  is_delegatable(), get_agent_mode(), is_hidden(),
  list_delegatable_agents(), list_primary_agents(), list_subagents()
"""

from __future__ import annotations

import asyncio
import importlib
import json
import os
import threading
from collections import OrderedDict
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Set

from flocks.utils.log import Log
from flocks.config.config import Config, ConfigInfo
from flocks.provider.provider import Provider, ChatMessage
from flocks.project.instance import Instance
from flocks.permission import from_config, merge
from flocks.agent.agent import (
    AgentInfo,
    AgentModel,
    AgentPromptMetadata,
    AvailableAgent,
    AvailableSkill,
    AvailableWorkflow,
    DelegationTrigger,
    normalize_agent_group,
)
from flocks.agent.business_groups import with_business_group
import flocks.agent.delegatable_settings as delegatable_settings
from flocks.agent.toolset import agent_declares_tool
from flocks.agent.tool_permissions import permission_items_to_ruleset
from flocks.agent.prompt_utils import categorize_tools
from flocks.agent.agent_factory import (
    scan_and_load,
    inject_dynamic_prompts,
    yaml_to_agent_info as _yaml_to_agent_info,
)
from flocks.plugin import PluginLoader, ExtensionPoint
from flocks.skill.skill import Skill

log = Log.create(service="agent.registry")

# Agent name aliases for backward compatibility
AGENT_ALIASES: Dict[str, str] = {
    "sisyphus": "rex",
    "sisyphus-junior": "rex-junior",
}

# ---------------------------------------------------------------------------
# Runtime metadata reference  (shared with backward-compat metadata.py)
# ---------------------------------------------------------------------------

_agents_ref: Optional[Dict[str, AgentInfo]] = None


def _set_agents_ref(agents: Dict[str, AgentInfo]) -> None:
    """Set the live agent dict reference.  Called once after all agents load."""
    global _agents_ref
    _agents_ref = agents


# ---------------------------------------------------------------------------
# Metadata query helpers  (merged from metadata.py)
# ---------------------------------------------------------------------------

def is_delegatable(agent_name: str) -> bool:
    resolved = AGENT_ALIASES.get(agent_name, agent_name)
    if not _agents_ref:
        return False
    agent = _agents_ref.get(resolved)
    return bool(agent and agent.delegatable and not agent.hidden)


def get_agent_mode(agent_name: str) -> Optional[str]:
    if _agents_ref and agent_name in _agents_ref:
        return _agents_ref[agent_name].mode
    return None


def is_hidden(agent_name: str) -> bool:
    if _agents_ref and agent_name in _agents_ref:
        return _agents_ref[agent_name].hidden
    return False


def list_delegatable_agents() -> List[str]:
    if _agents_ref:
        return [n for n, a in _agents_ref.items() if a.delegatable and not a.hidden]
    return []


def list_primary_agents() -> List[str]:
    if _agents_ref:
        return [n for n, a in _agents_ref.items() if a.mode == "primary"]
    return []


def list_subagents() -> List[str]:
    if _agents_ref:
        return [n for n, a in _agents_ref.items() if a.mode == "subagent"]
    return []


# ---------------------------------------------------------------------------
# Delegation candidate list builder
# ---------------------------------------------------------------------------

def _make_default_prompt_metadata(agent: AgentInfo) -> AgentPromptMetadata:
    return AgentPromptMetadata(
        category="plugin",
        cost="medium",
        triggers=[DelegationTrigger(
            domain=agent.name,
            trigger=agent.description or f"Tasks requiring {agent.name}",
        )],
    )


def _build_available_agents(agents: Dict[str, AgentInfo]) -> List[AvailableAgent]:
    available: List[AvailableAgent] = []
    for agent in agents.values():
        if not (agent.delegatable and agent.mode != "primary" and not agent.hidden):
            continue
        metadata = agent.prompt_metadata or _make_default_prompt_metadata(agent)
        available.append(AvailableAgent(
            name=agent.name,
            description=agent.description or "",
            metadata=metadata,
        ))
    return available


def _sort_available_agents(agents: List[AvailableAgent]) -> List[AvailableAgent]:
    return sorted(agents, key=lambda agent: agent.name.lower())


def _storage_custom_agent_to_info(agent_data: Dict[str, Any]) -> Optional[AgentInfo]:
    """Convert a Storage-backed custom agent record into AgentInfo."""
    name = agent_data.get("name")
    if not name:
        return None

    model_raw = agent_data.get("model")
    model: Optional[AgentModel] = None
    if isinstance(model_raw, dict):
        model_id = model_raw.get("model_id") or model_raw.get("modelID")
        provider_id = model_raw.get("provider_id") or model_raw.get("providerID")
        if model_id and provider_id:
            model = AgentModel(model_id=model_id, provider_id=provider_id)

    return AgentInfo(
        name=name,
        group=agent_data.get("group"),
        name_cn=agent_data.get("name_cn") or agent_data.get("nameCn"),
        description=agent_data.get("description"),
        description_cn=agent_data.get("description_cn") or agent_data.get("descriptionCn"),
        prompt=agent_data.get("prompt"),
        temperature=agent_data.get("temperature"),
        color=agent_data.get("color"),
        mode=agent_data.get("mode", "primary"),
        model=model,
        native=False,
        hidden=agent_data.get("hidden", False),
        delegatable=agent_data.get("delegatable"),
        permission=permission_items_to_ruleset(agent_data.get("permission")),
        tools=agent_data.get("tools", []),
        skills=agent_data.get("skills", []),
        prompt_profile=agent_data.get(
            "prompt_profile",
            agent_data.get("promptProfile", "standard"),
        ),
        tags=agent_data.get("tags", []),
    )


async def _load_storage_custom_agents(existing_names: Set[str]) -> Dict[str, AgentInfo]:
    """Load Storage-backed custom agents created by POST /api/agent."""
    try:
        from flocks.storage.storage import Storage
        entries = await Storage.list_entries("agent/custom/")
    except Exception as exc:
        log.warn("agent.registry.storage_custom_load_error", {"error": str(exc)})
        return {}

    loaded: Dict[str, AgentInfo] = {}
    for key, agent_data in entries:
        if not isinstance(agent_data, dict) or not agent_data.get("name"):
            continue
        agent = _storage_custom_agent_to_info(agent_data)
        if agent is None:
            continue
        if agent.name in existing_names or agent.name in loaded:
            log.warn("agent.registry.storage_custom_name_conflict", {
                "name": agent.name,
                "key": key,
            })
            continue
        loaded[agent.name] = agent
    return loaded


def _apply_delegatable_overrides(agents: Dict[str, AgentInfo]) -> None:
    overrides = delegatable_settings.load_overrides()
    for name, delegatable in overrides.items():
        agent = agents.get(name)
        if agent is not None:
            agent.delegatable = delegatable


def _apply_enabled_agents(
    agents: Dict[str, AgentInfo],
    enabled_agents: Optional[List[str]],
) -> None:
    """Apply the configured allowlist after any registry merge stage."""
    if enabled_agents is None:
        return
    allowed = set(enabled_agents)
    for name in [key for key in agents if key not in allowed]:
        del agents[name]


def _delegation_candidates(
    agents: Dict[str, AgentInfo],
    registered: Dict[str, AgentInfo],
    managed_names: Iterable[str],
    enabled_agents: Optional[List[str]],
) -> Dict[str, AgentInfo]:
    """The agents an orchestrator's prompt may offer for delegation.

    The loaded agents and the runtime-registered ones (Agent.register), merged
    the way the registry merges them: not over a managed name, and within the
    configured allowlist. ``delegate_task`` accepts a registered delegatable
    agent, so the prompt that tells the orchestrator whom to delegate to has to
    name it as well.
    """
    reserved = set(managed_names)
    candidates = dict(agents)
    for name, info in registered.items():
        if name not in reserved:
            candidates[name] = info
    _apply_enabled_agents(candidates, enabled_agents)
    return candidates


# ---------------------------------------------------------------------------
# Agent registry
# ---------------------------------------------------------------------------

class Agent:
    """
    Agent management namespace.

    Provides async get/list/refresh methods backed by a cached
    asyncio.Task that runs the 4-step load flow exactly once per
    session startup.
    """

    # Process-level registry for agents registered at runtime via Agent.register().
    #
    # Scope: GLOBAL (shared across all sessions in the same process).
    # This is intentional — runtime-registered agents behave like dynamically
    # installed plugin agents: once registered, they are available to every
    # session that runs in the process.
    #
    # Consequence: do NOT use Agent.register() to inject session-scoped
    # temporary agents.  If session isolation is needed in the future, a
    # separate per-session registry keyed by session_id should be introduced.
    _custom_agents: Dict[str, AgentInfo] = {}

    # ── Loading ────────────────────────────────────────────────────────────

    @staticmethod
    async def _load_agents() -> Dict[str, AgentInfo]:
        """
        4-step agent loading:

        ① Context  — tools and skills
        ② YAML     — scan_and_load() from built-in + plugin directories
        ③ Plugins  — PluginLoader Python modules + cfg.agent overrides
        ④ Prompts  — inject_dynamic_prompts() for phase-2 dynamic agents
        """
        # Lazy imports to avoid circular dependencies
        from flocks.tool.registry import ToolRegistry

        cfg = await Config.get()
        await ToolRegistry.init_async()

        # ── ① Collect context ─────────────────────────────────────────────
        available_tools = [t.name for t in ToolRegistry.list_tools() if t.enabled]
        categorized_tools = categorize_tools(available_tools)
        # Use list_enabled() so user-disabled skills are excluded from the
        # agent's system prompt context.  All() would include them.
        skills = await Skill.list_enabled()
        available_skills = [
            AvailableSkill(name=s.name, description=s.description, location=s.source or "project")
            for s in skills
        ]
        # Discover available workflows (best-effort; failure must not block agent load)
        available_workflows: List[AvailableWorkflow] = []
        try:
            from flocks.workflow.center import scan_skill_workflows
            workflow_entries = await scan_skill_workflows()
            for entry in workflow_entries:
                available_workflows.append(AvailableWorkflow(
                    name=entry.get("name") or "",
                    description=entry.get("description") or "",
                    path=entry.get("workflowPath") or "",
                    source=entry.get("sourceType") or "project",
                ))
        except Exception as _wf_err:
            log.debug("agent.registry.workflow_scan_skipped", {"error": str(_wf_err)})

        user_perms = from_config(cfg.permission or {})
        cli_run_mode = (
            os.environ.get("FLOCKS_CLI_RUN_MODE") == "true"
            or os.environ.get("FLOCKS_CLI_RUN_MODE") == "true"
        )
        cli_overrides = from_config({"question": "deny"}) if cli_run_mode else []

        if cfg.agent_logic and cfg.agent_logic != "rex":
            log.warn("agent.logic.deprecated", {"message": "non-rex agent logic is deprecated; using rex"})

        # ── ② YAML agents ─────────────────────────────────────────────────
        result = await asyncio.to_thread(scan_and_load)

        # Apply global base permissions on top of per-agent YAML permissions.
        # For agents with explicit tool lists, their deny-all baseline is kept;
        # only user config overrides are merged on top.
        if user_perms or cli_overrides:
            for agent in result.values():
                agent.permission = merge(agent.permission, user_perms, cli_overrides)

        # ── ③ Python plugin agents + cfg.agent overrides ──────────────────

        def _consume_agents(agents: list, source: str) -> None:
            for agent in agents:
                if agent.name in result:
                    log.warn("plugin.name_conflict", {
                        "name": agent.name,
                        "source": source,
                        "hint": f"Plugin agent '{agent.name}' conflicts with existing agent, skipped",
                    })
                    continue
                result[agent.name] = agent

        PluginLoader.register_extension_point(ExtensionPoint(
            attr_name="AGENTS",
            subdir="agents",
            item_type=AgentInfo,
            dedup_key=lambda a: a.name,
            consumer=_consume_agents,
            yaml_item_factory=_yaml_to_agent_info,
        ))
        PluginLoader.load_extension(
            "AGENTS",
            extra_sources=cfg.plugin or [],
            project_dir=Path.cwd(),
        )

        # Load complete Storage definitions before applying cfg.agent overlays.
        # Otherwise a group-only override creates an empty agent and masks the
        # stored prompt/model/tools on the next reload.
        storage_custom_agents = await _load_storage_custom_agents(set(result.keys()))
        result.update(storage_custom_agents)

        # User overrides from cfg.agent
        default_llm = await Config.resolve_default_llm()
        default_model_id = default_llm["model_id"] if default_llm else None

        base_permissions = _build_base_permissions(user_perms, cli_overrides)

        def _permission_dict_to_tools(permission_cfg: Dict[str, Any]) -> List[str]:
            try:
                from flocks.permission.next import PermissionNext
                from flocks.tool.registry import ToolRegistry

                ToolRegistry.init()
                ruleset = from_config(permission_cfg)
                return [
                    tool.name
                    for tool in ToolRegistry.list_tools()
                    if getattr(tool, "enabled", True)
                    and tool.name not in {"invalid", "_noop"}
                    and PermissionNext.evaluate(tool.name, "*", ruleset) == "allow"
                ]
            except Exception as exc:
                log.warn("agent.registry.permission_to_tools.error", {"error": str(exc)})
                return []

        from flocks.agent.managed import managed_agent_ids, managed_agents

        managed_names = managed_agent_ids()
        disabled_by_config: Set[str] = set()

        if cfg.agent:
            for key, value in cfg.agent.items():
                alias_key = AGENT_ALIASES.get(key, key)
                if alias_key != key:
                    log.warn("agent.alias.deprecated", {"message": f'"{key}" is deprecated, use "{alias_key}"'})
                key = alias_key
                if value.disable:
                    result.pop(key, None)
                    disabled_by_config.add(key)
                    continue
                if key in managed_names:
                    # The deployment's definition is not overlaid; only
                    # disabling it (above) and its group (below) are local.
                    if any(
                        field != "group" and setting not in (None, {}, [])
                        for field, setting in value.model_dump(exclude_defaults=True).items()
                    ):
                        log.warn("agent.managed.config_override_ignored", {"name": key})
                    continue

                item = result.get(key)
                if not item:
                    # Metadata overlays cannot turn a removed/missing definition
                    # into an executable empty agent. Empty serialized defaults
                    # (notably options={}) are not definition fields either.
                    if value.group is not None and not any(
                        field != "group" and setting not in (None, {}, [])
                        for field, setting in value.model_dump(exclude_defaults=True).items()
                    ):
                        continue
                    item = AgentInfo(
                        name=key,
                        mode="all",
                        permission=base_permissions,
                        tools=[],
                        options={},
                        native=False,
                    )
                    result[key] = item

                if value.prompt:
                    item.prompt = value.prompt
                if value.prompt_append and item.prompt:
                    item.prompt = item.prompt + "\n\n" + value.prompt_append
                if value.description:
                    item.description = value.description
                if value.description_cn is not None:
                    item.description_cn = value.description_cn
                if value.temperature is not None:
                    item.temperature = value.temperature
                if value.top_p is not None:
                    item.top_p = value.top_p
                if value.mode:
                    item.mode = value.mode
                if value.color:
                    item.color = value.color
                if value.hidden is not None:
                    item.hidden = value.hidden
                if value.steps is not None:
                    item.steps = value.steps
                if value.delegatable is not None:
                    item.delegatable = value.delegatable
                if value.skills is not None:
                    item.skills = list(value.skills)
                if value.prompt_profile is not None:
                    item.prompt_profile = value.prompt_profile
                item.options.update(value.options)
                if value.permission:
                    item.permission = merge(item.permission, from_config(value.permission), cli_overrides)
                    if isinstance(value.permission, dict):
                        item.tools = _permission_dict_to_tools(value.permission)

        # ── ③b Managed agents ─────────────────────────────────────────────
        # What the deployment manages (flocks.content.managed) replaces every
        # local agent of the same name -- YAML, plugin, Storage or config --
        # and a name whose definition is unusable stays reserved instead of
        # falling back to a local copy.
        for name in managed_names:
            result.pop(name, None)
        for name, info in managed_agents().items():
            if name in disabled_by_config:
                continue
            if user_perms or cli_overrides:
                # The global and CLI restrictions bind a managed agent like
                # any YAML one (step ②); only its definition is the deployment's.
                info = info.model_copy(update={"permission": merge(info.permission, user_perms, cli_overrides)})
            result[name] = info

        _apply_delegatable_overrides(result)

        # enabled_agents whitelist filter
        _apply_enabled_agents(result, cfg.enabled_agents)

        # ── ④ Phase-2 dynamic prompts ──────────────────────────────────────
        # Runtime-registered agents are merged below, after the prompts are
        # built; as delegation candidates they are counted already.
        available_agents = _build_available_agents(
            _delegation_candidates(result, Agent._custom_agents, managed_names, cfg.enabled_agents)
        )
        inject_dynamic_prompts(
            result,
            available_agents,
            categorized_tools,
            available_skills,
            available_workflows,
        )

        # Merge runtime-registered custom agents -- except over a managed name,
        # which no in-process registration may take over either.
        for name, info in Agent._custom_agents.items():
            if name in managed_names:
                log.warn("agent.managed.registration_ignored", {"name": name})
                continue
            result[name] = info

        # Upgrade known legacy catalog groups in memory, before explicit user overlays.
        result = {name: info if name in managed_names else with_business_group(info)
                  for name, info in result.items()}

        # Group overlays also apply to runtime/Storage registrations. Copy the
        # result rather than mutating the registered source definition.
        for key, value in (cfg.agent or {}).items():
            key = AGENT_ALIASES.get(key, key)
            if key in result and value.group is not None and not result[key].group_readonly:
                result[key] = result[key].model_copy(
                    update={"group": normalize_agent_group(value.group)}
                )

        # Runtime registration is not an escape hatch around the configured
        # agent allowlist. Apply the same policy after every registry source
        # has been merged.
        _apply_enabled_agents(result, cfg.enabled_agents)

        # Share reference with metadata query functions
        _set_agents_ref(result)

        return result

    @staticmethod
    def _create_task():
        return asyncio.create_task(Agent._load_agents())

    _state_accessor = Instance.state(_create_task)

    # Last observed mtime of skill_settings.json — used by each worker process
    # to detect changes made by other workers.  Stored as a class variable so it
    # persists across async calls in the same process.
    _skill_settings_mtime: float = 0.0
    _delegatable_settings_mtime: float = 0.0

    @classmethod
    def _sync_skill_settings_cache(cls) -> None:
        """Invalidate in-process agent cache when skill settings change on disk.

        ``PATCH /api/skills/{name}/toggle`` writes ``skill_settings.json`` and
        then calls ``Agent.invalidate_cache()``, which only clears the cache for
        the *current* uvicorn worker.  Other workers never receive the signal and
        keep serving stale agent prompts that still include the now-disabled skill.

        Each worker independently calls this method at the start of
        :meth:`state`.  If the file's mtime is newer than what this worker last
        saw, the local cache is dropped so the next :meth:`state` call rebuilds
        the agent prompts from the current (post-toggle) skill list.
        """
        try:
            sentinel = Skill.settings_path()
            if not sentinel.exists():
                return
            current_mtime = sentinel.stat().st_mtime
            if current_mtime > cls._skill_settings_mtime:
                # Another worker (or the current one) updated the settings file.
                # Record the new mtime first to avoid a redundant invalidation on
                # the very next call in the same worker.
                cls._skill_settings_mtime = current_mtime
                cls._state_accessor.invalidate_all()  # type: ignore[attr-defined]
        except Exception:
            pass

    # Generation of the managed-content snapshot the cached agents were built
    # from (flocks.content.managed); a refresh that changed it rebuilds them.
    _managed_generation: int = -1

    @classmethod
    def _sync_managed_content_cache(cls) -> None:
        from flocks.content.managed import ManagedContent

        generation = ManagedContent.generation()
        if generation != cls._managed_generation:
            cls._managed_generation = generation
            cls.invalidate_cache()

    @classmethod
    def _sync_delegatable_settings_cache(cls) -> None:
        """Invalidate in-process agent cache when delegatable overrides change on disk."""
        try:
            sentinel = delegatable_settings.settings_path()
            if not sentinel.exists():
                return
            current_mtime = sentinel.stat().st_mtime
            if current_mtime > cls._delegatable_settings_mtime:
                cls._delegatable_settings_mtime = current_mtime
                cls._state_accessor.invalidate_all()  # type: ignore[attr-defined]
        except Exception:
            pass

    # Agent plugin files are process-global, but ``_state_accessor`` keys its
    # cache by the *current* instance directory.  ``invalidate_cache`` can run
    # without an instance context (the file watcher fires from a timer thread),
    # so it also bumps a generation counter and :meth:`state` drops any
    # per-instance cache that was built under an older generation.
    _cache_generation: int = 0
    _state_generations: Dict[str, int] = {}

    @staticmethod
    async def state() -> Dict[str, AgentInfo]:
        # Detect cross-worker skill-settings changes before serving cached state.
        Agent._sync_skill_settings_cache()
        Agent._sync_delegatable_settings_cache()
        Agent._sync_managed_content_cache()
        key = Instance.get_directory() or "default"
        if Agent._state_generations.get(key) != Agent._cache_generation:
            Agent._state_accessor.invalidate()  # type: ignore[attr-defined]
            Agent._state_generations[key] = Agent._cache_generation
        load = Agent._state_accessor()
        if load.cancelled() or (not load.done() and load.get_loop().is_closed()):
            # A cancelled load, or one left pending on a closed event loop,
            # would stay cached and fail every later call.
            Agent._state_accessor.invalidate()  # type: ignore[attr-defined]
            load = Agent._state_accessor()
        # Every caller awaits the same load task.  Shield it so a cancelled
        # caller (a client disconnecting, a background task stopped) does not
        # cancel the load for everyone.
        return await asyncio.shield(load)

    @classmethod
    async def refresh(cls) -> Dict[str, AgentInfo]:
        cls.invalidate_cache()
        return await cls.state()

    @classmethod
    def invalidate_cache(cls) -> None:
        """Invalidate cached agent state in every directory of this process.

        Dynamic agent prompts depend on the current tool registry, so tool
        plugin refreshes also need a lightweight way to invalidate agents.
        """
        cls._cache_generation += 1
        cls._state_accessor.invalidate_all()  # type: ignore[attr-defined]

    # ── Lookup ──────────────────────────────────────────────────────────────

    #: Managed agents as each task first got them: (task scope, name) -> agent.
    #: scope -> agent name -> the definition that task got first; dropped when the task ends.
    _task_agents: "dict[str, dict[str, AgentInfo]]" = {}
    _task_agents_hooked = False

    @classmethod
    async def get(cls, agent: str) -> Optional[AgentInfo]:
        agents = await cls.state()
        resolved = AGENT_ALIASES.get(agent, agent)
        return cls._as_the_task_got_it(resolved, agents.get(resolved))

    @classmethod
    def _as_the_task_got_it(cls, name: str, current: Optional[AgentInfo]) -> Optional[AgentInfo]:
        """A managed agent stays as the running task first got it.

        A refresh of the managed content rebuilds every agent; a run already
        using one keeps the definition it started with (see
        flocks.content.managed.task_scope).  One the deployment no longer
        offers is not served, not even as the run got it earlier.
        """
        from flocks.agent.managed import managed_agent_ids
        from flocks.content.managed import ManagedContent, current_task_scope
        from flocks.content.models import ContentKind

        scope = current_task_scope()
        if scope is None or name not in managed_agent_ids():
            return current
        if name not in ManagedContent.available_ids(ContentKind.AGENT):
            return None
        if not cls._task_agents_hooked:
            from flocks.content.managed import on_task_scope_end

            on_task_scope_end(cls._release_task_agents)
            cls._task_agents_hooked = True
        held = cls._task_agents.setdefault(scope, {})
        pinned = held.get(name)
        if pinned is not None:
            return pinned
        if current is not None:
            held[name] = current
        return current

    @classmethod
    def _release_task_agents(cls, scope: str) -> None:
        cls._task_agents.pop(scope, None)

    @classmethod
    async def get_group_definition(cls, name: str) -> Optional[AgentInfo]:
        """Resolve selected group authority even for disabled/filtered YAML agents.

        There is no separate ownership cache: active agents reuse their loaded
        metadata; disabled definitions use the same first-wins native discovery.
        A name the deployment manages has no local definition: a file of that
        name is not the managed agent, whether that one is available or not.
        """
        from flocks.agent.managed import managed_agent_ids

        agent = await cls.get(name)
        if agent is not None:
            return agent
        resolved = AGENT_ALIASES.get(name, name)
        if resolved in managed_agent_ids():
            return None
        definitions = await asyncio.to_thread(scan_and_load)
        definition = definitions.get(resolved)
        return with_business_group(definition) if definition is not None else None

    @classmethod
    async def validate_group_settings(cls, updates: Dict[str, Any]) -> None:
        """Reject explicit fixed-group changes before generic config side effects."""
        for name, settings in updates.items():
            if not isinstance(settings, dict) or "group" not in settings:
                continue
            agent = await cls.get_group_definition(name)
            if agent is not None and agent.group_readonly:
                if normalize_agent_group(settings["group"]) != normalize_agent_group(agent.group):
                    raise ValueError(f"System agent group is read-only: {name}")

    @classmethod
    async def list(cls) -> List[AgentInfo]:
        cfg = await Config.get()
        agents = await cls.state()

        def sort_key(a: AgentInfo):
            if cfg.default_agent:
                default_name = AGENT_ALIASES.get(cfg.default_agent, cfg.default_agent)
                is_default = default_name == a.name
            else:
                is_default = a.name == "rex"
            return (not is_default, a.name)

        return sorted(agents.values(), key=sort_key)

    @classmethod
    async def list_available_agents(cls) -> List[AvailableAgent]:
        agents = await cls.state()
        return _sort_available_agents(_build_available_agents(agents))

    @classmethod
    async def default_agent(cls) -> str:
        cfg = await Config.get()
        agents = await cls.state()

        if cfg.default_agent:
            default_name = AGENT_ALIASES.get(cfg.default_agent, cfg.default_agent)
            agent = agents.get(default_name)
            if not agent:
                raise ValueError(f'default agent "{cfg.default_agent}" not found')
            if agent.mode == "subagent":
                raise ValueError(f'default agent "{cfg.default_agent}" is a subagent')
            if agent.hidden:
                raise ValueError(f'default agent "{cfg.default_agent}" is hidden')
            return agent.name

        rex = agents.get("rex")
        if rex and rex.mode != "subagent" and not rex.hidden:
            return rex.name

        for agent in agents.values():
            if agent.mode != "subagent" and not agent.hidden:
                return agent.name

        raise ValueError("no primary visible agent found")

    # ── Additional listing helpers ──────────────────────────────────────────

    @classmethod
    async def list_names(cls) -> List[str]:
        return [a.name for a in await cls.list()]

    @classmethod
    async def list_visible(cls) -> List[AgentInfo]:
        return [a for a in await cls.list() if not a.hidden]

    @classmethod
    async def list_hidden(cls) -> List[AgentInfo]:
        return [a for a in await cls.list() if a.hidden]

    @classmethod
    async def list_subagents(cls) -> List[AgentInfo]:
        return [a for a in await cls.list() if a.mode == "subagent" and not a.hidden]

    @classmethod
    async def list_primary(cls) -> List[AgentInfo]:
        return [a for a in await cls.list() if a.mode in ["primary", "all"] and not a.hidden]

    @classmethod
    async def list_by_mode(cls, mode: str) -> List[AgentInfo]:
        return [a for a in await cls.list() if a.mode == mode]

    @classmethod
    async def is_hidden(cls, agent_name: str) -> bool:
        agent = await cls.get(agent_name)
        return agent.hidden if agent else False

    # ── Prompt / config getters ─────────────────────────────────────────────

    @classmethod
    async def get_system_prompt(cls, agent_name: str) -> Optional[str]:
        agent = await cls.get(agent_name)
        return agent.prompt if agent else None

    @classmethod
    async def get_model_config(cls, agent_name: str) -> Optional[Dict[str, str]]:
        agent = await cls.get(agent_name)
        if not agent or not agent.model:
            return None
        return {
            "providerID": agent.model.provider_id,
            "modelID": agent.model.model_id,
        }

    # ── Tool declaration checking ───────────────────────────────────────────

    @classmethod
    async def has_tool(cls, agent_name: str, tool: str) -> bool:
        agent = await cls.get(agent_name)
        if not agent:
            return False
        if agent_declares_tool(agent, tool):
            return True
        from flocks.tool.catalog import get_always_load_tool_names
        return tool in get_always_load_tool_names()

    # ── Agent generation (LLM-assisted) ────────────────────────────────────

    @classmethod
    async def generate(cls, input_data: Dict[str, Any]) -> Dict[str, Any]:
        if input_data.get("model"):
            target_model = input_data["model"]
            provider_id = target_model["providerID"]
            model_id = target_model["modelID"]
        else:
            default_llm = await Config.resolve_default_llm()
            if default_llm:
                provider_id = default_llm["provider_id"]
                model_id = default_llm["model_id"]
            else:
                provider_id = "openai"
                model_id = "gpt-4"

        from flocks.session.prompt import SystemPrompt
        from flocks.session.prompt_strings import PROMPT_GENERATE
        system = SystemPrompt.header(provider_id)
        if hasattr(system, "append"):
            system.append(PROMPT_GENERATE)
        else:
            system = [PROMPT_GENERATE]

        existing = await cls.list()
        existing_names = ", ".join([a.name for a in existing])

        messages = [
            ChatMessage(role="system", content="\n".join(system)),
            ChatMessage(
                role="user",
                content=(
                    f'Create an agent configuration based on this request: "{input_data["description"]}".\n\n'
                    f"IMPORTANT: The following identifiers already exist and must NOT be used: {existing_names}\n"
                    "  Return ONLY the JSON object, no other text, do not wrap in backticks"
                ),
            ),
        ]

        response = await Provider.chat(model_id=model_id, messages=messages)
        content = response.content
        if "```json" in content:
            content = content.split("```json")[1].split("```")[0].strip()
        elif "```" in content:
            content = content.split("```")[1].split("```")[0].strip()

        try:
            return json.loads(content)
        except json.JSONDecodeError:
            raise ValueError(f"Failed to generate valid JSON: {content}")

    # ── File watcher ────────────────────────────────────────────────────────

    _watcher: Optional["AgentFileWatcher"] = None

    @classmethod
    def start_watcher(cls) -> None:
        """Start the file watcher that auto-invalidates the agent cache on plugin changes."""
        if cls._watcher is None:
            cls._watcher = AgentFileWatcher()
        cls._watcher.start()

    # ── Runtime registration ────────────────────────────────────────────────

    @classmethod
    def register(cls, name: str, info: AgentInfo) -> None:
        current = cls._custom_agents.get(name)
        if current is not None and current.prompt_protected and not info.prompt_protected:
            # A sealed definition is only ever replaced by another sealed one
            # (its own package re-registering); nothing else may swap it out.
            raise PermissionError(f"Agent {name} is protected and cannot be replaced")
        cls._custom_agents[name] = info

    @classmethod
    def registered(cls, name: str) -> Optional[AgentInfo]:
        """The runtime registration under *name*, if an extension made one."""
        return cls._custom_agents.get(name)

    @classmethod
    def unregister(cls, name: str) -> bool:
        if name in cls._custom_agents:
            del cls._custom_agents[name]
            return True
        return False


# ---------------------------------------------------------------------------
# Agent File Watcher
# ---------------------------------------------------------------------------


def _agent_event_should_reload(event: object) -> bool:
    """Return True if a watchdog event should invalidate the agent cache.

    Mirrors ``flocks.tool.registry._tool_event_should_reload``: atomic-save
    editors surface the real target via ``dest_path``, so we inspect both
    endpoints before deciding to skip.
    """
    candidates = []
    src = getattr(event, "src_path", "") or ""
    if src:
        candidates.append(src)
    dest = getattr(event, "dest_path", "") or ""
    if dest:
        candidates.append(dest)
    for path in candidates:
        # 只认 agents/ 之下的文件：skills/tools 里的 .md 改动不能触发 agent 重载
        if "agents" not in Path(path).parts:
            continue
        fname = os.path.basename(path)
        if fname == "agent.yaml" or path.endswith(".md"):
            return True
    return False


class AgentFileWatcher:
    """Watch plugin agent directories and auto-invalidate the Agent cache on change.

    Monitors:
    - ``~/.flocks/plugins/agents/``       (user-level)
    - ``<cwd>/.flocks/plugins/agents/``   (project-level)

    Triggers on ``agent.yaml`` or ``*.md`` file changes with a 1.5 s debounce
    so that IDE batch-writes (multiple files saved at once) only cause a single
    cache invalidation.
    """

    _DEBOUNCE_SECONDS = 1.5

    def __init__(self) -> None:
        self._observer: Optional[object] = None
        self._debounce_timer: Optional[threading.Timer] = None
        self._lock = threading.Lock()

    # ---- public ----

    def start(self) -> None:
        if self._observer is not None:
            return

        try:
            from watchdog.observers import Observer
            from watchdog.events import FileSystemEventHandler, FileSystemEvent
        except ImportError:
            log.warn(
                "agent.watcher.watchdog_missing",
                {"msg": "watchdog not installed, agent file watcher disabled"},
            )
            return

        watch_dirs = self._collect_watch_dirs()
        if not watch_dirs:
            log.info("agent.watcher.no_dirs", {"msg": "no agent plugin directories to watch"})
            return

        watcher = self

        # Only react to actual content-mutation events.  Without this guard the
        # ``opened``/``closed``/``closed_no_write`` events that watchdog emits
        # whenever any code (including the agent loader itself) reads
        # ``agent.yaml`` / ``*.md`` would re-trigger cache invalidation on every
        # access, causing a self-sustaining reload loop.
        _RELOAD_EVENT_TYPES = frozenset({"modified", "created", "deleted", "moved"})

        class _Handler(FileSystemEventHandler):
            def on_any_event(self, event: FileSystemEvent) -> None:
                if event.is_directory:
                    return
                if getattr(event, "event_type", "") not in _RELOAD_EVENT_TYPES:
                    return
                if _agent_event_should_reload(event):
                    watcher._schedule_invalidate()

        handler = _Handler()
        observer = Observer()
        for d in watch_dirs:
            try:
                observer.schedule(handler, d, recursive=True)
                log.debug("agent.watcher.watching", {"directory": d})
            except Exception as e:
                log.warn("agent.watcher.schedule_error", {"directory": d, "error": str(e)})

        observer.daemon = True
        observer.start()
        self._observer = observer
        log.info("agent.watcher.started", {"directories": sorted(watch_dirs)})

    def stop(self) -> None:
        with self._lock:
            if self._debounce_timer is not None:
                self._debounce_timer.cancel()
                self._debounce_timer = None
        if self._observer is not None:
            try:
                self._observer.stop()  # type: ignore[union-attr]
                self._observer.join(timeout=2)  # type: ignore[union-attr]
            except Exception:
                pass
            self._observer = None
            log.info("agent.watcher.stopped")

    # ---- internal ----

    def _schedule_invalidate(self) -> None:
        """Debounced cache invalidation."""
        with self._lock:
            if self._debounce_timer is not None:
                self._debounce_timer.cancel()
            self._debounce_timer = threading.Timer(
                self._DEBOUNCE_SECONDS, self._do_invalidate
            )
            self._debounce_timer.daemon = True
            self._debounce_timer.start()

    def _do_invalidate(self) -> None:
        Agent.invalidate_cache()
        log.info("agent.watcher.cache_invalidated", {"reason": "agent plugin file changed on disk"})

    def _collect_watch_dirs(self) -> Set[str]:
        """Return the agent directories to watch.

        ``<plugins>/agents`` is created first, so the ``agents/`` directory the
        first custom agent saved from the WebUI would otherwise create after
        startup is still covered.  The plugin roots themselves are
        ``ToolFileWatcher``'s: a second observer on the same path fails on
        macOS (FSEvents refuses it) and one of the two stops reloading.
        """
        dirs: Set[str] = set()
        try:
            from flocks.plugin.loader import DEFAULT_PLUGIN_ROOT
            user_root = Path(DEFAULT_PLUGIN_ROOT)
        except Exception:
            from flocks.config.config import get_user_plugins_root

            user_root = Path(get_user_plugins_root())

        user_dir = user_root / "agents"
        try:
            user_dir.mkdir(parents=True, exist_ok=True)
        except OSError:
            pass
        if os.path.isdir(user_dir):
            dirs.add(str(user_dir))

        try:
            project_root = Path.cwd() / ".flocks" / "plugins"
            project_dir = project_root / "agents"
            if str(project_dir) != str(user_dir) and project_root.is_dir():
                # The same for a project that keeps plugins: its first agent is still seen.
                try:
                    project_dir.mkdir(exist_ok=True)
                except OSError:
                    pass
                if project_dir.is_dir():
                    dirs.add(str(project_dir))
        except Exception:
            pass

        return dirs


# ---------------------------------------------------------------------------
# Base permission helper (for user-override created agents)
# ---------------------------------------------------------------------------

def _build_base_permissions(user_perms, cli_overrides):
    """Allow-all default permission set for user-created agents."""
    from flocks.agent.constants import Truncate
    defaults = from_config({
        "*": "allow",
        "doom_loop": "ask",
        "external_directory": {
            "*": "ask",
            f"{Truncate.DIR}": "allow",
            f"{Truncate.GLOB}": "allow",
        },
        "question": "deny",
        "read": {
            "*": "allow",
            "*.env": "ask",
            "*.env.*": "ask",
            "*.env.example": "allow",
        },
    })
    return merge(defaults, user_perms, cli_overrides)
