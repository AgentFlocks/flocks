"""Display defaults for known skills; never rewrite installed skill files."""

SECURITY_GROUPS = {
    'skyeye-sensor-use': ('网络安全', '平台集成'),
    'skyeye-use': ('网络安全', '平台集成'),
    'tdp-use': ('网络安全', '平台集成'),
    'onesig-use': ('网络安全', '平台集成'),
    'sangfor-edr-use': ('终端与主机安全', '平台集成'),
    'onesec-use': ('终端与主机安全', '平台集成'),
    'qingteng-use': ('终端与主机安全', '平台集成'),
    'sangfor-xdr-use': ('安全运营与设备接入', '平台集成'),
    'device-integration-guide': ('安全运营与设备接入', '平台集成'),
    'chaitin-cli': ('安全运营与设备接入', None),
    'ndr-alert-analysis': ('告警研判与取证', '安全研判'),
    'analyzing-browser-forensics-with-hindsight': ('告警研判与取证', None),
    'browser-use': ('浏览器与桌面自动化', '系统辅助'),
    'web2cli': ('浏览器与桌面自动化', '系统辅助'),
    'onboarding': ('运行保障', '系统辅助'),
    'workflow-builder': ('能力编排与开发', '系统辅助'),
    'workflow-config-guide': ('能力编排与开发', '系统辅助'),
    'skill-builder': ('能力编排与开发', '系统辅助'),
    'agent-builder': ('能力编排与开发', '系统辅助'),
    'tool-builder': ('能力编排与开发', '系统辅助'),
    'webui-page-builder': ('能力编排与开发', '系统辅助'),
}
PARADEV_GROUPS = {
    'browser': '浏览器与桌面自动化', 'computer': '浏览器与桌面自动化',
    'panes': '浏览器与桌面自动化',
    'plugins': '开发环境与集成', 'setup': '开发环境与集成',
    'integrations': '开发环境与集成', 'contribute': '开发环境与集成',
    'environment': '开发环境与集成',
    '10x': '协作与成果输出', 'standup': '协作与成果输出',
    'automate': '协作与成果输出', 'orchestrate': '协作与成果输出',
    'page': '协作与成果输出', 'doctor': '运行保障', 'feedback': '运行保障',
}


def business_skill_group(data: dict):
    name, current = data.get('name'), data.get('group')
    default = SECURITY_GROUPS.get(name)
    # An explicit blank is a user decision to ungroup, not a missing default.
    if 'group' in data and (not current or default is None or current != default[1]):
        return current
    if default:
        return default[0]
    # Generic names such as "page" are not enough to identify external skills.
    description = str(data.get('description', '')).lower()
    if name in PARADEV_GROUPS and ('paradev' in description or 'superset' in description):
        return PARADEV_GROUPS[name]
    return current
