import { useCallback, useEffect, useRef, useState } from 'react';
import { useCurrentUser, usePaneActive } from '@flocks/webui-contract-sdk';

// Memory only: never write alert evidence to browser storage.
export const FRESH_MS = 30_000;
export const RETAIN_MS = 5 * 60_000;
const entries = new Map<string, { data?: unknown; savedAt: number; pending?: Promise<unknown> }>();
let owner = '';
export function clearQueryCache() { entries.clear(); owner = ''; }
export function queryEntry(scope: string, key: string) {
  if (owner !== scope) { entries.clear(); owner = scope; }
  const now = Date.now();
  for (const [k, e] of entries) if (!e.pending && now - e.savedAt >= RETAIN_MS) entries.delete(k);
  return entries.get(key);
}
export async function cachedQuery<T>(scope: string, key: string, fetcher: () => Promise<T>, force = false): Promise<T> {
  let entry = queryEntry(scope, key);
  if (entry?.pending) return entry.pending as Promise<T>;
  if (!force && entry?.data !== undefined && Date.now() - entry.savedAt < FRESH_MS) return entry.data as T;
  entry = entry || { savedAt: 0 };
  entries.set(key, entry);
  const current = entry;
  current.pending = Promise.resolve().then(fetcher).then(data => {
    if (owner === scope && entries.get(key) === current) { current.data = data; current.savedAt = Date.now(); }
    return data;
  }).finally(() => { current.pending = undefined; });
  while (entries.size > 8) {
    const victim = [...entries].find(([k, e]) => k !== key && !e.pending);
    if (!victim) break;
    entries.delete(victim[0]);
  }
  return current.pending as Promise<T>;
}
export function useCachedQuery<T>(page: string, params: unknown, empty: T, fetcher: () => Promise<T>, failure: string, revision = 0) {
  const user = useCurrentUser?.();
  const active = usePaneActive?.() ?? true;
  const scope = JSON.stringify([user?.id ?? null, user?.username ?? null]);
  const key = JSON.stringify([scope, page, params], (name, value) => {
    if (value && typeof value === 'object' && value.mode === 'relative') return { mode: value.mode, range: value.range };
    return value;
  });
  const snapshot = queryEntry(scope, key)?.data as T | undefined;
  const [state, setState] = useState({ key, data: snapshot ?? empty, loading: snapshot === undefined, error: '' });
  const seq = useRef(0);
  const latest = useRef(key); latest.current = key;
  const fetchRef = useRef(fetcher); fetchRef.current = fetcher;
  const load = useCallback(async (force = true) => {
    if (!active) return;
    const version = ++seq.current;
    const cached = queryEntry(scope, key)?.data as T | undefined;
    setState({ key, data: cached ?? empty, loading: cached === undefined, error: '' });
    try {
      const fetch = fetchRef.current;
      const data = await cachedQuery(scope, key, fetch, force);
      if (version === seq.current && latest.current === key) setState({ key, data, loading: false, error: '' });
    } catch (err) {
      if (version === seq.current && latest.current === key) setState({ key, data: cached ?? empty, loading: false, error: err instanceof Error ? err.message : failure });
    }
  }, [key, scope, empty, failure, active]);
  useEffect(() => { void load(revision > 0); return () => { ++seq.current; }; }, [load, revision]);
  const visible = state.key === key ? state : { key, data: snapshot ?? empty, loading: snapshot === undefined, error: '' };
  return { ...visible, load, hasData: queryEntry(scope, key)?.data !== undefined };
}
