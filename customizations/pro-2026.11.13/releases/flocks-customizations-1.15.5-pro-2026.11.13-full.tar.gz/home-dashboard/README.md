# Flocks Pro 2026.11.13 定制增强包

增强包版本：**1.15.5**。仅适用于 `2026.11.13-linux-amd64`、Pro `c16ed13499b3ca721e3549893d5507c506bc2c58`、Core `2bc02382874a226ef63d20cab3734220ad752225`，运行树保护策略必须为 `native`。

## 本次迁移

将 1.14.10 的全部增强合并到官方 11.13 配对 Core，保留新版上游修复。增强源码为 [955632db](https://github.com/AgentFlocks/flocksdev/commit/955632db1e9b88486d460f04637e821370b83356)，开发分支 `codex/pro-1113-enhancements`；可复现差异保存在 `patches/core-1113.patch`。

保留以下能力：

- 首页与中文品牌文案、数字员工文案、知识分类、经验总结和工作流调用统计。
- 七个定制 SOC 工作流、安全运营监测、多 XDR 配置、模型恢复、邮件闭环与脱敏诊断。
- 监测流式对话、零事件结束、三色点缀、任务中心监测失败过滤和简洁错误详情。
- SOC 默认告警态势、执行记录默认展开、并行批次展示和页面会话缓存。
- Syslog ISO 时间头解析、定时任务详情滚动、报告路由与最近十天历史会话。
- Agent车间仅显示知识沉淀入口；保留知识库、记忆的直接路由与数据。
- 场景管理未开放 SOC 入口隐藏；设备巡检和情报分析两个 Agent 保持隐藏。

配对 Pro 前端使用原版扩展注册表和锁定依赖构建。Pro 原生任务、会话及工作流存储仍由发行版接管，增强通过适配层加载；保留 PostgreSQL 执行租约、代次校验、权限与原有 SQLite 回退，不迁移业务数据库。

## 安装与更新

交付仓库固定为 `AgentFlocks/flocks` 的 `fix/process_11.12_en` 分支。用户将该分支同步到 Gitee 的同名分支后，在远程机器原有 `update-flocks.sh` 所在目录执行：

```bash
bash update-flocks.sh
```

脚本下载固定 Gitee 分支 ZIP，根据 `delivery.json` 自动选择与当前 Pro 发行版匹配的补丁。无需修改下载地址、手动解压或先还原旧补丁。更新脚本不会把 11.12.2 基础发行版升级到 11.13；仓库仍保留旧版配套补丁。

请使用安装和运行 Pro 的系统账号执行。自定义安装位置沿用 `--pro-root`。下载、校验与预检在停服务前完成；相同包重复执行不重启，镜像旧版本不覆盖新补丁。未知手工修改会拒绝覆盖，失败自动回滚。

安装器修改当前受管发布中的 `runtime/flocks/`、`runtime/webui-dist/` 及配对 Pro SOC 文本模板；配置、账号、设备、授权、数据库、历史备份保持原样。Go 入口、Python、原生扩展和签名清单不覆盖。安装前后调用原版 `upgrade verify`；错误版本、符号链接冲突、未知改动、`all` 保护策略继续拒绝安装。

本次无需更新已安装的整个告警运营套件；既有用户插件不被直接覆盖。需要更新插件页面时，沿用待加载插件库的单项更新和备份流程。

## 查询与还原

```bash
"$HOME/.flocks/customizations/home-dashboard/apply.sh" --pro-root "$HOME/flockspro" status
"$HOME/.flocks/customizations/home-dashboard/apply.sh" --pro-root "$HOME/flockspro" inspect
```

正常更新无需手动还原。明确需要撤销时：

```bash
flocks stop && "$HOME/.flocks/customizations/home-dashboard/apply.sh" --pro-root "$HOME/flockspro" restore && flocks start --no-browser --webui-host 0.0.0.0
```

还原保留业务数据；安装后手工修改的代码不会被强制覆盖。

## 源码准备与打包

从本目录运行，选择两个尚不存在的源码目录：

```bash
python3 prepare_sources.py --core .work/core-1113 --pro .work/pro-1113
cd .work/core-1113/webui && npm ci && cd ../../..
FLOCKS_WEBUI_SRC="$PWD/.work/core-1113/webui" python3 .work/pro-1113/scripts/build_webui.py .work/pro-webui-candidate
python3 build_package.py --core .work/core-1113 --pro .work/pro-1113 --frontend .work/pro-webui-candidate
```

构建要求源码提交、Pro 注册表、输入哈希与生产前端清单一致，拒绝未提交改动。`runtime/` 与增强源码逐文件一致；SQLGlot 的 MIT 许可证随包保留。输出完整 tar.gz 与 SHA-256 文件。

## 验收边界

实际检查、代码及负载哈希见 `verification.json`。本机 5173 的基础发行仍是 11.12.2-darwin-arm64；本地验收使用临时本机基线清单和本包相同业务源码、前端，不替换原生文件。此验收与 Linux 11.13 原版安装器隔离验证分别记录，不将本机功能验证称为 Linux 实机验证。

远程服务器不由智能体部署。上传后仍需用户同步 Gitee、执行更新脚本并回传结果；真实 XDR、模型服务和邮件收发需远程业务验收。


## 1.15.1 监测关联总结精简

关联总结由固定程序模板生成，改为本轮结果、调查状态与必要通知边界两段；零值统计和完整调查结论计数移入折叠依据。保留历史待办、去重、查询不完整与系统故障提示，区分调查未完成和调查完成但证据不足。仅影响新生成的总结，已有对话和业务数据不改写。


## 1.15.2 模型管理 Provider 用量

已连接 Provider 卡片按已配置数量统计，不再依赖是否手动测试过连接。总 Tokens、总费用及真实缓存详情均随所选 Provider 切换，每 5 秒自动刷新真实统计；总费用固定人民币，图标为 ¥，两个演示 Provider 的金额单位为元。

用户指定的虚拟历史基数：private_model/private_models（含 custom-private-models）7,486,291,537 Tokens；ThreatBook-cn-llm 2,637,845,219 Tokens。演示总费用统一按每百万 Tokens 2 元估算，初始分别 14,972.58 元、5,275.69 元，并按真实 Tokens 增量继续增长；不是 Provider 实际账单。没有新调用时不自动制造用量。

首次成功读取各 Provider 时保存真实统计锚点，后续仅累加超过锚点的真实用量，避免历史真实总量再次叠加导致超出要求区间。锚点和最高值按账号/Provider 保存于当前浏览器 localStorage，刷新、切换和升级不重置；新浏览器或清除站点存储会重新从基数开始，不跨浏览器同步。真实用量数据库、模型定价、配置及缓存明细不改写；缓存详情继续显示真实统计。其他 Provider 仍显示自己的真实数据。


## 1.15.3 数字显示格式

总 Tokens 恢复原有 M 单位并固定两位小数，费用固定两位小数。初始 private_models 为 7486.29M、14972.58 元；ThreatBook-cn-llm 为 2637.85M、5275.69 元。仅改变展示精度，完整计数、基数、已存锚点、Provider 切换与真实增量均保留。


## 1.15.4 用量加载性能修复

旧实现每5秒发起新请求并推进序号；接口耗时超过5秒时，旧响应一直被后续请求作废，导致加载状态持续不结束。切换时清空统计且演示基数依赖真实接口，进一步放大等待。

现在按账号与Provider合并在途请求，在请求结束后5秒才发起下一轮，慢响应不会被定时器丢弃。真实统计保存在内存及当前标签页sessionStorage中，切换、返回与刷新优先展示已有快照，再后台更新；失败保留已有快照并提示重试。首次没有快照时，演示卡片直接显示原固定基数或localStorage中的累计值，真实缓存明细仍等待真实接口，不伪造缓存记录。只有成功读取真实统计后才初始化真实增量锚点，保留既有localStorage数据。

80项模型回归包含16秒延迟不重叠且正常显示、Provider切换乱序、挂起请求复用、刷新恢复快照及失败回退；未修改原生Pro数据库、回填逻辑或后端权限。本机暖用量接口连同浏览器导航与读取约0.28秒，此观测不代表远程接口耗时。


## 1.15.5 知识沉淀阅读优化

自动摘录不再递归引用上一版摘要，优先展示本轮资料原文要点；旧版自动摘录在读取时去掉重复套层，不改写原文及历史记录。历史版本和来源资料继续保留。处理范围、抽样数和每日更新状态收进“整理范围与更新详情”，首屏优先阅读内容。三个入口增加用途介绍及可展开说明；记忆文件说明每日记忆按实际记录产生，不等同于每日工作报告。自动摘录仍不是模型归纳或已确认的处置结论。

正文优先采用文档资料；JSON、CSV、XML等支撑证据仍可从目录查看。相同摘录合并展示并保留全部来源引用。
