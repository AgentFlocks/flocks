# DNS异常解析与隧道行为排查

只使用DNS日志排查失败解析和高熵长标签，不假定存在主机进程或已确认数据外传。

## 启动方式

归入“自定义工作流”，保留受管安装位置。内置手动触发器 `manual-review` 默认启用，状态为“就绪”；安装不会自动执行，不新建定时任务，也不开放Webhook。

可从工作流运行入口直接输入参数；“集成”页可查看、启用或停用“手动研判”触发器。初始输入 `{}` 使用内置 risk 合成样本；`{"scenario":"normal"}` 检查正常分支；`{"scenario":"insufficient"}` 检查资料不足分支。

“集成”页的手动触发卡片提供折叠的“手动运行”区，填写参数JSON后点击“运行一次”；原有概览测试运行仍可使用。原生手动触发接口为 `POST /api/workflow/custom-soc-ndr-dns/triggers/manual-review/test`，请求体使用 `{"body":{}}`（沿用应用登录认证），响应中的 `result.status` 才是实际执行状态。触发器还内置三种可供调用方读取的测试样本。映射将整个事件正文传入受限的 `suite_inputs`，不会把缺失数据数组映射为 null，也不会吞掉显式空数组。

触发器附带的 `_flocks`、`_trigger` 元数据只做形态和大小校验后丢弃，不参与身份授权、样本选择、业务研判或输出路径计算；现有登录权限保持不变。未提交事件正文或提交 null、数组等非对象正文会明确失败，不默认执行样本。

提供 `dns_records` 数组时只使用该数组，显式 `{"dns_records":[]}` 不会回退样本，必须进入待核验。外部数据标为 user_provided_unverified，不声称真实采集。可用带时区的 `evaluation_time` 指定历史评估时点；输出日期仍按实际执行时点动态计算。

## 数据字段与规则

client（合法IPv4/IPv6）、query、timestamp、rcode、query_type。

rcode 和 query_type 使用标准文本名称，大小写不敏感。支持的 rcode：NOERROR、FORMERR、SERVFAIL、NXDOMAIN、NOTIMP、REFUSED、YXDOMAIN、YXRRSET、NXRRSET、NOTAUTH、NOTZONE、DSOTYPENI、BADVERS、BADKEY、BADTIME、BADMODE、BADNAME、BADALG、BADTRUNC、BADCOOKIE。

支持的 query_type：A、AAAA、NS、CNAME、SOA、PTR、MX、TXT、SRV、CAA、NAPTR、DNAME、DNSKEY、DS、RRSIG、NSEC、NSEC3、NSEC3PARAM、TLSA、SSHFP、HTTPS、SVCB、ANY、AXFR、IXFR、OPT、LOC、SPF、RP、HINFO、CERT、URI。其它或未知类型记为数据质量缺口，不能当正常。数字类型码需由提供方先转换为对应标准名称。

query 支持大小写、末尾根点、根查询“.”、常见SRV/DKIM下划线、通配符标签及可转换为IDNA的国际化域名。除末尾根点外，总长不超过253个ASCII字符、每标签不超过63字符；空标签、URL或超长名称均记为无效记录，不把无效数据判成功。

同一客户端≥10条记录且NXDOMAIN≥50%，或≥5条首标签长度≥40且熵≥3.5的查询，其中≥3条TXT。

每轮最多1000条、总输入不超过1MB；每条不超过40个平面字段，单字段文本不超过1024字符。数字必须非负有限，百分比不得超过100。时间必须带时区。未知顶层字段、任意输出路径、命令或发送参数均拒绝；未使用的记录字段不流入后续节点。

## 节点及分支

1. 接收DNS解析记录
2. 校验查询字段与时间
3. 识别解析异常与高熵标签
4. 分级处置决策：risk → 风险研判与待办；normal → 正常结果与观察；insufficient → 资料缺口与核验。
5. 编制分析报告
6. 保存日报与证据索引

图中共9个节点，一次运行只执行7个。三条分支互斥，最终汇聚不等待未选中的路径。所有业务节点使用本地纯Python规则，不调用模型、网络、SMTP、扫描器或系统命令。

## 输出

执行时动态生成 `~/.flocks/workspace/outputs/<YYYY-MM-DD>/security-operations/custom-soc-ndr-dns/<唯一批次>.md` 和同名 `.json`。后续阶段不写文件，只有最后的保存节点落盘；文件名不来自输入。目录后代符号链接拒绝，受信的 `~/.flocks` 部署别名可使用符号链接。安全落盘要求POSIX目录描述符支持（macOS/Linux）；不支持的平台明确报错，仍可单步查看报告编制结果。

报告区分“分析已完成”和“业务处置状态”，包含来源标记、有效/无效计数、规则依据、证据输入行号、人工待办、通知展示配置及边界说明。邮箱读取共享 `flocks/workflow/custom_soc_suite_settings.json` 的 `emailDisplay`，缺配置明确失败；通知只进入报告，未发邮件。任何恢复或闭环结论仅表示提供的输入证据满足本工作流规则，不修改真实设备或任务。
