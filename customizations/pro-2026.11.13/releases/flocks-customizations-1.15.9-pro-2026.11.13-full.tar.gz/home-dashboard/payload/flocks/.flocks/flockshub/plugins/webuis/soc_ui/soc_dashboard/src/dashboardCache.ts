// Browser-memory snapshots only: survive page remounts, never persist alert data
// to disk. Each authenticated user and time filter has an independent snapshot.
export const DASHBOARD_CACHE_TTL_MS = 5 * 60 * 1000;
const snapshots = new Map<string, any>();
const filterKey = (filter: any) => JSON.stringify([filter.mode, filter.range, filter.start, filter.end]);

export function readDashboardSnapshot(scope: string, filter?: any, now = Date.now()): any {
  for (const [key, value] of snapshots) {
    if (now - value.savedAt >= DASHBOARD_CACHE_TTL_MS) snapshots.delete(key);
  }
  const candidates = [...snapshots.values()].filter(value => value.scope === scope
    && (!filter || filterKey(value.filter) === filterKey(filter)));
  return candidates[candidates.length - 1];
}

export function saveDashboardSnapshot(scope: string, filter: any, patch: any, now = Date.now()) {
  const key = JSON.stringify([scope, filterKey(filter)]);
  const previous = readDashboardSnapshot(scope, filter, now);
  snapshots.delete(key);
  snapshots.set(key, { ...previous, ...patch, scope, filter, savedAt: now });
  while (snapshots.size > 8) snapshots.delete(snapshots.keys().next().value!);
}

export function clearDashboardSnapshots() { snapshots.clear(); }
