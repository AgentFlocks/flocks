"""Portable, owner-bound installation and execution of daily knowledge synthesis.

Workflow files are the native source of truth. The Task Center supplies timezone-
aware scheduling, persistent execution history, retries and no-overlap behavior.
Only trusted Python code reads/writes files; the configured model returns text.
"""

from __future__ import annotations

import argparse
import asyncio
from contextlib import contextmanager
from contextvars import ContextVar
from datetime import datetime
import errno
from functools import wraps
import hashlib
import json
import os
from pathlib import Path
import uuid
from typing import Any
from zoneinfo import ZoneInfo

WORKFLOW_ID = "knowledge-daily-experience"
INSTALLATION_KIND = "knowledge-experience"
DEDUP_KEY = "customizations:knowledge-experience:daily:v1"
TITLE = "领域知识每日沉淀"

_INSTALLATION_MESSAGES = {
    "unsupported_platform": "Knowledge experience generation currently requires macOS or Linux.",
    "unsafe_path": "An internal knowledge runtime directory or file is a symbolic link or is not a regular file; no link was followed.",
    "root_changed": "The configured knowledge storage root changed during this operation; retry after the deployment paths are stable.",
    "invalid_state": "The knowledge installation record is invalid; preserve it and inspect the existing installation.",
    "installation_busy": "Another knowledge installation operation is running; retry after it finishes.",
    "invalid_timezone": "The specified timezone is unavailable; use an installed IANA timezone such as Asia/Shanghai.",
    "scheduler_conflict": "A conflicting knowledge scheduler exists; the existing scheduler was preserved.",
    "owner_conflict": "Knowledge runtime is already bound to another owner; the existing installation was preserved.",
    "workflow_conflict": "A same-ID workflow is unowned, modified or shadowed; the existing workflow was preserved.",
    "scheduler_missing": "The managed scheduler was removed; it will not be recreated implicitly.",
    "workflow_discovery": "The managed workflow was not found by native filesystem discovery; inspect the workflow search roots.",
}


class KnowledgeInstallationError(RuntimeError):
    """Only these fixed, non-sensitive diagnostics may be printed by the CLI."""

    def __init__(self, code: str):
        self.code = code
        super().__init__(_INSTALLATION_MESSAGES[code])


_bindings: ContextVar[dict | None] = ContextVar("knowledge_runtime_root_bindings", default=None)


def _absolute(path: Path) -> Path:
    # Do not resolve child components: only a declared deployment root is trusted.
    return Path(os.path.abspath(path.expanduser()))


def _check_bindings() -> None:
    for alias, (canonical, identity) in (_bindings.get() or {}).items():
        try:
            if alias.resolve(strict=False) != canonical:
                raise KnowledgeInstallationError("root_changed")
            if identity is not None:
                current = canonical.stat()
                if (current.st_dev, current.st_ino) != identity:
                    raise KnowledgeInstallationError("root_changed")
        except (OSError, RuntimeError) as error:
            raise KnowledgeInstallationError("root_changed") from error


def _trusted_root(path: Path) -> Path:
    alias = _absolute(path)
    _check_bindings()
    bindings = _bindings.get()
    if bindings is not None and alias in bindings:
        return bindings[alias][0]
    try:
        canonical = alias.resolve(strict=False)
        info = canonical.stat() if canonical.exists() else None
    except (OSError, RuntimeError) as error:
        raise KnowledgeInstallationError("unsafe_path") from error
    if info is not None and not canonical.is_dir():
        raise KnowledgeInstallationError("unsafe_path")
    if bindings is not None:
        bindings[alias] = (canonical, (info.st_dev, info.st_ino) if info else None)
    return canonical


@contextmanager
def _path_scope():
    token = _bindings.set({}) if _bindings.get() is None else None
    try:
        _check_bindings()
        yield
        _check_bindings()
    finally:
        if token is not None:
            _bindings.reset(token)


def _bound_paths(function):
    @wraps(function)
    async def run(*args, **kwargs):
        with _path_scope():
            return await function(*args, **kwargs)
    return run


def _state_path() -> Path:
    from flocks.config.config import Config

    data = _absolute(Config.get_data_path())
    home_root = _absolute(Path.home() / ".flocks")
    configured_root = _absolute(Path(os.environ["FLOCKS_ROOT"])) if os.environ.get("FLOCKS_ROOT") else home_root
    # The default data directory is a child, not an extra trusted symlink root.
    for anchor in dict.fromkeys((home_root, configured_root)):
        if data.is_relative_to(anchor):
            base = _trusted_root(anchor) / data.relative_to(anchor)
            break
    else:
        # Config explicitly allows a separate data directory (FLOCKS_DATA_DIR/XDG).
        base = _trusted_root(data)
    return base / "customizations-runtime" / INSTALLATION_KIND / "installation.json"


def _workflow_directory() -> Path:
    from flocks.workflow.center import resolve_global_workflow_roots

    root = _absolute(Path.home() / ".flocks")
    workflow_root = _absolute(resolve_global_workflow_roots()[-1])
    if not workflow_root.is_relative_to(root):
        raise KnowledgeInstallationError("unsafe_path")
    return _trusted_root(root) / workflow_root.relative_to(root) / WORKFLOW_ID


def _safe_directory(path: Path) -> None:
    with _directory_fd(path, create=True):
        pass


@contextmanager
def _directory_fd(path: Path, *, create: bool = False):
    """Walk canonical paths without following any internal link, including races."""
    if os.name != "posix":
        raise KnowledgeInstallationError("unsupported_platform")
    _check_bindings()
    path = _absolute(path)
    fd = os.open(path.anchor, os.O_RDONLY | os.O_DIRECTORY)
    try:
        for part in path.parts[1:]:
            if create:
                try:
                    os.mkdir(part, mode=0o700, dir_fd=fd)
                except FileExistsError:
                    pass
            try:
                child = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
            except OSError as error:
                if error.errno in {errno.ENOTDIR, errno.ELOOP}:
                    raise KnowledgeInstallationError("unsafe_path") from error
                raise
            os.close(fd)
            fd = child
        _check_bindings()
        yield fd
    finally:
        os.close(fd)


def _read_json(path: Path) -> dict[str, Any] | None:
    try:
        with _directory_fd(path.parent) as directory:
            try:
                fd = os.open(path.name, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK, dir_fd=directory)
            except OSError as error:
                if error.errno == errno.ELOOP:
                    raise KnowledgeInstallationError("unsafe_path") from error
                raise
            with os.fdopen(fd, "r", encoding="utf-8") as stream:
                import stat
                if not stat.S_ISREG(os.fstat(stream.fileno()).st_mode):
                    raise KnowledgeInstallationError("unsafe_path")
                value = json.load(stream)
            _check_bindings()
    except FileNotFoundError:
        return None
    except (ValueError, UnicodeError) as error:
        raise KnowledgeInstallationError("invalid_state") from error
    if not isinstance(value, dict):
        raise KnowledgeInstallationError("invalid_state")
    return value


def _atomic_json(path: Path, value: dict[str, Any]) -> None:
    import stat
    with _directory_fd(path.parent, create=True) as directory:
        try:
            existing = os.stat(path.name, dir_fd=directory, follow_symlinks=False)
            if not stat.S_ISREG(existing.st_mode):
                raise KnowledgeInstallationError("unsafe_path")
        except FileNotFoundError:
            pass
        temporary = ".knowledge-" + uuid.uuid4().hex + ".tmp"
        fd = os.open(temporary, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600, dir_fd=directory)
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as stream:
                json.dump(value, stream, ensure_ascii=False, indent=2)
                stream.write("\n")
                stream.flush()
                os.fsync(stream.fileno())
            _check_bindings()
            os.replace(temporary, path.name, src_dir_fd=directory, dst_dir_fd=directory)
            os.fsync(directory)
            _check_bindings()
        finally:
            try:
                os.unlink(temporary, dir_fd=directory)
            except FileNotFoundError:
                pass


@contextmanager
def _installation_lock():
    """Non-blocking OS lock; TaskStore's dedup index is not a unique index."""
    with _directory_fd(_state_path().parent, create=True) as directory:
        try:
            fd = os.open("installation.lock", os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW | os.O_NONBLOCK, 0o600, dir_fd=directory)
        except OSError as error:
            if error.errno == errno.ELOOP:
                raise KnowledgeInstallationError("unsafe_path") from error
            raise
    locked = False
    try:
        import fcntl
        import stat

        if not stat.S_ISREG(os.fstat(fd).st_mode):
            raise KnowledgeInstallationError("unsafe_path")

        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError as error:
            raise KnowledgeInstallationError("installation_busy") from error
        locked = True
        yield
    finally:
        if locked:
            fcntl.flock(fd, fcntl.LOCK_UN)
        os.close(fd)


def build_workflow(owner_id: str) -> dict[str, Any]:
    if not isinstance(owner_id, str) or not owner_id.strip():
        raise ValueError("An explicit owner ID is required")
    return {
        "name": TITLE,
        "description": "每日增量读取当前绑定账号可见资料，提炼带来源的领域经验；失败保留上一版。",
        "start": "update_knowledge",
        "nodes": [{
            "id": "update_knowledge",
            "type": "python",
            "description": "安全扫描、增量提炼、校验来源并发布领域经验",
            "timeoutFatal": True,
            "code": (
                "from flocks.server.routes.knowledge_experience_runtime import run_scheduled_update\n"
                "outputs = run_scheduled_update(inputs, llm=llm, cancelled=cancelled)\n"
            ),
        }],
        "edges": [],
        # Schedule belongs to Task Center, whose cron implementation supports
        # timezones. A workflow schedule trigger would also activate UTC pollers.
        "triggers": [{"id": "manual-default", "type": "manual", "enabled": True}],
        "metadata": {
            "customization": INSTALLATION_KIND,
            "workflowId": WORKFLOW_ID,
            "ownerId": owner_id,
            "schemaVersion": 1,
            "category": "knowledge",
            "node_timeout_s": 7200,
        },
    }


def _fingerprint(value: dict[str, Any]) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False).encode()).hexdigest()


async def _active_owner(owner_id: str):
    from flocks.auth.context import AuthUser
    from flocks.auth.service import AuthService

    record = await AuthService.get_user_by_id(owner_id)
    if record is None or record.status != "active":
        raise PermissionError("The bound knowledge owner is missing or disabled")
    return AuthUser(**record.model_dump(include=set(AuthUser.model_fields)))


def _assert_owned_scheduler(scheduler: Any, owner_id: str) -> None:
    if (
        scheduler.dedup_key != DEDUP_KEY
        or scheduler.workflow_id != WORKFLOW_ID
        or str(scheduler.execution_mode) not in {"workflow", "ExecutionMode.WORKFLOW"}
        or scheduler.context.get("owner_id") != owner_id
        or scheduler.context.get("customization") != INSTALLATION_KIND
    ):
        raise KnowledgeInstallationError("scheduler_conflict")


@_bound_paths
async def install_workflow(owner_id: str, timezone: str = "Asia/Shanghai") -> dict[str, Any]:
    """Install only for the explicit owner; repeated installs preserve scheduling choices."""
    from flocks.task.manager import TaskManager
    from flocks.task.models import ExecutionMode, SchedulerMode, TaskSource, TaskTrigger
    from flocks.task.store import TaskStore
    from flocks.workflow.fs_store import read_workflow_from_fs
    from flocks.workflow.models import Workflow

    try:
        ZoneInfo(timezone)  # Fail on invalid timezone rather than silently using UTC.
    except (KeyError, ValueError) as error:
        raise KnowledgeInstallationError("invalid_timezone") from error
    owner = await _active_owner(owner_id)
    if owner.role != "admin":
        raise PermissionError("Only an administrator may own the daily knowledge installation")
    definition = build_workflow(owner.id)
    Workflow.from_dict(definition)
    with _installation_lock():
        state = _read_json(_state_path())
        if state and (state.get("owner_id") != owner.id or state.get("workflow_id") != WORKFLOW_ID):
            raise KnowledgeInstallationError("owner_conflict")
        target = _workflow_directory() / "workflow.json"
        original = _read_json(target)
        current = read_workflow_from_fs(WORKFLOW_ID)
        if current and not original:
            raise KnowledgeInstallationError("workflow_conflict")
        if original:
            if not state or _fingerprint(original) != state.get("workflow_fingerprint"):
                raise KnowledgeInstallationError("workflow_conflict")
            if current is None or _fingerprint(current["workflowJson"]) != _fingerprint(original):
                raise KnowledgeInstallationError("workflow_conflict")
        await TaskStore.init()
        scheduler = await TaskStore.get_scheduler_by_dedup_key(DEDUP_KEY)
        if scheduler is not None:
            _assert_owned_scheduler(scheduler, owner.id)
            if state and state.get("scheduler_id") not in {None, scheduler.id}:
                raise KnowledgeInstallationError("scheduler_conflict")
        elif state and state.get("scheduler_id"):
            raise KnowledgeInstallationError("scheduler_missing")

        # Write recoverable installation ownership before creating a scheduler.
        # A crash after creation can be recovered using its fixed dedup key.
        desired = {
            "version": 1,
            "owner_id": owner.id,
            "workflow_id": WORKFLOW_ID,
            "scheduler_id": scheduler.id if scheduler else None,
            "workflow_fingerprint": _fingerprint(definition),
            "installed_at": (state or {}).get("installed_at") or datetime.now().isoformat(),
            "phase": "installing",
        }
        _atomic_json(_state_path(), desired)
        _atomic_json(target, definition)
        registered = read_workflow_from_fs(WORKFLOW_ID)
        if not registered or _fingerprint(registered["workflowJson"]) != desired["workflow_fingerprint"]:
            raise KnowledgeInstallationError("workflow_discovery")
        _check_bindings()
        if scheduler is None:
            scheduler = await TaskManager.create_scheduler(
                title=TITLE,
                description="每日凌晨更新绑定账号的领域经验，保留历史版本和来源引用。",
                mode=SchedulerMode.CRON,
                execution_mode=ExecutionMode.WORKFLOW,
                workflow_id=WORKFLOW_ID,
                trigger=TaskTrigger(cron="0 2 * * *", timezone=timezone, cron_description="每日凌晨 02:00"),
                source=TaskSource(source_type="scheduled_trigger"),
                context={"owner_id": owner.id, "customization": INSTALLATION_KIND},
                category="knowledge",
                tags=["customizations", INSTALLATION_KIND],
                created_by=owner.id,
                dedup_key=DEDUP_KEY,
            )
        desired.update({
            "phase": "installed",
            "scheduler_id": scheduler.id,
            "enabled": scheduler.is_active,
            "timezone": scheduler.trigger.timezone,
            "cron": scheduler.trigger.cron,
        })
        _atomic_json(_state_path(), desired)
        return {**desired, "next_run": scheduler.trigger.next_run.isoformat() if scheduler.trigger.next_run else None}


@_bound_paths
async def installation_status() -> dict[str, Any]:
    from flocks.task.store import TaskStore

    state = _read_json(_state_path())
    if state is None:
        return {"installed": False, "workflow_id": WORKFLOW_ID}
    result = {**state, "installed": state.get("phase") == "installed"}
    scheduler = await TaskStore.get_scheduler_by_dedup_key(DEDUP_KEY)
    if scheduler is None:
        return {**result, "enabled": False, "error": "Managed scheduler is missing"}
    _assert_owned_scheduler(scheduler, state["owner_id"])
    return {
        **result,
        "enabled": scheduler.is_active,
        "timezone": scheduler.trigger.timezone,
        "cron": scheduler.trigger.cron,
        "next_run": scheduler.trigger.next_run.isoformat() if scheduler.trigger.next_run else None,
    }


@_bound_paths
async def uninstall_workflow(owner_id: str | None = None) -> dict[str, Any]:
    """Disable only the managed schedule; retain workflow, snapshots and history."""
    from flocks.task.manager import TaskManager
    from flocks.task.store import TaskStore

    if _read_json(_state_path()) is None:
        return {"installed": False, "disabled": False}
    with _installation_lock():
        state = _read_json(_state_path())
        if not state:
            return {"installed": False, "disabled": False}
        if owner_id is not None and state.get("owner_id") != owner_id:
            raise PermissionError("Knowledge runtime belongs to another owner")
        scheduler = await TaskStore.get_scheduler_by_dedup_key(DEDUP_KEY)
        if scheduler:
            _assert_owned_scheduler(scheduler, state["owner_id"])
            if scheduler.id != state.get("scheduler_id"):
                raise KnowledgeInstallationError("scheduler_conflict")
            await TaskManager.disable_scheduler(scheduler.id)
        state["enabled"] = False
        _atomic_json(_state_path(), state)
        return {"installed": True, "disabled": True, "data_preserved": True}


async def _run_for_owner(owner_id: str, category: str | None = None, llm: Any = None):
    from flocks.auth.context import reset_current_auth_user, set_current_auth_user
    from flocks.server.routes.knowledge_experience import load_settings, update_for_user
    from flocks.workflow.llm import get_lazy_llm

    if os.name != "posix":
        raise RuntimeError("Knowledge experience generation currently requires macOS or Linux")
    owner = await _active_owner(owner_id)
    model = llm if llm is not None else get_lazy_llm()
    settings = load_settings()
    model_deadline = float(settings["modelTimeoutSeconds"])
    if settings.get("generationMode") == "daily-sampled":
        model_deadline = min(model_deadline, float(settings.get("fastModelTimeoutSeconds", 20)))
    # Keep the provider's own deadline below the core deadline: cancelling the
    # outer to_thread await cannot stop a synchronous model worker by itself.
    model_timeout = max(0.5, model_deadline - 5)

    async def authorize():
        current = await _active_owner(owner_id)
        if current.id != owner.id or current.role != owner.role:
            raise PermissionError("Knowledge authorization changed during generation")
        return current

    async def summarize(prompt: str) -> str:
        # Provider's workflow adapter keeps async SDK clients on its persistent
        # loop. Calling the sync facade in a worker avoids loop self-deadlocks.
        value = await asyncio.to_thread(
            model.ask, prompt, temperature=0.1, timeout_s=model_timeout, max_retries=0,
        )
        if not isinstance(value, str) or not value.strip():
            raise RuntimeError("The configured model returned no knowledge summary")
        return value

    token = set_current_auth_user(owner)
    try:
        return await update_for_user(owner, summarize, category=category, authorize=authorize)
    finally:
        reset_current_auth_user(token)


async def run_for_user(user: Any, category: str | None = None):
    """Update only the authenticated account, rechecking its current active status."""
    return await _run_for_owner(user.id, category=category)


@_bound_paths
async def _run_bound(inputs: dict[str, Any], llm: Any):
    from flocks.auth.context import get_current_auth_user
    from flocks.task.store import TaskStore

    caller = get_current_auth_user()
    if caller is not None:
        # Interactive execution is always scoped to its authenticated caller,
        # never to the administrator recorded by the unattended installation.
        actor = await _active_owner(caller.id)
        if actor.id != caller.id:
            raise PermissionError("The authenticated knowledge identity changed")
        if inputs.get("owner_id", actor.id) != actor.id:
            raise PermissionError("Interactive workflow input cannot select another knowledge owner")
        return _safe_result(await _run_for_owner(actor.id, category=inputs.get("category"), llm=llm))

    # Scheduled jobs have no browser identity. Only the installed, enabled
    # scheduler's running execution is allowed to use its explicitly bound owner.
    state = _read_json(_state_path())
    if not state or state.get("phase") != "installed":
        raise PermissionError("Daily knowledge installation is absent or disabled")
    owner_id = state["owner_id"]
    scheduler = await TaskStore.get_scheduler_by_dedup_key(DEDUP_KEY)
    if scheduler is None or not scheduler.is_active or scheduler.id != state.get("scheduler_id"):
        raise PermissionError("Daily knowledge scheduler is missing or disabled")
    _assert_owned_scheduler(scheduler, owner_id)
    execution = await TaskStore.get_active_execution_for_scheduler(scheduler.id)
    if (execution is None or str(execution.status) not in {"running", "TaskStatus.RUNNING"}
            or execution.workflow_id != WORKFLOW_ID):
        raise PermissionError("Unattributed workflow calls require the managed scheduler's active execution")
    if inputs.get("owner_id", owner_id) != owner_id:
        raise PermissionError("Workflow input cannot change the bound knowledge owner")
    owner = await _active_owner(owner_id)
    if owner.role != "admin":
        raise PermissionError("The daily knowledge owner is no longer an administrator")
    # Category filters are safe selectors, never paths. File roots and owner
    # identities are resolved by the deterministic service, not workflow input.
    return _safe_result(await _run_for_owner(owner_id, category=inputs.get("category"), llm=llm))


def _safe_result(result: dict[str, Any]) -> dict[str, Any]:
    """Only counters reach Task Center records or terminal output, never documents."""
    result_status = result.get("status")
    if result_status not in {"ready", "unchanged", "failed", "partial", "running"}:
        raise RuntimeError("Knowledge update returned an invalid status")
    safe = {"status": result_status}
    for field in ("calls", "updated", "failed", "unchanged"):
        value = result.get(field, 0)
        safe[field] = value if type(value) is int and value >= 0 else 0
    # Daily-mode results explicitly distinguish local extractive publication
    # and reused/frozen summaries. "ready" does not imply model success.
    for field in ("extractive", "frozen", "reused"):
        if field in result:
            value = result[field]
            safe[field] = value if type(value) is int and value >= 0 else 0
    if result_status in {"failed", "partial"}:
        raise RuntimeError(f"Knowledge update {result_status}: updated={safe['updated']}, failed={safe['failed']}; failed domains did not publish new versions")
    if result_status == "running":
        raise RuntimeError("Another knowledge update is already running; no duplicate update was started")
    return safe


def run_scheduled_update(inputs: dict[str, Any], llm: Any = None, cancelled=None):
    from flocks.workflow._async_runtime import run_sync_cancellable

    return run_sync_cancellable(_run_bound(inputs, llm), cancelled or (lambda: False))


async def _cli(arguments) -> dict[str, Any]:
    if arguments.owner:
        from flocks.auth.service import AuthService

        found = await AuthService.get_user_by_username(arguments.owner)
        if found is None:
            raise PermissionError("The specified knowledge owner does not exist")
        if arguments.owner_id and arguments.owner_id != found[0].id:
            raise ValueError("--owner and --owner-id identify different accounts")
        arguments.owner_id = found[0].id
    if arguments.action == "status":
        return await installation_status()
    if arguments.action == "disable":
        return await uninstall_workflow(arguments.owner_id)
    if not arguments.owner_id:
        raise ValueError("--owner or --owner-id is required for install and run")
    if arguments.action == "install":
        return await install_workflow(arguments.owner_id, timezone=arguments.timezone)
    owner = await _active_owner(arguments.owner_id)
    return _safe_result(await run_for_user(owner, category=arguments.category))


def main() -> int:
    parser = argparse.ArgumentParser(description="Install or manage owner-bound daily knowledge synthesis")
    parser.add_argument("action", choices=["install", "status", "disable", "run"])
    parser.add_argument("--owner-id")
    parser.add_argument("--owner", help="Local account username, resolved on the target machine")
    parser.add_argument("--timezone", default="Asia/Shanghai")
    parser.add_argument("--category")
    arguments = parser.parse_args()

    async def execute():
        try:
            return await _cli(arguments)
        finally:
            # CLI-only cleanup. Never close stores owned by the running server.
            from flocks.task.store import TaskStore
            from flocks.workflow.store import WorkflowStore

            await TaskStore.close()
            await WorkflowStore.close()

    try:
        result = asyncio.run(execute())
        print(json.dumps(result, ensure_ascii=False, default=str))
        return 0
    except Exception as error:
        # Provider failures may contain confidential request payloads. Keep CLI
        # output generic; application status reports contain safe failure labels.
        print(json.dumps(_cli_error(error)))
        return 1


def _cli_error(error: Exception) -> dict[str, str]:
    if isinstance(error, KnowledgeInstallationError):
        return {"error": type(error).__name__, "code": error.code, "message": str(error)}
    # Unknown/provider exceptions may embed credentials, document text or paths.
    return {"error": type(error).__name__, "message": "Knowledge operation failed; inspect configuration and runtime status."}


if __name__ == "__main__":
    raise SystemExit(main())
