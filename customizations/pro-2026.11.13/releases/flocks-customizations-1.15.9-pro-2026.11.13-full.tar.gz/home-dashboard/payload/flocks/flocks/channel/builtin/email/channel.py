"""Email ChannelPlugin using IMAP for inbound and SMTP for outbound."""

from __future__ import annotations

import asyncio
import email as email_lib
import imaplib
import smtplib
import socket
import ssl
import uuid
from datetime import datetime, timedelta, timezone
from time import monotonic
from email import encoders
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.utils import formatdate
from flocks import __version__
from flocks.channel.media_filename import sanitize_filename
from pathlib import Path
from typing import Any, Awaitable, Callable, Optional

from flocks.channel.base import (
    ChannelCapabilities,
    ChannelMeta,
    ChannelPlugin,
    ChatType,
    DeliveryResult,
    InboundMessage,
    OutboundContext,
)
from flocks.utils.log import Log

from .config import (
    is_valid_email,
    normalize_email_address,
    parse_allowed_senders,
    resolved_config,
)
from .inbound import (
    build_inbound_message,
    is_automated_sender,
    verify_sender_authentication,
)

log = Log.create(service="channel.email")

SMTP_CONNECT_TIMEOUT = 30
IMAP_BATCH_SECONDS = 90
IMAP_RETRY_MAX_SECONDS = 300
NETEASE_SMTP_HOSTS = {"smtp.163.com", "smtp.126.com"}
IMAP_CLIENT_ID = (
    '("name" "Flocks" '
    f'"version" "{__version__}" '
    '"vendor" "AgentFlocks" '
    '"support-url" "https://github.com/AgentFlocks/flocks")'
)


class _EmailNotSent(RuntimeError):
    """Per-attempt proof that SMTP did not accept this message."""

    def __init__(self, cause: Exception) -> None:
        super().__init__(str(cause))
        self.cause = cause


class EmailChannel(ChannelPlugin):
    """Single-mailbox Email channel."""

    def __init__(self) -> None:
        super().__init__()
        self._resolved: dict[str, Any] = {}
        self._seen_uids: set[bytes] = set()
        self._seen_uids_max = 5000
        self._thread_context: dict[str, dict[str, str]] = {}
        self._mail_health = {direction: self._empty_health() for direction in ('receive', 'send')}
        self._send_active: Optional[bool] = None
        self._send_abort: Optional[asyncio.Event] = None

    @property
    def send_ready(self) -> bool:
        """An enabled channel may try SMTP even while IMAP is reconnecting.

        Readiness is permission to attempt delivery, not a delivery receipt or
        a claim that SMTP is healthy. Explicit stop/disable always revokes it.
        """
        if self._config.get('enabled') is False or (self._send_abort is not None and self._send_abort.is_set()):
            return False
        active = self.status.connected if self._send_active is None else self._send_active
        return bool(active and self._resolved)

    def _require_send_enabled(self) -> None:
        if self._config.get('enabled') is False or (self._send_active is not None and not self.send_ready):
            raise _EmailNotSent(ValueError('邮件通道已停用，未发送'))

    @staticmethod
    def _empty_health() -> dict[str, Any]:
        return {'state': 'unknown', 'stage': 'unknown', 'last_success_at': None,
                'last_success_stage': None, 'last_error_at': None, 'last_error_stage': None, 'error_type': None,
                'consecutive_failures': 0, 'next_retry_at': None}

    def _health_stage(self, direction: str, stage: str) -> None:
        # Workers replace one snapshot atomically; readers never receive live dicts.
        self._mail_health[direction] = {**self._mail_health[direction], 'stage': stage}

    def _health_success(self, direction: str, stage: str) -> None:
        self._mail_health[direction] = {**self._mail_health[direction], 'state': 'healthy',
            'stage': stage, 'last_success_stage': stage,
            'last_success_at': datetime.now(timezone.utc).isoformat(),
            'consecutive_failures': 0, 'next_retry_at': None}

    def _health_failure(self, direction: str, exc: BaseException) -> None:
        previous = self._mail_health[direction]
        failures = previous['consecutive_failures'] + 1
        stage = 'tls' if isinstance(exc, ssl.SSLError) else previous['stage']
        self._mail_health[direction] = {**previous, 'state': 'unavailable',
            'last_error_at': datetime.now(timezone.utc).isoformat(), 'error_type': type(exc).__name__,
            'stage': stage, 'last_error_stage': stage,
            'consecutive_failures': failures,
            'next_retry_at': (datetime.now(timezone.utc) + timedelta(seconds=
                min(IMAP_RETRY_MAX_SECONDS, 30 * 2 ** min(failures - 1, 6)))).isoformat()}

    def health_snapshot(self) -> dict[str, dict[str, Any]]:
        """SMTP acceptance and IMAP receipt are independent, content-free facts."""
        result = {key: dict(value) for key, value in self._mail_health.items()}
        last_poll = result['receive']['last_success_at']
        if last_poll and result['receive']['state'] == 'healthy':
            # A hung receiver must not remain green indefinitely. The allowance
            # includes one bounded fetch batch and its final socket operation.
            stale_after = max(180, float(self._resolved.get('pollIntervalSeconds', 30)) * 2
                              + IMAP_BATCH_SECONDS + 30)
            if (datetime.now(timezone.utc) - datetime.fromisoformat(last_poll)).total_seconds() > stale_after:
                result['receive'].update(state='unavailable', stage='stale')
        return result

    def _poll_delay(self) -> float:
        interval = float(self._resolved.get('pollIntervalSeconds', 30))
        failures = self._mail_health['receive']['consecutive_failures']
        if not failures:
            return interval
        return max(interval, min(IMAP_RETRY_MAX_SECONDS, max(5, interval) * 2 ** min(failures - 1, 6)))

    async def _recover_smtp_if_due(self) -> None:
        health = self._mail_health['send']
        if health['state'] != 'unavailable' or not health['next_retry_at']:
            return
        if datetime.fromisoformat(health['next_retry_at']) > datetime.now(timezone.utc):
            return
        try:
            # Authenticate only. Never replay a notice whose delivery is unknown.
            await asyncio.to_thread(self._test_smtp_connection)
        except Exception as exc:
            log.warning('email.smtp.recovery_failed', {'error': type(exc).__name__,
                'stage': self._mail_health['send']['stage']})

    def meta(self) -> ChannelMeta:
        return ChannelMeta(
            id="email",
            label="Email",
            aliases=["mail", "imap", "smtp"],
            order=60,
        )

    def capabilities(self) -> ChannelCapabilities:
        return ChannelCapabilities(
            chat_types=[ChatType.DIRECT],
            media=True,
            threads=True,
            reactions=False,
            edit=False,
            rich_text=False,
        )

    @property
    def text_chunk_limit(self) -> int:
        return 50_000

    @property
    def rate_limit(self) -> tuple[float, int]:
        return (0.2, 2)

    def validate_config(self, config: dict) -> Optional[str]:
        cfg = resolved_config(config)
        missing = [
            name
            for name in ("address", "imapHost", "smtpHost")
            if not cfg.get(name)
        ]
        if cfg["authMode"] == "password" and not cfg.get("password"):
            missing.append("password")
        if cfg["authMode"] == "xoauth2" and not cfg.get("accessToken"):
            missing.append("accessToken")
        if missing:
            return "Missing required config: " + ", ".join(missing)
        if not is_valid_email(cfg["address"]):
            return "Invalid email address"
        if cfg["authMode"] not in {"password", "xoauth2"}:
            return "Email auth mode must be one of: password, xoauth2"
        if cfg["imapPort"] <= 0 or cfg["smtpPort"] <= 0:
            return "IMAP/SMTP ports must be positive integers"
        if cfg["imapSecurity"] not in {"ssl", "starttls", "insecure"}:
            return "IMAP security must be one of: ssl, starttls, insecure"
        if cfg["smtpSecurity"] not in {"ssl", "starttls", "insecure"}:
            return "SMTP security must be one of: ssl, starttls, insecure"
        if (
            cfg["smtpHost"].lower() in NETEASE_SMTP_HOSTS
            and (cfg["smtpPort"] != 465 or cfg["smtpSecurity"] != "ssl")
        ):
            return "NetEase 163/126 SMTP requires smtpPort=465 and smtpSecurity=ssl"
        if cfg["imapSecurity"] == "insecure" and not cfg["allowInsecureConnections"]:
            return "IMAP insecure mode requires allowInsecureConnections=true"
        if cfg["smtpSecurity"] == "insecure" and not cfg["allowInsecureConnections"]:
            return "SMTP insecure mode requires allowInsecureConnections=true"
        allowed = parse_allowed_senders(cfg)
        if not cfg["allowAll"] and not allowed:
            return "Email channel requires allowFrom or allowAll=true"
        if (
            not cfg["allowAll"]
            and allowed
            and cfg["requireAuthenticatedSender"]
            and not cfg["authservId"]
        ):
            return "Email channel requires authservId when requireAuthenticatedSender=true and allowFrom is configured"
        return None

    def normalize_target(self, raw: str) -> Optional[str]:
        target = normalize_email_address(raw)
        return target if is_valid_email(target) else None

    def target_hint(self) -> str:
        return "user@example.com"

    async def start(
        self,
        config: dict,
        on_message: Callable[[InboundMessage], Awaitable[None]],
        abort_event: Optional[asyncio.Event] = None,
    ) -> None:
        self._config = config
        self._resolved = resolved_config(config)
        self._on_message = on_message
        self._mail_health = {direction: self._empty_health() for direction in ('receive', 'send')}
        self._send_abort = abort_event or asyncio.Event()
        self._send_active = config.get('enabled', True) is True

        loop = asyncio.get_running_loop()
        await loop.run_in_executor(None, self._test_connections)

        abort = self._send_abort
        while not abort.is_set():
            try:
                messages = await loop.run_in_executor(None, self._fetch_new_messages)
                if getattr(self, '_monitor_unparsed', 0):
                    from flocks.monitoring.mail_transport import diagnose_poll
                    await diagnose_poll(self._resolved, 'UnparsedMessage')
                complete = True
                dispatch_error = None
                self._health_stage('receive', 'dispatch')
                for uid, message in messages:
                    if abort.is_set():
                        complete = False
                        break
                    try:
                        await on_message(message)
                        self._mark_seen(uid)
                    except Exception as exc:
                        complete = False
                        dispatch_error = exc
                        log.warning("email.message.dispatch_failed", {"error": type(exc).__name__, "uid": uid.decode(errors="replace")})
                if dispatch_error is not None:
                    raise dispatch_error
                if complete:
                    from flocks.monitoring.mail_transport import checkpoint
                    self._health_stage('receive', 'checkpoint')
                    await asyncio.to_thread(checkpoint, getattr(self, "_monitor_poll", None), getattr(self, "_monitor_high", None))
                    self._health_success('receive', 'poll')
                self.mark_connected()
            except asyncio.CancelledError:
                raise
            except Exception as exc:
                self._health_failure('receive', exc)
                self.mark_disconnected(type(exc).__name__)
                log.warning("email.poll.failed", {"error": type(exc).__name__,
                    "stage": self._mail_health['receive']['stage']})
                from flocks.monitoring.mail_transport import diagnose_poll
                await diagnose_poll(self._resolved, type(exc).__name__, self._mail_health['receive'])

            if not abort.is_set():
                await self._recover_smtp_if_due()
            delay = self._poll_delay()
            if self._mail_health['receive']['consecutive_failures']:
                self._mail_health['receive'] = {**self._mail_health['receive'],
                    'next_retry_at': (datetime.now(timezone.utc) + timedelta(seconds=delay)).isoformat()}
            try:
                await asyncio.wait_for(
                    abort.wait(),
                    timeout=delay,
                )
            except asyncio.TimeoutError:
                continue

    async def stop(self) -> None:
        self._send_active = False
        self._health_stage('receive', 'stopped')
        self._mail_health['receive'] = {**self._mail_health['receive'], 'state': 'unavailable', 'next_retry_at': None}
        self.mark_disconnected()

    async def send_text(self, ctx: OutboundContext) -> DeliveryResult:
        target = self.normalize_target(ctx.to)
        if not target:
            return DeliveryResult(
                channel_id="email",
                message_id="",
                success=False,
                error="Email send requires a valid recipient email address",
                delivery_state="not_sent",
            )

        try:
            loop = asyncio.get_running_loop()
            message_id = await loop.run_in_executor(
                None,
                self._send_email,
                target,
                ctx.text,
                ctx.reply_to_id,
                ctx.thread_id,
                None,
                ctx.subject, ctx.message_id, ctx.new_thread, ctx.html_body,
            )
            self.record_message()
            self._health_success('send', 'send')
            return DeliveryResult(
                channel_id="email",
                message_id=message_id,
                chat_id=target,
                success=True,
                delivery_state="accepted",
            )
        except asyncio.CancelledError as exc:
            self._health_failure('send', exc)
            raise
        except Exception as exc:
            known_not_sent = isinstance(exc, _EmailNotSent)
            cause = exc.cause if known_not_sent else exc
            self._health_failure('send', cause)
            return DeliveryResult(
                channel_id="email",
                message_id="",
                success=False,
                error=f"Email send failed: {exc}",
                retryable=known_not_sent and self._is_retryable(cause),
                delivery_state="not_sent" if known_not_sent else "unknown",
            )

    async def send_media(self, ctx: OutboundContext) -> DeliveryResult:
        target = self.normalize_target(ctx.to)
        if not target:
            return DeliveryResult(
                channel_id="email",
                message_id="",
                success=False,
                error="Email send_media requires a valid recipient email address",
                delivery_state="not_sent",
            )
        if not ctx.media_url:
            return await self.send_text(ctx)

        path = self._local_media_path(ctx.media_url)
        if path is None:
            return await self.send_text(
                OutboundContext(
                    **{
                        **vars(ctx),
                        "text": f"{ctx.text}\n\nAttachment/link: {ctx.media_url}".strip(),
                    }
                )
            )

        try:
            loop = asyncio.get_running_loop()
            message_id = await loop.run_in_executor(
                None,
                self._send_email,
                target,
                ctx.text,
                ctx.reply_to_id,
                ctx.thread_id,
                path,
            )
            self.record_message()
            self._health_success('send', 'send')
            return DeliveryResult(
                channel_id="email",
                message_id=message_id,
                chat_id=target,
                success=True,
                delivery_state="accepted",
            )
        except asyncio.CancelledError as exc:
            self._health_failure('send', exc)
            raise
        except Exception as exc:
            known_not_sent = isinstance(exc, _EmailNotSent)
            cause = exc.cause if known_not_sent else exc
            self._health_failure('send', cause)
            return DeliveryResult(
                channel_id="email",
                message_id="",
                success=False,
                error=f"Email send_media failed: {exc}",
                retryable=known_not_sent and self._is_retryable(cause),
                delivery_state="not_sent" if known_not_sent else "unknown",
            )

    def _test_connections(self) -> None:
        cfg = self._resolved
        imap = None
        try:
            self._health_stage('receive', 'connect')
            imap = self._connect_imap()
            self._health_stage('receive', 'authenticate')
            self._authenticate_imap(imap)
            self._identify_imap_client(imap)
            self._health_stage('receive', 'select')
            self._select_inbox(imap)
            from flocks.monitoring.mail_transport import poll_range
            # Monitoring's persisted opt-in cursor takes precedence over the
            # ordinary-chat "skip existing" preference, including restarting
            # this same plugin instance after mail arrived while disconnected.
            monitoring_catchup = poll_range(cfg, imap)
            if cfg["skipExistingOnStart"] and not monitoring_catchup:
                self._health_stage('receive', 'search')
                status, data = imap.uid("search", None, "ALL")
                if status != "OK":
                    raise RuntimeError('IMAP search failed')
                if data and data[0]:
                    self._seen_uids.update(data[0].split())
                    self._trim_seen_uids()
            self._health_success('receive', 'probe')
        except Exception as exc:
            self._health_failure('receive', exc)
            raise RuntimeError(f"IMAP connection test failed: {type(exc).__name__}") from exc
        finally:
            if imap is not None:
                try:
                    imap.logout()
                except Exception:
                    pass

        self._test_smtp_connection()

    def _test_smtp_connection(self) -> None:
        smtp = None
        try:
            self._health_stage('send', 'connect')
            smtp = self._connect_smtp()
            self._health_stage('send', 'authenticate')
            self._authenticate_smtp(smtp)
            self._health_success('send', 'probe')
        except Exception as exc:
            self._health_failure('send', exc)
            raise RuntimeError(f"SMTP connection test failed: {type(exc).__name__}") from exc
        finally:
            if smtp is not None:
                try:
                    smtp.quit()
                except Exception:
                    smtp.close()

    def _fetch_new_messages(self) -> list[tuple[bytes, InboundMessage]]:
        cfg = self._resolved
        parsed_messages: list[tuple[bytes, InboundMessage]] = []
        deadline = monotonic() + IMAP_BATCH_SECONDS
        self._health_stage('receive', 'connect')
        imap = self._connect_imap()
        try:
            self._health_stage('receive', 'authenticate')
            self._authenticate_imap(imap)
            self._identify_imap_client(imap)
            self._health_stage('receive', 'select')
            self._select_inbox(imap)
            from flocks.monitoring.mail_transport import poll_range, record_unparsed
            self._monitor_poll = poll_range(cfg, imap)
            self._monitor_high = None
            self._monitor_unparsed = 0
            if self._monitor_poll and getattr(self, "_monitor_validity", None) != self._monitor_poll[1]:
                self._seen_uids.clear()
                self._monitor_validity = self._monitor_poll[1]
            search = self._monitor_poll[2] if self._monitor_poll else ["UNSEEN"]
            self._health_stage('receive', 'search')
            status, data = imap.uid("search", None, *search)
            if status != "OK":
                raise RuntimeError('IMAP search failed')
            if not data or not data[0]:
                return parsed_messages

            uids = data[0].split()
            if self._monitor_poll:
                uids = sorted((u for u in uids if int(u) > self._monitor_poll[3]), key=int)[:100]
            for uid in uids:
                if self._monitor_poll and monotonic() >= deadline:
                    if self._monitor_high is None:
                        raise TimeoutError('IMAP batch budget exhausted before fetching mail')
                    break  # Only checkpoint fetched UIDs; catch up on the next poll.
                if self._monitor_poll:
                    self._monitor_high = int(uid)
                if uid in self._seen_uids:
                    continue
                self._health_stage('receive', 'fetch')
                status, msg_data = imap.uid("fetch", uid, "(BODY.PEEK[])")
                if status != "OK":
                    self._monitor_high = None
                    if self._monitor_poll:
                        raise RuntimeError("IMAP fetch failed")
                    continue
                try:
                    raw_email = msg_data[0][1]
                except (IndexError, TypeError):
                    log.warning("email.imap.malformed_response", {"uid": uid.decode(errors="replace")})
                    if self._monitor_poll:
                        raise RuntimeError("Malformed IMAP record")
                    continue
                if not isinstance(raw_email, (bytes, bytearray)):
                    log.warning("email.imap.non_bytes_payload", {"uid": uid.decode(errors="replace")})
                    if self._monitor_poll:
                        raise RuntimeError("Malformed IMAP payload")
                    continue

                try:
                    message = email_lib.message_from_bytes(raw_email)
                except Exception:
                    log.warning("email.imap.parse_failed", {"uid": uid.decode(errors="replace")})
                    if self._monitor_poll:
                        record_unparsed(self._monitor_poll, uid)
                        self._monitor_unparsed += 1
                        self._mark_seen(uid)
                    continue

                parsed, should_mark_seen = self._parse_and_authorize_with_tracking(
                    message,
                    uid.decode(errors="replace"),
                )
                if parsed is None:
                    if should_mark_seen:
                        self._mark_seen(uid)
                    elif self._monitor_poll:
                        record_unparsed(self._monitor_poll, uid)
                        self._monitor_unparsed += 1
                        self._mark_seen(uid)
                    continue
                if self._monitor_poll:
                    parsed.raw["uidvalidity"] = self._monitor_poll[1]
                parsed_messages.append((uid, parsed))
        finally:
            try:
                imap.logout()
            except Exception:
                pass
        return parsed_messages

    def _identify_imap_client(self, imap: imaplib.IMAP4) -> None:
        """Send IMAP ID for providers that gate mailbox access on client identity."""
        try:
            status, data = imap.xatom("ID", IMAP_CLIENT_ID)
        except Exception as exc:
            log.debug("email.imap.id_failed", {"error": str(exc)})
            return
        if status != "OK":
            log.debug(
                "email.imap.id_rejected",
                {"status": status, "response": self._format_imap_response(data)},
            )

    def _select_inbox(self, imap: imaplib.IMAP4) -> None:
        status, data = imap.select("INBOX")
        if status == "OK":
            return
        response = self._format_imap_response(data)
        raise RuntimeError(f"IMAP SELECT INBOX failed ({status}): {response}")

    @staticmethod
    def _format_imap_response(data: Any) -> str:
        if isinstance(data, (list, tuple)):
            parts = data
        else:
            parts = (data,)

        rendered: list[str] = []
        for part in parts:
            if part is None:
                continue
            if isinstance(part, bytes):
                rendered.append(part.decode("utf-8", errors="replace"))
            else:
                rendered.append(str(part))
        return "; ".join(rendered) if rendered else "(empty response)"

    def _parse_and_authorize(
        self,
        message: email_lib.message.Message,
        uid: str,
    ) -> Optional[InboundMessage]:
        parsed, _ = self._parse_and_authorize_with_tracking(message, uid)
        return parsed

    def _parse_and_authorize_with_tracking(
        self,
        message: email_lib.message.Message,
        uid: str,
    ) -> tuple[Optional[InboundMessage], bool]:
        cfg = self._resolved
        parsed = build_inbound_message(
            message,
            uid=uid,
            account_id="default",
            skip_attachments=bool(cfg["skipAttachments"]),
        )
        if parsed is None:
            return None, False

        inbound = parsed.inbound
        sender = inbound.sender_id
        if sender == cfg["address"]:
            return None, True
        if is_automated_sender(sender, dict(message.items())):
            return None, True

        allowed = parse_allowed_senders(cfg)
        if not cfg["allowAll"]:
            if not allowed or sender not in allowed:
                log.debug("email.sender.blocked", {"sender": sender})
                return None, True

        if cfg["requireAuthenticatedSender"] and allowed and not cfg["allowAll"]:
            if not cfg["authservId"]:
                log.warning("email.sender.authserv_id_missing", {"sender": sender})
                return None, True
            authenticated, reason = verify_sender_authentication(
                message,
                sender,
                authserv_id=str(cfg["authservId"]),
            )
            if not authenticated:
                log.warning("email.sender.unauthenticated", {
                    "sender": sender,
                    "reason": reason,
                })
                return None, True

        # Monitoring requires authenticated sender evidence even in allowAll mode.
        authenticated = False
        if cfg.get("authservId"):
            authenticated, _ = verify_sender_authentication(message, sender, authserv_id=str(cfg["authservId"]))
        from flocks.monitoring.mail_transport import mailbox_key
        inbound.raw.update(authenticated_sender=authenticated, mailbox_key=mailbox_key(cfg),
                           references=parsed.references, body=parsed.text if hasattr(parsed, "text") else inbound.text)
        context = {
            "subject": parsed.subject,
            "message_id": parsed.message_id,
            "references": parsed.references,
        }
        self._thread_context[sender] = context
        for key in {parsed.message_id, parsed.inbound.thread_id or "", parsed.inbound.reply_to_id or ""}:
            if key:
                self._thread_context[key] = context
        return inbound, False

    def _mark_seen(self, uid: bytes) -> None:
        self._seen_uids.add(uid)
        self._trim_seen_uids()

    def _connect_smtp(self) -> smtplib.SMTP:
        cfg = self._resolved
        context = ssl.create_default_context()
        if cfg["smtpSecurity"] == "ssl":
            return smtplib.SMTP_SSL(
                cfg["smtpHost"],
                int(cfg["smtpPort"]),
                timeout=SMTP_CONNECT_TIMEOUT,
                context=context,
            )
        smtp = smtplib.SMTP(
            cfg["smtpHost"],
            int(cfg["smtpPort"]),
            timeout=SMTP_CONNECT_TIMEOUT,
        )
        if cfg["smtpSecurity"] == "starttls":
            self._health_stage('send', 'tls')
            code, response = smtp.starttls(context=context)
            if code != 220:
                smtp.close()
                raise RuntimeError(f"SMTP STARTTLS not available: {response}")
        return smtp

    def _connect_imap(self) -> imaplib.IMAP4:
        cfg = self._resolved
        context = ssl.create_default_context()
        if cfg["imapSecurity"] == "ssl":
            return imaplib.IMAP4_SSL(
                cfg["imapHost"],
                int(cfg["imapPort"]),
                timeout=30,
                ssl_context=context,
            )

        imap = imaplib.IMAP4(cfg["imapHost"], int(cfg["imapPort"]), timeout=30)
        if cfg["imapSecurity"] != "starttls":
            return imap

        self._health_stage('receive', 'tls')
        code, response = imap.starttls(ssl_context=context)
        if code != "OK":
            imap.close()
            raise RuntimeError(f"IMAP STARTTLS not available: {response}")
        return imap

    def _xoauth2_initial_response(self) -> str:
        cfg = self._resolved
        return f"user={cfg['username']}\x01auth=Bearer {cfg['accessToken']}\x01\x01"

    def _authenticate_imap(self, imap: imaplib.IMAP4) -> None:
        cfg = self._resolved
        if cfg["authMode"] == "xoauth2":
            response = self._xoauth2_initial_response().encode("utf-8")
            imap.authenticate("XOAUTH2", lambda _challenge: response)
            return
        imap.login(cfg["username"], cfg["password"])

    def _authenticate_smtp(self, smtp: smtplib.SMTP) -> None:
        cfg = self._resolved
        if cfg["authMode"] == "xoauth2":
            smtp.auth("XOAUTH2", lambda _challenge=None: self._xoauth2_initial_response())
            return
        smtp.login(cfg["username"], cfg["password"])

    def _send_email(
        self,
        to_addr: str,
        body: str,
        reply_to_msg_id: Optional[str],
        thread_id: Optional[str],
        attachment_path: Optional[Path],
        subject_override: Optional[str] = None,
        stable_message_id: Optional[str] = None,
        new_thread: bool = False,
        html_body: Optional[str] = None,
    ) -> str:
        smtp = None
        try:
            self._require_send_enabled()
            msg = self._prepare_email(to_addr, body, reply_to_msg_id, thread_id,
                                      attachment_path, subject_override, stable_message_id, new_thread, html_body)
            self._health_stage('send', 'connect')
            smtp = self._connect_smtp()
            self._health_stage('send', 'authenticate')
            self._authenticate_smtp(smtp)
        except _EmailNotSent:
            self._close_smtp(smtp)
            raise
        except Exception as exc:
            self._close_smtp(smtp)
            # No call to send_message has occurred, including for TLS/auth errors.
            raise _EmailNotSent(exc) from exc
        try:
            # Stop/config changes may happen during an outbound hook or connect.
            # Recheck before DATA rather than trusting the earlier preflight.
            self._require_send_enabled()
            self._health_stage('send', 'send')
            smtp.send_message(msg)
        except (smtplib.SMTPRecipientsRefused, smtplib.SMTPSenderRefused,
                smtplib.SMTPHeloError, smtplib.SMTPNotSupportedError) as exc:
            # These smtplib failures occur before DATA is accepted.
            raise _EmailNotSent(exc) from exc
        except smtplib.SMTPDataError as exc:
            # A negative DATA response proves rejection. Lost/invalid responses
            # remain unknown and cannot safely authorize a duplicate delivery.
            if 400 <= exc.smtp_code < 600:
                raise _EmailNotSent(exc) from exc
            raise
        finally:
            self._close_smtp(smtp)
        return str(msg['Message-ID'])

    @staticmethod
    def _close_smtp(smtp: Any) -> None:
        if smtp is None:
            return
        try:
            smtp.quit()
        except Exception:
            try:
                smtp.close()
            except Exception:
                pass  # Cleanup never overwrites the original acceptance fact.

    def _prepare_email(
        self,
        to_addr: str,
        body: str,
        reply_to_msg_id: Optional[str],
        thread_id: Optional[str],
        attachment_path: Optional[Path],
        subject_override: Optional[str],
        stable_message_id: Optional[str],
        new_thread: bool,
        html_body: Optional[str] = None,
    ) -> MIMEMultipart:
        cfg = self._resolved
        msg = MIMEMultipart("alternative" if html_body and attachment_path is None else "mixed")
        msg["From"] = cfg["address"]
        msg["To"] = to_addr

        for header in (subject_override, stable_message_id):
            if header and any(c in header for c in "\r\n"):
                raise ValueError("Invalid notification header")
        ctx = {} if new_thread else self._resolve_thread_context(to_addr, reply_to_msg_id, thread_id)
        subject = subject_override or ctx.get("subject") or cfg["defaultSubject"]
        if not new_thread and not subject.lower().startswith("re:"):
            subject = f"Re: {subject}"
        msg["Subject"] = subject

        original_id = None if new_thread else (reply_to_msg_id or ctx.get("message_id"))
        references = None if new_thread else (thread_id or ctx.get("references") or original_id)
        if original_id:
            msg["In-Reply-To"] = original_id
        if references:
            msg["References"] = references

        msg["Date"] = formatdate(localtime=True)
        message_id = stable_message_id or f"<flocks-{uuid.uuid4().hex[:12]}@{self._message_id_domain()}>"
        msg["Message-ID"] = message_id
        content = MIMEMultipart("alternative") if html_body and attachment_path is not None else msg
        content.attach(MIMEText(body or "", "plain", "utf-8"))
        if html_body:
            content.attach(MIMEText(html_body, "html", "utf-8"))
        if content is not msg:
            msg.attach(content)

        if attachment_path is not None:
            with attachment_path.open("rb") as handle:
                part = MIMEBase("application", "octet-stream")
                part.set_payload(handle.read())
            encoders.encode_base64(part)
            safe_name = sanitize_filename(attachment_path.name, fallback="attachment")
            part.add_header(
                "Content-Disposition",
                "attachment",
                filename=safe_name,
            )
            msg.attach(part)

        return msg

    def _resolve_thread_context(
        self,
        to_addr: str,
        reply_to_msg_id: Optional[str],
        thread_id: Optional[str],
    ) -> dict[str, str]:
        for key in (thread_id, reply_to_msg_id, to_addr):
            if key and key in self._thread_context:
                return self._thread_context[key]
        return {}

    def _message_id_domain(self) -> str:
        address = str(self._resolved.get("address") or "")
        if "@" not in address:
            return "localhost"
        return address.rsplit("@", 1)[-1] or "localhost"

    def _trim_seen_uids(self) -> None:
        if len(self._seen_uids) <= self._seen_uids_max:
            return
        try:
            sorted_uids = sorted(self._seen_uids, key=lambda item: int(item))
            self._seen_uids = set(sorted_uids[-self._seen_uids_max // 2:])
        except (TypeError, ValueError):
            keep = list(self._seen_uids)[-self._seen_uids_max // 2:]
            self._seen_uids = set(keep)

    @staticmethod
    def _local_media_path(media_url: str) -> Optional[Path]:
        value = str(media_url or "").strip()
        if value.startswith("file://"):
            from urllib.parse import unquote
            value = unquote(value[len("file://"):])
        if value.startswith(("http://", "https://")):
            return None
        path = Path(value)
        return path if path.is_file() else None

    @staticmethod
    def _is_retryable(exc: Exception) -> bool:
        return isinstance(
            exc,
            (
                TimeoutError,
                ConnectionError,
                OSError,
                smtplib.SMTPServerDisconnected,
                smtplib.SMTPConnectError,
                smtplib.SMTPHeloError,
                socket.timeout,
            ),
        )
