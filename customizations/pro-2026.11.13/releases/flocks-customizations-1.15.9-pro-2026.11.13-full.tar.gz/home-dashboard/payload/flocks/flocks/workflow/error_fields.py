"""Payload-free error fields shared by SQLite and Pro workflow diagnostics.

Keep this independent of the selected store: managed Pro installs retain
their original store modules, including when PostgreSQL is unavailable.
"""
from __future__ import annotations

from typing import Any


def sqlite_error_fields(exc: BaseException) -> dict[str, Any]:
    fields = {"error_type": type(exc).__name__}
    code = getattr(exc, "sqlite_errorcode", None)
    name = getattr(exc, "sqlite_errorname", None)
    if isinstance(code, int):
        fields["sqlite_errorcode"] = code
    if isinstance(name, str) and name.startswith("SQLITE_"):
        fields["sqlite_errorname"] = name
    sqlstate = getattr(exc, "sqlstate", None)
    if isinstance(sqlstate, str) and len(sqlstate) == 5:
        fields["sqlstate"] = sqlstate
    return fields
