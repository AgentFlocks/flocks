"""Hub lifecycle integration. Merely shipping the package never enables it."""
import asyncio
import hashlib
import json
import os
import time
from pathlib import Path
from flocks.auth.context import get_current_auth_user
from flocks.hub import local
from flocks.project.project import Project, ProjectPathConflictError
from flocks.task.manager import TaskManager
from flocks.task.models import SchedulerStatus, RetryConfig
from flocks.task.plugin_models import TaskSpec
from flocks.task.plugin_sync import upsert_task_specs
from flocks.task.store import TaskStore
from flocks.workspace.manager import WorkspaceManager
from .models import COMPONENT_ID, MonitoringPolicy, MonitoringDeclaration
from .store import rows, write, encode, connection
from .adapter import discover
from .scheduling import IMMEDIATE_START_PENDING, start_immediately

_lock = asyncio.Lock()
CORE_CAPABILITIES = {'monitor.daily.v1', 'monitor.readonly.v1', 'monitor.native-messages.v1', 'monitor.confirmed-disposition.v1', 'monitor.automatic-status.v1', 'monitor.mail-feedback.v1'}
CORE_CAPABILITIES.add('monitor.investigation.v1')
CORE_CAPABILITIES.add('monitor.agent-component.v1')
CORE_CAPABILITIES.add('monitor.production-investigation.v1')
CORE_CAPABILITIES.add('monitor.reliable-investigation.v1')
CORE_CAPABILITIES.add('monitor.multi-xdr.v1')
CORE_CAPABILITIES.add('monitor.mail-manual.v1')
CORE_CAPABILITIES.add('monitor.mail-retry.v1')
CORE_CAPABILITIES.add('monitor.incident-evidence.v1')
CORE_CAPABILITIES.add('monitor.event-list.v1')
CORE_CAPABILITIES.add('monitor.confirmed-risk.v1')
CORE_CAPABILITIES.add('monitor.next-round-disposition.v1')
CORE_CAPABILITIES.add('monitor.source-membership.v1')
CORE_CAPABILITIES.add('monitor.mail-controls.v1')
CORE_CAPABILITIES.add('monitor.investigation-replan.v1')
CORE_CAPABILITIES.add('monitor.event-list-controls.v1')
CORE_CAPABILITIES.add('monitor.confirmed-findings.v1')


def validate_manifest(manifest, package=None):
    required = set((manifest.model_extra or {}).get('requiredCoreCapabilities', []))
    if not required or not required <= CORE_CAPABILITIES:
        raise ValueError('Monitoring component requires unsupported core capabilities')
    if 'monitor.agent-component.v1' in required:
        from .agent_component import AGENT_ID
        if not any(ref.type == 'agent' and ref.id == AGENT_ID and not ref.optional for ref in manifest.components):
            raise ValueError('监测套件必须包含监测智能体组件')
    import os
    if int(os.environ.get('WEB_CONCURRENCY', '1')) != 1:
        raise ValueError('安全运营监测阶段一仅支持单后端执行进程')
    if package is not None:
        MonitoringDeclaration.model_validate_json((Path(package) / 'monitoring.json').read_text())


async def install(manifest):
    record = local.get_record('component', COMPONENT_ID)
    if not record:
        raise ValueError('监测套件尚未安装')
    package = Path(record.installPath)
    validate_manifest(manifest, package)
    declaration = MonitoringDeclaration.model_validate_json((package / 'monitoring.json').read_text())
    user = get_current_auth_user()
    if user is None:
        raise ValueError('安装监测套件需要已登录的拥有者')
    async with _lock:
        old = await rows('SELECT * FROM monitor_installations WHERE owner=? AND scope=?', (user.id, COMPONENT_ID))
        directory = await preflight_install()
        projects = await Project.list(owner_id=user.id)
        names = {project.name.casefold() for project in projects}
        name, suffix = '安全运营监测', 1
        while name.casefold() in names:
            suffix += 1
            name = f'安全运营监测 ({suffix})'
        try:
            # Project.create checks canonical allowed roots before mkdir.
            project = await Project.create(owner_id=user.id, name=name, worktree=str(directory))
        except ProjectPathConflictError as exc:
            project = exc.project
        directory = Path(project.worktree)
        devices, tool, reason = await discover()
        from .agent_component import unavailable_reason
        reason = reason or await unavailable_reason()
        policy = MonitoringPolicy(owner=user.id, project=project.id, directory=str(directory),
                                  investigation_engine='agent-v1', timeout_seconds=1200,
                                  devices=devices, tool=tool or 'sangfor_xdr_incidents')
        if old:
            previous = MonitoringPolicy.model_validate_json(old[0]['policy'])
            if previous.project == project.id:
                policy.correlation_bindings = previous.correlation_bindings
            if previous.targets_configured and previous.project == project.id:
                from .configuration import resolve_targets
                policy = previous
                reason = await resolve_targets(policy) or await unavailable_reason()
            elif previous.project == project.id and previous.devices and devices != previous.devices:
                # A new sole available device must never inherit the old owner mailbox.
                policy = previous
                reason = '原监测设备接入已变化，请在监测配置中确认设备与责任人对应关系'
        from .capabilities import discover as discover_investigation
        catalog, notes = await discover_investigation(policy, include_unbound=True)
        policy.correlation_devices = sorted({cap.device for cap in catalog if cap.kind in {'tdp', 'sig'}})
        policy.correlation_notes = notes
        key = f'monitor:{user.id}:{project.id}:{COMPONENT_ID}'
        existing = await TaskStore.get_scheduler_by_dedup_key(key)
        was_disabled = bool(old and old[0]['installed'] and existing
                            and existing.status != SchedulerStatus.ACTIVE)
        if existing:
            await TaskManager.disable_scheduler(existing.id)
            for execution in await TaskStore.list_active_executions_for_scheduler(existing.id):
                await TaskManager.cancel_execution(execution.id)
        await upsert_task_specs([TaskSpec(
            dedup_key=key, title='安全运营监测', description='每十分钟查询分析、逐条邮件通知；下一轮解读责任人回信、标记并回查',
            cron=declaration.cron, enabled=False, timezone=policy.timezone,
            context={'monitoring': policy.model_dump()}, tags=['monitoring', COMPONENT_ID],
        )])
        scheduler = await TaskStore.get_scheduler_by_dedup_key(key)
        if scheduler is None:
            raise RuntimeError('监测调度注册失败')
        await _disable_round_retries(scheduler)
        # Installation gate is committed before activation; a crash leaves a
        # disabled definition which startup reconciliation can safely resume.
        await write('INSERT INTO monitor_installations(owner,scope,project,policy,installed,ready,reason,scheduler_id,activation_pending) VALUES(?,?,?,?,1,?,?,?,?) ON CONFLICT(owner,scope) DO UPDATE SET project=excluded.project,policy=excluded.policy,installed=1,ready=excluded.ready,reason=excluded.reason,scheduler_id=excluded.scheduler_id,activation_pending=excluded.activation_pending',
                    (user.id, COMPONENT_ID, project.id, encode(policy.model_dump()), int(not reason), reason, scheduler.id, int(not reason and not was_disabled)))
        if not reason and not was_disabled:
            scheduler.status = SchedulerStatus.ACTIVE
            await TaskStore.update_scheduler(scheduler)
            await write('UPDATE monitor_installations SET activation_pending=0 WHERE owner=? AND scope=?', (user.id, COMPONENT_ID))


async def preflight_install():
    """Check the target before replacing a package; never create directories here."""
    user = get_current_auth_user()
    if user is None:
        raise ValueError('安装监测套件需要已登录的拥有者')
    old = await rows('SELECT policy FROM monitor_installations WHERE owner=? AND scope=?', (user.id, COMPONENT_ID))
    if old:
        # Keep the original project identity and history on reinstall. A changed
        # workspace configuration is not authorization to migrate an old project.
        directory = Path(MonitoringPolicy.model_validate_json(old[0]['policy']).directory)
    else:
        digest = hashlib.sha256(user.id.encode()).hexdigest()[:16]
        directory = WorkspaceManager.get_instance().get_workspace_dir() / 'monitoring' / digest
    try:
        directory = directory.expanduser().resolve()
        roots = Project.allowed_roots()
        if not roots or not any(directory == root or directory.is_relative_to(root) for root in roots):
            raise ValueError('监测项目目录不在允许范围内，请检查 FLOCKS_WORKSPACE_DIR 与 FLOCKS_PROJECT_ROOTS 的配置及软链接真实位置')
        ancestor = directory
        while not ancestor.exists() and ancestor != ancestor.parent:
            ancestor = ancestor.parent
        if not ancestor.is_dir() or not os.access(ancestor, os.R_OK | os.W_OK | os.X_OK):
            raise ValueError('监测项目目录不可创建或写入，请检查工作区目录权限')
        if directory.exists():
            Project.validate_worktree(str(directory))
    except (OSError, RuntimeError) as exc:
        raise ValueError('监测项目目录无法解析，请检查工作区路径及软链接') from exc
    return directory


async def uninstall():
    async with _lock:
        for entry in await rows('SELECT * FROM monitor_installations WHERE scope=?', (COMPONENT_ID,)):
            await write('UPDATE monitor_installations SET installed=0,ready=0,activation_pending=0,reason=? WHERE owner=? AND scope=?',
                        ('已卸载', entry['owner'], COMPONENT_ID))
            await write('UPDATE monitor_auto_settings SET enabled=0 WHERE owner=? AND scope=?', (entry['owner'], COMPONENT_ID))
            await write('UPDATE monitor_mail_settings SET enabled=0 WHERE owner=? AND scope=?', (entry['owner'], COMPONENT_ID))
            if entry['scheduler_id']:
                await TaskManager.disable_scheduler(entry['scheduler_id'])
                # Disable and cancel every queued/running execution; cancellation
                # completion is awaited by the monitor dispatch wrapper.
                active = await TaskStore.list_active_executions_for_scheduler(entry['scheduler_id'])
                for execution in active:
                    await TaskManager.cancel_execution(execution.id)


async def _pause_installed():
    for entry in await rows('SELECT scheduler_id FROM monitor_installations WHERE scope=? AND installed=1', (COMPONENT_ID,)):
        await write('UPDATE monitor_installations SET activation_pending=0 WHERE scheduler_id=?', (entry['scheduler_id'],))
        if entry['scheduler_id']:
            await TaskManager.disable_scheduler(entry['scheduler_id'])
            for execution in await TaskStore.list_active_executions_for_scheduler(entry['scheduler_id']):
                await TaskManager.cancel_execution(execution.id)


async def _owned_installation(owner):
    entries = await rows('SELECT * FROM monitor_installations WHERE owner=? AND scope=? AND installed=1', (owner, COMPONENT_ID))
    if not entries:
        raise FileNotFoundError('请先在添加场景中安装安全运营监测')
    entry = entries[0]
    scheduler = await TaskStore.get_scheduler(entry['scheduler_id'])
    if scheduler is None:
        raise ValueError('监测任务缺失，请重新安装场景')
    policy = MonitoringPolicy.model_validate_json(entry['policy'])
    if policy.owner != owner:
        raise ValueError('监测任务归属不一致，请重新安装场景')
    await _migrate_policy(entry, scheduler, policy)
    return entry, scheduler, policy


async def _migrate_policy(entry, scheduler, policy):
    """Persist the sole supported policy in both stores, preserving history."""
    await _disable_round_retries(scheduler)
    current = policy.model_dump()
    if json.loads(entry['policy']) == current and scheduler.context.get('monitoring') == current:
        return
    context = {**scheduler.context, 'monitoring': current}
    # tasks.db owns both tables. Commit together so a crash cannot leave the
    # scheduler and installation disagreeing about the authorized policy.
    async with connection() as db:
        await db.execute('UPDATE monitor_installations SET policy=? WHERE owner=? AND scope=?',
                         (encode(current), policy.owner, policy.scope))
        await db.execute('UPDATE task_schedulers SET context=? WHERE id=?',
                         (encode(context), scheduler.id))
    entry['policy'] = encode(current)
    scheduler.context = context


async def _disable_round_retries(scheduler):
    """Investigation checkpoints, not TaskManager, own monitoring recovery."""
    if scheduler.retry.max_retries or scheduler.retry.retry_after:
        scheduler.retry.max_retries = 0
        scheduler.retry.retry_after = None
        await TaskStore.update_scheduler(scheduler)
    # Clear an old build's minute-based retry plan without erasing attempt facts.
    async with connection() as db:
        cursor = await db.execute("SELECT id,retry FROM task_executions WHERE scheduler_id=? AND status IN ('failed','queued')", (scheduler.id,))
        for item in await cursor.fetchall():
            retry = RetryConfig.model_validate_json(item['retry'])
            if retry.max_retries or retry.retry_after:
                retry.max_retries = 0
                retry.retry_after = None
                await db.execute('UPDATE task_executions SET retry=? WHERE id=?', (retry.model_dump_json(by_alias=True), item['id']))


async def _pause_monitor(entry):
    from . import diagnostics as diag
    with diag.span('pause.installation'):
        await write('UPDATE monitor_installations SET activation_pending=0 WHERE owner=? AND scope=?', (entry['owner'], COMPONENT_ID))
    with diag.span('pause.disable'):
        await TaskManager.disable_scheduler(entry['scheduler_id'])
    with diag.span('pause.executions'):
        active = await TaskStore.list_active_executions_for_scheduler(entry['scheduler_id'])
    for execution in active:
        with diag.span('pause.cancel', target_execution=diag.opaque(execution.id)):
            await TaskManager.cancel_execution(execution.id)


async def pause_for_agent_change(*, removing=False):
    """Drain active users before replacing/removing the shared role payload."""
    async with _lock:
        for entry in await rows('SELECT * FROM monitor_installations WHERE installed=1'):
            if MonitoringPolicy.model_validate_json(entry['policy']).investigation_engine != 'agent-v1':
                continue
            await _pause_monitor(entry)
            if removing:
                await write('UPDATE monitor_installations SET ready=0,reason=? WHERE owner=? AND scope=?',
                            ('监测智能体组件已卸载，请更新套件后重新启动', entry['owner'], COMPONENT_ID))


async def start_monitoring(owner):
    """Recheck capabilities, queue the first round now, then resume cron slots."""
    from . import diagnostics as diag
    waiting = time.monotonic()
    diag.event('control.lock', control_action='start', outcome='running', control_lock_busy=_lock.locked())
    async with _lock:
        diag.event('control.lock', control_action='start', outcome='ok', duration_ms=round((time.monotonic() - waiting) * 1000, 2))
        record = local.get_record('component', COMPONENT_ID)
        if not record:
            raise FileNotFoundError('请先在添加场景中安装安全运营监测')
        if not record.enabled:
            raise ValueError('场景已停用，请先在添加场景中启用')
        entry, scheduler, policy = await _owned_installation(owner)
        if policy.investigation_engine == 'agent-v1':
            from .agent_component import unavailable_reason
            reason = await unavailable_reason()
            if reason:
                await _pause_monitor(entry)
                await write('UPDATE monitor_installations SET ready=0,reason=? WHERE owner=? AND scope=?',
                            (reason, owner, COMPONENT_ID))
                raise ValueError(reason)
        if entry['ready'] and scheduler.status == SchedulerStatus.ACTIVE:
            return  # Retries cannot reset the schedule or duplicate work.
        await _pause_monitor(entry)
        await write('UPDATE monitor_installations SET ready=0,reason=? WHERE owner=? AND scope=?', ('接入检查尚未完成，请重试启动', owner, COMPONENT_ID))
        from flocks.hub.catalog import load_manifest
        validate_manifest(load_manifest('component', COMPONENT_ID), Path(record.installPath))
        if policy.targets_configured:
            from .configuration import resolve_targets
            reason = await resolve_targets(policy)
            devices, tool = policy.devices, policy.tool
        else:
            devices, tool, reason = await discover()
            if policy.devices and devices != policy.devices:
                reason = reason or '原监测设备接入已变化，请在监测配置中确认设备与责任人对应关系'
        if not Path(policy.directory).is_dir():
            reason = '监测工作目录不可用，请恢复目录或重新安装场景'
        if reason:
            await write('UPDATE monitor_installations SET reason=? WHERE owner=? AND scope=?', (reason, owner, COMPONENT_ID))
            raise ValueError(reason)
        policy.devices = devices
        policy.tool = tool
        scheduler.status = SchedulerStatus.DISABLED
        scheduler.context = {**scheduler.context, 'monitoring': policy.model_dump()}
        await TaskStore.update_scheduler(scheduler)
        await write('UPDATE monitor_installations SET policy=?,ready=1,reason=NULL,activation_pending=? WHERE owner=? AND scope=?',
                    (encode(policy.model_dump()), IMMEDIATE_START_PENDING, owner, COMPONENT_ID))
        from .investigation import retry_waiting
        await retry_waiting(policy)
        await start_immediately(scheduler)


async def pause_monitoring(owner):
    from . import diagnostics as diag
    waiting = time.monotonic()
    diag.event('control.lock', control_action='pause', outcome='running', control_lock_busy=_lock.locked())
    async with _lock:
        diag.event('control.lock', control_action='pause', outcome='ok', duration_ms=round((time.monotonic() - waiting) * 1000, 2))
        with diag.span('pause.installation'):
            entry, _, _ = await _owned_installation(owner)
        await _pause_monitor(entry)


async def set_investigation_engine(owner, engine):
    """Change the executor only while paused; preserve all cases/mail ledgers."""
    if engine != 'agent-v1':
        raise ValueError('仅支持智能体调查，请更新页面')
    async with _lock:
        entry, scheduler, policy = await _owned_installation(owner)
        if scheduler.status == SchedulerStatus.ACTIVE:
            raise ValueError('请先暂停监测，再切换调查方式')
        await _pause_monitor(entry)
        policy.investigation_engine = engine
        policy.timeout_seconds = 1200
        from .agent_component import resolve
        await resolve()
        from .capabilities import discover as discover_investigation
        catalog, notes = await discover_investigation(policy, include_unbound=True)
        policy.correlation_devices = sorted({cap.device for cap in catalog if cap.kind in {'tdp', 'sig'}})
        policy.correlation_notes = notes
        from .store import connection
        async with connection() as db:
            await db.execute('UPDATE task_schedulers SET context=? WHERE id=?',
                             (encode({**scheduler.context, 'monitoring': policy.model_dump()}), scheduler.id))
            await db.execute('UPDATE monitor_installations SET policy=? WHERE owner=? AND scope=?',
                             (encode(policy.model_dump()), owner, COMPONENT_ID))


async def set_scene_enabled(enabled):
    """Scene visibility is separate from the monitoring task's readiness/pause."""
    async with _lock:
        record = local.get_record('component', COMPONENT_ID)
        if not record:
            raise FileNotFoundError('请先安装安全运营监测场景')
        record.enabled = enabled
        local.save_installed_record(record)
        if not enabled:
            await _pause_installed()
        # Showing a scene must not silently resume a user-paused background task.


async def reconcile():
    record = local.get_record('component', COMPONENT_ID)
    if not record:
        await uninstall()
        return
    if not record.enabled:
        await _pause_installed()
        return
    # Never scan bundled source for runnable tasks. Recheck installed records.
    for entry in await rows('SELECT * FROM monitor_installations WHERE installed=1'):
        policy = MonitoringPolicy.model_validate_json(entry['policy'])
        scheduler = await TaskStore.get_scheduler(entry['scheduler_id'])
        if scheduler:
            await _migrate_policy(entry, scheduler, policy)
        if not entry['ready']:
            continue  # missing capability remains explicitly not ready
        if policy.investigation_engine == 'agent-v1':
            from .agent_component import unavailable_reason
            reason = await unavailable_reason()
            if reason:
                await _pause_monitor(entry)
                await write('UPDATE monitor_installations SET ready=0,reason=? WHERE owner=? AND scope=?',
                            (reason, policy.owner, policy.scope))
                continue
        if not Path(policy.directory).is_dir():
            await TaskManager.disable_scheduler(entry['scheduler_id'])
            await write('UPDATE monitor_installations SET ready=0,reason=? WHERE owner=? AND scope=?',
                        ('专用项目路径不可用', policy.owner, policy.scope))
            continue
        if entry['activation_pending']:
            scheduler = await TaskStore.get_scheduler(entry['scheduler_id'])
            if scheduler:
                if entry['activation_pending'] == IMMEDIATE_START_PENDING:
                    await start_immediately(scheduler)
                else:
                    await TaskManager.enable_scheduler(scheduler.id)
                    await write('UPDATE monitor_installations SET activation_pending=0 WHERE owner=? AND scope=?', (policy.owner, policy.scope))


async def compensate_install_failure(was_installed):
    """Fail closed for the current owner; keep other owners' installations intact."""
    user = get_current_auth_user()
    if user is None:
        return
    entries = await rows('SELECT scheduler_id FROM monitor_installations WHERE owner=? AND scope=?', (user.id, COMPONENT_ID))
    for entry in entries:
        await write('UPDATE monitor_installations SET installed=?,ready=0,activation_pending=0,reason=? WHERE owner=? AND scope=?',
                    (int(was_installed), '安装未完成，请重新安装', user.id, COMPONENT_ID))
        if entry['scheduler_id']:
            await TaskManager.disable_scheduler(entry['scheduler_id'])
            for execution in await TaskStore.list_active_executions_for_scheduler(entry['scheduler_id']):
                await TaskManager.cancel_execution(execution.id)
