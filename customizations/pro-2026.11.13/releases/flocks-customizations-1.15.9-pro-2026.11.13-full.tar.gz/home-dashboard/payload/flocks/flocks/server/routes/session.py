"""
Session management routes

Compatible with TypeScript API.
Uses camelCase field names for TypeScript compatibility.
"""
from __future__ import annotations

import asyncio
import json
from types import SimpleNamespace
import os
import time
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import quote
from typing import List, Optional, Any, Dict, Literal, Union, Tuple, cast
from fastapi import APIRouter, HTTPException, status, Query, Request, Response
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field, ConfigDict, model_validator

from flocks.auth.context import AuthUser, get_current_auth_user, reset_current_auth_user, set_current_auth_user
from flocks.channel.base import ChatType
from flocks.server.routes._timing import log_route_timing
from flocks.audit import emit_audit_event
from flocks.license import assert_license_active, license_status
from flocks.session.context_usage import (
    ContextUsageSnapshot,
    build_context_usage_snapshot,
    token_usage_to_dict,
)
from flocks.session.background_tasks import (
    has_pending_session_tasks,
    pending_background_tasks,
    track_background_task,
)
from flocks.session.session import (
    DEDICATED_AGENT_POLICY_METADATA_KEY,
    Session,
    SessionAgentMismatchError,
    SessionInactiveError,
    SessionInfo as SessionModel,
    SessionNotFoundError,
    is_model_auto_session_category,
)
from flocks.session.policy import SessionPolicy
from flocks.session.execution_mode import SessionExecutionMode
from flocks.session.core.status import (
    SessionStatusBusy,
    SessionStatusInfo,
    SessionStatusQueued,
)
from flocks.utils.log import Log
from flocks.utils.json_repair import parse_json_robust, repair_truncated_json
from flocks.utils.monitor import get_monitor
from flocks.server.auth import API_TOKEN_SERVICE_USER_ID, require_user

router = APIRouter()
log = Log.create(service="session-routes")

# Default agent name constant
DEFAULT_AGENT = "rex"
DEFAULT_MESSAGE_PAGE_LIMIT = 50
_CHANNEL_BINDING_QUERY_BATCH_SIZE = 500
_CONTEXT_USAGE_CACHE_TTL_SECONDS = 5.0
_context_usage_cache: Dict[Tuple[str, int], Tuple[float, ContextUsageSnapshot]] = {}
_context_usage_inflight: Dict[Tuple[str, int], asyncio.Task[ContextUsageSnapshot]] = {}
_context_usage_cache_lock = asyncio.Lock()

# File extensions that are safe to persist when materialising data-URL uploads.
# Intentionally narrow: any extension outside this set is rejected to prevent
# OS tools (Finder, ``open``) from misidentifying content based on the
# extension (e.g. a PNG named report.pdf.exe whose tail would otherwise be
# ".exe").
_UPLOAD_SAFE_EXTS = frozenset({"png", "jpg", "jpeg", "gif", "webp", "bmp", "pdf"})
_UPLOAD_EXT_BY_MIME = {
    "image/png": ".png",
    "image/jpeg": ".jpg",
    "image/jpg": ".jpg",
    "image/gif": ".gif",
    "image/webp": ".webp",
    "image/bmp": ".bmp",
    "application/pdf": ".pdf",
}


def _session_uploads_dir(session_id: str) -> Path:
    """Return the application-owned upload directory for one session."""
    from flocks.session.files import session_uploads_dir

    return session_uploads_dir(session_id)


def _materialize_data_url_part(
    session_id: str,
    data_url: str,
    mime_hint: str,
    filename_hint: Optional[str],
    *,
    failure_event: str = "session.prompt_queue.materialize_failed",
) -> str:
    """Persist a data URL under the application data directory."""
    try:
        import base64
        from flocks.utils.id import Identifier

        _header, _sep, encoded = data_url.partition(",")
        if not encoded:
            return data_url
        raw_bytes = base64.b64decode(encoded)
        uploads_root = _session_uploads_dir(session_id)
        uploads_root.mkdir(parents=True, exist_ok=True)

        ext = _UPLOAD_EXT_BY_MIME.get(mime_hint, "")
        if not ext and filename_hint:
            _, _, tail = filename_hint.rpartition(".")
            if tail.lower() in _UPLOAD_SAFE_EXTS:
                ext = "." + tail.lower()
        target = uploads_root / f"{Identifier.create('part')}{ext}"
        target.write_bytes(raw_bytes)
        return target.resolve().as_uri()
    except Exception as exc:
        log.warn(failure_event, {
            "sessionID": session_id,
            "error": str(exc),
        })
        return data_url


def _context_usage_cache_key(session_id: str, session: SessionModel) -> Tuple[str, int]:
    return session_id, int(getattr(session.time, "updated", 0) or 0)


async def _build_context_usage_for_cache(
    key: Tuple[str, int],
    session_id: str,
    *,
    session: SessionModel,
) -> ContextUsageSnapshot:
    current_task = asyncio.current_task()
    try:
        snapshot = await build_context_usage_snapshot(session_id, session=session)
        async with _context_usage_cache_lock:
            if _context_usage_inflight.get(key) is not current_task:
                return snapshot
            for cache_key in [item for item in _context_usage_cache if item[0] == session_id and item[1] < key[1]]:
                _context_usage_cache.pop(cache_key, None)
            has_newer_cache = any(item[0] == session_id and item[1] > key[1] for item in _context_usage_cache)
            if not has_newer_cache:
                _context_usage_cache[key] = (
                    time.monotonic() + _CONTEXT_USAGE_CACHE_TTL_SECONDS,
                    snapshot.model_copy(deep=True),
                )
        return snapshot
    finally:
        async with _context_usage_cache_lock:
            if _context_usage_inflight.get(key) is current_task:
                _context_usage_inflight.pop(key, None)


async def _cached_context_usage_snapshot(
    session_id: str,
    *,
    session: SessionModel,
) -> ContextUsageSnapshot:
    key = _context_usage_cache_key(session_id, session)
    now = time.monotonic()

    async with _context_usage_cache_lock:
        cached = _context_usage_cache.get(key)
        if cached and cached[0] > now:
            return cached[1].model_copy(deep=True)

        task = _context_usage_inflight.get(key)
        if task is None:
            task = asyncio.create_task(_build_context_usage_for_cache(key, session_id, session=session))
            _context_usage_inflight[key] = task

    snapshot = await asyncio.shield(task)
    return snapshot.model_copy(deep=True)

# =============================================================================
# Request/Response Models - API Compatible (camelCase)
# =============================================================================

SESSION_TITLE_MAX_LENGTH = 200


class PermissionRule(BaseModel):
    """Permission rule for API compatibility"""
    permission: str = Field(..., description="Permission name (tool name)")
    action: Literal["allow", "deny"] = Field("allow", description="Action: allow or deny")
    pattern: str = Field("*", description="Pattern to match")


class SessionCreateRequest(BaseModel):
    """
    Request to create a new session
    
    Schema follows standard Session.create format (matches Flocks):
    - parentID: optional parent session ID
    - title: optional session title
    - permission: optional permission ruleset
    
    Note: Model is not stored at session level (matches Flocks).
    Model is selected per-message based on priority:
    request.model > agent.model > lastModel > defaultModel
    """
    model_config = ConfigDict(populate_by_name=True, extra="ignore")
    
    parentID: Optional[str] = Field(None, alias="parent_id", description="Parent session ID")
    projectID: Optional[str] = Field(None, alias="project_id", description="Project ID")
    title: Optional[str] = Field(None, max_length=SESSION_TITLE_MAX_LENGTH, description="Session title")
    permission: Optional[List[PermissionRule]] = Field(None, description="Permission rules")
    category: Optional[str] = Field(None, description="Session category (e.g. 'user', 'workflow')")
    model_auto: bool = Field(
        False,
        description="Enable WebUI runtime model failover for this session",
    )


class FileDiff(BaseModel):
    """File diff info for API compatibility"""
    model_config = ConfigDict(populate_by_name=True)
    
    file: str = Field(..., description="File path")
    before: str = Field("", description="Content before changes")
    after: str = Field("", description="Content after changes")
    additions: int = Field(0, description="Lines added")
    deletions: int = Field(0, description="Lines deleted")


class SessionTime(BaseModel):
    """Session time information for API compatibility"""
    model_config = ConfigDict(populate_by_name=True)
    
    created: int = Field(..., description="Creation timestamp (ms)")
    updated: int = Field(..., description="Last update timestamp (ms)")
    compacting: Optional[int] = Field(None, description="Compaction timestamp (ms)")
    archived: Optional[int] = Field(None, description="Archive timestamp (ms)")


class SessionGoalResponse(BaseModel):
    """Persisted goal state shown by the WebUI composer banner."""
    model_config = ConfigDict(populate_by_name=True)

    status: Literal["active", "paused", "completed", "blocked"] = Field(..., description="Goal status")
    objective: str = Field(..., description="Goal objective")
    reason: Optional[str] = Field(None, description="Last goal judge reason")


class SessionResponse(BaseModel):
    """
    Session response - Flocks compatible
    
    Matches Flocks Session.Info format.
    """
    model_config = ConfigDict(populate_by_name=True, by_alias=True)
    
    id: str = Field(..., description="Session ID")
    slug: str = Field("", description="Session slug")
    projectID: str = Field(..., description="Project ID")
    effectiveProjectID: str = Field(..., description="Project used for session manager grouping")
    directory: str = Field(..., description="Working directory")
    parentID: Optional[str] = Field(None, description="Parent session ID")
    summary: Optional[Dict[str, Any]] = Field(None, description="Session summary with diffs")
    title: str = Field(..., description="Session title")
    version: str = Field("1.0.0", description="Session version")
    time: SessionTime = Field(..., description="Session timestamps")
    permission: Optional[List[Dict[str, Any]]] = Field(None, description="Permission rules")
    revert: Optional[Dict[str, Any]] = Field(None, description="Revert state")
    category: str = Field("user", description="Session category: user or task")
    status: str = Field("active", description="Session status: active or archived")
    provider: Optional[str] = Field(None, description="Pinned provider ID")
    model: Optional[str] = Field(None, description="Pinned model ID")
    model_pinned: bool = Field(False, description="Whether provider/model are pinned for this session")
    model_auto: bool = Field(False, description="Whether WebUI Auto mode is selected")
    ownerUserID: Optional[str] = Field(None, description="Session owner user id")
    ownerUsername: Optional[str] = Field(None, description="Session owner username")
    canWrite: bool = Field(False, description="Whether current user can continue this session")
    canDelete: bool = Field(False, description="Whether current user can delete this session")
    isShared: bool = Field(False, description="Whether this session is locally shared")
    goal: Optional[SessionGoalResponse] = Field(None, description="Persisted session goal state")


def _session_web_url(session_id: str) -> str:
    return f"/sessions/{quote(session_id, safe='')}"


class SessionDetailResponse(SessionResponse):
    webUrl: str = Field(..., description="Relative WebUI path; browser access requires session read permission")


class SessionListItem(BaseModel):
    """Lightweight session row for the session manager sidebar."""
    model_config = ConfigDict(populate_by_name=True, by_alias=True)

    id: str
    projectID: str
    projectName: Optional[str] = None
    effectiveProjectID: str
    directory: str
    title: str
    time: SessionTime
    category: str = "user"
    channelID: Optional[str] = None
    channelChatType: Optional[ChatType] = None
    status: str = "active"
    parentID: Optional[str] = None
    provider: Optional[str] = None
    model: Optional[str] = None
    model_pinned: bool = False
    model_auto: bool = False
    ownerUserID: Optional[str] = None
    ownerUsername: Optional[str] = None
    canWrite: bool = False
    canDelete: bool = False
    isShared: bool = False


class SessionListGroupRequest(BaseModel):
    projectID: str = Field(..., min_length=1)
    limit: int = Field(..., ge=1, le=10000)
    offset: int = Field(0, ge=0)


class SessionGroupedListRequest(BaseModel):
    projects: List[SessionListGroupRequest] = Field(..., max_length=512)
    search: Optional[str] = None

    @model_validator(mode="after")
    def validate_total_limit(self) -> "SessionGroupedListRequest":
        if sum(group.limit for group in self.projects) > 10000:
            raise ValueError("combined project limit must not exceed 10000")
        return self


class SessionListGroup(BaseModel):
    projectID: str
    items: List[SessionListItem]
    # The whole group (after the search filter), so a client listing every
    # project needs no second full read for counts and recent activity.
    total: int = 0
    lastActivityAt: Optional[int] = None


class SessionGroupedListResponse(BaseModel):
    groups: List[SessionListGroup]


class SessionRuntimeStatusResponse(BaseModel):
    """Runtime status snapshot for one session."""

    sessionID: str = Field(..., description="Session ID")
    webUrl: str = Field(..., description="Relative WebUI path; archived sessions may not be viewable")
    lifecycleStatus: Literal["active", "archived"] = Field(
        ...,
        description="Persisted session lifecycle status",
    )
    status: SessionStatusInfo = Field(..., description="Current runtime status")
    isProcessing: bool = Field(..., description="Whether accepted session work is still in progress")
    pendingPromptCount: int = Field(0, ge=0, description="Number of prompts waiting in the session queue")
    observedAt: int = Field(..., description="Server observation timestamp in milliseconds")


@dataclass(frozen=True)
class _ChannelSessionBinding:
    channel_id: str
    chat_id: str
    chat_type: ChatType


def _session_to_response(
    session: SessionModel,
    effective_project_id: Optional[str] = None,
    shared_project_ids: Optional[set[str]] = None,
) -> SessionResponse:
    """
    Convert SessionModel to SessionResponse
    """
    current_user = get_current_auth_user()
    can_write = session.status == "active" and SessionPolicy.can_write(session, current_user)
    can_delete = SessionPolicy.can_delete(session, current_user)
    is_shared = SessionPolicy.is_shared(session, shared_project_ids)
    from flocks.project.project import Project

    if effective_project_id is None:
        effective_project_id = Project.effective_project_id(
            current_user.id if current_user else API_TOKEN_SERVICE_USER_ID,
            session.project_id,
        )

    return SessionResponse(
        id=session.id,
        slug=session.slug,
        projectID=session.project_id,
        effectiveProjectID=effective_project_id,
        directory=session.directory,
        title=session.title,
        version=session.version,
        parentID=session.parent_id,
        time=SessionTime(
            created=session.time.created,
            updated=session.time.updated,
            compacting=session.time.compacting,
            archived=session.time.archived,
        ),
        summary=session.summary.model_dump() if session.summary else None,
        revert=session.revert.model_dump(by_alias=True) if session.revert else None,
        permission=[p.model_dump() for p in session.permission] if session.permission else None,
        category=session.category,
        status=session.status,
        provider=session.provider,
        model=session.model,
        model_pinned=session.model_pinned,
        model_auto=session.model_auto,
        ownerUserID=session.owner_user_id,
        ownerUsername=session.owner_username,
        canWrite=can_write and not (session.metadata or {}).get("monitorScope"),
        canDelete=can_delete,
        isShared=is_shared,
    )


def _session_to_list_item(
    session: SessionModel,
    effective_project_id: Optional[str] = None,
    shared_project_ids: Optional[set[str]] = None,
    project_name: Optional[str] = None,
    channel_binding: Optional[_ChannelSessionBinding] = None,
    title_override: Optional[str] = None,
) -> SessionListItem:
    """Convert a session to the lightweight manager-list response shape."""
    current_user = get_current_auth_user()
    from flocks.project.project import Project

    if effective_project_id is None:
        effective_project_id = Project.effective_project_id(
            current_user.id if current_user else API_TOKEN_SERVICE_USER_ID,
            session.project_id,
        )
    return SessionListItem(
        id=session.id,
        projectID=session.project_id,
        projectName=project_name,
        effectiveProjectID=effective_project_id,
        directory=session.directory,
        title=title_override if title_override is not None else session.title,
        time=SessionTime(
            created=session.time.created,
            updated=session.time.updated,
            compacting=session.time.compacting,
            archived=session.time.archived,
        ),
        category=session.category,
        channelID=channel_binding.channel_id if channel_binding else None,
        channelChatType=channel_binding.chat_type if channel_binding else None,
        status=session.status,
        parentID=session.parent_id,
        provider=session.provider,
        model=session.model,
        model_pinned=session.model_pinned,
        model_auto=session.model_auto,
        ownerUserID=session.owner_user_id,
        ownerUsername=session.owner_username,
        canWrite=session.status == "active" and SessionPolicy.can_write(session, current_user) and not (session.metadata or {}).get("monitorScope"),
        canDelete=SessionPolicy.can_delete(session, current_user),
        isShared=SessionPolicy.is_shared(session, shared_project_ids),
    )


async def _latest_channel_bindings(
    session_ids: List[str],
) -> Dict[str, _ChannelSessionBinding]:
    """Return the most recently active channel metadata for each session."""
    if not session_ids:
        return {}
    try:
        from flocks.channel.inbound.session_binding import SessionBindingService

        service = SessionBindingService()
        unique_session_ids = list(dict.fromkeys(session_ids))
        channel_bindings: Dict[str, _ChannelSessionBinding] = {}
        for start in range(0, len(unique_session_ids), _CHANNEL_BINDING_QUERY_BATCH_SIZE):
            batch = unique_session_ids[start:start + _CHANNEL_BINDING_QUERY_BATCH_SIZE]
            for binding in await service.list_bindings(session_ids=batch):
                if binding.session_id in channel_bindings:
                    continue
                try:
                    chat_type = ChatType(binding.chat_type)
                except (TypeError, ValueError):
                    log.warn("session.list.unknown_channel_chat_type", {
                        "session_id": binding.session_id,
                        "chat_type": str(binding.chat_type),
                    })
                    continue
                channel_bindings[binding.session_id] = _ChannelSessionBinding(
                    channel_id=binding.channel_id,
                    chat_id=binding.chat_id,
                    chat_type=chat_type,
                )
        return channel_bindings
    except Exception as exc:
        log.warn("session.list.channel_bindings_error", {"error": str(exc)})
        return {}


def _has_legacy_channel_title(
    session: SessionModel,
    binding: _ChannelSessionBinding,
) -> bool:
    """Return whether a stored title matches a legacy channel fallback."""
    prefix = f"[{binding.channel_id.capitalize()}]"
    if binding.chat_type == ChatType.DIRECT:
        direct_prefix = f"{prefix} DM — "
        title = session.title.strip()
        return (
            title.casefold().startswith(direct_prefix.casefold())
            and bool(title[len(direct_prefix):].strip())
        )
    else:
        expected = f"{prefix} {binding.chat_id}"
    return session.title.strip().casefold() == expected.casefold()


async def _first_user_channel_title(session_id: str) -> Optional[str]:
    """Read the first valid user-authored text stored for a channel session."""
    from flocks.channel.inbound.session_binding import extract_channel_title_text
    from flocks.session.message import Message

    messages = await Message.list(session_id, include_archived=True)
    for message in messages:
        if message.role != "user":
            continue
        with_parts = await Message.get_with_parts_lazy(session_id, message.id)
        if not with_parts:
            continue
        raw_text = "\n".join(
            part.text
            for part in with_parts.parts
            if part.type == "text"
            and not getattr(part, "synthetic", False)
            and getattr(part, "text", "")
        )
        title_text = extract_channel_title_text(raw_text)
        if title_text:
            return title_text
    return None


async def _legacy_channel_title_overrides(
    sessions: List[SessionModel],
    channel_bindings: Dict[str, _ChannelSessionBinding],
) -> Dict[str, str]:
    """Derive display titles for legacy fallback names without mutating storage."""
    from flocks.channel.inbound.session_binding import format_channel_title

    candidates = []
    for session in sessions:
        binding = channel_bindings.get(session.id)
        if binding and _has_legacy_channel_title(session, binding):
            candidates.append(session)

    async def resolve(session: SessionModel) -> tuple[str, Optional[str]]:
        try:
            title_text = await _first_user_channel_title(session.id)
            binding = channel_bindings[session.id]
            title = (
                format_channel_title(binding.channel_id, title_text)
                if title_text
                else None
            )
            return session.id, title
        except Exception as exc:
            log.warn("session.list.channel_title_override_error", {
                "session_id": session.id,
                "error": str(exc),
            })
            return session.id, None

    resolved = await asyncio.gather(*(resolve(session) for session in candidates))
    return {session_id: title for session_id, title in resolved if title is not None}


async def _session_to_response_with_goal(
    session: SessionModel,
    effective_project_id: Optional[str] = None,
    shared_project_ids: Optional[set[str]] = None,
) -> SessionResponse:
    """Convert SessionModel to SessionResponse and attach persisted goal state."""
    response = _session_to_response(session, effective_project_id, shared_project_ids)
    try:
        from flocks.session.goal import GoalManager

        goal_state = await GoalManager.get(session.id)
    except Exception as exc:
        log.warn("session.goal.response_error", {"sessionID": session.id, "error": str(exc)})
        goal_state = None

    if goal_state is not None:
        response.goal = SessionGoalResponse(
            status=goal_state.status,
            objective=goal_state.objective,
            reason=goal_state.last_reason or goal_state.paused_reason,
        )
    return response


def _require_session_read_access(session: SessionModel, user) -> None:
    if not SessionPolicy.can_read(session, user):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="仅会话所有者或受邀只读用户可访问会话")


def _require_session_write_access(session: SessionModel, user) -> None:
    if (session.metadata or {}).get("monitorScope"):
        raise HTTPException(status_code=409, detail="自动监测会话仅供查看，请在任务中心停用监测后管理历史")
    if not SessionPolicy.can_write(session, user):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="仅会话所有者可写，受邀用户为只读")
    if session.status != "active":
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="已归档会话不可修改，请先恢复")


async def _persist_active_session_write(
    session_id: str,
    operation,
    *,
    expected_generation: Optional[int] = None,
    expected_agent: Optional[str] = None,
):
    """Linearize a durable route write with archive/delete transitions."""
    try:
        return await Session.run_active_write(
            session_id,
            operation,
            expected_generation=expected_generation,
            expected_agent=expected_agent,
        )
    except SessionNotFoundError as exc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Session {session_id} not found",
        ) from exc
    except SessionInactiveError as exc:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="已归档会话不可修改，请先恢复",
        ) from exc
    except SessionAgentMismatchError as exc:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=str(exc),
        ) from exc


async def _require_agent_usable_for_chat(agent_name: Optional[str]) -> None:
    """Validate an explicitly requested chat agent.

    The Agent page "enabled" toggle is stored as ``delegatable`` for backward
    compatibility, but product semantics treat disabled subagents as unusable
    from both delegation and direct chat selection.
    """
    if not agent_name:
        return

    from flocks.agent.registry import Agent

    agent = await Agent.get(agent_name)
    if agent is None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f'Agent "{agent_name}" is not available',
        )

    tags = getattr(agent, "tags", None) or []
    if getattr(agent, "hidden", False) or "system" in tags:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f'Agent "{agent_name}" is not available for chat',
        )

    if getattr(agent, "mode", None) != "primary" and getattr(agent, "delegatable", True) is False:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f'Agent "{agent_name}" is disabled',
        )


async def _prepare_session_agent_before_bootstrap(
    session: SessionModel,
    requested_agent: Optional[str],
) -> tuple[SessionModel, str]:
    """Apply agent isolation before any project-scoped runtime is initialized."""
    from flocks.agent.registry import Agent
    from flocks.session.agent_policy import (
        AgentSessionPolicyError,
        prepare_session_for_agent,
    )

    await _require_agent_usable_for_chat(requested_agent)
    metadata = getattr(session, "metadata", None)
    policy = (
        metadata.get(DEDICATED_AGENT_POLICY_METADATA_KEY)
        if isinstance(metadata, dict)
        else None
    )
    claimed_agent = (
        policy.get("agent")
        if isinstance(policy, dict) and policy.get("version") == 1
        else None
    )
    stored_agent = getattr(session, "agent", None)
    if not requested_agent and not claimed_agent and not stored_agent:
        return session, DEFAULT_AGENT
    agent_name = (
        requested_agent
        or claimed_agent
        or stored_agent
        or await Agent.default_agent()
    )
    agent = await Agent.get(agent_name)
    if agent is None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f'Agent "{agent_name}" is not available',
        )
    try:
        prepared = await prepare_session_for_agent(session, agent)
    except AgentSessionPolicyError as exc:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=str(exc),
        ) from exc
    return prepared, agent_name


def _is_hidden_from_session_manager(session: SessionModel) -> bool:
    """Return whether a session should be excluded from manager listings."""
    metadata = session.metadata if isinstance(session.metadata, dict) else {}
    return bool(metadata.get("hideFromSessionManager"))


def _share_metadata(session: SessionModel, *, shared: bool, actor_user_id: str) -> Dict[str, Any]:
    metadata = dict(session.metadata) if isinstance(session.metadata, dict) else {}
    metadata["shared_local"] = shared
    if shared:
        metadata["shared_local_by"] = actor_user_id
        metadata["shared_local_at"] = int(time.time() * 1000)
    else:
        metadata.pop("shared_local_by", None)
        metadata.pop("shared_local_at", None)
    return metadata


async def _get_session_by_id_unfiltered(session_id: str) -> Optional[SessionModel]:
    """Fetch session by id while bypassing policy filtering."""
    return await Session.get_by_id_unfiltered(session_id)


def _working_directory_unavailable_reason(directory: Path) -> Optional[str]:
    """Why *directory* cannot be a session cwd, or ``None`` when it can.

    ``Path.is_dir()`` is not a safe predicate on Python 3.12: it only turns
    "not found" style errors into ``False``.  When the path exists but a parent
    directory denies search (x) permission, as happens after an install moves
    to another service account, ``stat()`` raises ``PermissionError``.  That
    means "unavailable", not a failed request.
    """

    try:
        if not directory.is_dir():
            return "missing"
    except OSError as exc:
        return exc.strerror or type(exc).__name__
    if not os.access(directory, os.R_OK | os.X_OK):
        return "unreadable"
    return None


async def _resolve_session_working_directory(session: SessionModel) -> str:
    """Keep a valid historical cwd, otherwise use the request context."""

    stored_unavailable_reason = "unset"
    if session.directory:
        directory = Path(session.directory).expanduser()
        stored_unavailable_reason = _working_directory_unavailable_reason(directory)
        if stored_unavailable_reason is None:
            return str(directory.resolve())

    from flocks.project.instance import Instance

    fallback_directory = Instance.get_directory() or os.getcwd()
    fallback_path = Path(fallback_directory).expanduser()
    if _working_directory_unavailable_reason(fallback_path) is not None:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="The session directory and current request directory are unavailable",
        )
    fallback_directory = str(fallback_path.resolve())

    log.warn(
        "session.directory.fallback",
        {
            "sessionID": session.id,
            "stored_directory": session.directory,
            "reason": stored_unavailable_reason,
            "fallback_directory": fallback_directory,
        },
    )
    try:
        from flocks.server.routes.event import publish_event

        await publish_event(
            "session.notice",
            {
                "sessionID": session.id,
                "kind": "directory-fallback",
                "storedDirectory": session.directory,
                "fallbackDirectory": fallback_directory,
            },
        )
    except Exception as exc:
        log.debug(
            "session.directory.fallback_notice_failed",
            {"sessionID": session.id, "error": str(exc)},
        )
    return fallback_directory


async def _publish_context_usage_update(
    event_publish_callback,
    session_id: str,
    *,
    session: Optional[SessionModel] = None,
    provider_id: Optional[str] = None,
    model_id: Optional[str] = None,
) -> None:
    """Best-effort SSE update for the composer context-usage meter."""
    if event_publish_callback is None:
        return
    try:
        if session is None:
            session = await _get_session_by_id_unfiltered(session_id)
        snapshot = await build_context_usage_snapshot(
            session_id,
            session=session,
            provider_id=provider_id,
            model_id=model_id,
        )
        await event_publish_callback(
            "context.usage.updated",
            snapshot.model_dump(by_alias=True),
        )
    except Exception as exc:
        log.debug("session.context_usage.publish_failed", {
            "sessionID": session_id,
            "error": str(exc),
        })


# =============================================================================
# Session CRUD Routes
# =============================================================================

@router.get(
    "/status",
    response_model=Dict[str, Any],
    summary="Get session status",
    description="Retrieve the current status of all sessions (idle, busy, retry)",
)
async def get_session_status(request: Request) -> Dict[str, Any]:
    """
    Get session status for all sessions the caller can read
    
    Returns a dictionary mapping session IDs to their status:
    - idle: Session is not processing
    - busy: Session is currently processing
    - retry: Session is retrying after an error
    
    Flocks compatible endpoint.
    """
    from flocks.session.core.status import SessionStatus
    from flocks.session.core.turn_state import get_turn_state, get_context_state
    
    from flocks.session.agent_inbox import AgentInbox

    current_user = require_user(request)
    statuses = dict(SessionStatus.list())
    # A session another process runs reads as busy here too.  Only a database
    # backend that shares sessions between processes names any.
    from flocks.coordination import sessions_running_elsewhere

    for session_id in await sessions_running_elsewhere():
        session_status = statuses.get(session_id)
        if session_status is None or session_status.type == "idle":
            statuses[session_id] = SessionStatusBusy()
    readable: Dict[str, bool] = {}

    async def can_read(session_id: str) -> bool:
        # The map must not show sessions (or their ancestry) that the caller
        # could not open one by one.
        if session_id not in readable:
            session = await _get_session_by_id_unfiltered(session_id)
            readable[session_id] = session is not None and SessionPolicy.can_read(session, current_user)
        return readable[session_id]

    result: Dict[str, Any] = {}
    for session_id, session_status in statuses.items():
        if not await can_read(session_id):
            continue
        result[session_id] = {
            **session_status.model_dump(),
            "ancestorSessionIDs": [
                ancestor_id
                for ancestor_id in AgentInbox.ancestors(session_id)
                if await can_read(ancestor_id)
            ],
            "turn": get_turn_state(session_id).model_dump(by_alias=True),
            "context": get_context_state(session_id).model_dump(by_alias=True),
        }
    return result


async def _build_session_runtime_status(session: SessionModel) -> SessionRuntimeStatusResponse:
    """Include a peer's shared execution lease in the runtime status."""
    from flocks.session.core.status import SessionStatus
    from flocks.session.interaction_queue import InteractionQueue
    from flocks.session.session_loop import SessionLoop

    queued_prompts = await InteractionQueue.list(session.id)
    runtime_status = SessionStatus.get_for_session(
        session.id,
        preferred_instance_id=session.directory,
    )

    # ``prompt_async`` marks its route-owned chain active before returning
    # 202, while SessionLoop sets ``busy`` only after the background task
    # starts. Treat that window (and inter-prompt queue hand-offs) as queued
    # so API clients never mistake accepted work for completion.
    if runtime_status.type == "idle":
        from flocks.session.ownership import is_owned
        if (
            Session.has_active_operations(session.id)
            or SessionLoop.is_running(session.id)
            or await is_owned(session.id)
        ):
            runtime_status = SessionStatusBusy()
        elif (
            _is_prompt_chain_active(session.id)
            or has_pending_session_tasks(session.id)
            or queued_prompts
        ):
            runtime_status = SessionStatusQueued()

    return SessionRuntimeStatusResponse(
        sessionID=session.id,
        webUrl=_session_web_url(session.id),
        lifecycleStatus=cast(Literal["active", "archived"], session.status),
        status=runtime_status,
        isProcessing=runtime_status.type != "idle",
        pendingPromptCount=len(queued_prompts),
        observedAt=int(time.time() * 1000),
    )


@router.get(
    "/{sessionID}/status",
    response_model=SessionRuntimeStatusResponse,
    summary="Get session runtime status",
    description="Get the current runtime status of a specific session",
    operation_id="session.statusById",
)
async def get_session_status_by_id(
    sessionID: str,
    request: Request,
    response: Response,
) -> SessionRuntimeStatusResponse:
    """Return an explicit runtime status, including idle, for one session."""
    response.headers["Cache-Control"] = "no-store"
    current_user = require_user(request)
    session = await _get_session_by_id_unfiltered(sessionID)
    if not session:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Session {sessionID} not found",
        )
    _require_session_read_access(session, current_user)
    return await _build_session_runtime_status(session)


@router.get(
    "/{sessionID}/turn/{turnID}",
    summary="Get how a turn stands",
    description="The receipt of a prompt or command sent with turnID: accepted, queued, running, done, failed, removed, or lost",
    operation_id="session.turnById",
)
async def get_session_turn(sessionID: str, turnID: str, request: Request, response: Response) -> Dict[str, Any]:
    """How a prompt or command the client sent stands, whichever worker runs it."""
    from flocks.session import turn_receipt

    response.headers["Cache-Control"] = "no-store"
    current_user = require_user(request)
    session = await _get_session_by_id_unfiltered(sessionID)
    if not session:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"Session {sessionID} not found")
    _require_session_read_access(session, current_user)
    receipt = await turn_receipt.get(sessionID, turnID)
    if receipt is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"Turn {turnID} not found")
    if turn_receipt.is_stale(receipt):
        receipt["state"] = turn_receipt.LOST
    return {"turnID": turnID, "sessionID": sessionID, **receipt}


def _eligible_session_list(
    sessions: List[SessionModel],
    current_user: AuthUser,
    visible_project_ids: set[str],
    shared_project_ids: set[str],
    *,
    session_status: str,
    directory: Optional[str] = None,
    project_id: Optional[str] = None,
    roots: Optional[bool] = None,
    start: Optional[int] = None,
    manager: Optional[bool] = None,
    category: Optional[str] = None,
) -> tuple[List[SessionModel], Dict[str, str]]:
    """Apply the common visibility and grouping rules before pagination."""
    from flocks.project.project import DEFAULT_PROJECT_ID, TASK_SESSION_GROUP_ID

    requested_group_id = TASK_SESSION_GROUP_ID if project_id == DEFAULT_PROJECT_ID else project_id
    manager_categories = {"user", "workflow", "entity-config"}
    eligible: List[SessionModel] = []
    effective_project_ids: Dict[str, str] = {}
    for session in sessions:
        if session.status == "archived":
            if current_user.role != "admin" and not SessionPolicy.is_owner(session, current_user):
                continue
        elif not SessionPolicy.can_read(session, current_user, shared_project_ids=shared_project_ids):
            continue
        if _is_hidden_from_session_manager(session):
            continue
        if session_status != "all" and session.status != session_status:
            continue
        if directory is not None and session.directory != directory:
            continue
        effective_project_id = (
            session.project_id if session.project_id in visible_project_ids else TASK_SESSION_GROUP_ID
        )
        if requested_group_id is not None and effective_project_id != requested_group_id:
            continue
        if (roots or manager) and session.parent_id:
            continue
        if start is not None and session.time.updated < start:
            continue
        if manager:
            if session.category not in manager_categories:
                continue
        elif category is not None:
            if session.category != category:
                continue
        elif session.category == "test":
            continue
        eligible.append(session)
        effective_project_ids[session.id] = effective_project_id
    return eligible, effective_project_ids


@router.get(
    "",
    response_model=List[Union[SessionResponse, SessionListItem]],
    summary="List sessions",
    description="Get a list of all sessions, sorted by most recently updated",
)
async def list_sessions(
    request: Request,
    view: Optional[Literal["list"]] = Query(None, description="Use lightweight list rows"),
    manager: Optional[bool] = Query(None, description="Apply session-manager visibility filters"),
    directory: Optional[str] = Query(None, description="Filter by project directory"),
    projectID: Optional[str] = Query(None, description="Filter by effective project ID"),
    roots: Optional[bool] = Query(None, description="Only return root sessions (no parentID)"),
    start: Optional[int] = Query(None, description="Filter sessions updated on or after this timestamp"),
    search: Optional[str] = Query(None, description="Filter by title (case-insensitive)"),
    limit: Optional[int] = Query(None, ge=1, description="Maximum sessions to return"),
    offset: Optional[int] = Query(None, ge=0, description="Number of filtered sessions to skip"),
    category: Optional[str] = Query(None, description="Filter by category: user or task"),
    session_status: Literal["active", "archived", "all"] = Query(
        "active",
        alias="status",
        description="Filter by session status",
    ),
) -> List[Union[SessionResponse, SessionListItem]]:
    """List all sessions with optional filters"""
    started_at = time.perf_counter()
    current_user = require_user(request)
    from flocks.project.project import Project
    list_started_at = time.perf_counter()
    all_sessions = await Session.list_all_unfiltered()
    if session_status == "archived":
        all_sessions.sort(
            key=lambda item: item.time.archived or item.time.updated,
            reverse=True,
        )
    list_elapsed_ms = (time.perf_counter() - list_started_at) * 1000
    visible_project_ids = Project.visible_project_ids(current_user.id)
    shared_project_ids = Project.shared_project_ids()
    
    eligible, eligible_project_ids = _eligible_session_list(
        all_sessions,
        current_user,
        visible_project_ids,
        shared_project_ids,
        session_status=session_status,
        directory=directory,
        project_id=projectID,
        roots=roots,
        start=start,
        manager=manager,
        category=category,
    )
    term = search.casefold() if search else None
    project_names = Project.registered_project_names() if view == "list" else {}

    channel_bindings: Dict[str, _ChannelSessionBinding] = {}
    channel_title_overrides: Dict[str, str] = {}
    if view == "list" and term is not None:
        # Search the same derived title that the lightweight list displays.
        channel_bindings = await _latest_channel_bindings([session.id for session in eligible])
        channel_title_overrides = await _legacy_channel_title_overrides(
            eligible,
            channel_bindings,
        )

    filtered = []
    effective_project_ids: Dict[str, str] = {}
    skip_remaining = offset or 0
    for session in eligible:
        searchable_title = channel_title_overrides.get(session.id, session.title)
        if term is not None and term not in searchable_title.casefold():
            continue
        if skip_remaining > 0:
            skip_remaining -= 1
            continue

        filtered.append(session)
        effective_project_ids[session.id] = eligible_project_ids[session.id]

        if limit is not None and len(filtered) >= limit:
            break

    if view == "list":
        if term is None:
            channel_bindings = await _latest_channel_bindings([session.id for session in filtered])
            channel_title_overrides = await _legacy_channel_title_overrides(
                filtered,
                channel_bindings,
            )
        response = [
            _session_to_list_item(
                s,
                effective_project_id=effective_project_ids[s.id],
                shared_project_ids=shared_project_ids,
                project_name=project_names.get(s.project_id),
                channel_binding=channel_bindings.get(s.id),
                title_override=channel_title_overrides.get(s.id),
            )
            for s in filtered
        ]
        log_route_timing(log, "session.list.light.complete", started_at=started_at, extra={
            "total": len(all_sessions),
            "count": len(response),
            "roots": roots,
            "manager": manager,
            "limit": limit,
            "offset": offset,
            "search": bool(search),
            "category": category,
            "status": session_status,
            "projectID": projectID,
            "list_ms": round(list_elapsed_ms, 2),
        })
        return response

    response = [
        await _session_to_response_with_goal(
            s,
            effective_project_ids[s.id],
            shared_project_ids,
        )
        for s in filtered
    ]
    log_route_timing(log, "session.list.complete", started_at=started_at, extra={
        "count": len(response),
        "roots": roots,
        "manager": manager,
        "limit": limit,
        "offset": offset,
        "search": bool(search),
        "category": category,
        "status": session_status,
        "projectID": projectID,
        "list_ms": round(list_elapsed_ms, 2),
    })
    return response


@router.post(
    "/list-grouped",
    response_model=SessionGroupedListResponse,
    summary="List session manager rows for multiple projects",
)
async def list_sessions_grouped(
    request: Request,
    payload: SessionGroupedListRequest,
) -> SessionGroupedListResponse:
    """Read once, then apply the manager list's pagination to each project."""
    current_user = require_user(request)
    if not payload.projects:
        return SessionGroupedListResponse(groups=[])

    from flocks.project.project import DEFAULT_PROJECT_ID, Project, TASK_SESSION_GROUP_ID

    started_at = time.perf_counter()
    list_started_at = time.perf_counter()
    all_sessions = await Session.list_all_unfiltered()
    list_elapsed_ms = (time.perf_counter() - list_started_at) * 1000
    visible_project_ids = Project.visible_project_ids(current_user.id)
    shared_project_ids = Project.shared_project_ids()
    project_names = Project.registered_project_names()
    eligible, effective_project_ids = _eligible_session_list(
        all_sessions,
        current_user,
        visible_project_ids,
        shared_project_ids,
        session_status="active",
        roots=True,
        manager=True,
    )

    def group_id(project_id: str) -> str:
        return TASK_SESSION_GROUP_ID if project_id == DEFAULT_PROJECT_ID else project_id

    requested_groups = {group_id(group.projectID) for group in payload.projects}
    candidates = [s for s in eligible if effective_project_ids[s.id] in requested_groups]
    term = payload.search.casefold() if payload.search else None
    channel_bindings: Dict[str, _ChannelSessionBinding] = {}
    title_overrides: Dict[str, str] = {}
    if term is not None:
        # Search the rendered title, including titles derived for old channel
        # sessions, exactly as the existing single-project list does.
        channel_bindings = await _latest_channel_bindings([s.id for s in candidates])
        title_overrides = await _legacy_channel_title_overrides(candidates, channel_bindings)

    by_project: Dict[str, List[SessionModel]] = {key: [] for key in requested_groups}
    for session in candidates:
        if term is not None and term not in title_overrides.get(session.id, session.title).casefold():
            continue
        by_project[effective_project_ids[session.id]].append(session)

    # Multiple requests may name the same group (including the default/tasks
    # alias) with different pagination; preserve the order and offsets.
    pages = [
        by_project[group_id(group.projectID)][group.offset:group.offset + group.limit]
        for group in payload.projects
    ]
    selected = {session.id: session for page in pages for session in page}
    if term is None:
        selected_sessions = list(selected.values())
        channel_bindings = await _latest_channel_bindings(list(selected))
        title_overrides = await _legacy_channel_title_overrides(selected_sessions, channel_bindings)

    rows = {
        session_id: _session_to_list_item(
            session,
            effective_project_id=effective_project_ids[session_id],
            shared_project_ids=shared_project_ids,
            project_name=project_names.get(session.project_id),
            channel_binding=channel_bindings.get(session_id),
            title_override=title_overrides.get(session_id),
        )
        for session_id, session in selected.items()
    }
    last_activity = {
        key: max((session.time.updated for session in sessions), default=None)
        for key, sessions in by_project.items()
    }
    result = SessionGroupedListResponse(groups=[
        SessionListGroup(
            projectID=group.projectID,
            items=[rows[s.id] for s in page],
            total=len(by_project[group_id(group.projectID)]),
            lastActivityAt=last_activity[group_id(group.projectID)],
        )
        for group, page in zip(payload.projects, pages)
    ])
    log_route_timing(log, "session.list.grouped.complete", started_at=started_at, extra={
        "total": len(all_sessions),
        "count": len(selected),
        "groups": len(payload.projects),
        "search": bool(payload.search),
        "list_ms": round(list_elapsed_ms, 2),
    })
    return result


async def _require_session_create_licence() -> None:
    """Ask the registered licence checker whether sessions may be created.

    A checker that withholds it answers the client with a 403 carrying a
    structured ``license_inactive`` detail, never a 500: a lapsed licence is
    a state the UI knows how to show, not a fault.
    """
    try:
        await assert_license_active(feature="session_create")
    except PermissionError as exc:
        try:
            current = await license_status()
        except Exception:  # noqa: BLE001 - a checker that cannot answer is reported as such
            current = {}
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "code": "license_inactive",
                "message": str(exc) or "licence is not active",
                "feature": "session_create",
                "license_status": current.get("status"),
                "inactive_reason": current.get("inactive_reason") or current.get("error"),
                "reapply_allowed": current.get("reapply_allowed"),
            },
        ) from exc


@router.post(
    "",
    response_model=SessionResponse,
    status_code=status.HTTP_200_OK,
    summary="Create session",
    description="Create a new session",
)
async def create_session(http_request: Request, request: Optional[SessionCreateRequest] = None) -> SessionResponse:
    """Create a new session"""
    current_user = require_user(http_request)
    await _require_session_create_licence()
    if request is None:
        request = SessionCreateRequest()
    if request.model_auto:
        category = request.category if request.category is not None else "user"
        if not is_model_auto_session_category(category):
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail=(
                    "Auto mode is only available for user, entity "
                    "configuration, and workflow sessions"
                ),
            )
        if current_user.id == API_TOKEN_SERVICE_USER_ID:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Auto mode can only be enabled from the WebUI",
            )
        from flocks.session.session_loop import SessionLoop

        auto_available, auto_reason = await SessionLoop.validate_auto_configuration()
        if not auto_available:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Auto mode is unavailable: {auto_reason}",
            )

    from flocks.project.instance import Instance
    from flocks.project.project import (
        DEFAULT_PROJECT_ID,
        Project,
        ProjectDeletionError,
        TASK_SESSION_GROUP_ID,
    )

    directory = Instance.get_directory() or os.getcwd()
    instance_project = Instance.get_project()
    project_id = instance_project.id if instance_project else DEFAULT_PROJECT_ID
    parent_session: Optional[SessionModel] = None

    # "default" is accepted for compatibility with older WebUI clients, but
    # ordinary sessions use the current request context rather than a virtual
    # project's worktree.
    if request.projectID and request.projectID not in {
        DEFAULT_PROJECT_ID,
        TASK_SESSION_GROUP_ID,
    }:
        project = await Project.get(request.projectID, owner_id=current_user.id)
        if not project:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Project {request.projectID} not found",
            )
        if project.path_status != "available":
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail=f"Project directory is {project.path_status}",
            )
        project_id = project.id
        directory = project.worktree

    if request.parentID:
        parent_session = await _get_session_by_id_unfiltered(request.parentID)
        if parent_session is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Parent session {request.parentID} not found",
            )
        _require_session_write_access(parent_session, current_user)
        if request.projectID and request.projectID not in {
            DEFAULT_PROJECT_ID,
            TASK_SESSION_GROUP_ID,
            parent_session.project_id,
        }:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="Parent and child sessions must belong to the same project",
            )
        project_id = parent_session.project_id
        directory = parent_session.directory
    
    # Trigger command:new hook if creating from parent (like /new command)
    if request.parentID:
        try:
            from flocks.hooks import trigger_hook, create_command_event
            from flocks.config import Config
            
            config = await Config.get()
            
            # Create hook event for the parent session
            event = create_command_event(
                action="new",
                session_id=request.parentID,
                context={
                    "previous_session_id": request.parentID,
                    "project_id": project_id,
                    "workspace_dir": directory,
                },
            )
            
            # Trigger hook (non-blocking, errors are caught)
            await trigger_hook(event)
            
        except Exception as e:
            # Hook failure should not block session creation
            log.warn("session.create.hook_failed", {
                "error": str(e),
                "parent_id": request.parentID,
            })
    
    # Convert permission rules
    permission = None
    if request.permission:
        from flocks.session.session import PermissionRule as SessionPermRule
        permission = [
            SessionPermRule(
                permission=p.permission,
                action=p.action,
                pattern=p.pattern,
            )
            for p in request.permission
        ]

    from flocks.session.execution_profile import PROFILE_METADATA_KEY

    session_execution_profile = {
        "entry": "webui",
        "source": "webui.session.create",
    }

    if request.projectID and request.projectID not in {
        DEFAULT_PROJECT_ID,
        TASK_SESSION_GROUP_ID,
    }:
        project = await Project.get(request.projectID, owner_id=current_user.id)
        if project is None:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail=f"Project {request.projectID} is no longer available",
            )
    try:
        session = await Session.create(
            project_id=project_id,
            directory=directory,
            title=request.title,
            parent_id=request.parentID,
            permission=permission,
            owner_user_id=(parent_session.owner_user_id if parent_session else current_user.id),
            owner_username=(parent_session.owner_username if parent_session else current_user.username),
            model_auto=request.model_auto,
            model_pinned=False,
            metadata={PROFILE_METADATA_KEY: session_execution_profile},
            **({"category": request.category} if request.category else {}),
        )
    except ProjectDeletionError as exc:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=str(exc),
        ) from exc
    Project.invalidate_session_stats()
    log.info("session.created", {"session_id": session.id})
    try:
        await emit_audit_event(
            "session_action",
            {
                "action": "create",
                "actor_id": current_user.username,
                "actor_name": current_user.username,
                "user_name": current_user.username,
                "username": current_user.username,
                "session_id": session.id,
                "owner_user_id": session.owner_user_id,
                "project_id": session.project_id,
            },
        )
    except Exception:
        pass
    return await _session_to_response_with_goal(session)




# =============================================================================
# Monitoring & Metrics Routes
# =============================================================================
# NOTE: the literal ``/metrics`` and ``/recent`` paths must be declared before
# ``/{sessionID}`` (below) or the path parameter route shadows them.

@router.get("/metrics")
async def get_metrics(request: Request):
    """
    Get system-wide monitoring metrics
    
    Returns metrics including:
    - Tool call parsing success/failure rates
    - Repair strategy success rates
    - Top failing tools
    - Recent failure details
    """
    current_user = require_user(request)
    if current_user.role != "admin":
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="仅管理员可执行该操作")
    monitor = get_monitor()
    metrics = monitor.get_metrics()
    
    return {
        "status": "success",
        "metrics": metrics,
    }


@router.get("/recent")
async def get_recent_sessions(
    request: Request,
    limit: int = Query(10, ge=1, le=50, description="Number of sessions"),
):
    """
    Get recent sessions

    Returns the most recently updated sessions the caller may read, with the
    same visibility rules as ``GET /session``.
    """
    # Every parameter is passed explicitly: called as a plain function, the
    # omitted ones would arrive as FastAPI ``Query`` objects, not None.
    return await list_sessions(
        request,
        view=None,
        manager=None,
        directory=None,
        projectID=None,
        roots=None,
        start=None,
        search=None,
        limit=limit,
        offset=None,
        category=None,
        session_status="active",
    )


@router.get("/{sessionID}/metrics")
async def get_session_metrics(sessionID: str, request: Request):
    """
    Get metrics for a specific session
    
    Returns session-specific metrics including:
    - Tool call counts and success rates
    - Failed tool calls
    - Repair attempts
    """
    current_user = require_user(request)
    session = await _get_session_by_id_unfiltered(sessionID)
    if not session:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Session {sessionID} not found",
        )
    _require_session_read_access(session, current_user)
    monitor = get_monitor()
    session_metrics = monitor.get_session_metrics(sessionID)
    
    if session_metrics is None:
        return {
            "status": "success",
            "sessionID": sessionID,
            "metrics": None,
            "message": "No metrics available for this session"
        }
    
    return {
        "status": "success",
        "sessionID": sessionID,
        "metrics": session_metrics,
    }


@router.get("/{sessionID}/statistics")
async def get_session_statistics(sessionID: str, request: Request):
    """
    Get session statistics
    
    Returns detailed statistics including:
    - Message count
    - Token count
    - Tool calls
    - Session duration
    - Model usage
    """
    current_user = require_user(request)
    try:
        session = await _get_session_by_id_unfiltered(sessionID)
        if not session:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Session {sessionID} not found",
            )
        _require_session_read_access(session, current_user)

        from flocks.session.message import Message

        messages = await Message.list_with_parts(sessionID, include_archived=True)
        
        # Calculate statistics
        message_count = len(messages)
        token_count = 0
        tool_call_count = 0
        model_usage = {}
        
        for message_with_parts in messages:
            msg = message_with_parts.info

            # Count tokens (approximate from parts)
            for part in message_with_parts.parts:
                if hasattr(part, "text") and part.text:
                    token_count += len(part.text.split())  # Rough approximation
                
                # Count tool calls
                if getattr(part, "type", None) == "tool":
                    tool_call_count += 1
            
            # Track model usage
            model = getattr(msg, "model", None)
            if model:
                model_key = model if isinstance(model, str) else json.dumps(model, sort_keys=True, default=str)
                model_usage[model_key] = model_usage.get(model_key, 0) + 1
        
        # Calculate duration
        created_ms = session.time.created
        updated_ms = session.time.updated
        duration_ms = updated_ms - created_ms
        duration_seconds = duration_ms / 1000
        
        stats = {
            "sessionID": sessionID,
            "messageCount": message_count,
            "tokenCount": token_count,
            "toolCallCount": tool_call_count,
            "modelUsage": model_usage,
            "durationSeconds": duration_seconds,
            "createdAt": created_ms,
            "updatedAt": updated_ms,
        }
        
        log.info("session.statistics", {"sessionID": sessionID, "messages": message_count})
        return stats
    except HTTPException:
        raise
    except Exception as e:
        log.error("session.statistics.error", {"sessionID": sessionID, "error": str(e)})
        raise HTTPException(status_code=500, detail=f"Failed to get session statistics: {str(e)}")


@router.get(
    "/{sessionID}",
    response_model=SessionDetailResponse,
    summary="Get session",
    description="Get session by ID",
)
async def get_session(sessionID: str, request: Request) -> SessionDetailResponse:
    """Get session by ID"""
    _current_user = require_user(request)
    session = await _get_session_by_id_unfiltered(sessionID)
    
    if not session:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Session {sessionID} not found"
        )
    _require_session_read_access(session, _current_user)
    if session.status != "active":
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Session {sessionID} not found",
        )
    response = await _session_to_response_with_goal(session)
    return SessionDetailResponse(**response.model_dump(), webUrl=_session_web_url(session.id))


@router.get(
    "/{sessionID}/context-usage",
    response_model=ContextUsageSnapshot,
    summary="Get session context usage",
    description="Get the current context usage snapshot for the composer meter",
)
async def get_session_context_usage(sessionID: str, request: Request) -> ContextUsageSnapshot:
    """Return current prompt/context usage for a session."""
    started_at = time.perf_counter()
    current_user = require_user(request)
    session = await _get_session_by_id_unfiltered(sessionID)
    if not session:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Session {sessionID} not found",
        )
    _require_session_read_access(session, current_user)
    snapshot = await _cached_context_usage_snapshot(sessionID, session=session)
    log_route_timing(log, "session.context_usage.complete", started_at=started_at, extra={
        "sessionID": sessionID,
        "source": snapshot.source,
        "used_tokens": snapshot.used_tokens,
        "segments": len(snapshot.segments),
    })
    return snapshot


@router.get(
    "/{sessionID}/children",
    response_model=List[SessionResponse],
    summary="Get session children",
    description="Get all child sessions forked from the specified parent",
)
async def get_session_children(sessionID: str, request: Request) -> List[SessionResponse]:
    """Get child sessions"""
    current_user = require_user(request)
    session = await _get_session_by_id_unfiltered(sessionID)
    if not session:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Session {sessionID} not found"
        )
    _require_session_read_access(session, current_user)
    children = await Session.children(session.project_id, sessionID)
    return [await _session_to_response_with_goal(s) for s in children if SessionPolicy.can_read(s, current_user)]


class TodoInfo(BaseModel):
    """Todo item info for API compatibility"""
    model_config = ConfigDict(populate_by_name=True)
    
    id: str = Field(..., description="Todo ID")
    content: str = Field(..., description="Task description")
    activeForm: Optional[str] = Field(None, description="Active/progressive task description")
    status: Literal["pending", "in_progress", "completed", "cancelled"] = Field(
        ..., description="Status: pending, in_progress, completed, cancelled"
    )
    priority: str = Field("medium", description="Priority: high, medium, low")


@router.get(
    "/{sessionID}/todo",
    response_model=List[TodoInfo],
    summary="Get session todos",
    description="Get the todo list for a session",
)
async def get_session_todos(sessionID: str, request: Request) -> List[TodoInfo]:
    """Get session todos"""
    from flocks.session.features.todo import Todo
    _current_user = require_user(request)
    session = await _get_session_by_id_unfiltered(sessionID)
    if not session:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Session {sessionID} not found"
        )
    _require_session_read_access(session, _current_user)
    try:
        todos = await Todo.get(sessionID)
        return [TodoInfo(**todo.model_dump(exclude_none=True)) for todo in todos]
    except Exception as e:
        log.warn("session.todo.read_error", {"sessionID": sessionID, "error": str(e)})
        return []


@router.post(
    "/{sessionID}/todo",
    response_model=List[TodoInfo],
    summary="Update session todos",
    description="Update the todo list for a session",
)
async def update_session_todos(sessionID: str, todos: List[TodoInfo], request: Request) -> List[TodoInfo]:
    """Update session todos"""
    from flocks.session.features.todo import Todo, TodoInfo as SessionTodoInfo
    _current_user = require_user(request)
    session = await _get_session_by_id_unfiltered(sessionID)
    if not session:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Session {sessionID} not found"
        )
    _require_session_write_access(session, _current_user)
    lifecycle_generation = Session.lifecycle_generation(sessionID)
    try:
        normalized_todos = [
            SessionTodoInfo(**todo.model_dump(exclude_none=True))
            for todo in todos
        ]
        await _persist_active_session_write(
            sessionID,
            lambda: Todo.update(sessionID, normalized_todos),
            expected_generation=lifecycle_generation,
        )
        return todos
    except HTTPException:
        raise
    except Exception as e:
        log.error("session.todo.write_error", {"sessionID": sessionID, "error": str(e)})
        raise HTTPException(status_code=500, detail=str(e))


class ContextFolderCreateRequest(BaseModel):
    """Add one read-only folder to the Session Context UI."""

    path: str
    display_name: Optional[str] = Field(None, alias="displayName")


async def _load_context_session(session_id: str, request: Request, *, write: bool = False):
    current_user = require_user(request)
    session = await _get_session_by_id_unfiltered(session_id)
    if not session:
        raise HTTPException(status_code=404, detail=f"Session {session_id} not found")
    if write:
        _require_session_write_access(session, current_user)
    else:
        _require_session_read_access(session, current_user)
    return session, current_user


def _require_context_root_owner(session, current_user: AuthUser) -> None:
    if not SessionPolicy.is_owner(session, current_user):
        raise HTTPException(status_code=403, detail="Context folders are only available to the Session owner")


@router.get("/{sessionID}/context", summary="Get Session Context")
async def get_session_context(
    sessionID: str,
    request: Request,
    before: Optional[str] = Query(None),
    limit: int = Query(100, ge=1, le=200),
):
    from flocks.session.files import build_session_context

    session, current_user = await _load_context_session(sessionID, request)
    try:
        return await build_session_context(
            session,
            include_roots=SessionPolicy.is_owner(session, current_user),
            before=before,
            limit=limit,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


async def _resolve_context_file(sessionID: str, resourceID: str, request: Request):
    from flocks.session.files import resolve_session_resource
    from flocks.utils.http_file_read_guard import require_http_private_path_access

    session, _current_user = await _load_context_session(sessionID, request)
    try:
        resource = await resolve_session_resource(session, resourceID)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except PermissionError as exc:
        raise HTTPException(status_code=403, detail=str(exc)) from None
    require_http_private_path_access(resource.path)
    if not resource.path.exists() or not resource.path.is_file():
        raise HTTPException(status_code=404, detail="Session file no longer exists")
    return resource


@router.get("/{sessionID}/context/files/{resourceID}/metadata", summary="Get Session Context file metadata")
async def get_session_context_file(sessionID: str, resourceID: str, request: Request):
    from flocks.session.files import session_resource_metadata

    resource = await _resolve_context_file(sessionID, resourceID, request)
    return session_resource_metadata(resource)


@router.get("/{sessionID}/context/files/{resourceID}/content", summary="Read Session Context text file")
async def read_session_context_file(sessionID: str, resourceID: str, request: Request):
    from flocks.server.routes.workspace import _max_read_bytes, _read_text_preview_sync
    from flocks.workspace.manager import WorkspaceManager

    resource = await _resolve_context_file(sessionID, resourceID, request)
    if not WorkspaceManager.is_text_file(resource.path):
        raise HTTPException(status_code=415, detail="File type is not supported for text preview")
    max_bytes = _max_read_bytes()
    content, truncated = await asyncio.to_thread(
        _read_text_preview_sync,
        resource.path,
        max_bytes,
    )
    return {
        "resourceID": resource.resource_id,
        "content": content,
        "truncated": truncated,
        "size": resource.path.stat().st_size,
        "previewLimitBytes": max_bytes,
    }


@router.get("/{sessionID}/context/files/{resourceID}/preview", summary="Preview Session Context file")
async def preview_session_context_file(sessionID: str, resourceID: str, request: Request):
    from flocks.server.routes.workspace import _inline_preview_response

    resource = await _resolve_context_file(sessionID, resourceID, request)
    return _inline_preview_response(resource.path)


@router.get("/{sessionID}/context/files/{resourceID}/download", summary="Download Session Context file")
async def download_session_context_file(sessionID: str, resourceID: str, request: Request):
    from flocks.server.routes.workspace import _download_response

    resource = await _resolve_context_file(sessionID, resourceID, request)
    return _download_response(resource.path, filename=resource.filename)


@router.post("/{sessionID}/context/folders", summary="Add Session Context folder")
async def add_session_context_folder(
    sessionID: str,
    payload: ContextFolderCreateRequest,
    request: Request,
):
    from flocks.server.routes.event import publish_event
    from flocks.session.files import (
        context_folder_entries_from_metadata,
        validate_context_folder,
    )
    from flocks.utils.id import Identifier

    session, current_user = await _load_context_session(sessionID, request, write=True)
    _require_context_root_owner(session, current_user)
    try:
        normalized_path = validate_context_folder(payload.path)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    added_entry = {
        "id": Identifier.ascending("part"),
        "path": normalized_path,
        "displayName": payload.display_name or Path(normalized_path).name or normalized_path,
        "createdAt": int(time.time() * 1000),
    }
    result_entry: dict[str, Any] = added_entry

    def add_folder(metadata: Dict[str, Any]) -> Dict[str, Any]:
        nonlocal result_entry
        entries = context_folder_entries_from_metadata(metadata)
        existing = next((item for item in entries if item["path"] == normalized_path), None)
        if existing is not None:
            result_entry = existing
        else:
            entries.append(added_entry)
        metadata["contextFolders"] = entries
        return metadata

    updated = await Session.mutate_metadata(
        session.project_id,
        session.id,
        add_folder,
    )
    if updated is None:
        raise HTTPException(status_code=404, detail=f"Session {sessionID} not found")
    await publish_event("session.context.updated", {"sessionID": sessionID})
    return {
        "id": result_entry["id"],
        "kind": "folder",
        "displayName": result_entry["displayName"],
        "status": "available",
    }


@router.delete("/{sessionID}/context/folders/{rootID}", summary="Remove Session Context folder")
async def remove_session_context_folder(sessionID: str, rootID: str, request: Request):
    from flocks.server.routes.event import publish_event
    from flocks.session.files import context_folder_entries_from_metadata

    session, current_user = await _load_context_session(sessionID, request, write=True)
    _require_context_root_owner(session, current_user)

    def remove_folder(metadata: Dict[str, Any]) -> Dict[str, Any]:
        entries = context_folder_entries_from_metadata(metadata)
        next_entries = [item for item in entries if item["id"] != rootID]
        if len(next_entries) == len(entries):
            raise KeyError(rootID)
        metadata["contextFolders"] = next_entries
        return metadata

    try:
        updated = await Session.mutate_metadata(
            session.project_id,
            session.id,
            remove_folder,
        )
    except KeyError as exc:
        raise HTTPException(status_code=404, detail="Context folder not found") from exc
    if updated is None:
        raise HTTPException(status_code=404, detail=f"Session {sessionID} not found")
    await publish_event("session.context.updated", {"sessionID": sessionID})
    return {"removed": True, "id": rootID}


async def _resolve_context_root_file(
    sessionID: str,
    rootID: str,
    relative_path: str,
    request: Request,
):
    from flocks.session.files import resolve_context_root_path
    from flocks.utils.http_file_read_guard import require_http_private_path_access

    session, current_user = await _load_context_session(sessionID, request)
    _require_context_root_owner(session, current_user)
    try:
        target = resolve_context_root_path(session, rootID, relative_path)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    require_http_private_path_access(target)
    if not target.exists():
        raise HTTPException(status_code=404, detail="Context path not found")
    return target


@router.get("/{sessionID}/context/roots/{rootID}/list", summary="List Session Context folder")
async def list_session_context_folder(
    sessionID: str,
    rootID: str,
    request: Request,
    path: str = Query(""),
    offset: int = Query(0, ge=0),
    limit: int = Query(100, ge=1, le=200),
):
    from flocks.session.files import list_context_root

    session, current_user = await _load_context_session(sessionID, request)
    _require_context_root_owner(session, current_user)
    try:
        page = await asyncio.to_thread(
            list_context_root, session, rootID, path, offset=offset, limit=limit,
        )
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except PermissionError as exc:
        raise HTTPException(status_code=403, detail=str(exc)) from None
    return {"rootID": rootID, "path": path, **page}


@router.get("/{sessionID}/context/roots/{rootID}/content", summary="Read Session Context folder text file")
async def read_session_context_root_file(
    sessionID: str,
    rootID: str,
    request: Request,
    path: str = Query(...),
):
    from flocks.server.routes.workspace import _max_read_bytes, _read_text_preview_sync
    from flocks.workspace.manager import WorkspaceManager

    target = await _resolve_context_root_file(sessionID, rootID, path, request)
    if not target.is_file() or not WorkspaceManager.is_text_file(target):
        raise HTTPException(status_code=415, detail="File type is not supported for text preview")
    max_bytes = _max_read_bytes()
    content, truncated = await asyncio.to_thread(_read_text_preview_sync, target, max_bytes)
    return {
        "path": path,
        "content": content,
        "truncated": truncated,
        "size": target.stat().st_size,
        "previewLimitBytes": max_bytes,
    }


@router.get("/{sessionID}/context/roots/{rootID}/preview", summary="Preview Session Context folder file")
async def preview_session_context_root_file(
    sessionID: str,
    rootID: str,
    request: Request,
    path: str = Query(...),
):
    from flocks.server.routes.workspace import _inline_preview_response

    target = await _resolve_context_root_file(sessionID, rootID, path, request)
    if not target.is_file():
        raise HTTPException(status_code=400, detail="Context path is not a file")
    return _inline_preview_response(target)


@router.get("/{sessionID}/context/roots/{rootID}/download", summary="Download Session Context folder file")
async def download_session_context_root_file(
    sessionID: str,
    rootID: str,
    request: Request,
    path: str = Query(...),
):
    from flocks.server.routes.workspace import _download_response

    target = await _resolve_context_root_file(sessionID, rootID, path, request)
    if not target.is_file():
        raise HTTPException(status_code=400, detail="Context path is not a file")
    return _download_response(target)


@router.post(
    "/{sessionID}/archive",
    response_model=SessionResponse,
    summary="Archive session",
    description="Archive a session and its descendants without deleting persisted data",
)
async def archive_session(sessionID: str, request: Request) -> SessionResponse:
    current_user = require_user(request)
    return await archive_session_for_user(sessionID, current_user)


@router.post(
    "/{sessionID}/restore",
    response_model=SessionResponse,
    summary="Restore session",
    description="Restore an archived session and its descendants",
)
async def restore_session(sessionID: str, request: Request) -> SessionResponse:
    current_user = require_user(request)
    return await restore_session_for_user(sessionID, current_user)


async def _manageable_session_tree(session: SessionModel, current_user: AuthUser) -> List[SessionModel]:
    tree = await Session.collect_tree(session.project_id, session.id)
    if any(not SessionPolicy.can_delete(item, current_user) for item in tree):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="仅会话所有者可管理归档会话")
    return tree


async def archive_session_for_user(session_id: str, current_user: AuthUser) -> SessionResponse:
    """Stop and archive a complete session tree while retaining persisted data."""
    session = await _get_session_by_id_unfiltered(session_id)
    if not session:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"Session {session_id} not found")

    tree = await _manageable_session_tree(session, current_user)

    auth_token = set_current_auth_user(current_user)
    try:
        try:
            archived_ok = await Session.archive(session.project_id, session.id)
        except RuntimeError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc
    finally:
        reset_current_auth_user(auth_token)
    if not archived_ok:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="会话归档失败")

    from flocks.server.routes.event import publish_event

    try:
        await publish_event("session.updated", {"id": session_id, "status": "archived"})
    except Exception as exc:
        log.warn("session.archive.event_error", {"session_id": session_id, "error": str(exc)})
    try:
        await emit_audit_event("session_action", {
            "action": "archive",
            "actor_id": current_user.username,
            "actor_name": current_user.username,
            "user_name": current_user.username,
            "username": current_user.username,
            "session_id": session_id,
            "owner_user_id": current_user.id,
            "project_id": session.project_id,
            "affected_sessions": len(tree),
        })
    except Exception:
        pass

    archived = await _get_session_by_id_unfiltered(session_id)
    if archived is None:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="会话归档状态不可用")
    return await _session_to_response_with_goal(archived)


async def restore_session_for_user(session_id: str, current_user: AuthUser) -> SessionResponse:
    """Restore a complete archived session tree."""
    session = await _get_session_by_id_unfiltered(session_id)
    if not session:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"Session {session_id} not found")

    tree = await _manageable_session_tree(session, current_user)
    if session.parent_id is not None:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="只能从根任务恢复完整任务树",
        )
    project_owner_id = session.owner_user_id or current_user.id
    auth_token = set_current_auth_user(current_user)
    try:
        try:
            restored_ok = await Session.restore(
                session.project_id,
                session.id,
                project_owner_id=project_owner_id,
            )
        except ValueError as exc:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail=str(exc),
            ) from exc
    finally:
        reset_current_auth_user(auth_token)
    if not restored_ok:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="会话恢复失败")

    from flocks.server.routes.event import publish_event

    try:
        await publish_event("session.updated", {"id": session_id, "status": "active"})
    except Exception as exc:
        log.warn("session.restore.event_error", {"session_id": session_id, "error": str(exc)})
    try:
        await emit_audit_event("session_action", {
            "action": "restore",
            "actor_id": current_user.username,
            "actor_name": current_user.username,
            "user_name": current_user.username,
            "username": current_user.username,
            "session_id": session_id,
            "owner_user_id": current_user.id,
            "project_id": session.project_id,
            "affected_sessions": len(tree),
        })
    except Exception:
        pass

    restored = await _get_session_by_id_unfiltered(session_id)
    if restored is None:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="会话恢复状态不可用")
    return await _session_to_response_with_goal(restored)


@router.delete(
    "/{sessionID}",
    status_code=status.HTTP_200_OK,
    summary="Permanently delete session",
    description="Permanently delete a session tree and its persisted history",
)
async def delete_session(sessionID: str, request: Request) -> bool:
    """Permanently delete a session by ID (returns true)."""
    current_user = require_user(request)
    return await delete_session_for_user(sessionID, current_user)


async def delete_session_for_user(session_id: str, current_user: AuthUser) -> bool:
    """Permanently delete a session tree using the normal lifecycle cleanup."""
    session = await _get_session_by_id_unfiltered(session_id)
    
    if not session:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Session {session_id} not found"
        )
    
    tree = await _manageable_session_tree(session, current_user)
    tree_ids = [item.id for item in tree]

    auth_token = set_current_auth_user(current_user)
    try:
        try:
            deleted_ok = await Session.delete(session.project_id, session_id)
        except RuntimeError as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc
    finally:
        reset_current_auth_user(auth_token)
    if not deleted_ok:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="会话永久删除失败")
    log.info("session.deleted", {"session_id": session_id})
    try:
        await emit_audit_event(
            "session_action",
            {
                "action": "permanent_delete",
                "actor_id": current_user.username,
                "actor_name": current_user.username,
                "user_name": current_user.username,
                "username": current_user.username,
                "session_id": session_id,
                "owner_user_id": current_user.id,
                "project_id": session.project_id,
                "affected_sessions": len(tree_ids),
            },
        )
    except Exception:
        pass
    return True


class SessionUpdateRequest(BaseModel):
    """Request to update session"""
    model_config = ConfigDict(populate_by_name=True)
    
    title: Optional[str] = Field(
        None,
        min_length=1,
        max_length=SESSION_TITLE_MAX_LENGTH,
        description="New title",
    )
    time: Optional[Dict[str, Any]] = Field(None, description="Time updates (archived)")
    provider: Optional[str] = Field(None, description="Pinned provider ID")
    model: Optional[str] = Field(None, description="Pinned model ID")
    model_pinned: Optional[bool] = Field(None, description="Whether provider/model are pinned for this session")
    model_auto: Optional[bool] = Field(None, description="Whether WebUI Auto mode is selected")


class SessionMoveProjectRequest(BaseModel):
    """Request to move a complete task tree to a project."""

    model_config = ConfigDict(populate_by_name=True)

    project_id: str = Field(..., alias="projectID", description="Target project ID")


@router.patch(
    "/{sessionID}",
    response_model=SessionResponse,
    summary="Update session",
    description="Update session properties",
)
async def update_session(
    sessionID: str,
    request: SessionUpdateRequest,
    http_request: Request,
) -> SessionResponse:
    """Update session"""
    existing = await _get_session_by_id_unfiltered(sessionID)
    
    if not existing:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Session {sessionID} not found"
        )
    current_user = require_user(http_request)
    _require_session_write_access(existing, current_user)

    if request.model_auto is True and (
        request.provider is not None
        or request.model is not None
        or request.model_pinned is True
    ):
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="Auto mode cannot be combined with a pinned provider/model",
        )
    if request.model_auto is True:
        if not is_model_auto_session_category(existing.category):
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail=(
                    "Auto mode is only available for user, entity "
                    "configuration, and workflow sessions"
                ),
            )
        if current_user.id == API_TOKEN_SERVICE_USER_ID:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Auto mode can only be enabled from the WebUI",
            )
        from flocks.session.session_loop import SessionLoop

        auto_available, auto_reason = await SessionLoop.validate_auto_configuration()
        if not auto_available:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Auto mode is unavailable: {auto_reason}",
            )
    if (request.provider is None) != (request.model is None):
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="provider and model must be updated together",
        )

    updates = {}
    if request.title is not None:
        updates["title"] = request.title
    if request.time and request.time.get("archived") is not None:
        updates["archived"] = request.time["archived"]
    if request.provider is not None:
        updates["provider"] = request.provider
    if request.model is not None:
        updates["model"] = request.model
    if request.model_pinned is not None:
        updates["model_pinned"] = request.model_pinned
        if request.model_pinned:
            updates["model_auto"] = False
    if request.model_auto is not None:
        updates["model_auto"] = request.model_auto
        if request.model_auto:
            updates["model_pinned"] = False
    if request.provider is not None and request.model is not None:
        updates["model_auto"] = False
        updates["model_pinned"] = True
    
    session = await Session.update(
        project_id=existing.project_id,
        session_id=sessionID,
        **updates,
    )
    
    if not session:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Session {sessionID} not found"
        )

    if (
        request.model_auto is False
        or request.model_pinned is True
        or (request.provider is not None and request.model is not None)
    ):
        from flocks.session.session_loop import SessionLoop

        SessionLoop.clear_auto_failover_state(sessionID)
    
    log.info("session.updated", {"session_id": sessionID})
    # 重命名/改模型也要让 TUI、其它标签页通过 SSE 看到（publish_event 会补全 info）
    try:
        from flocks.server.routes.event import publish_event

        await publish_event("session.updated", {"id": sessionID, "status": session.status})
    except Exception as exc:
        log.warn("session.update.event_error", {"session_id": sessionID, "error": str(exc)})
    return await _session_to_response_with_goal(session)


@router.patch(
    "/{sessionID}/project",
    response_model=SessionResponse,
    summary="Move session to project",
    description="Move a root session and all descendants to another project",
)
async def move_session_to_project(
    sessionID: str,
    request: SessionMoveProjectRequest,
    http_request: Request,
) -> SessionResponse:
    """Move an idle root task tree into a writable project."""

    existing = await _get_session_by_id_unfiltered(sessionID)
    if existing is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Session {sessionID} not found",
        )

    current_user = require_user(http_request)
    _require_session_write_access(existing, current_user)
    if existing.parent_id is not None:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="只能移动根任务及其完整任务树",
        )

    from flocks.project.project import Project

    target_project = await Project.get(request.project_id, owner_id=current_user.id)
    if target_project is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Project {request.project_id} not found",
        )
    if target_project.path_status != "available":
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="目标项目目录不可用",
        )
    if existing.project_id == target_project.id:
        return await _session_to_response_with_goal(existing)

    tree = await Session.collect_tree(existing.project_id, existing.id)
    if any(not SessionPolicy.can_write(item, current_user) for item in tree):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="仅任务所有者可移动完整任务树",
        )

    if any(_is_session_busy_for_move(item.id) for item in tree):
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="任务正在运行，请等待任务完成或停止后再移动",
        )
    if any(item.revert is not None for item in tree):
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="任务正在历史恢复状态，请先完成或取消恢复后再移动",
        )

    auth_token = set_current_auth_user(current_user)
    try:
        moved = await Session.move_to_project(
            existing.project_id,
            existing.id,
            target_project_id=target_project.id,
            target_directory=target_project.worktree,
            target_owner_id=current_user.id,
            additional_busy_check=_is_session_busy_for_move,
        )
    finally:
        reset_current_auth_user(auth_token)
    if moved is None:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="任务移动失败，请刷新后重试",
        )

    from flocks.server.routes.event import publish_event

    try:
        await publish_event("session.updated", {
            "id": sessionID,
            "projectID": target_project.id,
        })
    except Exception as exc:
        log.warn("session.move_project.event_error", {
            "session_id": sessionID,
            "error": str(exc),
        })

    return await _session_to_response_with_goal(
        moved,
        effective_project_id=target_project.id,
    )


@router.post(
    "/{sessionID}/share-local",
    response_model=SessionResponse,
    summary="Share session locally",
    description="Share this session to all local accounts as read-only",
)
async def share_session_local(sessionID: str, http_request: Request) -> SessionResponse:
    current_user = require_user(http_request)
    existing = await _get_session_by_id_unfiltered(sessionID)
    if not existing:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Session {sessionID} not found",
        )
    _require_session_write_access(existing, current_user)
    metadata = _share_metadata(existing, shared=True, actor_user_id=current_user.id)
    token = set_current_auth_user(current_user)
    try:
        session = await Session.update(
            project_id=existing.project_id,
            session_id=sessionID,
            metadata=metadata,
        )
    finally:
        reset_current_auth_user(token)
    if not session:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Session {sessionID} not found",
        )
    return await _session_to_response_with_goal(session)


@router.post(
    "/{sessionID}/unshare-local",
    response_model=SessionResponse,
    summary="Unshare session locally",
    description="Cancel local sharing of this session",
)
async def unshare_session_local(sessionID: str, http_request: Request) -> SessionResponse:
    current_user = require_user(http_request)
    existing = await _get_session_by_id_unfiltered(sessionID)
    if not existing:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Session {sessionID} not found",
        )
    _require_session_write_access(existing, current_user)
    metadata = _share_metadata(existing, shared=False, actor_user_id=current_user.id)
    token = set_current_auth_user(current_user)
    try:
        session = await Session.update(
            project_id=existing.project_id,
            session_id=sessionID,
            metadata=metadata,
        )
    finally:
        reset_current_auth_user(token)
    if not session:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Session {sessionID} not found",
        )
    return await _session_to_response_with_goal(session)


# =============================================================================
# Session Actions
# =============================================================================

async def _abort_session_processing(sessionID: str) -> bool:
    """Abort active processing for a session and notify subscribers.

    Returns whether anything of the session was running in this process.

    Aborts both the SessionLoop (sets abort_event so the next step check
    stops the loop) and the SessionRunner (stops the current LLM stream).
    Also auto-rejects any pending Question tool requests so the question
    handler polling loop unblocks immediately instead of timing out.

    Cascades abort to all child sub-agent sessions (synchronous subtasks
    and background tasks) so they stop together with the parent.
    """
    from flocks.session.runner import SessionRunner
    from flocks.session.session_loop import SessionLoop
    from flocks.server.routes.question import reject_session_questions

    # Abort the loop-level context (propagates to runner via shared abort_event)
    loop_aborted = SessionLoop.abort(sessionID)

    # Also cancel through the runner's own path (sets status to idle; it
    # reports True whether or not a runner was there, so ask first).
    runner_cancelled = sessionID in SessionRunner._active_sessions
    SessionRunner.cancel(sessionID)

    # Unblock any pending Question tool waiting for user input
    questions_rejected = await reject_session_questions(sessionID)

    # --- Cascade abort to child sub-agent sessions ---
    children_loops_aborted = SessionLoop.abort_children(sessionID)
    children_runners_cancelled = SessionRunner.cancel_children(sessionID)

    # Cancel background sub-agent tasks spawned by this session
    bg_cancelled = 0
    try:
        from flocks.task.background import cancel_background_runs_for_parent
        bg_cancelled = cancel_background_runs_for_parent(sessionID)
    except Exception as exc:
        log.warn("session.abort.bg_cancel_error", {"error": str(exc)})

    log.info("session.aborted", {
        "session_id": sessionID,
        "loop_aborted": loop_aborted,
        "questions_rejected": questions_rejected,
        "children_loops_aborted": children_loops_aborted,
        "children_runners_cancelled": children_runners_cancelled,
        "bg_tasks_cancelled": bg_cancelled,
    })

    # Publish SSE event so frontend knows execution stopped
    try:
        from flocks.server.routes.event import publish_event
        await publish_event("session.updated", {
            "id": sessionID,
            "status": "idle",
        })
    except Exception as exc:
        log.warn("session.abort.event_error", {"error": str(exc)})

    return bool(loop_aborted or runner_cancelled or children_loops_aborted or children_runners_cancelled or bg_cancelled)


class AbortSessionResult(BaseModel):
    """What an abort came to.

    ``stopped``: the run has ended.  ``requested``: the node running it took
    the request and is stopping it.  ``unconfirmed``: the request was recorded
    (or could not be), but no node answered for the run -- its node may be
    gone, and the run is released when its lease expires.  ``not_running``:
    nothing of the session was executing.
    """

    status: Literal["stopped", "requested", "unconfirmed", "not_running"]
    #: The run the request named (its execution lease generation), when one ran.
    generation: Optional[int] = None


@router.post(
    "/{sessionID}/abort",
    summary="Abort session",
    description="Abort an active session and stop any ongoing processing",
    response_model=AbortSessionResult,
)
async def abort_session(sessionID: str, http_request: Request = None) -> AbortSessionResult:
    """Abort session processing."""
    if http_request is not None:
        current_user = require_user(http_request)
        session = await _get_session_by_id_unfiltered(sessionID)
        if not session:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Session {sessionID} not found",
            )
        _require_session_write_access(session, current_user)
    from flocks.session import ownership

    ran_here = await _abort_session_processing(sessionID)
    # The run may be held outside this process; whoever holds its lease aborts it.
    try:
        target = await ownership.request_abort_of_run(sessionID)
    except Exception as exc:
        log.warn("session.abort.remote_request_failed", {"session_id": sessionID, "error": str(exc)})
        return AbortSessionResult(status="stopped" if ran_here else "unconfirmed")
    if target is None:
        return AbortSessionResult(status="stopped" if ran_here else "not_running")
    try:
        outcome = await ownership.confirm_abort(target)
    except Exception as exc:
        log.warn("session.abort.confirm_failed", {"session_id": sessionID, "error": str(exc)})
        outcome = ownership.ABORT_UNCONFIRMED
    log.info("session.abort.outcome", {"session_id": sessionID, "generation": target.generation, "status": outcome})
    return AbortSessionResult(status=outcome, generation=target.generation)


def install_remote_abort_handler() -> None:
    """Abort sessions this process runs when flocks.session.ownership asks.

    Called by the server as it starts (flocks.server.app), not on import.
    """
    from flocks.session.ownership import set_abort_handler

    set_abort_handler(_abort_session_processing)


class ForkRequest(BaseModel):
    """Request to fork session"""
    messageID: Optional[str] = Field(None, description="Message ID to fork up to")


class InitRequest(BaseModel):
    """Request to initialize session"""
    model_config = ConfigDict(populate_by_name=True)
    
    modelID: str = Field(..., description="Model ID")
    providerID: str = Field(..., description="Provider ID")
    messageID: str = Field(..., description="Message ID")


@router.post(
    "/{sessionID}/init",
    summary="Initialize session",
    description="Analyze the current application and create an AGENTS.md file with project-specific agent configurations",
)
async def initialize_session(sessionID: str, request: InitRequest, http_request: Request) -> bool:
    """Initialize session"""
    from flocks.session.runner import SessionRunner

    current_user = require_user(http_request)
    session = await _get_session_by_id_unfiltered(sessionID)
    if not session:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Session {sessionID} not found"
        )
    _require_session_write_access(session, current_user)

    from flocks.provider.provider import Provider

    Provider._ensure_initialized()
    if Provider.get(request.providerID) is None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Provider {request.providerID} not found",
        )

    # Resolve the command template (raises for unknown commands) ...
    await SessionRunner.command(
        session_id=sessionID,
        command="init",
        arguments="",
        message_id=request.messageID,
        model=f"{request.providerID}/{request.modelID}",
    )
    # ... then actually run it through the session input pipeline, exactly
    # like ``POST /command`` does, so the assistant reply (and any failure)
    # reaches subscribers over SSE instead of returning a silent ``true``.
    working_directory = await _resolve_session_working_directory(session)
    _schedule_slash_command(
        sessionID,
        session,
        working_directory,
        command="init",
        arguments="",
        model=f"{request.providerID}/{request.modelID}",
        message_id=request.messageID,
    )
    
    log.info("session.initialized", {"session_id": sessionID})
    return True


@router.post(
    "/{sessionID}/fork",
    response_model=SessionResponse,
    summary="Fork session",
    description="Create a new session by forking at a specific message point",
)
async def fork_session(sessionID: str, http_request: Request, request: Optional[ForkRequest] = None) -> SessionResponse:
    """Fork session"""
    current_user = require_user(http_request)
    session = await _get_session_by_id_unfiltered(sessionID)
    if not session:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Session {sessionID} not found"
        )
    _require_session_write_access(session, current_user)

    message_id = request.messageID if request else None
    if message_id:
        from flocks.session.message import Message

        if await Message.get(sessionID, message_id) is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Message {message_id} not found in session {sessionID}",
            )
    forked = await Session.fork(session.project_id, sessionID, message_id)
    
    log.info("session.forked", {"from": sessionID, "to": forked.id})
    return await _session_to_response_with_goal(forked)


@router.get(
    "/{sessionID}/diff",
    response_model=List[FileDiff],
    summary="Get session diff",
    description="Get file diffs for a session or specific message",
)
async def get_session_diff(
    sessionID: str,
    request: Request,
    messageID: Optional[str] = Query(None, description="Message ID to get diff for"),
) -> List[FileDiff]:
    """Get session diff"""
    from flocks.session.lifecycle.summary import SessionSummary

    current_user = require_user(request)
    session = await _get_session_by_id_unfiltered(sessionID)
    if not session:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Session {sessionID} not found",
        )
    _require_session_read_access(session, current_user)
    
    try:
        # ``SessionSummary`` stores both shapes under ``session_diff:<id>`` /
        # ``message_diff:<id>:<msg>``; reading the list-style key here resolved
        # to ``session_diff/<id>`` and never found the stored session diff.
        diffs = await SessionSummary.diff(session_id=sessionID, message_id=messageID)
        
        if diffs is None:
            return []
        return [FileDiff(**diff) for diff in diffs]
    except Exception as e:
        log.warn("session.diff.read_error", {"sessionID": sessionID, "error": str(e)})
        return []


class SummarizeRequest(BaseModel):
    """Request to summarize session"""
    providerID: str = Field(..., description="Provider ID")
    modelID: str = Field(..., description="Model ID")
    auto: bool = Field(False, description="Auto compaction mode")


@router.post(
    "/{sessionID}/summarize",
    summary="Summarize session",
    description="Generate a summary using AI compaction",
)
async def summarize_session(sessionID: str, request: SummarizeRequest, http_request: Request) -> bool:
    """Summarize session"""
    from flocks.project.bootstrap import instance_bootstrap
    from flocks.project.instance import Instance
    from flocks.server.routes.event import publish_event
    from flocks.session.message import Message, MessageRole

    current_user = require_user(http_request)
    session = await _get_session_by_id_unfiltered(sessionID)
    if not session:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Session {sessionID} not found"
        )
    _require_session_write_access(session, current_user)

    # Get all messages to find current agent from last user message
    # This matches Flocks logic in session.ts:520-528
    messages = await Message.list(sessionID)
    current_agent = DEFAULT_AGENT
    
    for msg in reversed(messages):
        if msg.role == MessageRole.USER:
            current_agent = msg.agent or DEFAULT_AGENT
            break

    session, _ = await _prepare_session_agent_before_bootstrap(
        session,
        current_agent,
    )
    working_directory = await _resolve_session_working_directory(session)
    
    async def _run_in_background():
        try:
            await Instance.provide(
                directory=working_directory,
                init=instance_bootstrap,
                fn=lambda: _run_session_compaction(
                    sessionID,
                    requested_agent=current_agent,
                    explicit_provider_id=request.providerID,
                    explicit_model_id=request.modelID,
                    auto=request.auto,
                    event_publish_callback=publish_event,
                    working_directory=working_directory,
                ),
            )
        except Exception as e:
            log.error("session.summarize.error", {
                "session_id": sessionID,
                "error": str(e),
            })
            await publish_event("session.error", {
                "sessionID": sessionID,
                "error": {
                    "name": type(e).__name__,
                    "message": str(e),
                    "data": {"message": str(e)},
                },
            })

    _schedule_background_coro(
        _run_in_background(),
        session_id=sessionID,
        action="session.summarize",
    )
    
    log.info("session.summarized", {"session_id": sessionID})
    return True


class RevertRequest(BaseModel):
    """Request to revert session"""
    messageID: str = Field(..., description="Message ID to revert to")
    partID: Optional[str] = Field(None, description="Part ID for partial revert")


@router.post(
    "/{sessionID}/revert",
    response_model=SessionResponse,
    summary="Revert session",
    description="Revert session to a specific message point",
)
async def revert_session(sessionID: str, request: RevertRequest, http_request: Request) -> SessionResponse:
    """Revert session"""
    from flocks.session.lifecycle.revert import SessionRevert

    current_user = require_user(http_request)
    session = await _get_session_by_id_unfiltered(sessionID)
    if not session:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Session {sessionID} not found"
        )
    _require_session_write_access(session, current_user)

    from flocks.session.message import Message

    if await Message.get(sessionID, request.messageID) is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Message {request.messageID} not found in session {sessionID}",
        )

    try:
        updated = await SessionRevert.revert(
            session_id=sessionID,
            message_id=request.messageID,
            part_id=request.partID,
        )
    except (ValueError, SessionInactiveError) as exc:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=str(exc),
        ) from exc
    
    log.info("session.reverted", {"session_id": sessionID, "message_id": request.messageID})
    return await _session_to_response_with_goal(updated)


@router.post(
    "/{sessionID}/unrevert",
    response_model=SessionResponse,
    summary="Unrevert session",
    description="Restore previously reverted messages",
)
async def unrevert_session(sessionID: str, http_request: Request) -> SessionResponse:
    """Unrevert session"""
    from flocks.session.lifecycle.revert import SessionRevert

    current_user = require_user(http_request)
    session = await _get_session_by_id_unfiltered(sessionID)
    if not session:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Session {sessionID} not found"
        )
    _require_session_write_access(session, current_user)

    try:
        updated = await SessionRevert.unrevert(session_id=sessionID)
    except (ValueError, SessionInactiveError) as exc:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=str(exc),
        ) from exc
    
    log.info("session.unreverted", {"session_id": sessionID})
    return await _session_to_response_with_goal(updated)


# =============================================================================
# Message Routes
# =============================================================================

class ModelInfo(BaseModel):
    """Model selection info for API compatibility"""
    providerID: str = Field(..., description="Provider ID")
    modelID: str = Field(..., description="Model ID")


class TextPartInput(BaseModel):
    """Text part input for API compatibility"""
    type: Literal["text"] = "text"
    id: Optional[str] = Field(None, description="Part ID")
    text: str = Field(..., description="Text content")


class FilePartInput(BaseModel):
    """File part input for API compatibility"""
    type: Literal["file"] = "file"
    id: Optional[str] = Field(None, description="Part ID")
    url: str = Field(..., description="File URL")
    mime: str = Field(..., description="MIME type")
    filename: Optional[str] = Field(None, description="File name")


class AgentPartInput(BaseModel):
    """Agent part input for API compatibility"""
    type: Literal["agent"] = "agent"
    id: Optional[str] = Field(None, description="Part ID")
    name: str = Field(..., description="Agent name")


class PromptRequest(BaseModel):
    """
    Request to send a prompt/message
    
    Schema follows standard SessionPrompt.PromptInput format
    """
    model_config = ConfigDict(populate_by_name=True, extra="ignore")
    
    parts: List[Dict[str, Any]] = Field(default_factory=list, description="Message parts")
    model: Optional[ModelInfo] = Field(None, description="Model selection")
    messageID: Optional[str] = Field(None, description="Message ID")
    agent: Optional[str] = Field(None, description="Agent name")
    display_text: Optional[str] = Field(None, alias="displayText", description="User-visible message text")
    noReply: Optional[bool] = Field(None, description="Skip AI response")
    mockReply: Optional[str] = Field(None, description="Inject a mock assistant message after noReply user message")
    tools: Optional[Dict[str, bool]] = Field(None, description="Tool settings (deprecated)")
    system: Optional[str] = Field(None, description="System prompt override")
    variant: Optional[str] = Field(None, description="Model variant")
    execution_mode: SessionExecutionMode = Field(
        SessionExecutionMode.BUILD,
        alias="executionMode",
        description="Execution mode for this user turn",
    )
    turn_id: Optional[str] = Field(
        None,
        alias="turnID",
        description="Client-chosen id of this turn; GET /session/{id}/turn/{turnID} says how it stands",
    )


class UserMessageInfo(BaseModel):
    """
    User message info - Flocks TUI compatible format.
    
    Flocks expects:
    {
        "id": string,
        "sessionID": string,
        "role": "user",
        "time": { "created": number },
        "agent": string,
        "model": { "providerID": string, "modelID": string },
        // optional fields...
    }
    """
    id: str
    sessionID: str
    role: Literal["user"] = "user"
    time: Dict[str, Any]
    agent: str = DEFAULT_AGENT
    model: Dict[str, str]  # { "providerID": string, "modelID": string }
    summary: Optional[Dict[str, Any]] = None
    system: Optional[str] = None
    tools: Optional[Dict[str, bool]] = None
    variant: Optional[str] = None
    compacted: Optional[bool] = None
    executionMode: SessionExecutionMode = SessionExecutionMode.BUILD


class AssistantMessageInfo(BaseModel):
    """
    Assistant message info - Flocks TUI compatible format.
    
    Flocks expects:
    {
        "id": string,
        "sessionID": string,
        "role": "assistant",
        "time": { "created": number, "completed"?: number },
        "parentID": string,
        "modelID": string,
        "providerID": string,
        "mode": string,
        "agent": string,
        "path": { "cwd": string, "root": string },
        "cost": number,
        "tokens": { "input": number, "output": number, ... },
        // optional fields...
    }
    """
    id: str
    sessionID: str
    role: Literal["assistant"] = "assistant"
    time: Dict[str, Any]
    parentID: Optional[str] = None
    modelID: str
    providerID: str
    mode: str = DEFAULT_AGENT
    agent: str = DEFAULT_AGENT
    path: Dict[str, str]  # { "cwd": string, "root": string }
    cost: float = 0.0
    tokens: Dict[str, Any] = Field(default_factory=lambda: {
        "input": 0,
        "output": 0,
        "reasoning": 0,
        "cache": {"read": 0, "write": 0}
    })
    error: Optional[Dict[str, Any]] = None
    summary: Optional[bool] = None
    finish: Optional[str] = None
    compacted: Optional[bool] = None


# Union type for message info
MessageInfo = Union[UserMessageInfo, AssistantMessageInfo]


class MessagePartInfo(BaseModel):
    """Message part info for API compatibility"""
    id: str
    messageID: str
    sessionID: str
    type: str
    text: Optional[str] = None
    time: Optional[Dict[str, Any]] = None
    synthetic: Optional[bool] = None
    tool: Optional[str] = None
    state: Optional[Dict[str, Any]] = None
    callID: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None
    # File / image attachment fields (populated when ``type == "file"``).
    url: Optional[str] = None
    mime: Optional[str] = None
    filename: Optional[str] = None
    resourceID: Optional[str] = None


class MessageWithParts(BaseModel):
    """Message with parts for API compatibility"""
    info: MessageInfo
    parts: List[MessagePartInfo] = []


class MessagePage(BaseModel):
    """Paged message response used by the WebUI session page."""
    sessionID: str
    items: List[MessageWithParts] = []
    hasMore: bool = False
    nextBefore: Optional[str] = None
    hasNewer: bool = False
    nextAfter: Optional[str] = None


class MessageEditRequest(BaseModel):
    """Request to edit message text."""

    text: str = Field(..., description="Updated raw text content")
    partID: Optional[str] = Field(None, description="Specific text part ID to edit")


def _json_bytes(value: Any) -> bytes:
    return json.dumps(value, ensure_ascii=False, default=str).encode("utf-8")


def _part_to_response_info(
    part: Any,
    *,
    session_id: str,
    message_id: str,
    index: int = 0,
) -> MessagePartInfo:
    text_value = getattr(part, "text", None) if part.type in ("text", "reasoning", "thinking") else None

    raw_time = getattr(part, "time", None)
    if hasattr(raw_time, "model_dump"):
        time_value = raw_time.model_dump()
    elif isinstance(raw_time, dict):
        time_value = raw_time
    else:
        time_value = None

    resource_id = None
    url_value = getattr(part, "url", None) if part.type == "file" else None
    if part.type == "file":
        from flocks.session.files import public_resource_id, session_upload_part_path

        # Only a file uploaded into this Session resolves as a context
        # resource. Channel media keeps its file:// URL: the WebUI turns that
        # into /api/file/download, which allows the data directory, whereas
        # the context preview route would answer 404 for it.
        if session_upload_part_path(session_id, part) is not None:
            resource_id = public_resource_id(message_id, str(part.id))
            if isinstance(url_value, str) and url_value.startswith("file:"):
                url_value = f"/api/session/{session_id}/context/files/{resource_id}/preview"

    state_value = None
    if part.type == "tool":
        raw_state = getattr(part, "state", None)
        if raw_state is not None:
            if hasattr(raw_state, "model_dump"):
                state_value = raw_state.model_dump()
            elif isinstance(raw_state, dict):
                state_value = dict(raw_state)
        if isinstance(state_value, dict):
            from flocks.session.files import output_file_attachments, public_resource_id

            attachments = output_file_attachments(
                str(getattr(part, "tool", "") or ""),
                state_value.get("attachments"),
            ) if state_value.get("status") == "completed" else None
            state_value["attachments"] = [
                {**attachment, "resourceID": public_resource_id(message_id, attachment["id"])}
                for attachment in attachments
            ] if attachments else None

    return MessagePartInfo(
        id=part.id if hasattr(part, "id") else f"{message_id}_part_{index}",
        messageID=message_id,
        sessionID=session_id,
        type=part.type,
        text=text_value,
        time=time_value,
        synthetic=getattr(part, "synthetic", None),
        tool=getattr(part, "tool", None) if part.type == "tool" else None,
        state=state_value,
        callID=getattr(part, "callID", None) if part.type == "tool" else None,
        metadata=getattr(part, "metadata", None),
        url=url_value,
        mime=getattr(part, "mime", None) if part.type == "file" else None,
        filename=getattr(part, "filename", None) if part.type == "file" else None,
        resourceID=resource_id,
    )


async def _message_to_response_info(msg: Any, *, cwd: str) -> MessageInfo:
    if msg.role == "user":
        model_dict = getattr(msg, "model", None)
        if model_dict and isinstance(model_dict, dict):
            model_info = model_dict
        else:
            try:
                from flocks.agent.registry import Agent

                default_agent = await Agent.default_agent()
                agent_obj = await Agent.get(default_agent)
                if agent_obj and hasattr(agent_obj, "model") and agent_obj.model:
                    model_info = agent_obj.model
                else:
                    model_info = {"providerID": "openai", "modelID": "gpt-4-turbo-preview"}
            except Exception:
                model_info = {"providerID": "openai", "modelID": "gpt-4-turbo-preview"}

        return UserMessageInfo(
            id=msg.id,
            sessionID=msg.sessionID,
            role="user",
            time=msg.time,
            agent=getattr(msg, "agent", None) or DEFAULT_AGENT,
            model=model_info,
            compacted=getattr(msg, "compacted", None),
            executionMode=getattr(
                msg,
                "executionMode",
                SessionExecutionMode.BUILD,
            ),
        )

    tokens_raw = getattr(msg, "tokens", None)
    if tokens_raw is not None and hasattr(tokens_raw, "model_dump"):
        tokens_dict = tokens_raw.model_dump()
    elif isinstance(tokens_raw, dict):
        tokens_dict = tokens_raw
    else:
        tokens_dict = {
            "input": 0,
            "output": 0,
            "reasoning": 0,
            "cache": {"read": 0, "write": 0},
        }

    path_raw = getattr(msg, "path", None)
    if path_raw is not None and hasattr(path_raw, "model_dump"):
        path_dict = path_raw.model_dump()
    elif isinstance(path_raw, dict):
        path_dict = path_raw
    else:
        path_dict = {"cwd": cwd, "root": cwd}

    return AssistantMessageInfo(
        id=msg.id,
        sessionID=msg.sessionID,
        role="assistant",
        time=msg.time,
        parentID=getattr(msg, "parentID", None),
        modelID=getattr(msg, "modelID", None) or "claude-sonnet-4-5-20250929",
        providerID=getattr(msg, "providerID", None) or "anthropic",
        mode=getattr(msg, "agent", None) or DEFAULT_AGENT,
        agent=getattr(msg, "agent", None) or DEFAULT_AGENT,
        path=path_dict,
        cost=getattr(msg, "cost", 0.0) or 0.0,
        tokens=tokens_dict,
        error=getattr(msg, "error", None),
        summary=getattr(msg, "summary", None),
        finish=getattr(msg, "finish", None),
        compacted=getattr(msg, "compacted", None),
    )


async def _message_with_parts_to_response(
    msg_with_parts: Any,
    *,
    session_id: str,
    cwd: str,
) -> MessageWithParts:
    msg = msg_with_parts.info
    info = await _message_to_response_info(msg, cwd=cwd)
    parts = [
        _part_to_response_info(
            part,
            session_id=session_id,
            message_id=msg.id,
            index=i,
        )
        for i, part in enumerate(msg_with_parts.parts)
    ]
    return MessageWithParts(info=info, parts=parts)


@router.get(
    "/{sessionID}/message",
    response_model=Union[List[MessageWithParts], MessagePage],
    summary="Get session messages",
    description="Get all messages in a session",
)
async def get_session_messages(
    sessionID: str,
    http_request: Request,
    limit: Optional[int] = Query(None, ge=1, le=100, description="Maximum messages to return"),
    before: Optional[str] = Query(None, description="Load messages before this message id"),
    after: Optional[str] = Query(None, description="Load messages after this message id"),
    around: Optional[str] = Query(None, description="Load a page containing this message id"),
    page: bool = Query(False, description="Return paged response metadata"),
    include_archived: bool = Query(True, description="Include compacted/archived messages"),
) -> Union[List[MessageWithParts], MessagePage]:
    """Get session messages"""
    from flocks.session.message import Message
    import os

    started_at = time.perf_counter()
    current_user = require_user(http_request)
    session = await _get_session_by_id_unfiltered(sessionID)
    if not session:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Session {sessionID} not found",
        )
    _require_session_read_access(session, current_user)
    if sum(bool(cursor) for cursor in (before, after, around)) > 1:
        raise HTTPException(status_code=422, detail="Only one message cursor may be supplied")

    try:
        from flocks.session.core.status import SessionStatus

        paged = page or before is not None or after is not None or around is not None
        if paged or limit:
            page_limit = limit or DEFAULT_MESSAGE_PAGE_LIMIT
            messages_with_parts, has_more, next_before, has_newer, next_after = await Message.list_page_with_parts(
                sessionID,
                limit=page_limit,
                before=before,
                after=after,
                around=around,
                include_archived=include_archived,
            )
        else:
            messages_with_parts = await Message.list_with_parts(
                sessionID,
                include_archived=include_archived,
            )
            has_more = False
            next_before = None
            has_newer = False
            next_after = None

        cwd = os.getcwd()
        result = [
            await _message_with_parts_to_response(
                msg_with_parts,
                session_id=sessionID,
                cwd=cwd,
            )
            for msg_with_parts in messages_with_parts
        ]

        payload_bytes = len(_json_bytes([item.model_dump() for item in result]))
        log_route_timing(log, "session.messages.page.complete", started_at=started_at, extra={
            "sessionID": sessionID,
            "count": len(result),
            "parts": sum(len(message.parts) for message in result),
            "paged": paged,
            "limit": limit,
            "before": bool(before),
            "has_more": has_more,
            "payload_bytes": payload_bytes,
        })

        if paged:
            return MessagePage(
                sessionID=sessionID,
                items=result,
                hasMore=has_more,
                nextBefore=next_before,
                hasNewer=has_newer,
                nextAfter=next_after,
            )
        return result
    except LookupError as e:
        raise HTTPException(status_code=404, detail="Message cursor not found") from e
    except Exception as e:
        log.error("session.messages.error", {"error": str(e), "sessionID": sessionID})
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to load session messages",
        ) from e


@router.get(
    "/{sessionID}/message/{messageID}",
    response_model=MessageWithParts,
    summary="Get message",
    description="Get a specific message by ID",
)
async def get_message(sessionID: str, messageID: str, http_request: Request) -> MessageWithParts:
    """Get single message"""
    from flocks.session.message import Message
    import os

    current_user = require_user(http_request)
    session = await _get_session_by_id_unfiltered(sessionID)
    if not session:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Session {sessionID} not found",
        )
    _require_session_read_access(session, current_user)

    msg_with_parts = await Message.get_with_parts_lazy(sessionID, messageID)
    if msg_with_parts:
        return await _message_with_parts_to_response(
            msg_with_parts,
            session_id=sessionID,
            cwd=os.getcwd(),
        )
    
    raise HTTPException(
        status_code=status.HTTP_404_NOT_FOUND,
        detail=f"Message {messageID} not found in session {sessionID}"
    )


@router.delete(
    "/{sessionID}/message/{messageID}/part/{partID}",
    summary="Delete message part",
    description="Delete a specific part from a message",
)
async def delete_message_part(sessionID: str, messageID: str, partID: str, http_request: Request) -> bool:
    """Delete message part"""
    from flocks.session.message import Message

    current_user = require_user(http_request)
    session = await _get_session_by_id_unfiltered(sessionID)
    if not session:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Session {sessionID} not found",
        )
    _require_session_write_access(session, current_user)

    try:
        removed = await Message.remove_part(sessionID, messageID, partID)
    except Exception as e:
        log.error("message.part.delete.error", {"error": str(e)})
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    if not removed:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Part {partID} not found in message {messageID}",
        )
    log.info("message.part.deleted", {
        "sessionID": sessionID,
        "messageID": messageID,
        "partID": partID,
    })
    return True


@router.patch(
    "/{sessionID}/message/{messageID}/part/{partID}",
    response_model=MessagePartInfo,
    summary="Update message part",
    description="Update a specific part in a message",
)
async def update_message_part(
    sessionID: str,
    messageID: str,
    partID: str,
    body: MessagePartInfo,
    http_request: Request,
) -> MessagePartInfo:
    """Update message part"""
    if body.id != partID or body.messageID != messageID or body.sessionID != sessionID:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Part IDs do not match URL parameters"
        )
    
    from flocks.session.message import Message

    current_user = require_user(http_request)
    session = await _get_session_by_id_unfiltered(sessionID)
    if not session:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Session {sessionID} not found",
        )
    _require_session_write_access(session, current_user)

    message = await Message.get_with_parts_lazy(sessionID, messageID)
    existing = next((part for part in message.parts if part.id == partID), None) if message else None
    if existing is None:
        raise HTTPException(status_code=404, detail="Message part not found")
    if body.type != existing.type or (
        existing.type == "tool" and body.tool != existing.tool
    ):
        raise HTTPException(status_code=400, detail="Message part type and tool are immutable")
    if existing.type == "tool" and existing.tool == "write":
        # Tool output provenance is server-owned. In particular, accepting a
        # stale running write state could erase a binding completed concurrently.
        # Tool state PATCHes are not needed by the text-editing API.
        if "state" in body.model_fields_set:
            raise HTTPException(status_code=400, detail="Tool state is server-managed")

    try:
        updated = await Message.update_part(
            sessionID, messageID, partID, **body.model_dump(exclude_unset=True),
        )
        if updated is None:
            raise HTTPException(status_code=404, detail="Message part not found")
        log.info("message.part.updated", {
            "sessionID": sessionID,
            "messageID": messageID,
            "partID": partID,
        })
        return _part_to_response_info(updated, session_id=sessionID, message_id=messageID)
    except HTTPException:
        raise
    except Exception as e:
        log.error("message.part.update.error", {"error": str(e)})
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))
    if updated is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Part {partID} not found in message {messageID}",
        )
    log.info("message.part.updated", {
        "sessionID": sessionID,
        "messageID": messageID,
        "partID": partID,
    })
    return body


async def _get_message_text_part(
    session_id: str,
    message_id: str,
    part_id: Optional[str] = None,
):
    """Return the target message and an editable text part."""
    from flocks.session.message import Message

    message = await Message.get(session_id, message_id)
    if not message:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Message {message_id} not found in session {session_id}",
        )

    parts = await Message.parts(message_id, session_id)
    if part_id:
        text_part = next((part for part in parts if getattr(part, "id", None) == part_id), None)
        if not text_part:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Part {part_id} not found in message {message_id}",
            )
        if getattr(text_part, "type", None) != "text":
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Part {part_id} is not an editable text part",
            )
    else:
        text_part = next((part for part in parts if getattr(part, "type", None) == "text"), None)
    if not text_part:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Message {message_id} does not have an editable text part",
        )

    return message, text_part


async def _publish_text_part_update(
    session_id: str,
    message_id: str,
    part_id: str,
    text: str,
    metadata: Optional[Dict[str, Any]] = None,
) -> None:
    """Broadcast a text part update so other subscribers stay in sync."""
    from flocks.server.routes.event import publish_event

    part: Dict[str, Any] = {
        "id": part_id,
        "messageID": message_id,
        "sessionID": session_id,
        "type": "text",
        "text": text,
    }
    if metadata:
        part["metadata"] = metadata
    await publish_event("message.part.updated", {"part": part})


def _track_background_task(
    task: "asyncio.Task[Any]",
    *,
    session_id: Optional[str] = None,
) -> None:
    """Keep background tasks alive until completion."""
    track_background_task(task, session_id=session_id)
    router._pending_tasks = pending_background_tasks()


def _schedule_background_coro(
    coro,
    *,
    session_id: Optional[str] = None,
    action: str = "session.background",
) -> "asyncio.Task[Any]":
    """Schedule a background coroutine with its opaque execution context."""
    import asyncio
    from flocks.hooks.execution import current_execution_context, execution_context_scope

    execution_context = current_execution_context()

    async def _guarded_coro() -> None:
        with execution_context_scope(execution_context):
            try:
                await coro
            except Exception as exc:
                log.error("session.background.error", {
                    "sessionID": session_id,
                    "action": action,
                    "error": str(exc),
                    "error_type": type(exc).__name__,
                })
                if session_id:
                    from flocks.server.routes.event import publish_event

                    try:
                        await publish_event("session.error", {
                            "sessionID": session_id,
                            "error": {
                                "name": type(exc).__name__,
                                "message": str(exc),
                                "data": {"message": str(exc), "action": action},
                            },
                        })
                    except Exception as publish_exc:
                        log.error("session.background.error.publish_failed", {
                            "sessionID": session_id,
                            "action": action,
                            "error": str(publish_exc),
                            "error_type": type(publish_exc).__name__,
                        })

    task = asyncio.get_running_loop().create_task(_guarded_coro())
    _track_background_task(task, session_id=session_id)
    return task


async def _prepare_replay_runtime(
    session_id: str,
    user_message,
) -> Dict[str, Any]:
    """Resolve replay runtime state before mutating session history."""
    from flocks.agent.registry import Agent
    from flocks.config.config import Config
    from flocks.provider.provider import Provider

    agent_name = getattr(user_message, "agent", None) or await Agent.default_agent()
    agent = await Agent.get(agent_name) or await Agent.get(DEFAULT_AGENT)
    session = await Session.get_by_id(session_id)
    auto_failover = bool(
        session
        and is_model_auto_session_category(getattr(session, "category", "user"))
        and getattr(session, "model_auto", False)
    )
    if auto_failover:
        default_llm = await Config.resolve_default_llm()
        if not default_llm:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Auto mode requires a configured default LLM",
            )
        provider_id = default_llm["provider_id"]
        model_id = default_llm["model_id"]
    else:
        # Replay follows the model active *now*, not the model stored on the
        # historical user message.
        dummy_request = type(
            "_MessageReplayRequest",
            (),
            {"model": None, "agent": agent_name},
        )()
        provider_id, model_id, _ = await _resolve_model(
            dummy_request,
            agent,
            session_id,
        )

    Provider._ensure_initialized()
    config = await Config.get()
    await Provider.apply_config(config, provider_id=provider_id)
    provider = Provider.get(provider_id)
    if not provider and not auto_failover:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Provider {provider_id} not found",
        )

    return {
        "agent_name": agent_name,
        "provider_id": provider_id,
        "model_id": model_id,
        "auto_failover": auto_failover,
    }


@dataclass
class _GoalRewind:
    """What :func:`_rewind_goal_for_replay` did to the goal, to publish or undo."""

    objective: Optional[str] = None  # the goal the replayed message sets, else None
    event: Optional[Dict[str, Any]] = None  # session.goal.updated, once the replay is in
    changed: bool = False
    previous: Any = None  # the GoalState before, put back when the replay fails
    written: Any = None  # the GoalState the rewind wrote (None: it removed the goal)


async def _rewind_goal_for_replay(
    session_id: str,
    message_id: str,
    original_text: str,
    *,
    edited_text: Optional[str] = None,
) -> _GoalRewind:
    """Bring the session goal back to the message history is being rewound to.

    The goal is kept beside the messages, and after every turn SessionLoop
    judges it and may append a continuation toward it. Goals are set by goal
    messages (their text a goal prompt), so replaying from a message

    - that is a goal message starts its goal over -- toward the edited
      objective when the message is being edited;
    - followed by a goal message, which the replay drops, clears the goal;
    - otherwise leaves the goal alone.

    Called before the history is touched, and storage errors are raised: a
    goal that cannot be read or changed stops the replay there. Should the
    replay fail later, :func:`_undo_goal_rewind` puts the goal back; the
    event is the caller's to publish once the replay is in.
    """
    from flocks.session.goal import GoalManager
    from flocks.session.message import Message

    previous = await GoalManager.get(session_id, strict=True)

    if GoalManager.is_goal_prompt(original_text):
        objective = GoalManager.objective_from_prompt(
            original_text if edited_text is None else edited_text
        )
        if objective:
            state = await GoalManager.set_goal(session_id, objective)
            return _GoalRewind(
                objective=state.objective,
                event={
                    "sessionID": session_id,
                    "status": state.status,
                    "objective": state.objective,
                    "reason": state.last_reason,
                },
                changed=True,
                previous=previous,
                written=state,
            )
        drops_goal = True
    else:
        drops_goal = False
        messages = await Message.list(session_id, include_archived=True)
        message_ids = [message.id for message in messages]
        if message_id in message_ids:
            for later in messages[message_ids.index(message_id) + 1:]:
                if getattr(later, "role", None) != "user":
                    continue
                if any(
                    getattr(part, "type", None) == "text"
                    and GoalManager.is_goal_prompt(getattr(part, "text", "") or "")
                    for part in await Message.parts(later.id, session_id)
                ):
                    drops_goal = True
                    break

    if not drops_goal or previous is None:
        return _GoalRewind(previous=previous)
    await GoalManager.remove(session_id)
    return _GoalRewind(
        event={
            "sessionID": session_id,
            "status": "cleared",
            "objective": previous.objective,
            "reason": None,
        },
        changed=True,
        previous=previous,
    )


async def _undo_goal_rewind(session_id: str, rewind: _GoalRewind) -> None:
    """Put the goal back as it was before a replay that failed.

    Only while the goal is still what the rewind left: one set again in the
    meantime (another message) is newer and stays. Reading and writing back
    are two steps, so a goal set right between them can still be lost.
    """
    from flocks.session.goal import GoalManager

    if not rewind.changed:
        return
    current = await GoalManager.get(session_id, strict=True)
    written = rewind.written
    if (current is None) != (written is None) or (
        current is not None
        and (current.objective, current.created_at) != (written.objective, written.created_at)
    ):
        return
    if rewind.previous is None:
        await GoalManager.remove(session_id)
    else:
        await GoalManager.save(session_id, rewind.previous)


def _edited_part_metadata(part: Any, display_text: Optional[str]) -> Optional[Dict[str, Any]]:
    """Metadata for a text part whose text was edited.

    The UI shows ``displayText`` in place of the text, so the label written
    for the old text (a goal's objective, a slash command) goes; a goal
    message gets its new objective instead.
    """
    metadata = dict(getattr(part, "metadata", None) or {})
    metadata.pop("displayText", None)
    metadata.pop("display_text", None)
    if display_text:
        metadata["displayText"] = display_text
    return metadata or None


async def _stop_replay_execution(session_id: str) -> None:
    """Stop and join the previous execution tree before rewinding history."""
    from flocks.session.agent_inbox import AgentInbox

    # Capture descendants and tasks before cancellation can unregister them.
    session_ids, tasks = AgentInbox.snapshot_tree(session_id)
    await _abort_session_processing(session_id)
    if not await AgentInbox.wait_for_tree(session_ids, tasks):
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Timed out waiting for previous session execution to stop",
        )


async def _run_existing_user_message(
    session_id: str,
    session,
    user_message,
    working_directory: str,
    runtime: Optional[Dict[str, Any]] = None,
):
    """Run SessionLoop using an already-persisted user message."""
    from flocks.server.routes.event import publish_event
    from flocks.session.lifecycle.revert import SessionRevert
    from flocks.session.message import Message
    from flocks.session.session_loop import SessionLoop, LoopCallbacks
    from flocks.utils.id import Identifier

    runtime = runtime or await _prepare_replay_runtime(session_id, user_message)
    agent_name = runtime["agent_name"]
    provider_id = runtime["provider_id"]
    model_id = runtime["model_id"]

    await SessionRevert.cleanup(session)

    async def _on_error(error: str):
        await publish_event("session.error", {
            "sessionID": session_id,
            "error": {"name": "SessionError", "message": error, "data": {"message": error}},
        })

    loop_callbacks = LoopCallbacks(
        on_error=_on_error,
        event_publish_callback=publish_event,
    )
    result = await SessionLoop.run(
        session_id=session_id,
        provider_id=provider_id,
        model_id=model_id,
        agent_name=agent_name,
        callbacks=loop_callbacks,
        working_directory=working_directory,
        auto_failover=bool(runtime.get("auto_failover", False)),
    )

    if result.action == "queued":
        log.info("session.message.replay.queued", {
            "sessionID": session_id,
            "user_message_id": user_message.id,
        })
        return {
            "status": "queued",
            "sessionID": session_id,
            "messageID": user_message.id,
        }

    end_ms = int(time.time() * 1000)
    finish_reason = "stop"
    final_content = ""
    assistant_message_id = None
    created_ms = end_ms
    final_tokens = {"input": 0, "output": 0, "reasoning": 0, "cache": {"read": 0, "write": 0}}
    actual_provider_id = result.provider_id or provider_id
    actual_model_id = result.model_id or model_id

    if result.last_message:
        assistant_message_id = result.last_message.id
        final_content = await Message.get_text_content(result.last_message)
        final_tokens = token_usage_to_dict(getattr(result.last_message, "tokens", None))
        finish = getattr(result.last_message, "finish", None)
        if finish:
            finish_reason = finish
        actual_provider_id = (
            getattr(result.last_message, "providerID", None)
            or actual_provider_id
        )
        actual_model_id = (
            getattr(result.last_message, "modelID", None)
            or actual_model_id
        )
        result_time = getattr(result.last_message, "time", None)
        if isinstance(result_time, dict):
            created_ms = result_time.get("created", created_ms)

    if result.action == "error":
        finish_reason = "error"
        if not assistant_message_id:
            assistant_message_id = Identifier.create("message")

    if not assistant_message_id:
        assistant_message_id = Identifier.create("message")

    await publish_event("message.updated", {
        "info": {
            "id": assistant_message_id,
            "sessionID": session_id,
            "role": "assistant",
            "time": {"created": created_ms, "completed": end_ms},
            "parentID": user_message.id,
            "modelID": actual_model_id,
            "providerID": actual_provider_id,
            "mode": agent_name,
            "agent": agent_name,
            "path": {"cwd": working_directory, "root": working_directory},
            "cost": 0,
            "tokens": final_tokens,
            "finish": finish_reason,
        }
    })
    await _publish_context_usage_update(
        publish_event,
        session_id,
        session=session,
        provider_id=actual_provider_id,
        model_id=actual_model_id,
    )

    log.info("session.message.replay.completed", {
        "sessionID": session_id,
        "user_message_id": user_message.id,
        "assistant_message_id": assistant_message_id,
        "finish": finish_reason,
        "content_length": len(final_content),
    })

    return {
        "status": "completed",
        "sessionID": session_id,
        "messageID": assistant_message_id,
        "finish": finish_reason,
    }


@router.post(
    "/{sessionID}/message/{messageID}/resend",
    status_code=status.HTTP_202_ACCEPTED,
    summary="Replay edited user message",
    description="Update a user message and regenerate subsequent assistant output",
)
async def resend_session_message(
    sessionID: str,
    messageID: str,
    body: MessageEditRequest,
    http_request: Request,
) -> Dict[str, str]:
    import os

    from flocks.project.bootstrap import instance_bootstrap
    from flocks.project.instance import Instance
    from flocks.server.routes.event import publish_event
    from flocks.session.goal import GoalManager
    from flocks.session.lifecycle.revert import SessionRevert
    from flocks.session.message import Message
    from flocks.session.session_loop import SessionLoop

    text = body.text.strip()
    if not text:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Edited message text cannot be empty",
        )

    message, text_part = await _get_message_text_part(sessionID, messageID, body.partID)
    if getattr(message, "role", None) != "user":
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Only user messages can be resent",
        )

    session = await _get_session_by_id_unfiltered(sessionID)
    if not session:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Session {sessionID} not found",
        )
    current_user = require_user(http_request)
    _require_session_write_access(session, current_user)

    if SessionLoop.is_running(sessionID):
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Session is currently generating a response",
        )

    try:
        await SessionRevert.ensure_replayable(session, messageID)
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=str(exc),
        ) from exc

    session, _ = await _prepare_session_agent_before_bootstrap(
        session,
        getattr(message, "agent", None),
    )
    working_directory = await _resolve_session_working_directory(session)

    async def _handle_resend() -> None:
        runtime = await _prepare_replay_runtime(sessionID, message)
        await _stop_replay_execution(sessionID)
        rewind = await _rewind_goal_for_replay(
            sessionID,
            messageID,
            getattr(text_part, "text", "") or "",
            edited_text=text,
        )
        stored_text = text if rewind.objective is None else GoalManager.goal_prompt(rewind.objective)
        metadata = _edited_part_metadata(text_part, rewind.objective)
        try:
            updated_session = await SessionRevert.revert(sessionID, messageID)
            await Message.update_part(sessionID, messageID, text_part.id, text=stored_text, metadata=metadata)
        except BaseException:
            await _undo_goal_rewind(sessionID, rewind)
            raise
        if rewind.event:
            await publish_event("session.goal.updated", rewind.event)
        await _publish_text_part_update(sessionID, messageID, text_part.id, stored_text, metadata)

        refreshed_message = await Message.get(sessionID, messageID)
        if not refreshed_message:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Message {messageID} not found after update",
            )

        await Instance.provide(
            directory=working_directory,
            init=instance_bootstrap,
            fn=lambda: _run_existing_user_message(
                sessionID,
                updated_session or session,
                refreshed_message,
                working_directory,
                runtime=runtime,
            ),
        )

    _schedule_background_coro(
        _handle_resend(),
        session_id=sessionID,
        action="message.resend",
    )
    return {"status": "accepted", "sessionID": sessionID, "messageID": messageID}


@router.post(
    "/{sessionID}/message/{messageID}/regenerate",
    status_code=status.HTTP_202_ACCEPTED,
    summary="Regenerate assistant message",
    description="Discard an assistant reply and regenerate it from its parent user message",
)
async def regenerate_session_message(
    sessionID: str,
    messageID: str,
    http_request: Request,
) -> Dict[str, str]:
    import os

    from flocks.project.bootstrap import instance_bootstrap
    from flocks.project.instance import Instance
    from flocks.server.routes.event import publish_event
    from flocks.session.lifecycle.revert import SessionRevert
    from flocks.session.message import Message
    from flocks.session.session_loop import SessionLoop

    message = await Message.get(sessionID, messageID)
    if not message:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Message {messageID} not found in session {sessionID}",
        )
    if getattr(message, "role", None) != "assistant":
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Only assistant messages can be regenerated",
        )

    parent_message_id = getattr(message, "parentID", None)
    if not parent_message_id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Assistant message does not have a parent user message",
        )

    parent_message, parent_text_part = await _get_message_text_part(sessionID, parent_message_id)
    if getattr(parent_message, "role", None) != "user":
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Assistant parent message must be a user message",
        )

    session = await _get_session_by_id_unfiltered(sessionID)
    if not session:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Session {sessionID} not found",
        )
    current_user = require_user(http_request)
    _require_session_write_access(session, current_user)

    if SessionLoop.is_running(sessionID):
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Session is currently generating a response",
        )

    try:
        await SessionRevert.ensure_replayable(session, parent_message_id)
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=str(exc),
        ) from exc

    session, _ = await _prepare_session_agent_before_bootstrap(
        session,
        getattr(parent_message, "agent", None),
    )
    working_directory = await _resolve_session_working_directory(session)

    async def _handle_regenerate() -> None:
        runtime = await _prepare_replay_runtime(sessionID, parent_message)
        await _stop_replay_execution(sessionID)
        rewind = await _rewind_goal_for_replay(
            sessionID,
            parent_message_id,
            getattr(parent_text_part, "text", "") or "",
        )
        try:
            updated_session = await SessionRevert.revert(sessionID, parent_message_id)
        except BaseException:
            await _undo_goal_rewind(sessionID, rewind)
            raise
        if rewind.event:
            await publish_event("session.goal.updated", rewind.event)
        refreshed_parent = await Message.get(sessionID, parent_message_id)
        if not refreshed_parent:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Parent message {parent_message_id} not found after revert",
            )

        await Instance.provide(
            directory=working_directory,
            init=instance_bootstrap,
            fn=lambda: _run_existing_user_message(
                sessionID,
                updated_session or session,
                refreshed_parent,
                working_directory,
                runtime=runtime,
            ),
        )

    _schedule_background_coro(
        _handle_regenerate(),
        session_id=sessionID,
        action="message.regenerate",
    )
    return {"status": "accepted", "sessionID": sessionID, "messageID": messageID}


@router.post(
    "/{sessionID}/message",
    summary="Send message",
    description="Send a new message and get AI response",
)
async def send_session_message(sessionID: str, request: PromptRequest, http_request: Request):
    """
    Send message to session
    
    Supports full agent loop with tool execution.
    Real-time updates are sent via the /event SSE endpoint.
    """
    log.info("session.message.send.start", {"sessionID": sessionID})
    
    from flocks.session.message import Message, MessageRole
    from flocks.server.routes.event import publish_event
    from flocks.utils.id import Identifier
    from flocks.tool.registry import ToolRegistry, ToolContext
    from flocks.agent.registry import Agent
    from flocks.project.instance import Instance
    import time
    import json
    import os
    
    session = await _get_session_by_id_unfiltered(sessionID)
    if not session:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Session {sessionID} not found"
        )
    current_user = require_user(http_request)
    _require_session_write_access(session, current_user)
    lifecycle_generation = Session.lifecycle_generation(sessionID)
    
    session, _ = await _prepare_session_agent_before_bootstrap(
        session,
        request.agent,
    )
    working_directory = await _resolve_session_working_directory(session)
    _validate_execution_mode_request(request)
    if request.execution_mode == SessionExecutionMode.GOAL:
        from flocks.session.goal import GoalManager

        objective = _extract_text_from_parts(request.parts).strip()
        state = await GoalManager.set_goal(sessionID, objective)
        await publish_event("session.goal.updated", {
            "sessionID": sessionID,
            "status": state.status,
            "objective": state.objective,
            "reason": state.last_reason,
        })
        request = request.model_copy(update={
            "parts": _replace_text_parts(
                request.parts,
                GoalManager.goal_prompt(state.objective),
            ),
            "display_text": request.display_text or objective,
        })
    
    log.info("session.message.send.processing", {
        "sessionID": sessionID,
        "working_directory": working_directory,
    })
    
    # Ensure instance is bootstrapped with MCP
    from flocks.project.bootstrap import instance_bootstrap
    
    try:
        result = await Instance.provide(
            directory=working_directory,
            init=instance_bootstrap,
            fn=lambda: _process_session_message(
                sessionID,
                session,
                request,
                working_directory,
                lifecycle_generation=lifecycle_generation,
                uploader_user_id=current_user.id,
            )
        )
        log.info("session.message.send.complete", {"sessionID": sessionID})
        return result
    except Exception as e:
        log.error("session.message.send.error", {
            "sessionID": sessionID,
            "error": str(e),
            "error_type": type(e).__name__,
        })
        raise


async def _get_last_model(session_id: str) -> Optional[Dict[str, str]]:
    """
    Get the last model used in the session (from last user message).
    Ported from original lastModel function.
    
    Returns:
        Dict with 'providerID' and 'modelID', or None
    """
    from flocks.session.message import Message
    
    try:
        # Get messages in reverse order (newest first)
        messages = await Message.list(session_id)
        
        # Find the last user message with model info
        for msg in reversed(messages):
            if msg.role == "user" and hasattr(msg, 'model') and msg.model:
                if isinstance(msg.model, dict) and 'providerID' in msg.model and 'modelID' in msg.model:
                    return msg.model
    except Exception as e:
        log.debug("session.last_model.error", {"error": str(e)})
    
    return None


def _parse_model_string(model: Optional[str]) -> Tuple[Optional[str], Optional[str]]:
    """Parse a provider/model string into separate IDs."""
    if not model:
        return None, None
    provider_id, sep, model_id = model.partition("/")
    if not sep or not provider_id or not model_id:
        return None, None
    return provider_id, model_id


async def _resolve_compaction_context(
    session_id: str,
    *,
    requested_agent: Optional[str] = None,
    requested_model: Optional[str] = None,
    explicit_provider_id: Optional[str] = None,
    explicit_model_id: Optional[str] = None,
) -> tuple[str, str, str]:
    """Resolve agent/provider/model for an explicit compaction request."""
    import os

    from flocks.agent.registry import Agent
    from flocks.config.config import Config
    from flocks.session.message import Message, MessageRole
    from flocks.storage.storage import Storage

    provider_id = explicit_provider_id
    model_id = explicit_model_id
    parsed_provider_id, parsed_model_id = _parse_model_string(requested_model)
    if not provider_id:
        provider_id = parsed_provider_id
    if not model_id:
        model_id = parsed_model_id

    agent_name = requested_agent or DEFAULT_AGENT

    try:
        messages = await Message.list(session_id)
    except Exception as exc:
        log.debug("session.compaction_context.messages_error", {
            "sessionID": session_id,
            "error": str(exc),
        })
        messages = []

    if not requested_agent:
        for msg in reversed(messages):
            if msg.role != MessageRole.USER:
                continue
            agent_name = getattr(msg, "agent", None) or agent_name
            model_dict = getattr(msg, "model", None)
            if isinstance(model_dict, dict):
                provider_id = provider_id or model_dict.get("providerID")
                model_id = model_id or model_dict.get("modelID")
            if provider_id and model_id:
                break

    if not provider_id or not model_id:
        try:
            overrides = await Storage.read("agent/model_overrides")
            if not isinstance(overrides, dict):
                overrides = {}
            override = overrides.get(agent_name) if agent_name else None
            if isinstance(override, dict):
                provider_id = provider_id or override.get("providerID")
                model_id = model_id or override.get("modelID")
        except Exception as exc:
            log.debug("session.compaction_context.agent_override_error", {
                "sessionID": session_id,
                "agent": agent_name,
                "error": str(exc),
            })

    if not provider_id or not model_id:
        try:
            agent = await Agent.get(agent_name) or await Agent.get(DEFAULT_AGENT)
            if agent and getattr(agent, "model", None):
                if isinstance(agent.model, dict):
                    provider_id = provider_id or agent.model.get("providerID") or agent.model.get("provider_id")
                    model_id = model_id or agent.model.get("modelID") or agent.model.get("model_id")
                else:
                    provider_id = provider_id or getattr(agent.model, "providerID", None) or getattr(agent.model, "provider_id", None)
                    model_id = model_id or getattr(agent.model, "modelID", None) or getattr(agent.model, "model_id", None)
        except Exception as exc:
            log.debug("session.compaction_context.agent_error", {
                "sessionID": session_id,
                "agent": agent_name,
                "error": str(exc),
            })

    if not provider_id or not model_id:
        try:
            default_llm = await Config.resolve_default_llm()
            if default_llm:
                provider_id = provider_id or default_llm["provider_id"]
                model_id = model_id or default_llm["model_id"]
        except Exception as exc:
            log.debug("session.compaction_context.default_model_error", {
                "sessionID": session_id,
                "error": str(exc),
            })

    if not provider_id or not model_id:
        try:
            last_model = await _get_last_model(session_id)
            if last_model:
                provider_id = provider_id or last_model.get("providerID")
                model_id = model_id or last_model.get("modelID")
        except Exception as exc:
            log.debug("session.compaction_context.last_model_error", {
                "sessionID": session_id,
                "error": str(exc),
            })

    if not provider_id or not model_id:
        provider_id = provider_id or os.environ.get("LLM_PROVIDER", "openai")
        model_id = model_id or os.environ.get("LLM_MODEL", "gpt-4-turbo-preview")

    return agent_name, provider_id, model_id


async def _run_session_compaction(session_id: str, **kwargs: Any) -> tuple[str, str, str]:
    """Execute session compaction directly without routing through the LLM loop.

    It holds the session's execution lease, as a runner does, for the whole
    compaction: a runner in another process cannot start meanwhile, and data
    retention there leaves the session alone. See ``_compact_session_owned``.
    """
    from flocks.session.ownership import SessionExecutionLease, current_lease

    if current_lease(session_id) is not None:
        return await _compact_session_owned(session_id, **kwargs)
    lease = await SessionExecutionLease.acquire(session_id)
    if lease is None:
        raise ValueError(f"Session {session_id} is running; compact it once that finished")
    async with lease:
        return await _compact_session_owned(session_id, **kwargs)


async def _compact_session_owned(
    session_id: str,
    *,
    requested_agent: Optional[str] = None,
    requested_model: Optional[str] = None,
    explicit_provider_id: Optional[str] = None,
    explicit_model_id: Optional[str] = None,
    parent_message_id: Optional[str] = None,
    auto: bool = False,
    event_publish_callback=None,
    focus_instruction: Optional[str] = None,
    working_directory: Optional[str] = None,
) -> tuple[str, str, str]:
    """The compaction itself, holding the session's execution lease.

    ``focus_instruction`` is forwarded verbatim to ``run_compaction`` so
    manual ``/compact <focus>`` invocations can bias what the
    summariser preserves.  ``None``/empty leaves the default behaviour.
    """
    from flocks.session.lifecycle.compaction import run_compaction
    from flocks.session.lifecycle.compaction.compaction import (
        pop_last_compaction_error,
    )
    from flocks.session.lifecycle.revert import SessionRevert
    from flocks.session.message import Message, MessageRole

    session = await Session.get_by_id(session_id)
    if not session:
        raise ValueError(f"Session {session_id} not found")
    if working_directory:
        session = session.model_copy(update={"directory": working_directory})

    await SessionRevert.cleanup(session)
    agent_name, provider_id, model_id = await _resolve_compaction_context(
        session_id,
        requested_agent=requested_agent,
        requested_model=requested_model,
        explicit_provider_id=explicit_provider_id,
        explicit_model_id=explicit_model_id,
    )

    messages = await Message.list(session_id)
    if not parent_message_id:
        for msg in reversed(messages):
            if msg.role == MessageRole.USER:
                parent_message_id = msg.id
                break
    if not parent_message_id:
        raise ValueError(f"Session {session_id} has no user message to compact")

    progress_callback = None
    if event_publish_callback is not None:
        # Adapter that bridges ``ProgressCallback(stage, data)`` from the
        # compaction pipeline onto the existing ``publish_event`` SSE
        # channel.  We use a dedicated event type
        # (``session.compaction_progress``) rather than overloading
        # ``session.status`` so the front-end dispatcher stays
        # explicit and unrelated consumers do not need to filter on a
        # nested ``stage`` field.  ``sessionID`` is closed over from
        # the enclosing scope.
        async def progress_callback(stage: str, data: dict) -> None:
            await event_publish_callback("session.compaction_progress", {
                "sessionID": session_id,
                "stage": stage,
                "data": data,
            })

    async def publish_current_context_usage() -> None:
        await _publish_context_usage_update(
            event_publish_callback,
            session_id,
            session=session,
            provider_id=provider_id,
            model_id=model_id,
        )

    # Drop anything stashed by an earlier (auto) round so a legitimate skip
    # below is not reported with a stale provider error.
    pop_last_compaction_error(session_id)
    try:
        result = await run_compaction(
            session_id,
            parent_message_id=parent_message_id,
            messages=messages,
            provider_id=provider_id,
            model_id=model_id,
            auto=auto,
            event_publish_callback=event_publish_callback,
            status_after="idle",
            focus_instruction=focus_instruction,
            progress_callback=progress_callback,
        )
    except Exception:
        await publish_current_context_usage()
        raise
    if result == "skipped":
        # The summary model call failed (no provider / timeout / API error):
        # ``SessionCompaction.process`` leaves the transcript untouched and
        # stashes the provider error.  A manual /summarize must not end in
        # silence, so surface that text the same way the "stop" path does.
        detail = pop_last_compaction_error(session_id)
        if detail:
            await publish_current_context_usage()
            raise RuntimeError(detail)
    if result == "stop":
        # ``SessionCompaction.process`` swallows the underlying provider
        # exception (so the loop path stays simple) but stashes the
        # user-facing message via ``_record_compaction_error``.  Surface
        # it verbatim here so the SSE ``session.error`` payload — and
        # therefore the front-end toast — shows the provider's original
        # error text instead of an opaque "Compaction failed".
        await publish_current_context_usage()
        detail = pop_last_compaction_error(session_id) or "Compaction failed"
        raise RuntimeError(detail)
    await publish_current_context_usage()
    return agent_name, provider_id, model_id


# JSON repair utilities — delegated to flocks.utils.json_repair
_parse_json_robust = parse_json_robust
_repair_json_string = repair_truncated_json


def _check_session_aborted(sessionID: str, checkpoint: str, step: int, **extra_context) -> bool:
    """
    Check whether the session has been aborted.
    
    Args:
        sessionID: Session ID
        checkpoint: Checkpoint name, such as "before_step", "in_stream", or "skip_tool_processing".
        step: Current step number.
        **extra_context: Additional log context.
    
    Returns:
        True when the session has been aborted and execution should stop.
    """
    from flocks.session.core.status import SessionStatus
    
    current_status = SessionStatus.get(sessionID)
    if current_status and current_status.type == "idle":
        log.info(f"session.message.aborted.{checkpoint}", {
            "sessionID": sessionID,
            "step": step,
            **extra_context,
        })
        return True
    return False


async def _validate_chat_upload_parts(session_id: str, owner_id: Optional[str], parts: List[Dict[str, Any]]) -> None:
    from flocks.session.files import resolve_chat_upload, restore_chat_upload_source

    for part in parts:
        upload_id = str(part.get("uploadID") or "").strip()
        if not upload_id:
            continue
        if not owner_id:
            raise HTTPException(status_code=400, detail="Chat upload owner is unavailable")
        if part.get("type") != "file" or not isinstance(part.get("mime"), str) or not part["mime"]:
            raise HTTPException(status_code=400, detail="Chat upload requires a file part and MIME type")
        try:
            # Brought back first when the staged upload is missing locally.
            await restore_chat_upload_source(session_id, owner_id, upload_id)
            resolve_chat_upload(session_id, owner_id, upload_id)
        except (FileNotFoundError, OSError, ValueError) as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc


async def _process_session_message(
    sessionID: str,
    session,
    request: PromptRequest,
    working_directory: str,
    *,
    lifecycle_generation: Optional[int] = None,
    uploader_user_id: Optional[str] = None,
):
    from flocks.session.interaction_queue import InteractionQueue

    await _validate_chat_upload_parts(sessionID, uploader_user_id, request.parts or [])
    hold = InteractionQueue.hold_uploads(sessionID, uploader_user_id or "", request.parts or [])
    try:
        return await _process_session_message_impl(
            sessionID, session, request, working_directory,
            lifecycle_generation=lifecycle_generation,
            uploader_user_id=uploader_user_id,
        )
    finally:
        InteractionQueue.release_uploads(hold)


async def _process_session_message_impl(
    sessionID: str,
    session,
    request: PromptRequest,
    working_directory: str,
    *,
    lifecycle_generation: Optional[int] = None,
    uploader_user_id: Optional[str] = None,
):
    """
    Process session message within Instance context.
    
    Delegates to SessionLoop.run() for the agent loop, eliminating
    duplicated loop/streaming/tool logic. SSE events flow through
    the event_publish_callback → StreamProcessor pipeline.
    """
    from flocks.session.message import Message, MessageRole
    from flocks.session.lifecycle.revert import SessionRevert
    from flocks.server.routes.event import publish_event
    from flocks.utils.id import Identifier
    from flocks.tool.registry import ToolRegistry
    from flocks.agent.registry import Agent
    from flocks.provider.provider import Provider
    from flocks.session.session_loop import SessionLoop, LoopCallbacks
    from flocks.session.runner import RunnerCallbacks
    import time
    import os

    if lifecycle_generation is None:
        lifecycle_generation = Session.lifecycle_generation(sessionID)
    
    # Clean up revert state before processing (Flocks compatibility)
    await SessionRevert.cleanup(session)
    
    # ------------------------------------------------------------------
    # 1. Extract text content
    # ------------------------------------------------------------------
    text_content = ""
    has_non_text_parts = False
    text_chunks = []
    for part in request.parts:
        part_type = part.get("type")
        if part_type == "text":
            text_chunks.append(part.get("text", ""))
        elif part_type:
            has_non_text_parts = True
    text_content = "".join(text_chunks)

    # Allow messages that only contain attachments (e.g. an image with no caption)
    if not text_content.strip() and not has_non_text_parts:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Message must contain text or at least one attachment"
        )

    log.info("session.message.received", {
        "sessionID": sessionID,
        "content_length": len(text_content),
        "has_non_text_parts": has_non_text_parts,
    })
    
    # ------------------------------------------------------------------
    # 2. Resolve agent and model (5-level priority)
    # ------------------------------------------------------------------
    agent_name = request.agent or session.agent or await Agent.default_agent()
    agent = await Agent.get(agent_name) or await Agent.get(DEFAULT_AGENT)
    try:
        from flocks.session.agent_policy import (
            AgentSessionPolicyError,
            prepare_session_for_agent,
        )

        session = await prepare_session_for_agent(session, agent)
    except AgentSessionPolicyError as exc:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=str(exc),
        ) from exc
    
    auto_failover = bool(
        is_model_auto_session_category(getattr(session, "category", "user"))
        and getattr(session, "model_auto", False)
        and not request.model
    )
    if auto_failover:
        from flocks.config.config import Config

        default_llm = await Config.resolve_default_llm()
        if not default_llm:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Auto mode requires a configured default LLM",
            )
        provider_id = default_llm["provider_id"]
        model_id = default_llm["model_id"]
        model_source = "auto_primary"
    else:
        provider_id, model_id, model_source = await _resolve_model(
            request, agent, sessionID
        )
    
    log.info("session.message.model", {
        "provider_id": provider_id,
        "model_id": model_id,
        "source": model_source,
    })

    if request.model:
        pinned_session = await Session.update(
            session.project_id,
            sessionID,
            **Session.explicit_model_updates(provider_id, model_id),
        )
        if pinned_session is not None:
            session = pinned_session
        else:
            session.provider = provider_id
            session.model = model_id
            session.model_pinned = True
            session.model_auto = False
        SessionLoop.clear_auto_failover_state(sessionID)
    
    # Ensure providers are initialized and configured
    Provider._ensure_initialized()
    from flocks.config.config import Config
    config = await Config.get()
    await Provider.apply_config(config, provider_id=provider_id)

    provider = Provider.get(provider_id)
    if not provider and not auto_failover:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Provider {provider_id} not found"
        )
    
    ToolRegistry.init()

    # ------------------------------------------------------------------
    # 3. Create user message and publish SSE events
    # ------------------------------------------------------------------
    from flocks.session import turn_receipt

    now_ms = int(time.time() * 1000)
    user_message_id = request.messageID or Identifier.create("message")
    user_part_id = Identifier.create("part")
    turn_receipt.note_user_message(user_message_id)

    # display_text (optional) is UI-only. The stored text part must stay as the
    # real prompt so SessionLoop, hooks, title generation, and queued prompts keep
    # seeing the same content the model receives.
    display_text = getattr(request, "display_text", None)
    display_metadata = {"displayText": display_text} if display_text else None

    _is_no_reply = bool(request.noReply)
    user_message = await _persist_active_session_write(
        sessionID,
        lambda: Message.create(
            session_id=sessionID,
            role=MessageRole.USER,
            content=text_content,
            id=user_message_id,
            time={"created": now_ms},
            agent=agent_name,
            model={"providerID": provider_id, "modelID": model_id},
            executionMode=request.execution_mode,
            system=request.system,
            part_id=user_part_id,
            part_metadata=display_metadata,
            synthetic=True if _is_no_reply else None,
        ),
        expected_generation=lifecycle_generation,
        expected_agent=agent_name,
    )
    user_message_id = user_message.id
    
    await publish_event("message.updated", {
        "info": {
            "id": user_message_id,
            "sessionID": sessionID,
            "role": "user",
            "time": {"created": now_ms},
            "agent": agent_name,
            "model": {"providerID": provider_id, "modelID": model_id},
            "executionMode": request.execution_mode.value,
        }
    })
    _part_event: dict = {
        "id": user_part_id,
        "messageID": user_message_id,
        "sessionID": sessionID,
        "type": "text",
        "text": text_content,
        "time": {"start": now_ms},
    }
    if display_metadata:
        _part_event["metadata"] = display_metadata
    if _is_no_reply:
        _part_event["synthetic"] = True
    await publish_event("message.part.updated", {"part": _part_event})

    # ------------------------------------------------------------------
    # 3a. Persist any non-text parts (file/image attachments) so the
    #     SessionLoop sees them when building the LLM request. Without
    #     this, file parts sent from clients would be silently dropped.
    #
    #     For ``data:`` URLs we materialize the bytes to disk and store
    #     a ``file://`` reference instead. Keeping the raw base64 string
    #     in the message database is dangerous: any code path that later
    #     stringifies the part (legacy LLM adapters, logging, compaction)
    #     would tokenize hundreds of KB of base64 and blow past the
    #     model's context window.
    # ------------------------------------------------------------------
    from flocks.session.message import FilePart

    for raw_part in request.parts or []:
        part_type = raw_part.get("type")
        if part_type == "text":
            continue  # Already stored as the message's TextPart above
        if part_type == "file":
            upload_id = str(raw_part.get("uploadID") or "").strip()
            url = raw_part.get("url") or ""
            mime = raw_part.get("mime") or ""
            source = raw_part.get("source") if isinstance(raw_part.get("source"), dict) else None
            if (not url and not upload_id) or not mime:
                log.warn("session.message.file_part.skipped", {
                    "sessionID": sessionID,
                    "reason": "missing url or mime",
                })
                continue
            # Materialize ``data:`` URLs to disk before persisting the part.
            if url.startswith("data:"):
                url = _materialize_data_url_part(
                    sessionID,
                    url,
                    mime,
                    raw_part.get("filename"),
                    failure_event="session.message.file_part.materialize_failed",
                )
                await _store_materialized_part(url)
            file_part_id = raw_part.get("id") or upload_id or Identifier.create("part")
            async def persist_file_part():
                nonlocal url, source
                from flocks.session.files import (
                    bind_staged_chat_upload,
                    move_stored_upload,
                    resolve_chat_upload,
                    restore_chat_upload,
                    restore_chat_upload_source,
                )

                original = None
                target = None
                try:
                    if upload_id:
                        await restore_chat_upload_source(sessionID, uploader_user_id or "", upload_id)
                        original = resolve_chat_upload(sessionID, uploader_user_id or "", upload_id)
                        target = bind_staged_chat_upload(sessionID, uploader_user_id or "", upload_id)
                        if original != target:
                            await move_stored_upload(original, target)
                        url = target.as_uri()
                        source = {"root": "session-upload", "path": target.name}
                    file_part = FilePart(
                        id=file_part_id,
                        sessionID=sessionID,
                        messageID=user_message_id,
                        mime=mime,
                        filename=raw_part.get("filename"),
                        url=url,
                        source=source,
                    )
                    await Message.add_part(sessionID, user_message_id, file_part)
                except BaseException:
                    if original is not None and target is not None and original != target:
                        # Message.add_part can fail after changing its cache or
                        # storage. A referenced file must remain retryable.
                        stored = await Message.get_with_parts_lazy(sessionID, user_message_id)
                        referenced = stored and any(
                            part.type == "file" and part.url == target.as_uri()
                            for part in stored.parts
                        )
                        if not referenced:
                            restore_chat_upload(original, target)
                            try:
                                await move_stored_upload(target, original)
                            except Exception as exc:
                                log.warn("session.upload.store_restore_failed", {
                                    "sessionID": sessionID,
                                    "error_type": type(exc).__name__,
                                })
                    raise

            try:
                await _persist_active_session_write(
                    sessionID,
                    persist_file_part,
                    expected_generation=lifecycle_generation,
                )
            except (FileNotFoundError, OSError, ValueError) as exc:
                raise HTTPException(status_code=400, detail=str(exc)) from exc
            from flocks.session.files import public_resource_id, session_upload_part_path

            # Same criterion as the history serializer: only a part stored in
            # this Session's uploads directory is a context resource.
            resource_id = None
            public_url = url
            if session_upload_part_path(sessionID, SimpleNamespace(url=url)) is not None:
                resource_id = public_resource_id(user_message_id, str(file_part_id))
                public_url = f"/api/session/{sessionID}/context/files/{resource_id}/preview"
            await publish_event("message.part.updated", {
                "part": {
                    "id": file_part_id,
                    "messageID": user_message_id,
                    "sessionID": sessionID,
                    "type": "file",
                    "mime": mime,
                    "filename": raw_part.get("filename"),
                    "url": public_url,
                    "resourceID": resource_id,
                    "time": {"start": now_ms},
                }
            })

    # ------------------------------------------------------------------
    # noReply: store message only, skip AI loop
    # ------------------------------------------------------------------
    if request.noReply:
        log.info("session.message.no_reply", {"sessionID": sessionID})

        # Optionally inject a mock assistant reply
        if request.mockReply:
            mock_msg_id = Identifier.ascending("message")
            mock_part_id = Identifier.ascending("part")
            mock_now = int(time.time() * 1000)
            await _persist_active_session_write(
                sessionID,
                lambda: Message.create(
                    session_id=sessionID,
                    role=MessageRole.ASSISTANT,
                    content=request.mockReply,
                    id=mock_msg_id,
                    time={"created": mock_now, "completed": mock_now},
                    parentID=user_message_id,
                    modelID="mock",
                    part_id=mock_part_id,
                ),
                expected_generation=lifecycle_generation,
            )
            await publish_event("message.updated", {
                "info": {
                    "id": mock_msg_id,
                    "sessionID": sessionID,
                    "role": "assistant",
                    "time": {"created": mock_now, "completed": mock_now},
                    "parentID": user_message_id,
                    "modelID": "mock",
                    "finish": "stop",
                }
            })
            await publish_event("message.part.updated", {
                "part": {
                    "id": mock_part_id,
                    "messageID": mock_msg_id,
                    "sessionID": sessionID,
                    "type": "text",
                    "text": request.mockReply,
                    "time": {"start": mock_now, "end": mock_now},
                },
            })

        await _publish_context_usage_update(
            publish_event,
            sessionID,
            session=session,
            provider_id=provider_id,
            model_id=model_id,
        )

        return {
            "id": user_message_id,
            "sessionID": sessionID,
            "role": "user",
            "content": text_content,
            "finish": "stop",
        }

    # ------------------------------------------------------------------
    # 4. Run unified SessionLoop (replaces ~700 lines of inline loop)
    # ------------------------------------------------------------------
    async def _on_error(error: str):
        await publish_event("session.error", {
            "sessionID": sessionID,
            "error": {"name": "SessionError", "message": error, "data": {"message": error}},
        })
    
    loop_callbacks = LoopCallbacks(
        on_error=_on_error,
        event_publish_callback=publish_event,
    )
    
    result = await SessionLoop.run(
        session_id=sessionID,
        provider_id=provider_id,
        model_id=model_id,
        agent_name=agent_name,
        callbacks=loop_callbacks,
        working_directory=working_directory,
        auto_failover=auto_failover,
    )

    # ------------------------------------------------------------------
    # 4a. already_running: user message was persisted but the active loop
    #     will pick it up on the next iteration — do NOT emit a fake empty
    #     assistant completion event here.
    # ------------------------------------------------------------------
    if result.action == "queued":
        log.info("session.message.queued", {
            "sessionID": sessionID,
            "user_message_id": user_message_id,
            "reason": "loop already running; message queued for next iteration",
        })
        return {
            "id": user_message_id,
            "sessionID": sessionID,
            "role": "user",
            "content": text_content,
            "status": "queued",
        }
    
    # ------------------------------------------------------------------
    # 5. Build response from loop result
    # ------------------------------------------------------------------
    end_ms = int(time.time() * 1000)
    finish_reason = "stop"
    final_content = ""
    assistant_message_id = None
    final_tokens = {"input": 0, "output": 0, "reasoning": 0, "cache": {"read": 0, "write": 0}}
    actual_provider_id = result.provider_id or provider_id
    actual_model_id = result.model_id or model_id
    
    if result.last_message:
        assistant_message_id = result.last_message.id
        final_content = await Message.get_text_content(result.last_message)
        final_tokens = token_usage_to_dict(getattr(result.last_message, "tokens", None))
        finish = getattr(result.last_message, 'finish', None)
        if finish:
            finish_reason = finish
        actual_provider_id = (
            getattr(result.last_message, "providerID", None)
            or actual_provider_id
        )
        actual_model_id = (
            getattr(result.last_message, "modelID", None)
            or actual_model_id
        )
    
    if result.action == "error":
        finish_reason = "error"
        if not assistant_message_id:
            assistant_message_id = Identifier.create("message")
    
    if not assistant_message_id:
        assistant_message_id = Identifier.create("message")
    
    # Publish final completion event
    await publish_event("message.updated", {
        "info": {
            "id": assistant_message_id,
            "sessionID": sessionID,
            "role": "assistant",
            "time": {"created": now_ms, "completed": end_ms},
            "parentID": user_message_id,
            "modelID": actual_model_id,
            "providerID": actual_provider_id,
            "mode": agent_name,
            "agent": agent_name,
            "path": {"cwd": working_directory, "root": working_directory},
            "cost": 0,
            "tokens": final_tokens,
            "finish": finish_reason,
        }
    })
    await _publish_context_usage_update(
        publish_event,
        sessionID,
        session=session,
        provider_id=actual_provider_id,
        model_id=actual_model_id,
    )
    
    # Collect parts for the response
    all_parts = []
    if result.last_message:
        parts = await Message.parts(result.last_message.id, sessionID)
        for part in parts:
            part_dict = part.model_dump() if hasattr(part, 'model_dump') else {}
            all_parts.append(part_dict)
    
    log.info("message.completed", {
        "id": assistant_message_id,
        "session_id": sessionID,
        "role": "assistant",
        "content_length": len(final_content),
        "total_steps": result.metadata.get("steps", 0),
    })
    
    # Generate session title after first user message (async, don't block response)
    try:
        from flocks.session.lifecycle.title import SessionTitle
        import asyncio
        loop = asyncio.get_running_loop()
        from flocks.server.routes.event import publish_event
        title_task = loop.create_task(
            SessionTitle.generate_title_after_first_message(
                session_id=sessionID,
                model_id=actual_model_id,
                provider_id=actual_provider_id,
                event_publish_callback=publish_event,
            )
        )
        if not hasattr(router, '_title_tasks'):
            router._title_tasks = set()
        router._title_tasks.add(title_task)
        title_task.add_done_callback(lambda t: router._title_tasks.discard(t))
    except Exception as e:
        log.warn("session.title.trigger_error", {"error": str(e)})
    
    return {
        "info": {
            "id": assistant_message_id,
            "sessionID": sessionID,
            "role": "assistant",
            "time": {"created": now_ms, "completed": end_ms},
            "parentID": user_message_id,
            "modelID": actual_model_id,
            "providerID": actual_provider_id,
            "mode": agent_name,
            "agent": agent_name,
            "path": {"cwd": working_directory, "root": working_directory},
            "cost": 0,
            "tokens": {"input": 0, "output": 0, "reasoning": 0, "cache": {"read": 0, "write": 0}},
            "finish": finish_reason,
        },
        "parts": all_parts if all_parts else [{
            "id": Identifier.create("part"),
            "messageID": assistant_message_id,
            "sessionID": sessionID,
            "type": "text",
            "text": final_content,
        }]
    }


async def _resolve_model(request, agent, sessionID: str):
    """
    Resolve model using the same explicit-pinning semantics as SessionLoop.

    Priority:
    1. request.model (explicit in request)
    2. session pinned model
    3. agent model override (storage) or agent.model (AgentInfo field)
    4. parent session pinned model
    5. config model (flocks.json)
    6. lastModel(sessionID) (last used model)
    7. environment variables (final fallback)

    Returns (provider_id, model_id, source).
    """
    import os
    
    provider_id = None
    model_id = None
    source = "unknown"
    
    # Priority 1: User specified model
    if request.model:
        provider_id = request.model.providerID
        model_id = request.model.modelID
        source = "request"

    # Priority 2: Session explicit pin
    session = None
    if not provider_id or not model_id:
        session = await Session.get_by_id(sessionID)
        if Session.has_pinned_model(session):
            provider_id = session.provider
            model_id = session.model
            source = "session"

    # Priority 3: Agent model (override from storage, then AgentInfo.model)
    if not provider_id or not model_id:
        # 2a: Check model overrides from storage (set via UI for native agents)
        from flocks.storage.storage import Storage
        try:
            overrides = await Storage.read("agent/model_overrides")
            if not isinstance(overrides, dict):
                overrides = {}
        except Exception:
            overrides = {}
        agent_name = agent.name if hasattr(agent, 'name') else None
        if agent_name and agent_name in overrides:
            override = overrides[agent_name]
            override_provider = override.get('providerID')
            override_model = override.get('modelID')
            if override_provider and override_model:
                provider_id = override_provider
                model_id = override_model
                source = "agent_override"
        
        # 2b: Check AgentInfo.model field (for custom agents or programmatic config)
        if not provider_id or not model_id:
            if hasattr(agent, 'model') and agent.model:
                if isinstance(agent.model, dict):
                    provider_id = agent.model.get('providerID') or agent.model.get('provider_id')
                    model_id = agent.model.get('modelID') or agent.model.get('model_id')
                else:
                    provider_id = getattr(agent.model, 'provider_id', None) or getattr(agent.model, 'providerID', None)
                    model_id = getattr(agent.model, 'model_id', None) or getattr(agent.model, 'modelID', None)
                if provider_id and model_id:
                    source = "agent"

    # Priority 4: Parent session explicit model
    if not provider_id or not model_id:
        if session is None:
            session = await Session.get_by_id(sessionID)
        parent_id = getattr(session, "parent_id", None) if session else None
        if parent_id:
            parent = await Session.get_by_id(parent_id)
            if Session.has_pinned_model(parent):
                provider_id = parent.provider
                model_id = parent.model
                source = "parent_session"

    # Priority 5: System default from config (default_models.llm -> config.model fallback)
    if not provider_id or not model_id:
        try:
            from flocks.config.config import Config
            default_llm = await Config.resolve_default_llm()
            if default_llm:
                provider_id = default_llm["provider_id"]
                model_id = default_llm["model_id"]
                source = "config"
        except Exception:
            pass

    # Priority 6: Last model used in session
    if not provider_id or not model_id:
        last_model = await _get_last_model(sessionID)
        if last_model:
            last_provider = last_model.get('providerID')
            last_model_id = last_model.get('modelID')
            if last_provider and last_model_id:
                provider_id = last_provider
                model_id = last_model_id
                source = "lastModel"

    # Priority 7: Fallback to environment variables
    if not provider_id or not model_id:
        provider_id = os.environ.get("LLM_PROVIDER", "openai")
        model_id = os.environ.get("LLM_MODEL", "gpt-4-turbo-preview")
        source = "env_default"
    
    return provider_id, model_id, source


def _extract_text_from_parts(parts: List[Dict[str, Any]]) -> str:
    return "".join(part.get("text", "") for part in parts if part.get("type") == "text")


def _validate_execution_mode_request(request: PromptRequest) -> None:
    if request.execution_mode != SessionExecutionMode.GOAL:
        return
    objective = _extract_text_from_parts(request.parts).strip()
    if not objective:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Goal mode requires a non-empty text objective",
        )
    if any(part.get("type") != "text" for part in request.parts):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Goal mode does not support attachments",
        )


def _event_text_for_execution_mode(
    parts: List[Dict[str, Any]],
    execution_mode: SessionExecutionMode,
) -> str:
    text = _extract_text_from_parts(parts)
    if execution_mode == SessionExecutionMode.GOAL:
        return f"/goal {text.strip()}"
    return text


def _replace_text_parts(
    parts: Optional[List[Dict[str, Any]]],
    text: str,
    text_metadata: Optional[Dict[str, Any]] = None,
) -> List[Dict[str, Any]]:
    updated_parts: List[Dict[str, Any]] = []
    replaced = False
    for part in parts or []:
        if part.get("type") == "text" and not replaced:
            next_part = dict(part)
            next_part["text"] = text
            if text_metadata:
                merged_metadata = dict(next_part.get("metadata") or {})
                merged_metadata.update(text_metadata)
                next_part["metadata"] = merged_metadata
            updated_parts.append(next_part)
            replaced = True
            continue
        if part.get("type") == "text":
            continue
        updated_parts.append(dict(part))

    if not replaced:
        next_part: Dict[str, Any] = {"type": "text", "text": text}
        if text_metadata:
            next_part["metadata"] = dict(text_metadata)
        updated_parts.insert(0, next_part)
    return updated_parts


def _coerce_model_for_prompt_request(model: Any):
    import types

    if not model:
        return None
    if isinstance(model, str):
        if "/" not in model:
            return None
        provider_id, model_id = model.split("/", 1)
        return types.SimpleNamespace(providerID=provider_id, modelID=model_id)
    if isinstance(model, dict):
        provider_id = model.get("providerID") or model.get("provider_id")
        model_id = model.get("modelID") or model.get("model_id")
        if provider_id and model_id:
            return types.SimpleNamespace(providerID=provider_id, modelID=model_id)
        return None
    return model


def _prompt_queue_lock(session_id: str) -> asyncio.Lock:
    if not hasattr(router, "_prompt_queue_drain_locks"):
        router._prompt_queue_drain_locks = {}
    locks = router._prompt_queue_drain_locks
    lock = locks.get(session_id)
    if lock is None:
        lock = asyncio.Lock()
        locks[session_id] = lock
    return lock


def _is_prompt_chain_active(session_id: str) -> bool:
    return session_id in getattr(router, "_prompt_queue_active_sessions", set())


def _is_session_busy_for_move(session_id: str) -> bool:
    """Cover loop execution and route-owned background work during a move."""

    from flocks.session.session_loop import SessionLoop

    return (
        Session.has_active_operations(session_id)
        or SessionLoop.is_running(session_id)
        or _is_prompt_chain_active(session_id)
        or has_pending_session_tasks(session_id)
    )


def _set_prompt_chain_active(session_id: str, active: bool) -> None:
    if not hasattr(router, "_prompt_queue_active_sessions"):
        router._prompt_queue_active_sessions = set()
    active_sessions = router._prompt_queue_active_sessions
    if active:
        active_sessions.add(session_id)
    else:
        active_sessions.discard(session_id)


async def _publish_prompt_queue(session_id: str) -> None:
    from flocks.server.routes.event import publish_event
    from flocks.session.interaction_queue import InteractionQueue

    items = await InteractionQueue.list(session_id)
    await publish_event("session.prompt_queue.updated", {
        "sessionID": session_id,
        "items": [item.model_dump() for item in items],
    })


async def _store_materialized_part(url: str) -> None:
    """Keep a data URL that was written to the uploads directory in the database too."""
    if not url.startswith("file:"):
        return
    from flocks.session.files import store_upload
    from flocks.session.utils.file_extractor import file_url_to_path

    await store_upload(Path(file_url_to_path(url)))


def _materialize_queued_parts(session_id: str, parts: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Persist queued data URLs so large base64 payloads do not sit in memory."""
    prepared: List[Dict[str, Any]] = []
    for part in parts:
        next_part = dict(part)
        url = next_part.get("url")
        if next_part.get("type") == "file" and isinstance(url, str) and url.startswith("data:"):
            mime = next_part.get("mime") or ""
            filename = next_part.get("filename")
            next_part["url"] = _materialize_data_url_part(session_id, url, mime, filename)
        prepared.append(next_part)
    return prepared


def _event_from_queued_prompt(item, working_directory: str):
    from flocks.input.events import UserInputEvent

    return UserInputEvent(
        source_type="webui",
        sessionID=item.sessionID,
        text=_event_text_for_execution_mode(item.parts, item.executionMode),
        parts=[dict(part) for part in item.parts],
        agent=item.agent,
        model=item.model,
        variant=item.variant,
        metadata={
            "_sessionLifecycleGeneration": Session.lifecycle_generation(item.sessionID),
            **(
                {"_uploaderUserID": item.execution_context.get("_uploaderUserID")}
                if isinstance(item.execution_context, dict)
                and item.execution_context.get("_uploaderUserID")
                else {}
            ),
        },
        display_text=item.display_text,
        messageID=item.messageID,
        noReply=item.noReply,
        mockReply=item.mockReply,
        tools=item.tools,
        system=item.system,
        executionMode=item.executionMode,
        working_directory=working_directory,
    )


class _QueuedSessionMissing(RuntimeError):
    """A queued prompt's session is gone by the time its turn comes."""


async def _drain_prompt_queue_locked(session_id: str, working_directory: str) -> bool:
    from flocks.hooks.execution import execution_context_scope
    from flocks.project.bootstrap import instance_bootstrap
    from flocks.project.instance import Instance
    from flocks.session import turn_receipt
    from flocks.session.interaction_queue import InteractionQueue
    from flocks.session.session_loop import SessionLoop

    while True:
        if SessionLoop.is_running(session_id):
            return False

        item = await InteractionQueue.pop_next(session_id)
        if item is None:
            await _publish_prompt_queue(session_id)
            return True

        owner_id = str((item.execution_context or {}).get("_uploaderUserID") or "")
        # A queue item may be dispatched by a different worker task than the
        # request that submitted it. Restore the item's captured context (e.g.
        # trusted identity transfer) and never inherit unrelated worker state.
        captured = dict(item.execution_context or {})
        turn_id = captured.pop("_turnID", None)
        hold = InteractionQueue.hold_uploads(session_id, owner_id, item.parts)
        try:
            await _publish_prompt_queue(session_id)
            # The item's receipt moves on from the moment it left the queue:
            # a failure while getting it ready ends its turn as failed.
            async with turn_receipt.running(session_id, turn_id):
                session = await Session.get_by_id(session_id)
                if not session:
                    raise _QueuedSessionMissing(session_id)

                event = _event_from_queued_prompt(item, working_directory)
                session, _ = await _prepare_session_agent_before_bootstrap(
                    session,
                    event.agent,
                )
                item_working_directory = await _resolve_session_working_directory(session)
                event.working_directory = item_working_directory
                log.info("session.prompt_queue.dispatch", {
                    "sessionID": session_id,
                    "queueID": item.id,
                })
                with execution_context_scope(captured, inherit=False):
                    await Instance.provide(
                        directory=item_working_directory,
                        init=instance_bootstrap,
                        fn=lambda: _dispatch_sse_input(
                            session_id, session, event, item_working_directory
                        ),
                    )
        except _QueuedSessionMissing:
            log.warn("session.prompt_queue.session_missing", {"sessionID": session_id, "queueID": item.id})
            continue
        finally:
            InteractionQueue.release_uploads(hold)


async def _run_prompt_event_chain(session_id: str, session, event, working_directory: str) -> None:
    from flocks.project.bootstrap import instance_bootstrap
    from flocks.project.instance import Instance
    from flocks.session import turn_receipt

    try:
        async with _prompt_queue_lock(session_id):
            dispatch_failed = False
            try:
                async with turn_receipt.running(session_id, (event.metadata or {}).get("_turnID")):
                    await Instance.provide(
                        directory=working_directory,
                        init=instance_bootstrap,
                        fn=lambda: _dispatch_sse_input(session_id, session, event, working_directory),
                    )
            except Exception:
                dispatch_failed = True
                raise
            finally:
                try:
                    await _drain_prompt_queue_locked(session_id, working_directory)
                except Exception as drain_exc:
                    if dispatch_failed:
                        log.error("session.prompt_queue.drain_after_error_failed", {
                            "sessionID": session_id,
                            "error": str(drain_exc),
                        })
                    else:
                        raise
    finally:
        _set_prompt_chain_active(session_id, False)


async def _schedule_prompt_queue_drain(session_id: str, working_directory: str) -> None:
    max_attempts = 80
    retry_interval_s = 0.25

    async def _run() -> None:
        try:
            async with _prompt_queue_lock(session_id):
                for attempt in range(max_attempts):
                    completed = await _drain_prompt_queue_locked(session_id, working_directory)
                    if completed:
                        return
                    await asyncio.sleep(retry_interval_s)
                log.warn("session.prompt_queue.drain_retry_exhausted", {
                    "sessionID": session_id,
                    "attempts": max_attempts,
                })
        finally:
            _set_prompt_chain_active(session_id, False)

    _set_prompt_chain_active(session_id, True)
    _schedule_background_coro(
        _run(),
        session_id=session_id,
        action="prompt_queue.drain",
    )


async def _wait_for_session_idle(session_id: str, timeout_s: float = 5.0) -> None:
    await _wait_for_sessions_idle([session_id], timeout_s=timeout_s)


async def _wait_for_sessions_idle(session_ids: List[str], timeout_s: float = 5.0) -> None:
    from flocks.session.session_loop import SessionLoop

    pending = set(session_ids)
    if not pending:
        return

    deadline = time.time() + timeout_s
    while pending:
        running = {sid for sid in pending if SessionLoop.is_running(sid)}
        if not running:
            return
        now = time.time()
        if now >= deadline:
            log.warn("session.wait_idle.timeout", {
                "session_ids": sorted(running),
                "timeout_s": timeout_s,
            })
            return
        pending = running
        await asyncio.sleep(min(0.05, max(0.0, deadline - now)))


def _build_prompt_request_from_event(event, prompt_text: str, display_text: Optional[str] = None):
    import types

    return types.SimpleNamespace(
        parts=_replace_text_parts(event.parts, prompt_text, event.metadata or None),
        display_text=display_text,
        agent=event.agent,
        model=_coerce_model_for_prompt_request(event.model),
        variant=event.variant,
        messageID=event.message_id,
        mockReply=event.mock_reply,
        noReply=event.no_reply,
        tools=event.tools,
        system=event.system,
        execution_mode=event.execution_mode,
    )


async def _dispatch_sse_input(sessionID: str, session, event, working_directory: str) -> None:
    import time as _time

    from flocks.input.dispatcher import dispatch_user_input, parse_slash_command
    from flocks.input.output import SSEOutputSink
    from flocks.server.routes.event import publish_event
    from flocks.session.message import Message, MessageRole
    from flocks.utils.id import Identifier

    from flocks.agent.registry import Agent
    from flocks.session.agent_policy import prepare_session_for_agent

    agent_name = (
        event.agent
        or getattr(session, "agent", None)
        or await Agent.default_agent()
    )
    agent = await Agent.get(agent_name) or await Agent.get(DEFAULT_AGENT)
    if agent is None:
        raise ValueError(f"Agent {agent_name!r} is not available")
    session = await prepare_session_for_agent(session, agent)
    lifecycle_generation = event.metadata.get("_sessionLifecycleGeneration")
    if not isinstance(lifecycle_generation, int):
        lifecycle_generation = Session.lifecycle_generation(sessionID)

    async def _create_user_message(
        user_text: str,
        model_info: Optional[Dict[str, str]] = None,
        *,
        agent_override: Optional[str] = None,
        ignored: Optional[bool] = None,
    ) -> str:
        from flocks.session import turn_receipt

        now_ms = int(_time.time() * 1000)
        user_msg_id = event.message_id or Identifier.create("message")
        user_part_id = Identifier.create("part")
        turn_receipt.note_user_message(user_msg_id)
        message_agent = agent_override or agent_name
        await _persist_active_session_write(
            sessionID,
            lambda: Message.create(
                session_id=sessionID,
                role=MessageRole.USER,
                content=user_text,
                id=user_msg_id,
                time={"created": now_ms},
                agent=message_agent,
                executionMode=event.execution_mode,
                **({"model": model_info} if model_info else {}),
                ignored=ignored,
                part_id=user_part_id,
            ),
            expected_generation=lifecycle_generation,
            expected_agent=message_agent,
        )
        await publish_event("message.updated", {
            "info": {
                "id": user_msg_id,
                "sessionID": sessionID,
                "role": "user",
                "time": {"created": now_ms},
                "agent": message_agent,
                "executionMode": event.execution_mode.value,
                **({"model": model_info} if model_info else {}),
            }
        })
        await publish_event("message.part.updated", {
            "part": {
                "id": user_part_id,
                "messageID": user_msg_id,
                "sessionID": sessionID,
                "type": "text",
                "text": user_text,
                **({"ignored": ignored} if ignored is not None else {}),
                "time": {"start": now_ms},
            }
        })
        return user_msg_id

    async def _publish_direct_response(output_event, text: str) -> None:
        user_text = output_event.user_visible_text
        parent_msg_id = await _create_user_message(user_text, ignored=True)
        asst_now = int(_time.time() * 1000)
        asst_msg_id = Identifier.ascending("message")
        asst_part_id = Identifier.ascending("part")
        await _persist_active_session_write(
            sessionID,
            lambda: Message.create(
                session_id=sessionID,
                role=MessageRole.ASSISTANT,
                content=text,
                id=asst_msg_id,
                time={"created": asst_now, "completed": asst_now},
                parentID=parent_msg_id,
                modelID="command",
                providerID="builtin",
                agent=agent_name,
                finish="stop",
                ignored=True,
                part_id=asst_part_id,
            ),
            expected_generation=lifecycle_generation,
        )
        await publish_event("message.updated", {
            "info": {
                "id": asst_msg_id,
                "sessionID": sessionID,
                "role": "assistant",
                "time": {"created": asst_now, "completed": asst_now},
                "parentID": parent_msg_id,
                "modelID": "command",
                "providerID": "builtin",
                "agent": agent_name,
                "mode": agent_name,
                "finish": "stop",
                "tokens": {
                    "input": 0,
                    "output": 0,
                    "reasoning": 0,
                    "cache": {"read": 0, "write": 0},
                },
            }
        })
        await publish_event("message.part.updated", {
            "part": {
                "id": asst_part_id,
                "messageID": asst_msg_id,
                "sessionID": sessionID,
                "type": "text",
                "text": text,
                "ignored": True,
                "time": {"start": asst_now, "end": asst_now},
            }
        })
        await _publish_context_usage_update(
            publish_event,
            sessionID,
            session=session,
        )

    async def _run_llm(output_event, prompt_text: str, display_text: Optional[str] = None) -> None:
        parsed = parse_slash_command(output_event.text, output_event.metadata)
        if parsed is not None and parsed.canonical_name == "goal":
            from flocks.session.goal import GoalManager

            state = await GoalManager.get(sessionID)
            if state is not None:
                await publish_event("session.goal.updated", {
                    "sessionID": sessionID,
                    "status": state.status,
                    "objective": state.objective,
                    "reason": state.last_reason,
                })
        request = _build_prompt_request_from_event(output_event, prompt_text, display_text)
        await _process_session_message(
            sessionID,
            session,
            request,
            working_directory,
            lifecycle_generation=lifecycle_generation,
            uploader_user_id=(
                str(event.metadata.get("_uploaderUserID") or "").strip() or None
            ),
        )

    async def _clear_history() -> None:
        await _clear_session_history(sessionID)

    async def _publish_command_status(
        _output_event,
        status_type: str,
        message: Optional[str] = None,
    ) -> None:
        from flocks.session.core.status import SessionStatus, SessionStatusDreaming

        if status_type == "dreaming" and message:
            status = SessionStatusDreaming(message=message)
            SessionStatus.set(sessionID, status)
            status_payload = status.model_dump()
        else:
            SessionStatus.clear(sessionID)
            status_payload = {"type": "idle"}
        await publish_event("session.status", {
            "sessionID": sessionID,
            "status": status_payload,
        })

    async def _run_session_control(output_event, parsed) -> bool:
        if parsed.canonical_name != "compact":
            return False

        focus_instruction = parsed.args.strip() or None
        compact_agent, compact_provider_id, compact_model_id = await _resolve_compaction_context(
            sessionID,
            requested_agent=output_event.agent,
            requested_model=output_event.model,
        )
        parent_msg_id = await _create_user_message(
            output_event.user_visible_text,
            {
                "providerID": compact_provider_id,
                "modelID": compact_model_id,
            },
            agent_override=compact_agent,
        )
        await _run_session_compaction(
            sessionID,
            requested_agent=compact_agent,
            explicit_provider_id=compact_provider_id,
            explicit_model_id=compact_model_id,
            parent_message_id=parent_msg_id,
            auto=False,
            event_publish_callback=publish_event,
            focus_instruction=focus_instruction,
            working_directory=working_directory,
        )
        return True

    sink = SSEOutputSink(
        "webui",
        direct_response=_publish_direct_response,
        run_llm=_run_llm,
        session_control=_run_session_control,
        command_status=_publish_command_status,
        clear_history=_clear_history,
    )
    await dispatch_user_input(event, sink)


class PromptQueueUpdateRequest(BaseModel):
    text: str = Field(..., description="Updated queued prompt text")


async def _enqueue_prompt_request(
    session_id: str,
    request: PromptRequest,
    *,
    expected_generation: Optional[int] = None,
    uploader_user_id: Optional[str] = None,
    turn_id: Optional[str] = None,
):
    from flocks.session.interaction_queue import InteractionQueue
    from flocks.hooks.execution import current_execution_context

    _validate_execution_mode_request(request)
    await _validate_chat_upload_parts(session_id, uploader_user_id, request.parts)
    hold = InteractionQueue.hold_uploads(session_id, uploader_user_id or "", request.parts)
    try:
        if expected_generation is None:
            expected_generation = Session.lifecycle_generation(session_id)
        await _require_agent_usable_for_chat(request.agent)
        model = request.model.model_dump(by_alias=True) if request.model else None
        originals = [dict(part) for part in request.parts]
        parts = _materialize_queued_parts(session_id, originals)
        for original, part in zip(originals, parts):
            if str(original.get("url") or "").startswith("data:"):
                await _store_materialized_part(str(part.get("url") or ""))
        execution_context = current_execution_context()
        if uploader_user_id:
            execution_context = {**execution_context, "_uploaderUserID": uploader_user_id}
        if turn_id:
            execution_context = {**execution_context, "_turnID": turn_id}
        return await _persist_active_session_write(
            session_id,
            lambda: InteractionQueue.enqueue(
                session_id,
                parts=parts,
                agent=request.agent,
                model=model,
                variant=request.variant,
                display_text=request.display_text,
                message_id=request.messageID,
                no_reply=request.noReply,
                mock_reply=request.mockReply,
                tools=request.tools,
                system=request.system,
                execution_mode=request.execution_mode,
                execution_context=execution_context,
            ),
            expected_generation=expected_generation,
        )
    finally:
        InteractionQueue.release_uploads(hold)


@router.get(
    "/{sessionID}/prompt_queue",
    summary="List queued prompts",
    description="List pending non-blocking prompts for a session",
)
async def list_prompt_queue(sessionID: str, request: Request) -> Dict[str, Any]:
    from flocks.session.interaction_queue import InteractionQueue

    session = await _get_session_by_id_unfiltered(sessionID)
    if not session:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Session {sessionID} not found",
        )
    current_user = require_user(request)
    _require_session_read_access(session, current_user)
    items = await InteractionQueue.list(sessionID)
    return {"sessionID": sessionID, "items": [item.model_dump() for item in items]}


@router.post(
    "/{sessionID}/prompt_queue",
    status_code=status.HTTP_202_ACCEPTED,
    summary="Queue prompt",
    description="Queue a prompt without writing it to the formal message history",
)
async def enqueue_prompt(
    sessionID: str,
    request: PromptRequest,
    http_request: Request,
) -> Dict[str, Any]:
    from flocks.session.interaction_queue import QueueFullError

    session = await _get_session_by_id_unfiltered(sessionID)
    if not session:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Session {sessionID} not found",
        )
    current_user = require_user(http_request)
    _require_session_write_access(session, current_user)
    await _require_agent_usable_for_chat(request.agent)
    try:
        item = await _enqueue_prompt_request(
            sessionID,
            request,
            uploader_user_id=current_user.id,
        )
    except QueueFullError as exc:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(exc)) from exc
    await _publish_prompt_queue(sessionID)
    return {"status": "queued", "sessionID": sessionID, "queueID": item.id}


@router.patch(
    "/{sessionID}/prompt_queue/{queueID}",
    summary="Update queued prompt",
    description="Update the text part of a queued prompt",
)
async def update_prompt_queue_item(
    sessionID: str,
    queueID: str,
    request: PromptQueueUpdateRequest,
    http_request: Request,
) -> Dict[str, Any]:
    from flocks.session.interaction_queue import InteractionQueue, QueueItemNotFoundError

    _session, _current_user = await _load_context_session(
        sessionID,
        http_request,
        write=True,
    )
    text = request.text.strip()
    if not text:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Queued prompt text cannot be empty",
        )
    try:
        item = await InteractionQueue.update_text(sessionID, queueID, text)
    except QueueItemNotFoundError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc
    await _publish_prompt_queue(sessionID)
    return {"status": "updated", "sessionID": sessionID, "item": item.model_dump()}


@router.delete(
    "/{sessionID}/prompt_queue/{queueID}",
    summary="Remove queued prompt",
    description="Remove a queued prompt before it executes",
)
async def remove_prompt_queue_item(
    sessionID: str,
    queueID: str,
    request: Request,
) -> Dict[str, Any]:
    from flocks.session.interaction_queue import InteractionQueue, QueueItemNotFoundError

    await _load_context_session(sessionID, request, write=True)
    try:
        removed_item = await InteractionQueue.remove(sessionID, queueID)
    except QueueItemNotFoundError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc
    removed_turn = (removed_item.execution_context or {}).get("_turnID") if isinstance(removed_item.execution_context, dict) else None
    if removed_turn:
        from flocks.session import turn_receipt

        await turn_receipt.advance_quietly(sessionID, removed_turn, turn_receipt.REMOVED, queueID=queueID)
    uploader_user_id = (
        str((removed_item.execution_context or {}).get("_uploaderUserID") or "").strip()
        if isinstance(removed_item.execution_context, dict)
        else ""
    )
    if uploader_user_id:
        from flocks.session.files import discard_staged_chat_uploads_from_parts

        await discard_staged_chat_uploads_from_parts(
            uploader_user_id,
            removed_item.parts,
        )
    await _publish_prompt_queue(sessionID)
    return {"status": "removed", "sessionID": sessionID, "queueID": queueID}


@router.post(
    "/{sessionID}/prompt_queue/{queueID}/run_now",
    status_code=status.HTTP_202_ACCEPTED,
    summary="Run queued prompt now",
    description="Abort the current prompt and run the selected queued prompt next",
)
async def run_prompt_queue_item_now(
    sessionID: str,
    queueID: str,
    request: Request,
) -> Dict[str, Any]:
    import os

    from flocks.session.interaction_queue import InteractionQueue, QueueItemNotFoundError

    session = await _get_session_by_id_unfiltered(sessionID)
    if not session:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Session {sessionID} not found",
        )
    current_user = require_user(request)
    _require_session_write_access(session, current_user)
    working_directory = await _resolve_session_working_directory(session)
    try:
        await InteractionQueue.promote(sessionID, queueID)
    except QueueItemNotFoundError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc
    await _publish_prompt_queue(sessionID)

    # The parent may already be idle while its independent children still run.
    await abort_session(sessionID)
    await _wait_for_session_idle(sessionID)

    await _schedule_prompt_queue_drain(sessionID, working_directory)
    return {"status": "accepted", "sessionID": sessionID, "queueID": queueID}


@router.post(
    "/{sessionID}/prompt_async",
    status_code=status.HTTP_202_ACCEPTED,
    summary="Send async message",
    description="Send a message asynchronously (returns immediately)",
)
async def send_session_message_async(
    sessionID: str,
    request: PromptRequest,
    http_request: Request = None,
):
    """Send message asynchronously - returns 202 immediately, response via SSE"""
    import os
    from flocks.input.events import UserInputEvent
    from flocks.session import turn_receipt
    from flocks.session.interaction_queue import InteractionQueue, QueueFullError
    from flocks.session.session_loop import SessionLoop

    try:
        turn_id = turn_receipt.turn_id_from(request.turn_id)
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc
    session = await _get_session_by_id_unfiltered(sessionID)
    if not session:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Session {sessionID} not found"
        )
    uploader_user_id: Optional[str] = None
    if http_request is not None:
        current_user = require_user(http_request)
        _require_session_write_access(session, current_user)
        uploader_user_id = current_user.id
    lifecycle_generation = Session.lifecycle_generation(sessionID)
    
    session, _ = await _prepare_session_agent_before_bootstrap(
        session,
        request.agent,
    )
    working_directory = await _resolve_session_working_directory(session)
    _validate_execution_mode_request(request)
    
    log.info("session.prompt_async.accepted", {
        "sessionID": sessionID,
        "directory": working_directory,
    })

    event_text = _event_text_for_execution_mode(
        request.parts,
        request.execution_mode,
    )
    event_display_text = request.display_text
    if request.execution_mode == SessionExecutionMode.GOAL:
        event_display_text = (
            event_display_text
            or _extract_text_from_parts(request.parts).strip()
        )

    event = UserInputEvent(
        source_type="webui",
        sessionID=sessionID,
        text=event_text,
        parts=[dict(part) for part in request.parts],
        agent=request.agent,
        model=request.model.model_dump(by_alias=True) if request.model else None,
        variant=request.variant,
        metadata={
            "_sessionLifecycleGeneration": lifecycle_generation,
            **({"_turnID": turn_id} if turn_id else {}),
            **({"_uploaderUserID": uploader_user_id} if uploader_user_id else {}),
        },
        display_text=event_display_text,
        messageID=request.messageID,
        noReply=request.noReply,
        mockReply=request.mockReply,
        tools=request.tools,
        system=request.system,
        executionMode=request.execution_mode,
        working_directory=working_directory,
    )

    await _validate_chat_upload_parts(sessionID, uploader_user_id, request.parts)
    hold = InteractionQueue.hold_uploads(sessionID, uploader_user_id or "", request.parts)
    try:
        existing_queue = await InteractionQueue.list(sessionID)
        if SessionLoop.is_running(sessionID) or existing_queue or _is_prompt_chain_active(sessionID):
            if turn_id:
                # Written before the item is in the queue: the turn running now
                # may take it the moment it is, and its receipt moves on from here.
                await _create_turn_receipt(sessionID, turn_id, turn_receipt.QUEUED)
            try:
                item = await _enqueue_prompt_request(
                    sessionID,
                    request,
                    expected_generation=lifecycle_generation,
                    uploader_user_id=uploader_user_id,
                    turn_id=turn_id,
                )
            except BaseException as exc:
                if turn_id:
                    await turn_receipt.advance_quietly(
                        sessionID, turn_id, turn_receipt.FAILED, error=f"{type(exc).__name__}: {exc}"[:500],
                    )
                if isinstance(exc, QueueFullError):
                    raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(exc)) from exc
                raise
            if turn_id:
                try:
                    await turn_receipt.name_queue_item(sessionID, turn_id, item.id)
                except Exception as exc:
                    log.warn("session.turn_receipt.queue_item_not_named", {"sessionID": sessionID, "error": str(exc)})
                turn_receipt.ensure_queue_keeper()
            await _publish_prompt_queue(sessionID)
            if not SessionLoop.is_running(sessionID):
                await _schedule_prompt_queue_drain(sessionID, working_directory)
            return {
                "status": "queued", "sessionID": sessionID, "queueID": item.id,
                **({"turnID": turn_id} if turn_id else {}),
            }

        if turn_id:
            await _create_turn_receipt(sessionID, turn_id, turn_receipt.ACCEPTED)
        _set_prompt_chain_active(sessionID, True)
        task = _schedule_background_coro(
            _run_prompt_event_chain(sessionID, session, event, working_directory),
            session_id=sessionID,
            action="session.prompt_async",
        )
        if hold:
            # A done callback also releases requests cancelled before dispatch
            # enters its coroutine and therefore before its finally can run.
            task.add_done_callback(lambda _task, token=hold: InteractionQueue.release_uploads(token))
            hold = ""
        return {"status": "accepted", "sessionID": sessionID, **({"turnID": turn_id} if turn_id else {})}
    finally:
        InteractionQueue.release_uploads(hold)


async def _create_turn_receipt(session_id: str, turn_id: str, state: str) -> None:
    """The receipt of a turn its client follows, before the turn is dispatched (turn_receipt.create)."""
    from flocks.session import turn_receipt

    try:
        await turn_receipt.create(session_id, turn_id, state)
    except turn_receipt.TurnIdInUse as exc:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(exc)) from exc
    except Exception as exc:
        log.warn("session.turn_receipt.create_failed", {"sessionID": session_id, "error_type": type(exc).__name__})
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="the turn could not be recorded, so it was not started",
        ) from exc


class CommandRequest(BaseModel):
    """Request to execute a command"""
    model_config = ConfigDict(populate_by_name=True)
    
    command: str = Field(..., description="Command name")
    arguments: str = Field("", description="Command arguments")
    arguments_json: Optional[Any] = Field(None, alias="argumentsJson", description="Structured command arguments")
    messageID: Optional[str] = Field(None, description="Message ID")
    agent: Optional[str] = Field(None, description="Agent name")
    model: Optional[str] = Field(None, description="Model string (provider/model)")
    variant: Optional[str] = Field(None, description="Model variant")
    parts: Optional[List[Dict[str, Any]]] = Field(None, description="Additional parts")
    turn_id: Optional[str] = Field(
        None,
        alias="turnID",
        description="Client-chosen id of this turn; GET /session/{id}/turn/{turnID} says how it stands",
    )


@router.post(
    "/{sessionID}/command",
    status_code=status.HTTP_202_ACCEPTED,
    summary="Send command",
    description="Execute a slash command in the session (returns 202, result via SSE)",
)
async def send_session_command(sessionID: str, request: CommandRequest, http_request: Request = None):
    """
    Execute a slash command.

    Direct commands (/tools, /skills, /help, /mcp) are handled without calling
    the LLM. Their output is pushed as an assistant message directly via SSE.
    Side-effecting direct commands like /clear run without creating a chat
    message and instead update session state via callbacks.

    LLM-based commands (/init, /compact, ...) are routed through
    the normal session-loop pipeline.

    In both cases the user message (showing the raw slash command text, e.g.
    "/tools") is created inside the background task so there is exactly ONE user
    message in the session history.  The frontend shows a temporary placeholder
    that is replaced as soon as the real SSE event arrives.
    """
    import asyncio
    import os

    from flocks.input.events import UserInputEvent
    from flocks.session import turn_receipt

    try:
        turn_id = turn_receipt.turn_id_from(request.turn_id)
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc
    session = await _get_session_by_id_unfiltered(sessionID)
    if not session:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Session {sessionID} not found",
        )
    if http_request is not None:
        current_user = require_user(http_request)
        _require_session_write_access(session, current_user)
    lifecycle_generation = Session.lifecycle_generation(sessionID)

    session, _ = await _prepare_session_agent_before_bootstrap(
        session,
        request.agent,
    )
    working_directory = await _resolve_session_working_directory(session)
    raw_arguments = request.arguments
    if not raw_arguments and request.arguments_json is not None:
        raw_arguments = json.dumps(request.arguments_json, ensure_ascii=False)
    command_metadata: Dict[str, Any] = {}
    command_metadata["_sessionLifecycleGeneration"] = lifecycle_generation
    if request.arguments_json is not None:
        command_metadata["commandArgumentsJson"] = request.arguments_json
    if turn_id:
        command_metadata["_turnID"] = turn_id
        await _create_turn_receipt(sessionID, turn_id, turn_receipt.ACCEPTED)

    _schedule_slash_command(
        sessionID,
        session,
        working_directory,
        command=request.command,
        arguments=raw_arguments,
        model=request.model,
        message_id=request.messageID,
        agent=request.agent,
        variant=request.variant,
        parts=request.parts,
        metadata=command_metadata,
    )

    log.info("session.command.accepted", {
        "sessionID": sessionID,
        "command": request.command,
    })

    return {"status": "accepted", "sessionID": sessionID, **({"turnID": turn_id} if turn_id else {})}


def _schedule_slash_command(
    sessionID: str,
    session,
    working_directory: str,
    *,
    command: str,
    arguments: str = "",
    model: Optional[str] = None,
    message_id: Optional[str] = None,
    agent: Optional[str] = None,
    variant: Optional[str] = None,
    parts: Optional[List[Dict[str, Any]]] = None,
    metadata: Optional[Dict[str, Any]] = None,
) -> None:
    """Run a slash command in the background; results and errors go out over SSE."""
    import asyncio

    from flocks.input.events import UserInputEvent

    command_metadata: Dict[str, Any] = dict(metadata or {})
    command_metadata.setdefault(
        "_sessionLifecycleGeneration",
        Session.lifecycle_generation(sessionID),
    )

    # The text the user typed, shown verbatim in the chat bubble
    slash_text = f"/{command}"
    if arguments:
        slash_text += f" {arguments}"

    # ── Background task ──────────────────────────────────────────────────────
    async def _handle_command() -> None:
        event = UserInputEvent(
            source_type="webui",
            sessionID=sessionID,
            text=slash_text,
            parts=[dict(part) for part in (parts or [])],
            agent=agent,
            model=model,
            variant=variant,
            metadata=command_metadata,
            display_text=slash_text,
            messageID=message_id,
            working_directory=working_directory,
        )

        try:
            from flocks.project.instance import Instance
            from flocks.project.bootstrap import instance_bootstrap
            from flocks.session import turn_receipt

            async with turn_receipt.running(sessionID, command_metadata.get("_turnID")):
                await Instance.provide(
                    directory=working_directory,
                    init=instance_bootstrap,
                    fn=lambda: _dispatch_sse_input(sessionID, session, event, working_directory),
                )

        except Exception as exc:
            import traceback
            from flocks.server.routes.event import publish_event

            log.error("session.command.error", {
                "sessionID": sessionID,
                "command": command,
                "error": str(exc),
                "traceback": traceback.format_exc(),
            })
            await publish_event("session.error", {
                "sessionID": sessionID,
                "error": {
                    "name": type(exc).__name__,
                    "message": str(exc),
                    "data": {},
                },
            })

    loop = asyncio.get_running_loop()
    task = loop.create_task(_handle_command())
    _track_background_task(task, session_id=sessionID)


class ShellRequest(BaseModel):
    """Request to run shell command"""
    agent: str = Field(..., description="Agent name")
    command: str = Field(..., description="Shell command to execute")
    model: Optional[ModelInfo] = Field(None, description="Model selection")


@router.post(
    "/{sessionID}/shell",
    summary="Run shell command",
    description="Execute a shell command in the session context",
)
async def run_shell_command(sessionID: str, request: ShellRequest, http_request: Request):
    """Run shell command"""
    from flocks.hooks.execution import ExecutionStopped
    from flocks.server.routes.event import publish_event
    from flocks.session.runner import SessionRunner

    current_user = require_user(http_request)
    session = await _get_session_by_id_unfiltered(sessionID)
    if not session:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Session {sessionID} not found"
        )
    _require_session_write_access(session, current_user)

    model = None
    if request.model:
        model = {"providerID": request.model.providerID, "modelID": request.model.modelID}
    
    try:
        async with Session.active_operation(sessionID):
            result = await SessionRunner.shell(
                session_id=sessionID,
                agent=request.agent,
                command=request.command,
                model=model,
                event_publish_callback=publish_event,
            )
    except SessionNotFoundError as exc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(exc),
        ) from exc
    except SessionInactiveError as exc:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=str(exc),
        ) from exc
    except (ExecutionStopped, PermissionError) as exc:
        # A generic extension lifecycle may stop this operation (a tool-gate
        # deny surfaces as PermissionError).  Keep the response stable without
        # interpreting extension-specific policy data.
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="execution stopped by extension",
        ) from exc
    
    log.info("session.shell.executed", {
        "sessionID": sessionID,
        "command": request.command[:50],
    })
    
    return result


# =============================================================================
# Permission Routes
# =============================================================================

class PermissionResponse(BaseModel):
    """Permission response for API compatibility"""
    response: Literal["allow", "deny", "always", "never", "allow_session"] = Field(
        ..., description="Response: allow, deny, always, never, or allow_session"
    )


@router.post(
    "/{sessionID}/permissions/{permissionID}",
    summary="Respond to permission",
    description="Approve or deny a permission request",
)
async def respond_to_permission(
    sessionID: str,
    permissionID: str,
    request: PermissionResponse,
    http_request: Request,
) -> bool:
    """Respond to permission request"""
    from flocks.permission.next import PermissionNext

    current_user = require_user(http_request)
    session = await _get_session_by_id_unfiltered(sessionID)
    if not session:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Session {sessionID} not found",
        )
    _require_session_write_access(session, current_user)
    pending = await PermissionNext.get_pending_info(permissionID)
    if pending is not None and pending.session_id != sessionID:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Permission {permissionID} not found in session {sessionID}",
        )
    
    await PermissionNext.reply(
        request_id=permissionID,
        reply=request.response,
    )
    
    log.info("permission.responded", {
        "sessionID": sessionID,
        "permissionID": permissionID,
        "response": request.response,
    })
    
    return True


# =============================================================================
# Diff Routes (FileDiff class defined at top of file)
# =============================================================================


async def _clear_session_history(
    sessionID: str,
    *,
    expected_generation: Optional[int] = None,
) -> int:
    """Clear stored messages for a session and notify subscribed UIs."""
    session_info = await _get_session_by_id_unfiltered(sessionID)
    if not session_info:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Session {sessionID} not found",
        )

    from flocks.server.routes.event import publish_event
    from flocks.session.goal import GoalManager
    from flocks.session.interaction_queue import InteractionQueue
    from flocks.session.message import Message

    await abort_session(sessionID)
    await InteractionQueue.clear(sessionID)
    try:
        await _publish_prompt_queue(sessionID)
    except Exception as exc:
        log.warn("session.clear.prompt_queue_event_error", {"sessionID": sessionID, "error": str(exc)})
    await _wait_for_session_idle(sessionID)

    async def clear_persisted_history() -> int:
        await GoalManager.clear(sessionID)
        deleted_count = await Message.clear(sessionID)
        await Session._clear_project_move_metadata_locked(sessionID)
        return deleted_count

    deleted_count = await _persist_active_session_write(
        sessionID,
        clear_persisted_history,
        expected_generation=expected_generation,
    )
    log.info("session.cleared", {"sessionID": sessionID, "deleted": deleted_count})

    try:
        await publish_event("session.cleared", {
            "sessionID": sessionID,
            "deletedMessages": deleted_count,
        })
    except Exception as exc:
        log.warn("session.clear.event_error", {"sessionID": sessionID, "error": str(exc)})

    return deleted_count


@router.post("/{sessionID}/clear")
async def clear_session(sessionID: str, http_request: Request):
    """
    Clear session messages
    
    Removes all messages from the session while keeping the session itself.
    """
    try:
        session_info = await _get_session_by_id_unfiltered(sessionID)
        if not session_info:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Session {sessionID} not found",
            )
        current_user = require_user(http_request)
        _require_session_write_access(session_info, current_user)

        deleted_count = await _clear_session_history(
            sessionID,
            expected_generation=Session.lifecycle_generation(sessionID),
        )
        return {
            "status": "success",
            "sessionID": sessionID,
            "deletedMessages": deleted_count,
        }
    except HTTPException:
        raise
    except Exception as e:
        log.error("session.clear.error", {"sessionID": sessionID, "error": str(e)})
        raise HTTPException(status_code=500, detail=f"Failed to clear session: {str(e)}")
