"""User-scoped project registry backed by JSON files.

Projects are UI/session groupings bound to existing directories. Legacy project
records in Storage are intentionally ignored; sessions that do not reference a
registered project remain ordinary sessions rather than becoming a project.
"""

from __future__ import annotations

import asyncio
import contextvars
import hashlib
import json
import os
import re
import subprocess
import sys
import tempfile
import time
import uuid
import weakref
from contextlib import asynccontextmanager, contextmanager
from datetime import datetime
from pathlib import Path
from typing import Annotated, AsyncIterator, Any, ClassVar, Dict, Iterator, List, Literal, Optional, Tuple

from pydantic import BaseModel, ConfigDict, Field

from flocks.config.config import Config
from flocks.utils.log import Log

log = Log.create(service="project")

# Legacy stored project ID used by ordinary sessions. It is not a ProjectInfo
# entry and never resolves to a worktree.
DEFAULT_PROJECT_ID = "default"
# Session-manager wire ID for the Tasks section; also not a project.
TASK_SESSION_GROUP_ID = "tasks"
DEFAULT_PROJECT_NAME = "默认"
_RESERVED_PROJECT_NAMES = {"default", DEFAULT_PROJECT_NAME.casefold()}


def _platform_file_lock(fd: int) -> None:
    if sys.platform == "win32":  # pragma: no cover - Windows only
        import msvcrt

        msvcrt.locking(fd, msvcrt.LK_LOCK, 1)
    else:
        import fcntl

        fcntl.flock(fd, fcntl.LOCK_EX)


def _platform_file_unlock(fd: int) -> None:
    if sys.platform == "win32":  # pragma: no cover - Windows only
        import msvcrt

        msvcrt.locking(fd, msvcrt.LK_UNLCK, 1)
    else:
        import fcntl

        fcntl.flock(fd, fcntl.LOCK_UN)


async def _acquire_file_lock(fd: int) -> None:
    """Acquire a blocking OS lock without leaking it when the waiter is cancelled."""

    worker = asyncio.create_task(asyncio.to_thread(_platform_file_lock, fd))
    try:
        await asyncio.shield(worker)
    except asyncio.CancelledError:
        while not worker.done():
            try:
                await asyncio.shield(worker)
            except asyncio.CancelledError:
                continue
        if not worker.cancelled():
            worker.result()
            _platform_file_unlock(fd)
        raise


@contextmanager
def _registry_cross_process_lock(registry_path: Path) -> Iterator[None]:
    """Serialize registry read-modify-write operations across processes."""

    registry_path.parent.mkdir(parents=True, exist_ok=True)
    lock_path = registry_path.with_suffix(".json.lock")
    fd = os.open(str(lock_path), os.O_RDWR | os.O_CREAT, 0o600)
    locked = False
    try:
        _platform_file_lock(fd)
        locked = True
        yield
    finally:
        try:
            if locked:
                _platform_file_unlock(fd)
        finally:
            os.close(fd)


class ProjectNameConflictError(ValueError):
    """Raised when a project name is already registered for the user."""


class ProjectPathConflictError(ValueError):
    """Raised when a project directory is already registered."""

    def __init__(self, project: "ProjectInfo") -> None:
        super().__init__(f"Project directory is already registered as '{project.name}'")
        self.project = project


class ProjectDeletionError(ValueError):
    """Raised when a protected project cannot be deleted."""


WORKBENCH_PROJECT_SCOPE = "workbench"
PROJECT_SCOPE_PATTERN = r"^[a-z][a-z0-9-]{0,63}$"
# ``workbench`` holds the folders of the session manager. An extension may
# keep its own folders under another scope name; they stay out of the session
# manager and can reuse the same directories only through their own scope.
ProjectScope = Annotated[str, Field(pattern=PROJECT_SCOPE_PATTERN)]


def normalize_project_scope(scope: Optional[str]) -> str:
    value = (scope or WORKBENCH_PROJECT_SCOPE).strip()
    if not re.fullmatch(PROJECT_SCOPE_PATTERN, value):
        raise ValueError(f"Invalid project scope: {scope!r}")
    return value


class ProjectIcon(BaseModel):
    """Project icon configuration."""

    url: Optional[str] = None
    override: Optional[str] = None
    color: Optional[str] = None


class ProjectTime(BaseModel):
    """Project time metadata."""

    created: int
    updated: int
    initialized: Optional[int] = None


class ProjectInfo(BaseModel):
    """Project information returned by project and session APIs."""

    model_config = ConfigDict(populate_by_name=True)

    id: str
    worktree: str
    source_kind: Optional[Literal["local", "git", "zip", "url", "website"]] = Field(None, alias="sourceKind")
    scope: Optional[ProjectScope] = None
    vcs: Optional[str] = None
    name: Optional[str] = None
    icon: Optional[ProjectIcon] = None
    time: ProjectTime
    sandboxes: List[str] = Field(default_factory=list)
    is_default: bool = Field(False, alias="isDefault")
    path_status: Literal["available", "missing", "unreadable"] = Field(
        "available",
        alias="pathStatus",
    )
    session_count: int = Field(0, alias="sessionCount")
    matched_session_count: int = Field(0, alias="matchedSessionCount")
    last_activity_at: Optional[int] = Field(None, alias="lastActivityAt")
    owner_user_id: Optional[str] = Field(None, alias="ownerUserID")
    can_write: bool = Field(True, alias="canWrite")
    can_delete: bool = Field(True, alias="canDelete")
    is_shared: bool = Field(False, alias="isShared")


class ProjectRegistryEntry(BaseModel):
    """Persisted project entry."""

    model_config = ConfigDict(populate_by_name=True)

    id: str
    name: str
    worktree: str
    source_kind: Optional[Literal["local", "git", "zip", "url", "website"]] = Field(None, alias="sourceKind")
    scope: Optional[ProjectScope] = None
    created_at: int = Field(alias="createdAt")
    updated_at: int = Field(alias="updatedAt")
    owner_user_id: Optional[str] = Field(None, alias="ownerUserID")
    shared_local: bool = Field(False, alias="sharedLocal")
    removed_at: Optional[int] = Field(None, alias="removedAt")


class ProjectRegistry(BaseModel):
    """Per-user project registry file."""

    model_config = ConfigDict(populate_by_name=True)

    default_worktree: Optional[str] = Field(None, alias="defaultWorktree")
    projects: List[ProjectRegistryEntry] = Field(default_factory=list)


class Project:
    """User-scoped registry of explicitly created projects."""

    _lock = asyncio.Lock()
    _lifecycle_locks: ClassVar[weakref.WeakValueDictionary[str, asyncio.Lock]] = (
        weakref.WeakValueDictionary()
    )
    _held_lifecycle_guards: ClassVar[
        contextvars.ContextVar[Dict[str, asyncio.Task[Any]]]
    ] = contextvars.ContextVar("project_lifecycle_guards", default={})
    _session_stats_cache: ClassVar[
        Dict[Tuple[str, str], Tuple[float, Dict[str, Tuple[int, int, Optional[int]]]]]
    ] = {}
    _session_stats_cache_ttl_seconds = 30.0

    @staticmethod
    def _now_ms() -> int:
        return int(datetime.now().timestamp() * 1000)

    @classmethod
    def lifecycle_lock(cls, project_id: str) -> asyncio.Lock:
        """Serialize session creation, project removal, and restoration per project."""

        lock = cls._lifecycle_locks.get(project_id)
        if lock is None:
            lock = asyncio.Lock()
            cls._lifecycle_locks[project_id] = lock
        return lock

    @classmethod
    @asynccontextmanager
    async def lifecycle_guard(cls, project_id: str) -> AsyncIterator[None]:
        """Serialize a project lifecycle transition across tasks and processes.

        The context is re-entrant for the current asyncio task so project deletion
        can archive several roots through the same public session APIs. ContextVar
        state records the owning task explicitly because child tasks inherit
        context and must acquire their own lock.
        """

        task = asyncio.current_task()
        if task is None:
            raise RuntimeError("Project lifecycle guard requires an asyncio task")

        held = cls._held_lifecycle_guards.get()
        if held.get(project_id) is task:
            yield
            return

        async with cls.lifecycle_lock(project_id):
            lock_dir = Config.get_data_path() / "locks" / "project-lifecycle"
            lock_dir.mkdir(parents=True, exist_ok=True)
            lock_name = hashlib.sha256(project_id.encode("utf-8")).hexdigest()
            fd = os.open(str(lock_dir / f"{lock_name}.lock"), os.O_RDWR | os.O_CREAT, 0o600)
            acquired = False
            try:
                await _acquire_file_lock(fd)
                acquired = True
                token = cls._held_lifecycle_guards.set({**held, project_id: task})
                try:
                    yield
                finally:
                    cls._held_lifecycle_guards.reset(token)
            finally:
                try:
                    if acquired:
                        _platform_file_unlock(fd)
                finally:
                    os.close(fd)

    @classmethod
    def registry_state(
        cls,
        project_id: str,
        *,
        owner_id: str,
    ) -> Literal["virtual", "missing", "active", "removed"]:
        """Return the registry state used by session create/restore guards."""

        if project_id in {DEFAULT_PROJECT_ID, TASK_SESSION_GROUP_ID}:
            return "virtual"
        entry = next(
            (
                item
                for item in cls._read_registry(owner_id).projects
                if item.id == project_id
            ),
            None,
        )
        if entry is None:
            return "missing"
        return "removed" if entry.removed_at is not None else "active"

    @classmethod
    def is_removed(cls, project_id: str) -> bool:
        """Return whether any local registry marks this project as removed."""

        return any(
            entry.id == project_id and entry.removed_at is not None
            for entry in cls._all_registry_entries(include_removed=True)
        )

    @staticmethod
    def _flocks_root() -> Path:
        return Path(os.getenv("FLOCKS_ROOT", str(Path.home() / ".flocks"))).expanduser()

    @classmethod
    def _owner_hash(cls, owner_id: str) -> str:
        return hashlib.sha256(owner_id.encode("utf-8")).hexdigest()[:24]

    @classmethod
    def registry_path(cls, owner_id: str) -> Path:
        """Return the project registry path for a user."""

        return cls._flocks_root() / "projects" / f"{cls._owner_hash(owner_id)}.json"

    @staticmethod
    def _normalized_worktree(worktree: str) -> str:
        """Compare registry paths even after their directories become unavailable."""

        path = Path(worktree).expanduser()
        try:
            path = path.resolve(strict=False)
        except (OSError, RuntimeError):
            # Unreadable paths and symlink loops must not block other projects.
            # New/restored worktrees are still checked by validate_worktree.
            path = Path(os.path.abspath(path))
        return os.path.normcase(str(path))

    @staticmethod
    def _directory_context(directory: str) -> Tuple[Path, Path, Optional[str]]:
        path = Path(directory).expanduser().resolve()
        worktree = path
        vcs: Optional[str] = None
        try:
            result = subprocess.run(
                ["git", "rev-parse", "--show-toplevel"],
                cwd=path,
                capture_output=True,
                text=True,
                timeout=5,
                check=False,
            )
            if result.returncode == 0 and result.stdout.strip():
                worktree = Path(result.stdout.strip()).resolve()
                vcs = "git"
        except (OSError, subprocess.SubprocessError):
            pass
        return path, worktree, vcs

    @classmethod
    def worktree_for_directory(cls, directory: str) -> str:
        """Return a stable runtime scope for CLI sessions in a directory."""

        _, worktree, _ = cls._directory_context(directory)
        return os.path.normcase(str(worktree))

    @staticmethod
    def _directory_access(path: Path) -> Literal["available", "missing", "unreadable"]:
        """Whether the account running Flocks can open ``path`` as a directory.

        ``missing`` means nothing reachable is a directory there; ``unreadable``
        that this account may not reach or list it, whether it exists or not.
        """

        try:
            if not path.is_dir():
                return "missing"
        except OSError:
            # Python 3.12 raises instead of returning False when a parent
            # directory denies search (x) permission; the folder may still
            # exist, this account just cannot reach it.
            return "unreadable"
        if not os.access(path, os.R_OK | os.X_OK):
            return "unreadable"
        # os.access only reads permission bits; on Windows it ignores the access
        # list, so a service account left out of a folder's ACL passes it. Opening
        # the folder for listing is the check the system itself makes.
        try:
            with os.scandir(path):
                pass
        except (FileNotFoundError, NotADirectoryError):
            return "missing"
        except OSError:
            return "unreadable"
        return "available"

    @classmethod
    def _path_status(cls, worktree: str) -> Literal["available", "missing", "unreadable"]:
        return cls._directory_access(Path(worktree))

    @staticmethod
    def _detect_vcs(worktree: str) -> Optional[str]:
        try:
            return "git" if (Path(worktree) / ".git").exists() else None
        except OSError:
            # Same as _path_status: an unreachable worktree has no known VCS.
            return None

    @classmethod
    def allowed_roots(cls, default_worktree: Optional[str] = None) -> List[Path]:
        """Return canonical roots available to the server-side folder picker."""

        configured = os.getenv("FLOCKS_PROJECT_ROOTS", "").strip()
        candidates = [Path(item).expanduser() for item in configured.split(os.pathsep) if item]
        workspace = None
        if not candidates:
            from flocks.workspace.manager import WorkspaceManager

            # The application's configured workspace can live outside HOME,
            # including when ~/.flocks is a symlink. Trust only that workspace,
            # not its parent data directory. Explicit project roots stay strict.
            workspace = WorkspaceManager.get_instance().get_workspace_dir().expanduser()
            candidates = [Path.home(), workspace]
        if default_worktree:
            candidates.append(Path(default_worktree).expanduser())

        roots: List[Path] = []
        for candidate in candidates:
            try:
                resolved = candidate.resolve(strict=candidate != workspace)
            except (OSError, RuntimeError):
                continue
            if not resolved.is_dir() and not (candidate == workspace and not resolved.exists()):
                continue
            if any(resolved == root or resolved.is_relative_to(root) for root in roots):
                continue
            roots = [root for root in roots if not root.is_relative_to(resolved)]
            roots.append(resolved)
        return sorted(roots, key=lambda item: str(item).casefold())

    @classmethod
    def validate_worktree(
        cls,
        worktree: str,
        *,
        default_worktree: Optional[str] = None,
        create_if_missing: bool = False,
    ) -> str:
        """Validate and canonicalize a project directory."""

        if not worktree or not worktree.strip():
            raise ValueError("Project directory cannot be empty")
        requested_path = Path(worktree).expanduser()
        if not requested_path.is_absolute():
            raise ValueError("Project directory must be an absolute path")
        requested_path = Path(os.path.abspath(requested_path))
        roots = cls.allowed_roots(default_worktree)

        try:
            needs_creation = create_if_missing and not requested_path.exists()
        except PermissionError:
            # It may exist: this account cannot reach it. Reported below as
            # such; creating it would fail the same way.
            needs_creation = False
        if needs_creation:
            ancestor = requested_path
            missing_parts: List[str] = []
            while not ancestor.exists() and ancestor != ancestor.parent:
                missing_parts.append(ancestor.name)
                ancestor = ancestor.parent
            try:
                resolved_ancestor = ancestor.resolve(strict=True)
            except (OSError, RuntimeError) as exc:
                raise ValueError("Project directory cannot be resolved") from exc
            target = resolved_ancestor.joinpath(*reversed(missing_parts))
            if roots and not any(target == root or target.is_relative_to(root) for root in roots):
                raise ValueError("Project directory is outside the allowed roots")
            try:
                target.mkdir(parents=True, exist_ok=True)
            except OSError as exc:
                raise ValueError("Project directory could not be created") from exc

        try:
            path = requested_path.resolve(strict=True)
            readable = True
        except PermissionError:
            # A parent denies search, or on Windows the folder's access list
            # leaves this account out: the folder may well exist, so this is a
            # permission to grant, not a path to correct.
            readable = False
            try:
                path = requested_path.resolve(strict=False)
            except (OSError, RuntimeError):
                path = requested_path
        except (OSError, RuntimeError) as exc:
            raise ValueError("Project directory does not exist") from exc
        if readable:
            access = cls._directory_access(path)
            if access == "missing":
                raise ValueError("Project path must be a directory")
            readable = access == "available"

        # The allowed roots and this account's access are separate settings
        # (FLOCKS_PROJECT_ROOTS; the folder's permissions or ACL), each fixed
        # by an administrator: name every one that is missing.
        allowed = not roots or any(path == root or path.is_relative_to(root) for root in roots)
        if not allowed and not readable:
            raise ValueError("Project directory is outside the allowed roots and is not readable")
        if not allowed:
            raise ValueError("Project directory is outside the allowed roots")
        if not readable:
            raise ValueError("Project directory is not readable")
        return os.path.normcase(str(path))

    @classmethod
    def _read_registry_file(cls, path: Path) -> Optional[ProjectRegistry]:
        if not path.exists():
            return None
        try:
            return ProjectRegistry.model_validate_json(path.read_text(encoding="utf-8"))
        except (OSError, ValueError) as exc:
            log.error("project.registry.read_failed", {"path": str(path), "error": str(exc)})
            return None

    @classmethod
    def _read_registry(
        cls,
        owner_id: str,
    ) -> ProjectRegistry:
        path = cls.registry_path(owner_id)
        registry = cls._read_registry_file(path)
        if registry is not None:
            # The pre-task/project split stored a virtual default worktree.
            # Keep reading that field for compatibility but never use it.
            registry.default_worktree = None
            return registry
        return ProjectRegistry(projects=[])

    @classmethod
    def _write_registry(cls, owner_id: str, registry: ProjectRegistry) -> None:
        path = cls.registry_path(owner_id)
        path.parent.mkdir(parents=True, exist_ok=True)

        fd, temporary_path = tempfile.mkstemp(
            dir=str(path.parent),
            prefix=f".{path.stem}.",
            suffix=".tmp",
        )
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                json.dump(
                    registry.model_dump(by_alias=True, exclude_none=True),
                    handle,
                    ensure_ascii=False,
                    indent=2,
                )
                handle.write("\n")
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temporary_path, path)
            try:
                directory_fd = os.open(path.parent, os.O_RDONLY)
                try:
                    os.fsync(directory_fd)
                finally:
                    os.close(directory_fd)
            except OSError:
                pass
        except Exception:
            try:
                os.unlink(temporary_path)
            except OSError:
                pass
            raise

    @classmethod
    def _entry_to_info(
        cls,
        entry: ProjectRegistryEntry,
        *,
        can_write: bool = True,
    ) -> ProjectInfo:
        return ProjectInfo(
            id=entry.id,
            worktree=entry.worktree,
            name=entry.name,
            sourceKind=entry.source_kind,
            scope=entry.scope or WORKBENCH_PROJECT_SCOPE,
            vcs=cls._detect_vcs(entry.worktree),
            time=ProjectTime(created=entry.created_at, updated=entry.updated_at),
            pathStatus=cls._path_status(entry.worktree),
            ownerUserID=entry.owner_user_id,
            canWrite=can_write,
            canDelete=can_write,
            isShared=entry.shared_local,
        )

    @classmethod
    async def ensure_registry(
        cls,
        owner_id: str,
    ) -> ProjectRegistry:
        """Load a registry and create an empty one when needed."""

        async with cls._lock:
            path = cls.registry_path(owner_id)
            with _registry_cross_process_lock(path):
                registry = cls._read_registry(owner_id)
                if not path.exists():
                    cls._write_registry(owner_id, registry)
                return registry

    @classmethod
    async def create(
        cls,
        *,
        owner_id: str,
        name: Optional[str],
        worktree: str,
        source_kind: Literal["local", "git", "zip", "url", "website"] = "local",
        scope: str = WORKBENCH_PROJECT_SCOPE,
    ) -> ProjectInfo:
        """Register an existing directory for a user."""

        scope = normalize_project_scope(scope)
        async with cls._lock:
            with _registry_cross_process_lock(cls.registry_path(owner_id)):
                registry = cls._read_registry(owner_id)
                normalized_worktree = cls.validate_worktree(
                    worktree,
                    create_if_missing=True,
                )

                for entry in registry.projects:
                    if entry.removed_at is not None:
                        continue
                    if cls._normalized_worktree(entry.worktree) == normalized_worktree:
                        raise ProjectPathConflictError(cls._entry_to_info(entry))

                # A blank name falls back to the directory name; only an empty
                # directory name (e.g. a filesystem root) is an error.
                normalized_name = (name or "").strip() or Path(normalized_worktree).name.strip()
                if not normalized_name:
                    raise ValueError("Project name cannot be empty")
                if normalized_name.casefold() in _RESERVED_PROJECT_NAMES:
                    raise ProjectNameConflictError("Project name is reserved")
                if any(
                    entry.removed_at is None
                    and entry.name.strip().casefold() == normalized_name.casefold()
                    for entry in registry.projects
                ):
                    raise ProjectNameConflictError(f"Project name '{normalized_name}' already exists")

                now = cls._now_ms()
                removed_entry = next(
                    (
                        entry
                        for entry in registry.projects
                        if entry.removed_at is not None
                        and cls._normalized_worktree(entry.worktree) == normalized_worktree
                    ),
                    None,
                )
                # Only ordinary workbench folders come back as the old registration.
                # An extension scope keys its own data by registration, so
                # re-adding a folder there starts a new history and the removed
                # registration keeps hiding what belonged to it.
                if (
                    removed_entry is not None
                    and scope == WORKBENCH_PROJECT_SCOPE
                    and (removed_entry.scope or WORKBENCH_PROJECT_SCOPE) == WORKBENCH_PROJECT_SCOPE
                ):
                    removed_entry.scope = scope
                    removed_entry.source_kind = source_kind
                    removed_entry.name = normalized_name
                    removed_entry.worktree = normalized_worktree
                    removed_entry.owner_user_id = owner_id
                    removed_entry.shared_local = False
                    removed_entry.removed_at = None
                    removed_entry.updated_at = now
                    cls._write_registry(owner_id, registry)
                    cls.invalidate_session_stats(owner_id)
                    log.info("project.restored", {"id": removed_entry.id})
                    return cls._entry_to_info(removed_entry)

                project_id = f"prj_{uuid.uuid4()}"
                entry = ProjectRegistryEntry(
                    id=project_id,
                    name=normalized_name,
                    worktree=normalized_worktree,
                    createdAt=now,
                    updatedAt=now,
                    ownerUserID=owner_id,
                    sourceKind=source_kind,
                    scope=scope,
                )
                registry.projects.append(entry)
                cls._write_registry(owner_id, registry)
            cls.invalidate_session_stats(owner_id)
            log.info("project.created", {"id": project_id, "owner": cls._owner_hash(owner_id)})
            return cls._entry_to_info(entry)

    @classmethod
    async def list(
        cls,
        *,
        owner_id: str,
    ) -> List[ProjectInfo]:
        registry = await cls.ensure_registry(owner_id)
        projects = [
            cls._entry_to_info(entry)
            for entry in registry.projects
            if entry.removed_at is None
        ]
        projects.sort(key=lambda item: item.time.updated, reverse=True)
        return projects

    @classmethod
    def _all_registry_entries(
        cls,
        *,
        include_removed: bool = False,
    ) -> List[ProjectRegistryEntry]:
        """Return valid entries across local user registries."""

        registry_dir = cls._flocks_root() / "projects"
        if not registry_dir.is_dir():
            return []
        entries: List[ProjectRegistryEntry] = []
        for path in registry_dir.glob("*.json"):
            registry = cls._read_registry_file(path)
            if registry is not None:
                entries.extend(
                    entry
                    for entry in registry.projects
                    if include_removed or entry.removed_at is None
                )
        return entries

    @classmethod
    def shared_project_ids(cls) -> set[str]:
        """Return IDs of all projects shared to local accounts."""

        return {entry.id for entry in cls._all_registry_entries() if entry.shared_local}

    @classmethod
    def get_owner_user_id(cls, project_id: str) -> Optional[str]:
        """Return the owner of a registered project, if it is available."""

        return next(
            (
                entry.owner_user_id
                for entry in cls._all_registry_entries()
                if entry.id == project_id and entry.owner_user_id
            ),
            None,
        )

    @classmethod
    async def list_visible(
        cls,
        *,
        owner_id: str,
    ) -> List[ProjectInfo]:
        """List owned projects plus projects shared by other local users."""

        owned = await cls.list(owner_id=owner_id)
        owned_ids = {project.id for project in owned}
        shared = [
            cls._entry_to_info(entry, can_write=False)
            for entry in cls._all_registry_entries()
            if entry.shared_local and entry.owner_user_id != owner_id and entry.id not in owned_ids
        ]
        shared.sort(key=lambda item: item.time.updated, reverse=True)
        return [*owned, *shared]

    @classmethod
    def visible_project_ids(cls, owner_id: str) -> set[str]:
        """Return project IDs visible to a local user."""

        return cls.registered_project_ids(owner_id) | cls.shared_project_ids()

    @classmethod
    def is_local_shared(cls, owner_id: Optional[str], project_id: Optional[str]) -> bool:
        """Return whether an owner's registered project is locally shared."""

        if not owner_id or not project_id or project_id == DEFAULT_PROJECT_ID:
            return False
        registry = cls._read_registry(owner_id)
        return any(
            entry.id == project_id
            and entry.removed_at is None
            and entry.shared_local
            for entry in registry.projects
        )

    @classmethod
    async def set_local_shared(
        cls,
        project_id: str,
        *,
        owner_id: str,
        shared: bool,
    ) -> ProjectInfo:
        """Share or unshare an owned project with all local accounts."""

        if project_id == DEFAULT_PROJECT_ID:
            raise ProjectDeletionError("The default project cannot be shared")
        async with cls._lock:
            with _registry_cross_process_lock(cls.registry_path(owner_id)):
                registry = cls._read_registry(owner_id)
                entry = next(
                    (
                        item
                        for item in registry.projects
                        if item.id == project_id and item.removed_at is None
                    ),
                    None,
                )
                if entry is None:
                    raise ValueError(f"Project {project_id} not found")
                entry.owner_user_id = owner_id
                entry.shared_local = shared
                entry.updated_at = cls._now_ms()
                cls._write_registry(owner_id, registry)
            cls.invalidate_session_stats()
            log.info(
                "project.sharing.updated",
                {"id": project_id, "owner": cls._owner_hash(owner_id), "shared": shared},
            )
            return cls._entry_to_info(entry)

    @classmethod
    async def get(
        cls,
        project_id: str,
        *,
        owner_id: str,
    ) -> Optional[ProjectInfo]:
        registry = await cls.ensure_registry(owner_id)
        entry = next(
            (
                item
                for item in registry.projects
                if item.id == project_id and item.removed_at is None
            ),
            None,
        )
        return cls._entry_to_info(entry) if entry else None

    @classmethod
    async def update(cls, project_id: str, *, owner_id: str, name: str) -> ProjectInfo:
        """Rename a registered project."""

        if project_id == DEFAULT_PROJECT_ID:
            raise ProjectDeletionError("The default project cannot be renamed")
        normalized_name = name.strip()
        if not normalized_name:
            raise ValueError("Project name cannot be empty")
        if normalized_name.casefold() in _RESERVED_PROJECT_NAMES:
            raise ProjectNameConflictError("Project name is reserved")

        async with cls._lock:
            with _registry_cross_process_lock(cls.registry_path(owner_id)):
                registry = cls._read_registry(owner_id)
                entry = next(
                    (
                        item
                        for item in registry.projects
                        if item.id == project_id and item.removed_at is None
                    ),
                    None,
                )
                if entry is None:
                    raise ValueError(f"Project {project_id} not found")
                if any(
                    item.id != project_id
                    and item.removed_at is None
                    and item.name.strip().casefold() == normalized_name.casefold()
                    for item in registry.projects
                ):
                    raise ProjectNameConflictError(f"Project name '{normalized_name}' already exists")

                entry.name = normalized_name
                entry.updated_at = cls._now_ms()
                cls._write_registry(owner_id, registry)
            cls.invalidate_session_stats(owner_id)
            log.info("project.updated", {"id": project_id})
            return cls._entry_to_info(entry)

    @classmethod
    async def delete(cls, project_id: str, *, owner_id: str) -> bool:
        """Hide a project registration while preserving metadata for restoration."""

        async with cls.lifecycle_guard(project_id):
            return await cls._delete_locked(project_id, owner_id=owner_id)

    @classmethod
    async def require_deletion_allowed(cls, project_id: str, *, owner_id: str) -> None:
        """Check extension-owned active work while the lifecycle guard is held."""
        from flocks.project.lifecycle import require_project_deletion_allowed

        project = await cls.get(project_id, owner_id=owner_id)
        if project is None:
            raise ValueError(f"Project {project_id} not found")
        await require_project_deletion_allowed(project, owner_id)

    @classmethod
    async def _delete_locked(cls, project_id: str, *, owner_id: str) -> bool:
        """Update the project registry while its lifecycle guard is held."""

        if project_id == DEFAULT_PROJECT_ID:
            raise ProjectDeletionError("The default project cannot be deleted")
        await cls.require_deletion_allowed(project_id, owner_id=owner_id)
        async with cls._lock:
            with _registry_cross_process_lock(cls.registry_path(owner_id)):
                registry = cls._read_registry(owner_id)
                entry = next(
                    (
                        item
                        for item in registry.projects
                        if item.id == project_id and item.removed_at is None
                    ),
                    None,
                )
                if entry is None:
                    raise ValueError(f"Project {project_id} not found")
                now = cls._now_ms()
                entry.removed_at = now
                entry.updated_at = now
                entry.shared_local = False
                cls._write_registry(owner_id, registry)
            cls.invalidate_session_stats(owner_id)
            log.info("project.removed", {"id": project_id})
            return True

    @classmethod
    async def restore(
        cls,
        project_id: str,
        *,
        owner_id: str,
    ) -> Optional[ProjectInfo]:
        """Restore a soft-removed project when its original directory is usable."""

        async with cls.lifecycle_guard(project_id):
            return await cls._restore_locked(project_id, owner_id=owner_id)

    @classmethod
    async def _restore_locked(
        cls,
        project_id: str,
        *,
        owner_id: str,
    ) -> Optional[ProjectInfo]:
        """Restore registry metadata while its lifecycle guard is held."""

        if project_id == DEFAULT_PROJECT_ID:
            return None
        async with cls._lock:
            with _registry_cross_process_lock(cls.registry_path(owner_id)):
                registry = cls._read_registry(owner_id)
                entry = next((item for item in registry.projects if item.id == project_id), None)
                if entry is None:
                    raise ProjectDeletionError(
                        f"Project {project_id} restoration metadata is unavailable"
                    )
                if entry.removed_at is None:
                    return cls._entry_to_info(entry)
                if cls._path_status(entry.worktree) != "available":
                    raise ProjectDeletionError(
                        f"Project '{entry.name}' directory is unavailable; the archived task was not restored"
                    )

                normalized_worktree = cls.validate_worktree(
                    entry.worktree,
                    create_if_missing=False,
                )
                for other in registry.projects:
                    if other.id == entry.id or other.removed_at is not None:
                        continue
                    if cls._normalized_worktree(other.worktree) == normalized_worktree:
                        raise ProjectPathConflictError(cls._entry_to_info(other))
                    if other.name.strip().casefold() == entry.name.strip().casefold():
                        raise ProjectNameConflictError(
                            f"Project name '{entry.name}' already exists"
                        )

                entry.worktree = normalized_worktree
                entry.owner_user_id = owner_id
                entry.shared_local = False
                entry.removed_at = None
                entry.updated_at = cls._now_ms()
                cls._write_registry(owner_id, registry)
            cls.invalidate_session_stats(owner_id)
            log.info("project.restored", {"id": project_id})
            return cls._entry_to_info(entry)

    @classmethod
    def worktree_registration_ids(cls, owner_id: str, project: ProjectInfo) -> set[str]:
        """The project's id plus removed registrations of the same folder."""
        return {entry.id for entry in cls._read_registry(owner_id).projects
                if entry.id == project.id or (entry.removed_at is not None and
                    cls._normalized_worktree(entry.worktree) == cls._normalized_worktree(project.worktree))}

    @classmethod
    async def purge_registrations(cls, owner_id: str, project_ids: set[str]) -> None:
        """Remove registrations after the caller has cleaned the data keyed by them."""
        async with cls._lock:
            with _registry_cross_process_lock(cls.registry_path(owner_id)):
                registry = cls._read_registry(owner_id)
                registry.projects = [entry for entry in registry.projects if entry.id not in project_ids]
                cls._write_registry(owner_id, registry)
            cls.invalidate_session_stats(owner_id)

    @classmethod
    def removed_project_ids(cls) -> set[str]:
        return {entry.id for entry in cls._all_registry_entries(include_removed=True) if entry.removed_at is not None}

    @classmethod
    def registered_project_ids(cls, owner_id: str) -> set[str]:
        registry = cls._read_registry(owner_id)
        return {entry.id for entry in registry.projects if entry.removed_at is None}

    @classmethod
    def registered_project_names(cls) -> Dict[str, str]:
        """Return project display names across local user registries."""

        return {
            entry.id: entry.name
            for entry in cls._all_registry_entries(include_removed=True)
        }

    @classmethod
    def effective_project_id(cls, owner_id: str, stored_project_id: Optional[str]) -> str:
        if stored_project_id and stored_project_id in cls.visible_project_ids(owner_id):
            return stored_project_id
        return TASK_SESSION_GROUP_ID

    @classmethod
    def get_session_stats_cache(
        cls,
        owner_id: str,
        search: str,
    ) -> Optional[Dict[str, Tuple[int, int, Optional[int]]]]:
        """Return a short-lived copy of cached project session statistics."""

        key = (owner_id, search.casefold())
        cached = cls._session_stats_cache.get(key)
        if cached is None:
            return None
        cached_at, stats = cached
        if time.monotonic() - cached_at >= cls._session_stats_cache_ttl_seconds:
            cls._session_stats_cache.pop(key, None)
            return None
        return dict(stats)

    @classmethod
    def set_session_stats_cache(
        cls,
        owner_id: str,
        search: str,
        stats: Dict[str, Tuple[int, int, Optional[int]]],
    ) -> None:
        """Cache project session statistics for an owner and search term."""

        cls._session_stats_cache[(owner_id, search.casefold())] = (
            time.monotonic(),
            dict(stats),
        )

    @classmethod
    def invalidate_session_stats(cls, owner_id: Optional[str] = None) -> None:
        """Invalidate cached project counts after session or registry changes."""

        if owner_id is None:
            cls._session_stats_cache.clear()
            return
        for key in [key for key in cls._session_stats_cache if key[0] == owner_id]:
            cls._session_stats_cache.pop(key, None)

    @classmethod
    async def from_directory(cls, directory: str) -> Dict[str, Any]:
        """Build an ephemeral runtime context without persisting a project."""

        path, worktree, vcs = cls._directory_context(directory)

        now = cls._now_ms()
        project = ProjectInfo(
            id=DEFAULT_PROJECT_ID,
            worktree=str(worktree),
            vcs=vcs,
            name=DEFAULT_PROJECT_NAME,
            time=ProjectTime(created=now, updated=now),
            isDefault=True,
            pathStatus=cls._path_status(str(path)),
        )
        return {"project": project, "sandbox": str(worktree)}
