"""Portable, read-only output classification. Uses only the Python standard library."""
from __future__ import annotations

import hashlib
import json
import os
import re
import stat
import threading
import time
from collections import Counter, OrderedDict
from datetime import datetime
from pathlib import Path, PurePosixPath
from typing import Any

CONFIG_PATH = Path(__file__).with_name("knowledge_categories.json")
_CACHE: OrderedDict[tuple, tuple[float, dict]] = OrderedDict()
_LOCK = threading.Lock()
_DATE = re.compile(r"(?<!\d)(20\d{2})[-_]?([01]\d)[-_]?([0-3]\d)(?!\d)")
_TEXT = {".md", ".txt", ".csv", ".json", ".xml", ".log", ".py", ".js", ".php", ".sh", ".jsonl"}


def load_config(path: Path = CONFIG_PATH) -> dict:
    config = json.loads(path.read_text(encoding="utf-8-sig"))
    if config.get("schemaVersion") != 1:
        raise ValueError("Unsupported knowledge category schemaVersion")
    for key, minimum, maximum in (("cacheSeconds", 1, 300), ("maxNodes", 100, 1000000), ("maxDepth", 1, 64)):
        if type(config.get(key)) is not int or not minimum <= config[key] <= maximum:
            raise ValueError(f"Invalid knowledge category setting: {key}")
    for key in ("documentExtensions", "processExtensions"):
        if not isinstance(config.get(key), list) or not all(isinstance(x, str) and x.startswith(".") for x in config[key]):
            raise ValueError(f"Invalid extension list: {key}")

    def compile_patterns(owner: dict, key: str) -> None:
        values = owner.get(key)
        if not isinstance(values, list) or not all(isinstance(x, str) and len(x) <= 500 for x in values):
            raise ValueError(f"Invalid pattern list: {key}")
        owner[f"_{key}"] = [re.compile(x, re.IGNORECASE) for x in values]

    for key in ("sensitivePatterns", "processPatterns"):
        compile_patterns(config, key)
    categories = config.get("categories")
    if not isinstance(categories, list) or not categories:
        raise ValueError("Knowledge categories cannot be empty")
    ids: set[str] = set()
    for category in categories:
        category_id = category.get("id", "")
        if not re.fullmatch(r"[a-z0-9-]+", category_id) or category_id in ids:
            raise ValueError("Invalid or duplicate knowledge category ID")
        ids.add(category_id)
        if not isinstance(category.get("title"), str) or not category["title"] or type(category.get("priority")) is not int:
            raise ValueError(f"Invalid category: {category_id}")
        compile_patterns(category, "patterns")
        subs = category.get("subcategories", [])
        if not subs or subs[-1].get("patterns") != []:
            raise ValueError(f"Category {category_id} needs a final fallback subcategory")
        sub_ids: set[str] = set()
        for sub in subs:
            if not re.fullmatch(r"[a-z0-9-]+", sub.get("id", "")) or sub["id"] in sub_ids or not sub.get("title"):
                raise ValueError(f"Invalid subcategory in {category_id}")
            sub_ids.add(sub["id"])
            compile_patterns(sub, "patterns")
    if "unclassified" not in ids:
        raise ValueError("Missing unclassified fallback category")
    for tag in config.get("tags", []):
        if not isinstance(tag.get("title"), str) or not tag["title"]:
            raise ValueError("Invalid knowledge tag")
        tag["_pattern"] = re.compile(tag["pattern"], re.IGNORECASE)
    config["_ranked"] = sorted(categories, key=lambda item: -item["priority"])
    return config


def _matches(patterns: list, value: str) -> bool:
    return any(pattern.search(value) for pattern in patterns)


def _date(path: str, modified_at: float) -> str:
    for match in _DATE.finditer(path):
        value = "-".join(match.groups())
        try:
            datetime.strptime(value, "%Y-%m-%d")
            return value
        except ValueError:
            pass
    return datetime.fromtimestamp(modified_at).strftime("%Y-%m-%d") if modified_at else ""


def _sort_key(node: dict) -> tuple:
    stem = PurePosixPath(node["path"]).stem
    without_date = _DATE.sub("", stem)
    clock = re.search(r"(?:^|[T_ -])([0-2]\d)[:_-]?([0-5]\d)(?:[:_-]?([0-5]\d))?$", without_date)
    if clock:
        seconds = int(clock[1]) * 3600 + int(clock[2]) * 60 + int(clock[3] or 0)
    else:
        modified = datetime.fromtimestamp(node["modified_at"])
        seconds = modified.hour * 3600 + modified.minute * 60 + modified.second
    return (node["date"], seconds, node["modified_at"], node["root"], node["path"])


def _attach_evidence(files: list[dict]) -> None:
    directories: dict[tuple, list] = {}
    for node in files:
        if node["kind"] != "process":
            directories.setdefault((node["root"], str(PurePosixPath(node["path"]).parent)), []).append(node)
    for (_, directory), siblings in directories.items():
        documents = [n for n in siblings if n["kind"] == "document"]
        evidence = [n for n in siblings if n["kind"] == "evidence"]
        stems = {PurePosixPath(n["path"]).stem for n in evidence}
        dedicated = directory != "." and not _DATE.fullmatch(PurePosixPath(directory).name)
        for node in documents:
            node["has_evidence"] = PurePosixPath(node["path"]).stem in stems or bool(dedicated and len(documents) == 1 and evidence)


def classify(path: str, root: str, config: dict, modified_at: float = 0) -> dict | None:
    """Classify relative names only; never read or execute document contents."""
    pure = PurePosixPath(path)
    if pure.is_absolute() or any(p.startswith(".") or p in {"", ".."} for p in pure.parts):
        return None
    if _matches(config["_sensitivePatterns"], path):
        return None
    suffix = pure.suffix.lower()
    process = _matches(config["_processPatterns"], path) or suffix in config["processExtensions"]
    if suffix not in config["documentExtensions"] and not process:
        return None
    category = next((c for c in config["_ranked"] if _matches(c["_patterns"], path)),
                    next(c for c in config["categories"] if c["id"] == "unclassified"))
    sub = next(s for s in category["subcategories"] if not s["patterns"] or _matches(s["_patterns"], path))
    tags = [tag["title"] for tag in config.get("tags", []) if tag["_pattern"].search(path)]
    # Strip timestamps, but preserve IP addresses, CVEs and meaningful numeric targets.
    def normalize(value: str) -> str:
        value = re.sub(r"(?<!\d)20\d{2}[-_]?[01]\d[-_]?[0-3]\d(?:[T_ -]\d{2}(?:[:_-]?\d{2}){0,2})?", " ", value)
        value = re.sub(r"(?:[_ -]\d{2}[_:-]\d{2}|[_ -]\d{4})$", "", value)
        return re.sub(r"[\s_-]+", " ", value).strip().casefold()
    title = normalize(pure.stem) or pure.stem
    parents = "/".join(normalize(p) for p in pure.parts[:-1] if not _DATE.fullmatch(p))
    topic = hashlib.sha256(f"{root}|{category['id']}|{sub['id']}|{parents}|{title}|{suffix}".encode()).hexdigest()[:24]
    kind = "process" if process else "evidence" if suffix in {".json", ".csv", ".xml", ".png", ".jpg", ".jpeg", ".webp"} else "document"
    return {
        "name": pure.name, "path": path, "root": root, "root_label": root,
        "type": "file", "is_text_file": suffix in _TEXT, "modified_at": modified_at,
        "category": category["id"], "category_title": category["title"],
        "subcategory": sub["id"], "subcategory_title": sub["title"],
        "tags": tags, "date": _date(path, modified_at), "topic": topic,
        "topic_title": title, "kind": kind, "extension": suffix.lstrip("."),
    }


def scan(roots: list[tuple[str, Path]], config: dict) -> dict:
    files: list[dict] = []
    count = 0
    incomplete = False
    for root_id, root in roots:
        if root.is_symlink() or not root.is_dir():
            continue
        stack = [(root, 0)]
        while stack and count < config["maxNodes"]:
            directory, depth = stack.pop()
            try:
                if directory.is_symlink():
                    incomplete = True
                    continue
                # Recent date directories are visited first. Symlink dirs are never followed.
                with os.scandir(directory) as iterator:
                    entries = sorted(iterator, key=lambda entry: entry.name, reverse=True)
                descend = []
                for entry in entries:
                    if count >= config["maxNodes"]:
                        incomplete = True
                        break
                    count += 1
                    if entry.name.startswith(".") or entry.is_symlink():
                        continue
                    path = Path(entry.path)
                    relative = path.relative_to(root).as_posix()
                    if _matches(config["_sensitivePatterns"], relative):
                        continue
                    info = entry.stat(follow_symlinks=False)
                    if stat.S_ISDIR(info.st_mode):
                        if depth < config["maxDepth"]:
                            descend.append((path, depth + 1))
                        else:
                            incomplete = True
                    elif stat.S_ISREG(info.st_mode):
                        node = classify(relative, root_id, config, info.st_mtime)
                        if node:
                            node["size"] = info.st_size
                            files.append(node)
                stack.extend(reversed(descend))
            except OSError:
                incomplete = True
        if stack:
            incomplete = True
    # Filename time is meaningful within a dated output; mtime is the final tie breaker.
    files.sort(key=_sort_key, reverse=True)
    _attach_evidence(files)
    return {"files": files, "truncated": incomplete, "scanned_nodes": count,
            "indexed_at": time.time(), "config": config}


def get_index(roots: list[tuple[str, Path]], refresh: bool = False, config_path: Path = CONFIG_PATH) -> dict:
    signature = config_path.stat()
    key = (tuple((root_id, str(path.absolute())) for root_id, path in roots),
           str(config_path.absolute()), signature.st_mtime_ns, signature.st_size)
    # Serialize builds so simultaneous list/file requests do not duplicate filesystem scans.
    with _LOCK:
        cached = _CACHE.get(key)
        if cached and not refresh and time.monotonic() - cached[0] < cached[1]["config"]["cacheSeconds"]:
            _CACHE.move_to_end(key)
            return cached[1]
        result = scan(roots, load_config(config_path))
        _CACHE[key] = (time.monotonic(), result)
        _CACHE.move_to_end(key)
        while len(_CACHE) > 8:
            _CACHE.popitem(last=False)
        return result


def summary(index: dict, include_process: bool = False) -> dict:
    files = [n for n in index["files"] if include_process or n["kind"] != "process"]
    counts = Counter(n["category"] for n in files)
    subcounts = Counter((n["category"], n["subcategory"]) for n in files)
    categories = []
    for category in index["config"]["categories"]:
        if not counts[category["id"]]:
            continue
        categories.append({
            "id": category["id"], "title": category["title"], "description": category.get("description", ""),
            "count": counts[category["id"]],
            "subcategories": [{"id": s["id"], "title": s["title"], "count": subcounts[category["id"], s["id"]]}
                              for s in category["subcategories"] if subcounts[category["id"], s["id"]]],
        })
    return {"categories": categories, "count": len(files), "topics": len({n["topic"] for n in files}),
            "tags": sorted({t for n in files for t in n["tags"]}),
            "extensions": sorted({n["extension"] for n in files}),
            "truncated": index["truncated"], "indexed_at": index["indexed_at"]}


def query_files(index: dict, *, category: str = "", subcategory: str = "", query: str = "",
                tag: str = "", extension: str = "", after: str = "", before: str = "",
                topic: str = "", latest: bool = True, include_process: bool = False,
                with_evidence: bool = False, offset: int = 0, limit: int = 50) -> dict:
    terms = query.casefold().split()
    matches = []
    for node in index["files"]:
        if not include_process and node["kind"] == "process":
            continue
        if with_evidence and not node.get("has_evidence"):
            continue
        if any((category and node["category"] != category,
                subcategory and node["subcategory"] != subcategory,
                tag and tag not in node["tags"], extension and node["extension"] != extension,
                after and node["date"] < after, before and node["date"] > before,
                topic and node["topic"] != topic)):
            continue
        searchable = " ".join([node["path"], node["category_title"], node["subcategory_title"], *node["tags"]]).casefold()
        if not all(term in searchable for term in terms):
            continue
        matches.append(node)
    counts = Counter(n["topic"] for n in matches)
    seen: set[str] = set()
    rows = []
    for node in matches:
        if latest and not topic and node["topic"] in seen:
            continue
        seen.add(node["topic"])
        rows.append(node)
    return {"items": [{**n, "version_count": counts[n["topic"]]} for n in rows[offset:offset + limit]],
            "total": len(rows), "file_count": len(matches), "offset": offset,
            "has_more": offset + limit < len(rows), "indexed_at": index["indexed_at"],
            "truncated": index["truncated"]}


def file_context(index: dict, root: str, path: str) -> dict:
    node = next((n for n in index["files"] if n["root"] == root and n["path"] == path), None)
    if node is None:
        return {"node": None, "related": []}
    directory = str(PurePosixPath(path).parent)
    siblings = [n for n in index["files"] if n["root"] == root and str(PurePosixPath(n["path"]).parent) == directory
                and n["path"] != path and n["kind"] != "process"]
    # Only exact basename pairs, or evidence next to a single report in a dedicated folder.
    stem = PurePosixPath(path).stem
    one_report = node["kind"] == "document" and not any(n["kind"] == "document" for n in siblings)
    dedicated = directory != "." and not _DATE.fullmatch(PurePosixPath(directory).name)
    related = [n for n in siblings if PurePosixPath(n["path"]).stem == stem
               or (dedicated and one_report and n["kind"] == "evidence")]
    return {"node": {**node, "version_count": sum(n["topic"] == node["topic"] for n in index["files"])},
            "related": related[:50], "related_truncated": len(related) > 50}
