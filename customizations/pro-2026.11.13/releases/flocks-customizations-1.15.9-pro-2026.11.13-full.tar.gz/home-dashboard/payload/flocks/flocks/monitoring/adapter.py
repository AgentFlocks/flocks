"""Sangfor XDR contract with read-only defaults; discovery never calls devices."""
import json
from flocks.session.interaction_policy import monitoring_call_scope
from flocks.tool.registry import ToolContext, ToolRegistry
from flocks.tool.structured_output import OutputCapture, StructuredOutputError, bounded_copy
from . import diagnostics as diag

ALLOWED_ACTIONS = frozenset({'list', 'get_entities', 'get_proof'})
QUERY_FIELDS = {'deal_statuses', 'white_status', 'time_field'}


def require_query_contract(info):
    properties = info.get_schema().to_json_schema().get('properties', {})
    if not QUERY_FIELDS <= properties.keys():
        raise ContractError('请更新 XDR API 工具：缺少处置状态、加白状态或时间字段筛选能力')


class ContractError(RuntimeError):
    pass


async def device_catalog():
    """List every registered XDR by stable ID, including unavailable targets."""
    from flocks.tool.device.store import list_devices, get_device_tool_enabled
    await ToolRegistry.init_async()
    catalog = []
    tools = ToolRegistry.list_tools()
    for device in await list_devices():
        if device.service_id != 'sangfor_xdr':
            continue
        entry = {'id': device.id, 'name': device.name, 'available': False, 'reason': None, 'tool': None}
        catalog.append(entry)
        if not device.enabled:
            entry['reason'] = 'XDR 接入已停用，请先在设备接入中启用'
            continue
        if not all(device.fields_set.get(key) for key in ('host', 'auth_code')):
            entry['reason'] = 'XDR 接入缺少地址或认证信息，请在设备接入中补全'
            continue
        candidates = []
        for info in tools:
            if (info.name.split('__')[0] == 'sangfor_xdr_incidents' and info.enabled
                    and info.source == 'device' and info.provider == device.storage_key
                    and not info.requires_confirmation
                    and await get_device_tool_enabled(device.id, info.name) is not False):
                schema = info.get_schema().to_json_schema()
                properties = schema.get('properties', {})
                if {'action', 'start_time', 'end_time', 'page_num', 'page_size', 'uuid', 'entity_type', *QUERY_FIELDS} <= properties.keys():
                    candidates.append(info.name)
        if len(candidates) == 1:
            entry.update(available=True, tool=candidates[0])
        elif candidates:
            entry['reason'] = 'XDR 事件查询工具存在多个匹配项，请检查设备工具绑定'
        else:
            entry['reason'] = 'XDR 事件查询工具不可用，请更新 XDR API 工具并检查筛选字段、工具启用状态及确认要求'
    return catalog


async def discover():
    catalog = await device_catalog()
    candidates = [entry for entry in catalog if entry['available']]
    if len(candidates) != 1:
        reason = ('请在监测配置中选择需要监测的 XDR 设备' if len(candidates) > 1 else
                  catalog[0]['reason'] if catalog else
                  '未找到已启用的 XDR 接入，请先在设备接入中添加并启用 XDR')
        return [], None, reason
    device = candidates[0]
    return [device['id']], device['tool'], None


class XdrAdapter:
    allowed_actions = ALLOWED_ACTIONS

    def __init__(self, policy, session_id):
        self.policy, self.session_id = policy, session_id

    async def call(self, device, params, message_id):
        with monitoring_call_scope(self.policy.tool_for(device), device, params), diag.tool_call(), diag.span('tool.execute', device=diag.opaque(device),
                                        action=params.get('action') if params.get('action') in self.allowed_actions else 'other'):
            return await self._call(device, params, message_id)

    async def _call(self, device, params, message_id):
        if params.get('action') not in self.allowed_actions or device not in self.policy.devices:
            diag.event('adapter.failure', failure=True, reason='permission')
            raise PermissionError('Monitoring permits only bound read-only XDR actions')
        tool_name = self.policy.tool_for(device)
        tool = ToolRegistry.get(tool_name)
        if tool is None or not tool.info.enabled or tool.info.requires_confirmation:
            diag.event('adapter.failure', failure=True, reason='unavailable')
            raise ContractError('只读查询能力不可用或需要确认')
        if params.get('action') == 'list' and QUERY_FIELDS.intersection(params):
            require_query_contract(tool.info)
        if 'severities' in params.get('api_params', {}):
            properties = tool.info.get_schema().to_json_schema().get('properties', {})
            if 'severities' not in properties.get('api_params', {}).get('properties', {}):
                raise ContractError('请更新 XDR API 工具：联调抽样需要事件等级筛选能力')
        ctx = ToolContext(session_id=self.session_id, message_id=message_id, agent='rex')
        capture = OutputCapture(tool_name, private=True)
        ctx._output_capture = capture
        try:
            result = await ToolRegistry.execute(
                tool_name,
                ctx=ctx,
                device_id=device, **params,
            )
        finally:
            del ctx._output_capture
        diag.event('adapter.result', success=result.success, truncated=bool(result.truncated),
                   has_error=bool(result.error), **diag.shape(result.output))
        if not result.success:
            diag.event('adapter.failure', failure=True, reason='tool_failed')
            # Device errors may include credentials or raw HTTP bodies. Persist a
            # bounded code; the protected device subsystem retains diagnostics.
            raise ContractError('设备查询失败或权限不足；请检查接入状态')
        try:
            value = capture.take(result)
        except StructuredOutputError as exc:
            diag.event('adapter.failure', failure=True, reason='structured_output', structured_reason=str(exc), truncated=bool(result.truncated))
            raise ContractError('XDR 完整响应不可用或超过处理预算，未提交本页数据') from None
        diag.event('adapter.structured', **diag.shape(value))
        if isinstance(value, str):
            try:
                value = json.loads(value)
            except (ValueError, RecursionError) as exc:
                diag.event('adapter.failure', failure=True, reason='non_json', truncated=bool(result.truncated),
                           error_type=type(exc).__name__, json_position=getattr(exc, 'pos', None),
                           json_line=getattr(exc, 'lineno', None), json_column=getattr(exc, 'colno', None),
                           **diag.shape(value))
                raise ContractError('XDR 返回非 JSON 数据') from None
            try:
                value = bounded_copy(value)
            except StructuredOutputError as exc:
                diag.event('adapter.failure', failure=True, reason='structured_output', structured_reason=str(exc))
                raise ContractError('XDR 响应结构超过处理预算，未提交本页数据') from None
        diag.event('adapter.decoded', **diag.shape(value))
        if not isinstance(value, dict):
            diag.event('adapter.failure', failure=True, reason='not_object')
            raise ContractError('XDR 返回结构不符合契约')
        code = value.get('code')
        code_ok = code is None or (type(code) in (int, str) and code in (0, '0', 200, '200', 'Success'))
        if value.get('success') is False or not code_ok:
            diag.event('adapter.failure', failure=True, reason='business_error')
            raise ContractError('XDR 业务查询失败')
        return value


def response_items(data):
    # Existing XDR handler fixtures use data.item; tool descriptions also
    # advertise data.list. Accept these explicit contracts, never arbitrary
    # nested lists or a missing field as an empty successful response.
    if not isinstance(data, dict):
        raise ContractError('缺少 data.list/data.item；不能将未知响应视为空事件')
    fields = [key for key in ('list', 'item') if key in data]
    if not fields or any(not isinstance(data[key], list) for key in fields):
        raise ContractError('缺少有效 data.list/data.item；不能将未知响应视为空事件')
    if len(fields) == 2 and data['list'] != data['item']:
        raise ContractError('data.list 与 data.item 冲突，查询完整性无法确认')
    return data[fields[0]]


def page_items(value):
    data = value.get('data')
    items = response_items(data)
    if any(not isinstance(x, dict) or not isinstance(x.get('uuId'), str) or not x['uuId'] for x in items):
        raise ContractError('事件缺少稳定 uuId')
    total = data.get('total')
    if total is not None and (isinstance(total, bool) or not isinstance(total, int) or total < 0):
        raise ContractError('分页 total 无效')
    diag.event('page.validated', items=len(items), total=total)
    return items, total


def normalize(device, raw):
    from .event_details import normalize_basics
    # Native incidents use ascending incidentSeverity; legacy riskLevel has
    # the opposite direction. Never fall back from a present but invalid native
    # field, or a conflicting legacy value could override the actual response.
    native = 'incidentSeverity' in raw
    field = 'incidentSeverity' if native else 'riskLevel'
    level = raw.get(field)
    risk_levels = {2, 3, 4} if native else {0, 1, 2}
    valid_levels = {-1, 1, 2, 3, 4} if native else {0, 1, 2, 3, 4, 5}
    valid = type(level) is int and level in valid_levels
    # Low/info is not evidence of a benign event. No auto-ignore policy exists.
    risk = 'risk' if valid and level in risk_levels else 'unknown'
    return {
        'key': f'{device}:incident:{raw["uuId"]}', 'id': raw['uuId'], 'device': device,
        'name': str(raw.get('name') or '未命名事件')[:300],
        'risk': risk, 'riskLevel': level if valid and not native else None,
        'incidentSeverity': level if valid and native else None,
        'severitySource': field if valid else None,
        'incidentThreatClass': raw['incidentThreatClass'][:160] if isinstance(raw.get('incidentThreatClass'), str) else '',
        'incidentThreatType': raw['incidentThreatType'][:160] if isinstance(raw.get('incidentThreatType'), str) else '',
        'host': str(raw.get('hostIp') or '')[:200],
        'alertIds': list(dict.fromkeys(x for x in raw.get('alertIds', [])
                                      if isinstance(x, str) and x and len(x) <= 200)) if isinstance(raw.get('alertIds'), list) else [],
        'closure': 'open', 'disposition': '待人工确认',
        'dealStatus': raw.get('dealStatus') if type(raw.get('dealStatus')) is int else None,
        'startTime': raw.get('startTime') if type(raw.get('startTime')) is int else None,
        'endTime': raw.get('endTime') if type(raw.get('endTime')) is int else None,
        'basics': normalize_basics(raw),
        'reason': ('XDR 事件等级 incidentSeverity 2–4（中危、高危、严重）' if native else 'XDR 旧版 riskLevel 0–2') if risk == 'risk' else '缺少明确忽略依据，保持待判定',
    }
