"""
Tool Registry - Tool registration and management system

Provides a framework for registering, discovering, and executing tools.
Compatible with Flocks's TypeScript Tool system.
"""

import ast
import asyncio
import copy
import importlib
import json
import os
import sys
import threading
import time
from concurrent.futures import TimeoutError as FuturesTimeoutError
from dataclasses import dataclass
from dataclasses import field as dataclass_field
from enum import Enum
from pathlib import Path
from typing import Any, Awaitable, Callable, Dict, List, Literal, Mapping, Optional, Set

from pydantic import BaseModel, Field, field_validator
from pydantic_core import PydanticCustomError

from flocks.utils.log import Log

log = Log.create(service="tool-registry")


class ToolRefreshError(RuntimeError):
    """A refresh stage failed and the previous registry state was restored."""

    def __init__(self, stage: str, errors: List[str]):
        self.stage = stage
        self.errors = list(errors)
        super().__init__(f"{stage}: {'; '.join(self.errors)}")


class ToolCategory(str, Enum):
    """Tool categories"""
    FILE = "file"
    TERMINAL = "terminal"
    BROWSER = "browser"
    CODE = "code"
    SEARCH = "search"
    SYSTEM = "system"
    CUSTOM = "custom"


class ParameterType(str, Enum):
    """Parameter types for tool schema"""
    STRING = "string"
    INTEGER = "integer"
    NUMBER = "number"
    BOOLEAN = "boolean"
    ARRAY = "array"
    OBJECT = "object"


class ToolParameter(BaseModel):
    """Tool parameter definition"""
    name: str = Field(..., description="Parameter name")
    type: ParameterType = Field(..., description="Parameter type")
    description: str = Field("", description="Parameter description")
    required: bool = Field(True, description="Is parameter required")
    default: Optional[Any] = Field(None, description="Default value")
    enum: Optional[List[Any]] = Field(None, description="Allowed values")
    json_schema: Optional[Dict[str, Any]] = Field(
        None,
        description=(
            "Optional JSON Schema override for this parameter. "
            "When provided, this schema will be used as-is (merged with description/default/enum) "
            "instead of the simplified schema derived from `type`."
        ),
    )


class ToolSchema(BaseModel):
    """Tool JSON Schema"""
    type: str = Field("object", description="Schema type")
    properties: Dict[str, Any] = Field(default_factory=dict, description="Parameter properties")
    required: List[str] = Field(default_factory=list, description="Required parameters")

    def to_json_schema(self) -> Dict[str, Any]:
        """Convert to JSON Schema format."""
        schema = {
            "type": self.type,
            "properties": self.properties or {},
        }
        # Only include required if non-empty
        if self.required:
            schema["required"] = self.required
        return schema


def normalize_tool_group(value: Optional[str]) -> Optional[str]:
    """Validate native tool grouping metadata (not a runtime parameter)."""
    if value is None:
        return None
    if not isinstance(value, str):
        raise PydanticCustomError("group_type", "group must be a string or null")
    value = value.strip()
    if len(value) > 32:
        raise PydanticCustomError("group_length", "group must be at most 32 characters")
    if any(ord(char) < 32 or ord(char) == 127 for char in value):
        raise PydanticCustomError("group_control", "group cannot contain control characters")
    return value


def is_shipped_tool_path(path: Path) -> bool:
    """Whether the resolved definition belongs to the installation's native tools.

    Deliberately independent of cwd, Instance, ``native`` and plugin names.
    User/Hub copies (and symlinks pointing outside the installation) stay editable.
    """
    root = Path(__file__).resolve().parents[2] / ".flocks" / "plugins" / "tools"
    return Path(path).resolve().is_relative_to(root.resolve())


def validate_tool_definition_group(path: Path, current: Mapping[str, Any], updates: Mapping[str, Any]) -> None:
    """Preflight a partial native definition update before writing other fields."""
    if "group" in updates and is_shipped_tool_path(path):
        if normalize_tool_group(updates["group"]) != normalize_tool_group(current.get("group")):
            raise ValueError("System tool group is read-only")


class ToolInfo(BaseModel):
    """Tool information"""
    name: str = Field(..., description="Tool name (unique identifier)")
    description: str = Field(..., description="Tool description")
    description_cn: Optional[str] = Field(None, description="Chinese UI description")
    category: ToolCategory = Field(ToolCategory.CUSTOM, description="Tool category")
    parameters: List[ToolParameter] = Field(default_factory=list, description="Tool parameters")
    enabled: bool = Field(True, description="Is tool enabled")
    requires_confirmation: bool = Field(False, description="Requires user confirmation")
    provider: Optional[str] = Field(None, description="Tool provider name (for grouped plugin tools)")
    provider_version: Optional[str] = Field(
        None,
        description=(
            "Provider/service version string (e.g. '9.2'). Sourced from the "
            "`version` field in `_provider.yaml`. Surfaced to the LLM via the "
            "tool description so the model can pick version-appropriate behavior."
        ),
    )
    source: Optional[str] = Field(None, description="Tool source: builtin, dynamic, plugin_py, plugin_yaml, mcp, api, device")
    native: bool = Field(False, description=(
        "True for built-in tools (registered via @register_function) and project-level "
        "plugin tools (<cwd>/.flocks/plugins/tools/). False for user-level plugin tools "
        "(~/.flocks/plugins/tools/). Determined by loading context, not declared in YAML."
    ))
    always_load: Optional[bool] = Field(
        None,
        description="Whether the tool should always be exposed in each request",
    )
    disable_on_repeated_failure: bool = Field(
        True,
        description="Whether identical repeated failures may automatically disable the tool",
    )
    tags: List[str] = Field(
        default_factory=list,
        description="Lightweight retrieval tags used by tool catalog search",
    )
    vendor: Optional[str] = Field(
        None,
        description=(
            "Manufacturer / vendor of the security product this tool integrates with. "
            "Read from `_provider.yaml` → `vendor`. Examples: 'threatbook', 'qianxin', "
            "'sangfor', 'qingteng'. None for non-device tools."
        ),
    )

    group: Optional[str] = Field(None, description="Optional plugin group")
    group_readonly: bool = Field(False, description="Computed from the actual system definition source")
    side_effect: Optional[Literal["none", "idempotent", "queryable", "unknown"]] = Field(
        None,
        description=(
            "What a call may change outside the run (flocks.task.outcome): 'none', "
            "'idempotent' (repeating it has the effect of once by its nature -- not by "
            "an idempotency key, which a retried run does not reuse), 'queryable' (its "
            "effect can be looked up; also for calls guarded by a key) or 'unknown'. "
            "Unset: read-only built-ins are 'none', everything else 'unknown'."
        ),
    )

    _validate_group = field_validator("group", mode="before")(normalize_tool_group)

    def get_schema(self) -> ToolSchema:
        """Generate JSON Schema for this tool."""
        properties = {}
        required = []

        for param in self.parameters:
            if param.json_schema:
                # Prefer user-provided JSON Schema for complex parameters.
                prop: Dict[str, Any] = dict(param.json_schema)
                # Ensure description/default/enum are present unless explicitly overridden.
                if param.description and "description" not in prop:
                    prop["description"] = param.description
                if param.default is not None and "default" not in prop:
                    prop["default"] = param.default
                if param.enum and "enum" not in prop:
                    prop["enum"] = param.enum
            else:
                prop = {
                    "type": param.type.value,
                    "description": param.description,
                }

                # Array type requires items property
                if param.type == ParameterType.ARRAY:
                    prop["items"] = {"type": "string"}

                # Object type requires properties
                if param.type == ParameterType.OBJECT:
                    prop["properties"] = {}

                if param.default is not None:
                    prop["default"] = param.default
                if param.enum:
                    prop["enum"] = param.enum

            properties[param.name] = prop

            if param.required:
                required.append(param.name)

        # For device-integrated tools, surface a synthetic ``device_id`` schema
        # parameter so the LLM knows it can (and usually must) target a
        # specific instance. ToolRegistry.execute strips this kwarg before
        # dispatch and uses it to activate per-device credentials/SSL toggle.
        # Skipped if the tool's YAML already declares a ``device_id`` param.
        if self.source == "device" and "device_id" not in properties:
            properties["device_id"] = {
                "type": "string",
                "description": (
                    "目标设备实例的唯一 ID（UUID），来自 device_manage(action='list') 返回的"
                    " `device_id` 字段。当系统中接入了多台同类型设备（例如多台 TDP）"
                    "时必须传入；只有单台时也建议显式传入以避免歧义。"
                ),
            }

        return ToolSchema(properties=properties, required=required)


class ToolResult(BaseModel):
    """Tool execution result"""
    success: bool = Field(..., description="Execution successful")
    output: Any = Field(None, description="Output data")
    error: Optional[str] = Field(None, description="Error message if failed")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="Additional metadata")
    title: Optional[str] = Field(None, description="Result title for display")
    truncated: bool = Field(False, description="Whether output was truncated")
    attachments: Optional[List[Dict[str, Any]]] = Field(None, description="File attachments")


@dataclass
class PermissionRequest:
    """Permission request for tool execution"""
    permission: str  # Type: read, edit, bash, grep, glob, list, external_directory
    patterns: List[str]  # Patterns to match
    always: List[str] = dataclass_field(default_factory=list)  # Always allow patterns
    metadata: Dict[str, Any] = dataclass_field(default_factory=dict)


class ToolContext:
    """
    Context for tool execution

    Provides session info, abort signal, and permission handling.
    Compatible with Flocks's Tool.Context interface.
    """

    def __init__(
        self,
        session_id: str,
        message_id: str,
        agent: str = "rex",
        call_id: Optional[str] = None,
        extra: Optional[Dict[str, Any]] = None,
        abort_event: Optional[asyncio.Event] = None,
        permission_callback: Optional[Callable[[PermissionRequest], Awaitable[None]]] = None,
        metadata_callback: Optional[Callable[[Dict[str, Any]], None]] = None,
        event_publish_callback: Optional[Callable[[str, Dict[str, Any]], Awaitable[None]]] = None,
        input_patch_callback: Optional[Callable[[Dict[str, Any]], Awaitable[None]]] = None,
        validated_input_guard: Optional[Callable[[str, Dict[str, Any]], Awaitable[bool]]] = None,
    ):
        self.session_id = session_id
        self.message_id = message_id
        self.agent = agent
        self.call_id = call_id
        self.extra = extra or {}
        self._abort_event = abort_event or asyncio.Event()
        self._permission_callback = permission_callback
        self._metadata_callback = metadata_callback
        self._metadata: Dict[str, Any] = {}
        self.event_publish_callback = event_publish_callback
        self._input_patch_callback = input_patch_callback
        # Optional caller-owned precondition on the final effective inputs.
        # It can restrict an allowed call, never bypass an extension's gate.
        self.validated_input_guard = validated_input_guard

    @property
    def idempotency_key(self) -> Optional[str]:
        """A key naming this call, for an external system that deduplicates requests.

        The same for every attempt of this call (a retry inside the tool, a
        replay of the call), different for every other call -- including the
        calls of a run started again, in a new session.  So it guards a call
        against its own repeats, not a task against being run twice: a tool
        that relies on it declares ``side_effect="queryable"``, and a run whose
        such call did not confirm waits for a person instead of retrying.
        """
        if not self.call_id:
            return None
        import hashlib

        return hashlib.sha256(f"{self.session_id}\x00{self.call_id}".encode("utf-8")).hexdigest()[:32]

    async def notify_input_patched(self, effective_input: Dict[str, Any]) -> None:
        """Report the input the handler will actually receive after a
        ``tool.execute.before`` hook patched it.

        Only called when a hook changed the input; the caller (session stream
        layer) uses it to refresh what the UI shows for the running tool.
        A failing callback must not block execution.
        """
        if self._input_patch_callback is None:
            return
        try:
            await self._input_patch_callback(dict(effective_input))
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            log.warn("tool.input_patch_callback.error", {
                "call_id": self.call_id,
                "error": str(exc),
            })

    @property
    def abort(self) -> asyncio.Event:
        """Get abort event (for checking if execution should be cancelled)"""
        return self._abort_event

    @property
    def aborted(self) -> bool:
        """Check if execution was aborted"""
        return self._abort_event.is_set()

    async def ask(
        self,
        permission: str,
        patterns: List[str],
        always: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None
    ) -> None:
        """
        Request permission for an operation

        Args:
            permission: Permission type (read, edit, bash, etc.)
            patterns: Patterns to match
            always: Always-allow patterns
            metadata: Additional metadata
        """
        from flocks.session.interaction_policy import require_interactive
        await require_interactive(self.session_id)
        execution_mode = self.extra.get("execution_mode")
        if execution_mode:
            from flocks.session.execution_mode import is_permission_allowed

            if not is_permission_allowed(
                execution_mode,
                permission,
                patterns,
                self,
            ):
                raise PermissionError(
                    "Plan mode may only edit the current session plan file."
                )

        request = PermissionRequest(
            permission=permission,
            patterns=patterns,
            always=always or ["*"],
            metadata=metadata or {}
        )

        if self._permission_callback:
            await self._permission_callback(request)
        else:
            # Default: auto-approve (for testing/non-interactive mode)
            log.debug("permission.auto_approved", {
                "permission": permission,
                "patterns": patterns
            })

    def metadata(self, input_data: Dict[str, Any]) -> None:
        """
        Update tool metadata (for live progress updates)

        Args:
            input_data: Metadata to update (may contain 'title' and 'metadata' keys)
        """
        if "title" in input_data:
            self._metadata["title"] = input_data["title"]
        if "metadata" in input_data:
            self._metadata.update(input_data["metadata"])

        if self._metadata_callback:
            self._metadata_callback(self._metadata)


def callable_tool_denial_reason(
    tool_name: str,
    allowed_tool_names: Any,
) -> Optional[str]:
    """Return a denial reason when a turn-scoped tool set rejects a call."""
    valid_allowed_tools = (
        isinstance(allowed_tool_names, list)
        and all(isinstance(name, str) and bool(name) for name in allowed_tool_names)
    )
    if not valid_allowed_tools or tool_name not in allowed_tool_names:
        return f"Tool is not callable in this turn: {tool_name}"
    return None


# Type for tool handler function
ToolHandler = Callable[..., Awaitable[ToolResult]]


def _coerce_params(
    kwargs: Dict[str, Any],
    parameters: List[ToolParameter],
    tool_name: str = "",
) -> Dict[str, Any]:
    """Coerce parameter types based on declared schema to handle LLM type mismatches.

    For example, an LLM may pass a list/dict where a string is expected.
    Returns a new dict with coerced values.
    """
    param_type_map = {p.name: p.type for p in parameters}
    coerced: Dict[str, Any] = {}

    def _coerce_json_string(value: Any, expected_type: type[Any]) -> Any:
        if not isinstance(value, str):
            return value
        try:
            parsed = json.loads(value)
        except (TypeError, ValueError, json.JSONDecodeError):
            return value
        if isinstance(parsed, expected_type):
            return parsed
        return value

    for k, v in kwargs.items():
        declared = param_type_map.get(k)
        if declared == ParameterType.STRING and not isinstance(v, str):
            original_type = type(v).__name__
            if isinstance(v, (dict, list)):
                # pretty-print: the main consumer is ``write`` content, where
                # compact JSON is what nobody wants on disk
                v = json.dumps(v, ensure_ascii=False, indent=2)
            else:
                v = str(v)
            log.debug("tool.execute.coerce_param", {
                "tool": tool_name, "param": k,
                "original_type": original_type, "coerced_to": "str",
            })
        elif declared == ParameterType.BOOLEAN and not isinstance(v, bool):
            v = str(v).lower() in ("true", "1", "yes")
        elif declared == ParameterType.INTEGER and not isinstance(v, int):
            try:
                v = int(v)
            except (TypeError, ValueError):
                pass
        elif declared == ParameterType.NUMBER and not isinstance(v, (int, float)):
            try:
                v = float(v)
            except (TypeError, ValueError):
                pass
        elif declared == ParameterType.OBJECT and isinstance(v, str):
            coerced_value = _coerce_json_string(v, dict)
            if coerced_value is not v:
                v = coerced_value
                log.debug("tool.execute.coerce_param", {
                    "tool": tool_name, "param": k,
                    "original_type": "str", "coerced_to": "dict",
                })
        elif declared == ParameterType.ARRAY and isinstance(v, str):
            coerced_value = _coerce_json_string(v, list)
            if coerced_value is not v:
                v = coerced_value
                log.debug("tool.execute.coerce_param", {
                    "tool": tool_name, "param": k,
                    "original_type": "str", "coerced_to": "list",
                })
        coerced[k] = v
    return coerced


def _numeric_type_errors(
    kwargs: Dict[str, Any],
    parameters: List["ToolParameter"],
) -> List[str]:
    """Describe integer/number parameters whose values survived coercion unchanged.

    ``_coerce_params`` leaves a value it cannot convert as-is (``limit="abc"``);
    handing that to the handler produces an opaque TypeError deep inside the
    tool, so refuse it up front the way unknown parameters are refused.
    """
    errors: List[str] = []
    for param in parameters:
        if param.name not in kwargs:
            continue
        value = kwargs[param.name]
        if value is None:
            continue
        if param.type == ParameterType.INTEGER and not isinstance(value, int):
            errors.append(f"parameter '{param.name}' must be an integer (got {value!r})")
        elif param.type == ParameterType.NUMBER and not isinstance(value, (int, float)):
            errors.append(f"parameter '{param.name}' must be a number (got {value!r})")
    return errors


def _normalize_param_key(name: str) -> str:
    """Normalize parameter keys for conservative alias matching."""
    return "".join(ch for ch in str(name).lower() if ch.isalnum())


def _api_service_storage_key(provider: str) -> str:
    """Resolve the single persisted key used for an API-like provider."""
    from flocks.config.api_versioning import versioned_storage_key_for

    return versioned_storage_key_for(provider) or provider


_SCOPED_SCHEMA_ALIASES: Dict[str, Dict[str, str]] = {
    # SkyEye historically surfaced "威胁级别", which some callers guessed as
    # threat_level. Keep the schema canonical on hazard_level, but accept the
    # legacy guess only for this tool so we do not affect other products.
    "skyeye_alarm_list": {
        "threat_level": "hazard_level",
    },
}


def remap_schema_kwargs(
    kwargs: Dict[str, Any],
    declared_param_names: List[str],
    *,
    tool_name: str | None = None,
) -> tuple[Dict[str, Any], Dict[str, str]]:
    """Remap guessed argument keys to declared schema keys when unambiguous.

    Only applies conservative normalization (case / separators), and only when
    a normalized key maps to exactly one declared parameter name.
    """
    scoped_aliases = _SCOPED_SCHEMA_ALIASES.get(tool_name or "", {})
    declared_lookup: Dict[str, List[str]] = {}
    for name in declared_param_names:
        declared_lookup.setdefault(_normalize_param_key(name), []).append(name)

    remapped: Dict[str, Any] = {}
    aliases: Dict[str, str] = {}

    for key, value in kwargs.items():
        if key in declared_param_names:
            remapped[key] = value
            continue
        scoped_target = scoped_aliases.get(key)
        if scoped_target in declared_param_names:
            aliases[key] = scoped_target
            if scoped_target not in remapped:
                remapped[scoped_target] = value
            continue
        normalized = _normalize_param_key(key)
        candidates = declared_lookup.get(normalized, [])
        if len(candidates) == 1:
            # A recognised alias never surfaces as an unknown parameter: when
            # the canonical key was also supplied it wins and the alias is
            # dropped (same rule as the scoped aliases above).
            target = candidates[0]
            aliases[key] = target
            if target not in remapped:
                remapped[target] = value
            continue
        remapped[key] = value

    return remapped, aliases


def _schema_hint_from_properties(
    declared_param_names: List[str],
    required: List[str],
    *,
    max_items: int = 20,
) -> str:
    """Build a compact schema hint string for argument-validation errors."""
    allowed_preview = ", ".join(declared_param_names[:max_items]) or "(none)"
    if len(declared_param_names) > max_items:
        allowed_preview += ", ..."
    required_preview = ", ".join(required[:max_items]) or "(none)"
    if len(required) > max_items:
        required_preview += ", ..."
    return f"Allowed parameters: {allowed_preview}. Required: {required_preview}."


class Tool:
    """Tool wrapper class"""

    def __init__(
        self,
        info: ToolInfo,
        handler: ToolHandler,
    ):
        self.info = info
        self.handler = handler

    async def execute(self, ctx: ToolContext, **kwargs) -> ToolResult:
        """Execute the tool with given parameters and context"""
        from flocks.tool.structured_output import PRIVATE_ERROR, is_private_capture
        private_output = is_private_capture(ctx, self.info.name)
        try:
            raw_kwargs = dict(kwargs)

            # Log tool execution start
            log.info("tool.execute.start", {
                "tool": self.info.name,
                "agent": ctx.agent,
                "session": ctx.session_id,
                "params": list(kwargs.keys()),
            })

            schema = self.info.get_schema()
            schema_properties = schema.properties if isinstance(schema.properties, dict) else {}
            declared_param_names = list(schema_properties.keys())

            # Strict schema precheck: remap obvious aliases first, then validate.
            # This reduces first-call failures caused by case/separator drift
            # (e.g. file_path -> filePath) without allowing speculative params.
            remap_aliases: Dict[str, str] = {}
            effective_kwargs = dict(kwargs)
            if declared_param_names:
                effective_kwargs, remap_aliases = remap_schema_kwargs(
                    effective_kwargs,
                    declared_param_names,
                    tool_name=self.info.name,
                )
                if remap_aliases:
                    log.info("tool.execute.param_remapped", {
                        "tool": self.info.name,
                        "aliases": remap_aliases,
                    })

                unknown = sorted(
                    key for key in effective_kwargs.keys() if key not in schema_properties
                )
                if unknown:
                    schema_hint = _schema_hint_from_properties(
                        declared_param_names,
                        list(schema.required),
                    )
                    return ToolResult(
                        success=False,
                        error=(
                            f"Invalid arguments for {self.info.name}: unknown parameters: "
                            f"{', '.join(unknown)}. {schema_hint}"
                        ),
                        metadata={
                            "schema_precheck": {
                                "tool": self.info.name,
                                "source": self.info.source,
                                "unknown": unknown,
                                "allowed": declared_param_names,
                                "required": list(schema.required),
                                "aliases": remap_aliases,
                            }
                        },
                    )

            # Validate required parameters
            for required_param in schema.required:
                if required_param not in effective_kwargs:
                    log.warn("tool.execute.missing_param", {
                        "tool": self.info.name,
                        "missing": required_param,
                        "provided": list(effective_kwargs.keys()),
                    })
                    schema_hint = _schema_hint_from_properties(
                        declared_param_names,
                        list(schema.required),
                    )
                    return ToolResult(
                        success=False,
                        error=(
                            f"Missing required parameter: {required_param}. "
                            f"{schema_hint}"
                        ),
                        metadata={
                            "schema_precheck": {
                                "tool": self.info.name,
                                "source": self.info.source,
                                "provided": sorted(effective_kwargs.keys()),
                                "allowed": declared_param_names,
                                "required": list(schema.required),
                                "aliases": remap_aliases,
                            }
                        },
                    )

            coerced_kwargs = _coerce_params(effective_kwargs, self.info.parameters, self.info.name)
            type_errors = _numeric_type_errors(coerced_kwargs, self.info.parameters)
            if type_errors:
                schema_hint = _schema_hint_from_properties(
                    declared_param_names,
                    list(schema.required),
                )
                return ToolResult(
                    success=False,
                    error=(
                        f"Invalid arguments for {self.info.name}: "
                        f"{'; '.join(type_errors)}. {schema_hint}"
                    ),
                    metadata={
                        "schema_precheck": {
                            "tool": self.info.name,
                            "source": self.info.source,
                            "invalid_types": type_errors,
                            "allowed": declared_param_names,
                            "required": list(schema.required),
                            "aliases": remap_aliases,
                        }
                    },
                )

            # Preserve extension-owned ingress context for work created by an
            # enclosing lifecycle.  Flocks treats this as an opaque carrier;
            # installed extensions remain responsible for validating its data.
            from flocks.hooks.contracts import (
                HookDecisionAction,
                ToolDecision,
                ToolExecutionOutcome,
                merge_redacted_rewrite,
                restore_redacted_echo,
            )
            from flocks.hooks.execution import (
                current_execution_context,
                execution_stop_error,
            )
            from flocks.hooks.pipeline import HookPipeline
            from flocks.session.tool_execution import (
                build_session_tool_execution_payload,
            )

            tool_context_extra = dict(ctx.extra)
            inherited_context = current_execution_context()
            if inherited_context and not isinstance(
                tool_context_extra.get("execution_context"), dict
            ):
                tool_context_extra["execution_context"] = inherited_context
            tool_context_extra["tool_call_id"] = getattr(ctx, "call_id", None)
            tool_context_extra["tool_source"] = getattr(self.info, "source", None)
            tool_context_extra["tool_category"] = getattr(self.info.category, "value", self.info.category)
            payload = await build_session_tool_execution_payload(
                session_id=ctx.session_id,
                message_id=ctx.message_id,
                agent=ctx.agent,
                tool_name=self.info.name,
                tool_input=raw_kwargs,
                tool_schema=schema.to_json_schema(),
                tool_context_extra=tool_context_extra,
                validated_input=coerced_kwargs,
            )
            execution_context = current_execution_context()
            path_binding = execution_context.get("filesystem_path_binding")
            had_binding = "filesystem_path_binding" in ctx.extra
            previous_binding = ctx.extra.get("filesystem_path_binding")
            if isinstance(path_binding, Mapping):
                ctx.extra["filesystem_path_binding"] = dict(path_binding)
            started_at = time.perf_counter()
            result: ToolResult | None = None
            terminal_status = "error"
            terminal_error: BaseException | None = None
            input_patched = False
            try:
                from flocks.hooks.tool_gate import run_tool_gate, take_carried_decision

                # The only tool.execute.before firing for this call: the
                # session stream layer does not run it again (it learns about
                # an input rewrite via notify_input_patched), and a caller that
                # already ran the gate passes its verdict down rather than
                # having the handlers asked twice.
                verdict = take_carried_decision(
                    ctx.extra, call_id=getattr(ctx, "call_id", None)
                )
                original_kwargs = coerced_kwargs
                legacy_base = coerced_kwargs
                rewritten: Dict[str, Any] = {}
                if verdict is None:
                    # The flat legacy keys travel next to the contract, as they did
                    # when the stream layer fired this gate: a handler written
                    # against the old shape rewrites ``tool.input`` in place. Give
                    # it a deep copy so nothing it mutates reaches the handler
                    # unseen. Hooks on ``tool.input.rewrite`` do not need it.
                    legacy_input = copy.deepcopy(coerced_kwargs)
                    verdict = await run_tool_gate(
                        {
                            **payload,
                            "sessionID": ctx.session_id,
                            "workspace": tool_context_extra.get("workspace_dir"),
                            "agent": ctx.agent,
                            "tool": {
                                "name": self.info.name,
                                "input": legacy_input,
                                "callID": getattr(ctx, "call_id", None),
                            },
                        },
                        call_id=getattr(ctx, "call_id", None),
                        tool_input=legacy_input,
                    )
                    # One gate pass authorizes the call (approvals and audit run
                    # once). Policies judged the redact_sensitive view, so an
                    # in-place rewrite may only fill values hidden there: the
                    # secrets a redaction hook restores. Anything a policy
                    # can see must come through validated_input_patch.
                    rewritten = verdict.tool_input or {}
                    legacy_base = merge_redacted_rewrite(coerced_kwargs, rewritten)
                decision = verdict.decision
                if decision.validated_input_patch or legacy_base != coerced_kwargs:
                    # Hooks see the redact_sensitive view; never let an echoed
                    # "[REDACTED]" marker replace the real (restored) secret.
                    patch = restore_redacted_echo(
                        legacy_base,
                        dict(decision.validated_input_patch or {}),
                    )
                    patched_kwargs, _ = remap_schema_kwargs(
                        {**legacy_base, **patch},
                        declared_param_names,
                        tool_name=self.info.name,
                    )
                    invalid_patch_keys = sorted(
                        key for key in patched_kwargs if key not in schema_properties
                    )
                    if invalid_patch_keys:
                        raise ValueError(
                            "Hook requested invalid validated_input_patch keys: "
                            + ", ".join(invalid_patch_keys)
                        )
                    for required_param in schema.required:
                        if required_param not in patched_kwargs:
                            raise ValueError(
                                "Hook patch removed required parameter: "
                                + required_param
                            )
                    coerced_kwargs = _coerce_params(
                        patched_kwargs,
                        self.info.parameters,
                        self.info.name,
                    )
                    payload = await build_session_tool_execution_payload(
                        session_id=ctx.session_id,
                        message_id=ctx.message_id,
                        agent=ctx.agent,
                        tool_name=self.info.name,
                        tool_input=raw_kwargs,
                        tool_schema=schema.to_json_schema(),
                        tool_context_extra=tool_context_extra,
                        validated_input=coerced_kwargs,
                    )
                input_patched = coerced_kwargs != original_kwargs
                dropped = sorted(
                    key for key in set(rewritten) | set(original_kwargs)
                    if rewritten
                    and rewritten.get(key) != original_kwargs.get(key)
                    and rewritten.get(key) != coerced_kwargs.get(key)
                )
                if dropped:
                    # Visible values a legacy hook changed in place without
                    # also patching them through the contract.
                    log.warn("tool.legacy_input_rewrite.ignored", {
                        "tool": self.info.name,
                        "call_id": getattr(ctx, "call_id", None),
                        "keys": dropped,
                    })
                if decision.action is HookDecisionAction.DENY:
                    terminal_status = "deny"
                    result = ToolResult(
                        success=False,
                        error=decision.reason or "Tool execution denied by hook",
                        metadata={
                            "hook_decision": decision.model_dump(mode="json"),
                            "blocked_by_hook": True,
                        },
                    )
                elif decision.action is HookDecisionAction.CONFIRM:
                    terminal_status = "confirm"
                    result = ToolResult(
                        success=False,
                        error=decision.reason or "Tool execution requires confirmation",
                        metadata={
                            "hook_decision": decision.model_dump(mode="json"),
                            "confirmation_required": True,
                            "correlation_id": payload["tool_execution"]["execution"]["id"],
                        },
                    )
                else:
                    inputs_allowed = True
                    if ctx.validated_input_guard is not None:
                        try:
                            inputs_allowed = await ctx.validated_input_guard(
                                self.info.name, copy.deepcopy(coerced_kwargs)
                            ) is True
                        except Exception:
                            inputs_allowed = False
                    if not inputs_allowed:
                        terminal_status = "deny"
                        result = ToolResult(
                            success=False,
                            error="Final tool arguments did not satisfy the caller's execution precondition",
                            metadata={
                                "validated_input_guard_blocked": True,
                                "hook_decision": decision.model_dump(mode="json"),
                            },
                        )
                    else:
                        if input_patched:
                            await ctx.notify_input_patched(coerced_kwargs)
                        from flocks.session.interaction_policy import require_monitor_read, require_interactive
                        if getattr(self.info, "requires_confirmation", False):
                            await require_interactive(ctx.session_id)
                        await require_monitor_read(self.info.name, coerced_kwargs, ctx.session_id,
                                                   resolved_device=ctx.extra.get("monitor_resolved_device"))
                        from flocks.monitoring import diagnostics as monitor_diag
                        with monitor_diag.span("tool.handler"):
                            result = await self.handler(ctx, **coerced_kwargs)
                        terminal_status = "success" if result.success else "error"
            except asyncio.CancelledError as exc:
                terminal_status = "cancelled"
                terminal_error = exc
                raise
            except Exception as exc:
                terminal_status = "error"
                terminal_error = exc
                result = ToolResult(success=False, error=str(exc))
            finally:
                if had_binding:
                    ctx.extra["filesystem_path_binding"] = previous_binding
                else:
                    ctx.extra.pop("filesystem_path_binding", None)
                duration_ms = max(0, int((time.perf_counter() - started_at) * 1000))
                summary: Any = None
                if result is not None and result.output is not None:
                    summary = {
                        "type": type(result.output).__name__,
                        "truncated": bool(result.truncated),
                    }
                error_message = (str(terminal_error) if terminal_error is not None
                                 else result.error if result and not result.success else None)
                if private_output and error_message:
                    error_message = PRIVATE_ERROR
                outcome = ToolExecutionOutcome(
                    status=terminal_status,
                    duration_ms=duration_ms,
                    error_type=(
                        type(terminal_error).__name__
                        if terminal_error is not None
                        else None
                    ),
                    error_message=error_message,
                    result_summary=summary,
                )
                try:
                    await HookPipeline.run_tool_after({
                        **payload,
                        "outcome": outcome.model_dump(mode="json"),
                    })
                except Exception as after_exc:
                    log.error("tool.execute.after_hook.error", {
                        "tool": self.info.name,
                        "error": PRIVATE_ERROR if private_output else str(after_exc),
                    })
            if result is None:
                raise RuntimeError("Tool execution did not produce a result")

            from flocks.monitoring import diagnostics as monitor_diag
            monitor_diag.tool_result('tool.raw', result)
            from flocks.tool.structured_output import capture_output, hide_private_output
            capture_output(ctx, self.info.name, result)
            hidden = hide_private_output(ctx, self.info.name, result)

            with monitor_diag.span('tool.normalize'):
                # Auto-truncate output unless the tool already handled it
                if result.success and not result.truncated and not hidden:
                    from flocks.tool.truncation import truncate_output
                    output_text = result.output
                    if output_text is not None and not isinstance(output_text, str):
                        import json as _json
                        try:
                            output_text = _json.dumps(output_text, ensure_ascii=False, indent=2)
                            result.output = output_text
                        except (TypeError, ValueError):
                            output_text = str(output_text)
                            result.output = output_text
                    if isinstance(output_text, str):
                        agent_name = ctx.agent if isinstance(ctx.agent, str) else ""
                        tr = truncate_output(output_text, has_task_tool="task" in agent_name.lower())
                        if tr.truncated:
                            result.output = tr.content
                            result.truncated = True
                            result.metadata = {
                                **(result.metadata or {}),
                                "truncated": True,
                                "output_path": tr.output_path,
                            }

            monitor_diag.tool_result('tool.normalized', result)
            log.info("tool.execute.complete", {
                "tool": self.info.name,
                "success": result.success,
                "has_output": bool(result.output),
                "truncated": result.truncated,
            })

            return result

        except Exception as e:
            if isinstance(e, FuturesTimeoutError):
                raise
            log.error("tool.execute.error", {
                "tool": self.info.name,
                "error": PRIVATE_ERROR if private_output else str(e),
                "error_type": type(e).__name__,
            })
            return ToolResult(
                success=False,
                error=PRIVATE_ERROR if private_output else str(e)
            )


class ToolRegistry:
    """
    Tool Registry - manages tool registration and execution

    Compatible with Flocks's Tool Registry pattern.
    """

    _builtin_module_groups = [
        # file/ — filesystem operations
        (
            "flocks.tool.file",
            [
                "read",
                "write",
                "edit",
                "apply_patch",
                "glob",
                "doc_parser",
                "delete",
                "move",
                "copy",
                "mkdir",
            ],
        ),
        # code/ — code analysis + terminal
        ("flocks.tool.code", ["bash", "grep", "lsp_tool"]),
        # web/ — internet access
        ("flocks.tool.web", ["webfetch", "websearch"]),
        # Owner-scoped, read-only Knowledgebase retrieval (connection is lazy).
        # REA reverse-analysis cards and task progress (rea_analysis).
        ("flocks.tool", ["knowledgebase", "rea", "task_diagnosis"]),
        # agent/ — agent delegation/coordination
        ("flocks.tool.agent", ["delegate_task", "task", "communication"]),
        # task/ — task/workflow
        ("flocks.tool.task", [
            "schedule_task_center",
            "todo",
            "run_workflow",
            "run_workflow_node",
            "workflow_config_manage",
        ]),
        # security/ — SSH forensics + threat intelligence (optional: asyncssh)
        ("flocks.tool.security", ["ssh_host_cmd", "ssh_run_script"]),
        # system/ — questions, model config, memory, MCP management, session management, slash commands
        ("flocks.tool.system", ["question", "plan_exit", "model_config", "memory", "flocks_mcp", "session_manage", "slash_command", "tool_search"]),
        # skill/ — skill management (search, install, status, deps, remove, load)
        ("flocks.tool.skill", ["flocks_skills", "skill_load"]),
        # device/ — security device asset context and status probes
        ("flocks.tool.device", ["manage_tool"]),
        # channel/ — IM platform messaging
        ("flocks.tool.channel", ["channel_message", "im_send_message"]),
        # wecom/ — 企业微信 MCP（文档、智能表格）
        ("flocks.tool.wecom", ["wecom_mcp"]),
        # invalid-argument fallback tool (excluded from search/callable schema by name)
        ("flocks.tool", ["invalid"]),
    ]

    _tools: Dict[str, Tool] = {}
    _initialized: bool = False
    _dynamic_modules: Dict[str, str] = {}
    _dynamic_tools_by_module: Dict[str, List[str]] = {}
    _plugin_tool_names: List[str] = []
    # Source-level plugin failures observed by the last load. They remain
    # diagnostic only because the plugin loader already isolates each source.
    _plugin_load_errors: List[str] = []
    _revision: int = 0
    _config_state_token: Optional[tuple[str, int, int, int]] = None
    _failure_state: Dict[str, Dict[str, Any]] = {}
    _failure_disable_threshold: int = 3
    _init_lock = threading.Lock()
    _refresh_lock = threading.RLock()
    _initializing_thread_id: Optional[int] = None

    # Snapshot of every tool's factory-default ``enabled`` flag — captured
    # in :meth:`register` at the moment the tool object is handed to the
    # registry (i.e. right after construction from YAML / decorator /
    # ``TOOLS`` attribute + :func:`apply_tool_catalog_defaults`, but
    # BEFORE any of the overlay / service-sync machinery gets to mutate
    # ``tool.info.enabled``).  This is the source of truth for the
    # "factory default" surfaced in the HTTP API and used by
    # :func:`reset_tool_setting` to recover the original value for tools
    # that don't have a YAML file (built-in / plugin_py).
    #
    # Lifecycle is kept in lock-step with ``_tools``:
    #   • :meth:`register`                 → write (always overwrites,
    #     so a YAML upgrade that flips the default is picked up on the
    #     next reload/`POST /reload`).
    #   • :meth:`_unregister_plugin_tools` → pop  (avoids stale defaults
    #     leaking across ``refresh_plugin_tools`` cycles).
    _enabled_defaults: Dict[str, bool] = {}

    @classmethod
    def _core_definition_paths(cls) -> List[Path]:
        package_root = Path(__file__).resolve().parents[1]
        return [
            package_root.joinpath(*package.split(".")[1:], f"{module}.py").resolve()
            for package, modules in cls._builtin_module_groups
            for module in modules
        ] + [Path(__file__).resolve()]

    @classmethod
    def _is_core_handler(cls, handler: Callable) -> bool:
        code = getattr(handler, "__code__", None)
        return code is not None and Path(code.co_filename).resolve() in cls._core_definition_paths()

    @classmethod
    def _definition_group_readonly(cls, tool: Tool) -> bool:
        definition = getattr(tool, "_yaml_path", None) or getattr(tool, "_definition_path", None)
        if definition is not None:
            return is_shipped_tool_path(definition)
        if cls._is_core_handler(tool.handler):
            return True
        code = getattr(tool.handler, "__code__", None)
        return code is not None and is_shipped_tool_path(Path(code.co_filename))

    @classmethod
    def validate_group_settings(cls, settings: Mapping[str, Any]) -> None:
        """Preflight incoming tool_settings without loading plugins or config.

        Safe inside ConfigWriter and generic config preflight: enabled-only
        entries do nothing, and even a cold registry uses metadata-only reads.
        No bootstrap, config overlay, plugin execution or ConfigWriter calls.
        """
        for name, entry in settings.items():
            if not isinstance(entry, Mapping) or "group" not in entry:
                continue
            desired = normalize_tool_group(entry["group"])
            tool = cls._tools.get(name)
            if tool is not None:
                readonly = cls._definition_group_readonly(tool)
                group = tool.info.group
            else:
                readonly, group = cls._unloaded_definition_group(name)
            if readonly and desired != normalize_tool_group(group):
                raise ValueError(f"System tool group is read-only: {name}")

    @classmethod
    def _unloaded_definition_group(cls, name: str) -> tuple[bool, Optional[str]]:
        # Core registration wins over plugin discovery, including modules
        # imported before init and intentionally non-native core tools.
        for path in cls._core_definition_paths():
            if not path.is_file():
                continue
            for node in ast.walk(ast.parse(path.read_text(encoding="utf-8"))):
                if not isinstance(node, ast.Call) or not isinstance(node.func, ast.Attribute):
                    continue
                if node.func.attr != "register_function":
                    continue
                fields = {kw.arg: kw.value for kw in node.keywords}
                name_node = fields.get("name")
                if isinstance(name_node, ast.Constant) and name_node.value == name:
                    group_node = fields.get("group")
                    group = ast.literal_eval(group_node) if group_node is not None else None
                    return True, normalize_tool_group(group)
        from flocks.tool.tool_loader import find_yaml_tool, _read_yaml_raw

        path = find_yaml_tool(name)
        if path is not None and is_shipped_tool_path(path):
            return True, normalize_tool_group(_read_yaml_raw(path).get("group"))
        return False, None

    @classmethod
    def register(cls, tool: Tool) -> None:
        """Register a tool"""
        tool.info.group_readonly = cls._definition_group_readonly(tool)
        try:
            from flocks.tool.catalog import apply_tool_catalog_defaults

            tool.info = apply_tool_catalog_defaults(tool.info)
        except Exception as e:
            log.debug("tool.policy_defaults.apply_failed", {
                "name": tool.info.name,
                "error": str(e),
            })
        # Capture the factory default BEFORE anything else can touch
        # ``info.enabled``.  ``apply_tool_catalog_defaults`` above only
        # fills metadata like ``always_load`` and never flips
        # ``enabled``, so whatever we read here is the value written in
        # the YAML / decorator at source-tree time.
        #
        # Direct assignment (not setdefault) is deliberate: every
        # ``register`` — including re-registering the same name after a
        # YAML edit via ``POST /api/tools/{name}/reload`` or a
        # ``refresh_plugin_tools`` cycle — must refresh the snapshot so
        # ``enabled_default`` / ``reset`` reflect the current source of
        # truth instead of the first value ever observed.
        with cls._refresh_lock:
            cls._enabled_defaults[tool.info.name] = bool(tool.info.enabled)
            cls._tools[tool.info.name] = tool
        log.debug("tool.registered", {
            "name": tool.info.name,
            "category": tool.info.category.value,
        })

    @classmethod
    def revision(cls) -> int:
        """Return the current registry revision.

        The revision is bumped when tool membership or enabled state changes
        so long-lived session caches can detect toolset changes.
        """
        cls._ensure_initialized()
        cls._sync_configured_enabled_states()
        with cls._refresh_lock:
            return cls._revision

    @classmethod
    def _current_config_state_token(cls) -> tuple[str, int, int, int]:
        """Return a cross-process token for the active flocks config file."""
        from flocks.config.config_writer import ConfigWriter

        path = ConfigWriter._get_config_path()
        try:
            stat = path.stat()
            return str(path), stat.st_ino, stat.st_mtime_ns, stat.st_size
        except OSError:
            return str(path), -1, -1, -1

    @classmethod
    def _sync_configured_enabled_states(cls) -> None:
        """Apply config changes written by another server worker.

        Registry revisions and ``ToolInfo.enabled`` values are process-local,
        while ``flocks.json`` is shared.  Rebuild enabled states whenever the
        atomically replaced config file changes so a request handled by a
        different worker immediately observes tool/service toggles and
        repeated-failure auto-disables.
        """
        try:
            token = cls._current_config_state_token()
        except Exception:
            return

        with cls._refresh_lock:
            if token == cls._config_state_token:
                return

            previous_states = {
                name: bool(tool.info.enabled)
                for name, tool in cls._tools.items()
            }
            for name, tool in cls._tools.items():
                default_enabled = cls._enabled_defaults.get(name)
                if default_enabled is not None:
                    tool.info.enabled = default_enabled
            cls._sync_api_service_states()
            cls._apply_tool_settings()
            cls._config_state_token = token

            changed_names = [
                name
                for name, tool in cls._tools.items()
                if previous_states[name] != bool(tool.info.enabled)
            ]
            for name in changed_names:
                if cls._tools[name].info.enabled:
                    cls._reset_failure_state(name)
            if changed_names:
                cls._bump_revision("config_enabled_state_sync")

    @classmethod
    def _bump_revision(cls, reason: str) -> None:
        """Advance the registry revision and invalidate agent prompt caches."""
        with cls._refresh_lock:
            cls._revision += 1
            revision = cls._revision
        try:
            from flocks.agent.registry import Agent
            Agent.invalidate_cache()
        except Exception as e:
            log.debug("tool.revision.agent_invalidate_failed", {"error": str(e)})
        log.debug("tool.registry.revision.bumped", {"revision": revision, "reason": reason})

    @classmethod
    def register_function(
        cls,
        name: str,
        description: str,
        description_cn: Optional[str] = None,
        category: ToolCategory = ToolCategory.CUSTOM,
        parameters: Optional[List[ToolParameter]] = None,
        requires_confirmation: bool = False,
        native: Optional[bool] = None,
        always_load: Optional[bool] = None,
        tags: Optional[List[str]] = None,
        enabled: bool = True,
        group: Optional[str] = None,
    ) -> Callable[[ToolHandler], ToolHandler]:
        """
        Decorator to register a function as a tool.

        ``native=None`` means the loading context decides. Built-in tools get
        ``native=True`` in bulk by ``_register_builtin_tools()`` only when the
        decorator did not explicitly pass ``native``. User plugin Python files
        that use this decorator still default to ``native=False`` unless their
        loading path marks them project-level.

        Usage:
            @ToolRegistry.register_function(
                name="read",
                description="Read file contents",
                parameters=[ToolParameter(name="filePath", type=ParameterType.STRING)]
            )
            async def read_tool(ctx: ToolContext, filePath: str) -> ToolResult:
                ...
        """
        def decorator(func: ToolHandler) -> ToolHandler:
            info_kwargs: Dict[str, Any] = {
                "name": name,
                "description": description,
                "description_cn": description_cn,
                "category": category,
                "parameters": parameters or [],
                "requires_confirmation": requires_confirmation,
                "always_load": always_load,
                "tags": list(tags or []),
                "enabled": enabled,
                "group": group,
            }
            if native is not None:
                info_kwargs["native"] = native
            info = ToolInfo(**info_kwargs)
            tool = Tool(info=info, handler=func)
            cls.register(tool)
            return func
        return decorator

    @classmethod
    def unregister(cls, name: str) -> bool:
        """Unregister a tool by name. Returns True if the tool was found and removed."""
        with cls._refresh_lock:
            removed = cls._tools.pop(name, None)
        if removed:
            log.debug("tool.unregistered", {"name": name})
        return removed is not None

    @classmethod
    def _ensure_initialized(cls) -> None:
        """Initialize the registry on first public access."""
        if not cls._initialized and cls._initializing_thread_id != threading.get_ident():
            cls.init()

    @classmethod
    def get(cls, name: str) -> Optional[Tool]:
        """Get a tool by name"""
        cls._ensure_initialized()
        cls._sync_configured_enabled_states()
        with cls._refresh_lock:
            return cls._tools.get(name)

    @classmethod
    def list_tools(cls, category: Optional[ToolCategory] = None) -> List[ToolInfo]:
        """List all registered tools, optionally filtered by category"""
        cls._ensure_initialized()
        cls._sync_configured_enabled_states()
        with cls._refresh_lock:
            tools = list(cls._tools.values())
            if category:
                tools = [t for t in tools if t.info.category == category]
            return [t.info for t in tools]

    @classmethod
    def get_schema(cls, name: str) -> Optional[ToolSchema]:
        """Get tool schema by name"""
        tool = cls.get(name)
        if tool:
            return tool.info.get_schema()
        return None

    @classmethod
    async def execute(
        cls,
        tool_name: str,
        ctx: Optional[ToolContext] = None,
        **kwargs
    ) -> ToolResult:
        """Execute a tool by name"""
        from flocks.session.runtime_controls import runtime_controls

        controls = runtime_controls.get()
        if controls is not None:
            controls.check_budget()
            denial = controls.denial(tool_name)
            if denial:
                return ToolResult(success=False, error=denial)
            if controls.sandbox_required:
                sandbox = ctx.extra.get("sandbox") if ctx else None
                if not sandbox or not sandbox.get("container_name"):
                    return ToolResult(success=False, error="Required sandbox is unavailable; refusing host execution")
                if ctx.extra.get("sandbox_elevated"):
                    return ToolResult(success=False, error="Elevated host execution is disabled in headless sandbox mode")

        # Create default context if not provided
        if ctx is None:
            ctx = ToolContext(
                session_id="default",
                message_id="default"
            )

        # Model-originated session calls are limited to the exact tool schema
        # sent for this turn. Fail closed when that schema context is absent or
        # malformed, before registry lookup, governance hooks, or handlers run.
        if ctx.extra.get("enforce_callable_tools") is True:
            denial_reason = callable_tool_denial_reason(
                tool_name,
                ctx.extra.get("turn_callable_tool_names"),
            )
            if denial_reason:
                log.warn("tool.execute.not_callable", {
                    "name": tool_name,
                    "session_id": ctx.session_id,
                })
                return ToolResult(
                    success=False,
                    error=denial_reason,
                )

        tool = cls.get(tool_name)
        if not tool:
            return ToolResult(
                success=False,
                error=f"Tool not found: {tool_name}"
            )
        from flocks.session.interaction_policy import require_interactive
        if tool_name == "question" or getattr(tool.info, "requires_confirmation", False):
            try:
                await require_interactive(ctx.session_id)
            except PermissionError as exc:
                return ToolResult(success=False, error=str(exc))

        from flocks.session.interaction_policy import require_monitor_read
        try:
            await require_monitor_read(tool_name, kwargs, ctx.session_id)
        except PermissionError as exc:
            return ToolResult(success=False, error=str(exc))

        execution_mode = ctx.extra.get("execution_mode")
        if execution_mode:
            from flocks.session.execution_mode import (
                is_tool_allowed,
                tool_call_denial_reason,
            )

            if not is_tool_allowed(execution_mode, tool_name):
                log.warn("tool.execute.execution_mode_denied", {
                    "name": tool_name,
                    "execution_mode": str(execution_mode),
                    "session_id": ctx.session_id,
                })
                return ToolResult(
                    success=False,
                    error=(
                        f"Tool {tool_name!r} is not available in "
                        f"{str(getattr(execution_mode, 'value', execution_mode))!r} execution mode."
                    ),
                )
            denial_reason = tool_call_denial_reason(
                execution_mode,
                tool_name,
                kwargs,
                ctx,
            )
            if denial_reason:
                log.warn("tool.execute.execution_mode_call_denied", {
                    "name": tool_name,
                    "execution_mode": str(execution_mode),
                    "session_id": ctx.session_id,
                })
                return ToolResult(success=False, error=denial_reason)

        log.info("tool.execute", {
            "name": tool_name,
            "params": list(kwargs.keys()),
        })

        device_id = None
        per_device_enabled = None

        from flocks.tool.credential_context import is_credential_probe_active

        credential_probe_active = is_credential_probe_active()
        if tool.info.source == "device" and tool.info.provider:
            requested_device_id = kwargs.pop("device_id", None)
            try:
                resolved_device_id, resolution_error = await cls._resolve_device_target(
                    storage_key=tool.info.provider,
                    requested_device_id=str(requested_device_id).strip() if requested_device_id else None,
                )
            except Exception as exc:
                log.warn("tool.device.target_resolve_failed", {
                    "tool": tool_name,
                    "provider": tool.info.provider,
                    "device_id": requested_device_id,
                    "error": str(exc),
                })
                resolved_device_id = None
                resolution_error = "设备目标解析失败，请通过 device_manage(action='list') 确认设备后重试。"

            if resolution_error:
                return ToolResult(success=False, error=resolution_error)
            device_id = resolved_device_id
        elif not tool.info.enabled and not credential_probe_active:
            return ToolResult(
                success=False,
                error=f"Tool is disabled: {tool_name}"
            )

        if not tool.info.enabled and not credential_probe_active:
            return ToolResult(
                success=False,
                error=f"Tool is disabled: {tool_name}"
            )

        if device_id:
            # Per-device tool enable gate: a device instance may carry a
            # disabled override independent of the shared global tool state.
            # A stored enabled=True row is legacy data and is treated the same
            # as no override; it must not bypass the global disabled state.
            try:
                from flocks.tool.device.store import get_device_tool_enabled
                per_device_enabled = await get_device_tool_enabled(device_id, tool_name)
                if per_device_enabled is False:
                    return ToolResult(
                        success=False,
                        error=(
                            f"工具 {tool_name!r} 在设备 {device_id!r} 上已禁用。"
                            "如需启用，请在设备管理页面打开对应工具开关。"
                        ),
                    )
            except Exception as _gate_err:
                log.debug("tool.device.per_device_gate_error", {
                    "tool": tool_name, "device_id": device_id, "error": str(_gate_err),
                })

        if device_id:
            from flocks.tool.credential_context import activate_device_credentials
            async with activate_device_credentials(device_id) as activated:
                if not activated:
                    return ToolResult(
                        success=False,
                        error=f"设备 {device_id!r} 未找到或已禁用，请通过 device_manage(action='list') 确认 device_id 是否正确。",
                    )
                ctx.extra["monitor_resolved_device"] = device_id
                from flocks.session.ownership import require_execution_allowed
                require_execution_allowed(ctx.session_id)
                result = await tool.execute(ctx, **kwargs)
        else:
            from flocks.session.ownership import require_execution_allowed
            require_execution_allowed(ctx.session_id)
            result = await tool.execute(ctx, **kwargs)

        if not credential_probe_active:
            if result.success:
                cls._reset_failure_state(tool_name)
            else:
                result_metadata = result.metadata or {}
                if (result_metadata.get("blocked_by_hook") or result_metadata.get("confirmation_required")
                        or result_metadata.get("validated_input_guard_blocked") or result_metadata.get("transient")):
                    # A hook verdict (policy deny / confirmation) says nothing about
                    # the tool itself, nor does a moment of being busy; counting
                    # them would switch the tool off for everyone after three.
                    disabled = False
                elif await cls._failure_auto_disable_enabled():
                    disabled = cls._record_failure(tool, kwargs, result.error)
                else:
                    cls._reset_failure_state(tool_name)
                    disabled = False
                if disabled:
                    result.metadata = {**(result.metadata or {}), "disabled": True, "disabled_reason": "repeated_error"}
                    suffix = f"tool disabled after {cls._failure_disable_threshold} identical errors"
                    if result.error:
                        result.error = f"{result.error} ({suffix})"
                    else:
                        result.error = suffix
        return result

    @classmethod
    async def _resolve_default_device_id(cls, storage_key: str) -> Optional[str]:
        """Find the unique enabled device row bound to *storage_key*.

        Returns the device_id when exactly one enabled instance exists; None
        if there is no instance, the lone instance is disabled, or several
        enabled instances exist (in which case the LLM must disambiguate via
        an explicit ``device_id`` kwarg).
        """
        try:
            from flocks.tool.device.store import list_devices
        except Exception:
            return None
        try:
            devices = await list_devices()
        except Exception:
            return None
        candidates = [
            d for d in devices
            if d.storage_key == storage_key and d.enabled
        ]
        if len(candidates) == 1:
            return candidates[0].id
        return None

    @classmethod
    async def _resolve_device_target(
        cls,
        *,
        storage_key: str,
        requested_device_id: Optional[str],
    ) -> tuple[Optional[str], Optional[str]]:
        """Resolve or validate the device target for a device-backed tool."""
        try:
            from flocks.tool.device.store import list_devices
        except Exception:
            return None, "设备模块不可用，请稍后重试。"

        try:
            devices = await list_devices()
        except Exception:
            return None, "读取设备列表失败，请稍后重试。"

        enabled_candidates = [
            device for device in devices
            if device.storage_key == storage_key and device.enabled
        ]

        if requested_device_id:
            requested = next((device for device in devices if device.id == requested_device_id), None)
            if requested is None or not requested.enabled:
                return None, (
                    f"设备 {requested_device_id!r} 未找到或已禁用，请通过 device_manage(action='list') 确认 device_id 是否正确。"
                )
            if requested.storage_key != storage_key:
                return None, (
                    f"设备 {requested_device_id!r} 不属于当前工具对应的设备类型，请通过 device_manage(action='list') 确认目标设备。"
                )
            return requested.id, None

        if len(enabled_candidates) == 1:
            resolved = enabled_candidates[0].id
            log.info("tool.device.default_resolved", {
                "provider": storage_key,
                "device_id": resolved,
            })
            return resolved, None

        if not enabled_candidates:
            return None, "当前没有可用的目标设备，请通过 device_manage(action='list') 确认设备状态。"

        return None, (
            "当前存在多台同类型设备，调用前必须显式传入 `device_id`。"
            "请先调用 device_manage(action='list') 确认目标设备。"
        )

    @classmethod
    async def execute_batch(
        cls,
        calls: List[Dict[str, Any]],
        ctx: Optional[ToolContext] = None,
        parallel: bool = True
    ) -> List[ToolResult]:
        """
        Execute multiple tools

        Args:
            calls: List of {"name": str, "params": dict}
            ctx: Tool context
            parallel: Execute in parallel if True

        Returns:
            List of results in same order
        """
        if parallel:
            tasks = [
                cls.execute(tool_name=call["name"], ctx=ctx, **call.get("params", {}))
                for call in calls
            ]
            return await asyncio.gather(*tasks)
        else:
            results = []
            for call in calls:
                result = await cls.execute(tool_name=call["name"], ctx=ctx, **call.get("params", {}))
                results.append(result)
            return results

    @classmethod
    def all_tool_ids(cls) -> List[str]:
        """Get all registered tool IDs"""
        cls._ensure_initialized()
        with cls._refresh_lock:
            return list(cls._tools.keys())

    @classmethod
    def snapshot_identity(cls) -> tuple[int, tuple[str, ...]]:
        """Return a revision/tool-id identity from one consistent registry state."""
        cls._ensure_initialized()
        cls._sync_configured_enabled_states()
        with cls._refresh_lock:
            return cls._revision, tuple(cls._tools.keys())

    @classmethod
    def get_dynamic_tools_by_module(cls) -> Dict[str, List[str]]:
        """Return a copy of the dynamic-module → tool-names mapping."""
        cls._ensure_initialized()
        with cls._refresh_lock:
            return {
                module_name: list(tool_names)
                for module_name, tool_names in cls._dynamic_tools_by_module.items()
            }

    @classmethod
    def get_api_service_ids(cls) -> set:
        """Return all known API service IDs (provider names).

        API service discovery must only come from tools loaded through the
        ``tools/api`` or ``tools/device`` paths, i.e. tools whose ``ToolInfo``
        is explicitly marked with ``source='api'`` or ``source='device'`` and
        has a provider name.

        This intentionally ignores dynamic module names and other registration
        side effects so non-API helper/security modules cannot appear in the
        API Services UI by mistake.
        """
        from flocks.tool.tool_loader import API_LIKE_SOURCES
        ids: set = set()
        for tool_info in cls.list_tools():
            if tool_info.source in API_LIKE_SOURCES and tool_info.provider:
                ids.add(tool_info.provider)
        return ids

    @classmethod
    def init(cls) -> None:
        """Initialize registry with built-in tools"""
        if cls._initialized:
            return

        with cls._init_lock:
            if cls._initialized:
                return

            cls._initializing_thread_id = threading.get_ident()
            try:
                # Import and register built-in tools
                cls._register_builtin_tools()
                cls._register_dynamic_tools()
                cls._register_plugin_extension_point()
                cls._plugin_load_errors = cls._load_plugin_tools()
                cls._initialized = True
                log.debug("tool_registry.initialized", {"count": len(cls._tools)})
            finally:
                cls._initializing_thread_id = None

    @classmethod
    async def init_async(cls) -> None:
        """Initialize the registry without blocking the event loop."""
        await asyncio.to_thread(cls.init)

    @classmethod
    def _load_plugin_tools(cls, errors: Optional[List[str]] = None) -> List[str]:
        """Load plugin tools from both user-level and project-level plugin dirs on init.

        Without this, YAML/Python plugin tools only appear after an explicit
        ``POST /api/tools/refresh`` or a tool registry initialization pass.

        Scans both:
        - ``~/.flocks/plugins/tools/`` (user-level)
        - ``<cwd>/.flocks/plugins/tools/`` (project-level)

        Tracks which tool names were added so that
        ``refresh_plugin_tools`` can accurately unregister stale entries
        (regardless of the ``ToolInfo.source`` value).

        Returns every source-level load error for diagnostics and scoped Hub
        refresh decisions.
        """
        before = set(cls._tools.keys())
        load_errors: List[str] = []
        try:
            from flocks.plugin import PluginLoader

            reported_errors = PluginLoader.load_extension("TOOLS", load_entry_points=True)
            if reported_errors:
                load_errors.extend(reported_errors)
        except Exception as e:
            log.warn("tool_registry.plugin_load_failed", {"error": str(e)})
            load_errors.append(f"plugin loader: {e}")
        if errors is not None:
            errors.extend(load_errors)
        after = set(cls._tools.keys())
        new_plugin_tools = sorted(after - before)
        python_tool_sources: Dict[str, Path] = {}
        try:
            from flocks.tool.tool_loader import discover_python_tool_sources

            python_tool_sources = discover_python_tool_sources()
        except Exception as e:
            log.debug("tool_registry.python_source_discovery_failed", {"error": str(e)})

        from flocks.config.config import get_user_plugins_root

        user_plugin_root = get_user_plugins_root().resolve()
        python_plugin_names: set[str] = set()
        for name in new_plugin_tools:
            tool = cls._tools.get(name)
            if tool is None:
                continue
            # Python plugin files that register via @ToolRegistry.register_function
            # are imported for side effects and therefore bypass the extension-point
            # consumer that would normally stamp source="plugin_py".
            if tool.info.source is None:
                tool.info.source = "plugin_py"
        # Some python plugin tools may be registered as a side effect before
        # this method captures ``before`` (for example during import chains
        # kicked off by built-in tool initialization). Do not rely solely on
        # the ``after - before`` delta; reconcile against the actual plugin
        # files on disk so refresh/restart keeps their source metadata stable.
        for name, origin in python_tool_sources.items():
            tool = cls._tools.get(name)
            if tool is None:
                continue
            existing_source = tool.info.source
            if existing_source not in (None, "plugin_py"):
                continue
            tool.info.source = "plugin_py"
            python_plugin_names.add(name)
            origin_path = origin.resolve()
            try:
                origin_path.relative_to(user_plugin_root)
                tool.info.native = False
            except ValueError:
                tool.info.native = True
        cls._plugin_tool_names = sorted(set(new_plugin_tools) | python_plugin_names)
        if errors is not None and load_errors:
            return load_errors
        cls._finalize_plugin_tools_load()
        return load_errors

    @classmethod
    def _finalize_plugin_tools_load(cls) -> None:
        """Apply configuration overlays after an accepted plugin load."""
        cls._bootstrap_user_api_services()
        # Defence-in-depth: ``register()`` is the canonical writer for
        # ``_enabled_defaults`` but this catches any tool that landed in
        # ``_tools`` via an unorthodox path.  Must run BEFORE
        # ``_sync_api_service_states`` / ``_apply_tool_settings`` so the
        # snapshot still reflects factory values, not overlay results.
        cls._snapshot_enabled_defaults()
        cls._sync_api_service_states()
        cls._apply_tool_settings()

    @classmethod
    def _bootstrap_user_api_services(cls) -> None:
        """Auto-enable newly loaded user-level API tools in flocks.json.

        For each tool that satisfies ALL of:
          - source in API_LIKE_SOURCES (i.e. "api" or "device")
          - provider is set
          - native is False (user-level plugin)
          - enabled is True (tool-level default)

        Ensures the corresponding api_services entry in flocks.json has
        ``enabled: true`` so that ``_sync_api_service_states()`` won't
        immediately disable it.  Existing explicit user choices
        (``enabled: false``) are never overwritten.
        """
        from flocks.config.runtime import runtime_config
        if runtime_config.get() is not None:
            # Headless overrides must never bootstrap persistent user settings.
            return
        try:
            from flocks.config.config_writer import ConfigWriter
            from flocks.tool.tool_loader import API_LIKE_SOURCES
        except Exception:
            return

        seen_providers: set = set()
        for tool in cls._tools.values():
            info = tool.info
            if (
                info.source not in API_LIKE_SOURCES
                or not info.provider
                or info.native
                or not info.enabled
            ):
                continue
            provider = _api_service_storage_key(info.provider)
            if provider in seen_providers:
                continue
            seen_providers.add(provider)

            existing = ConfigWriter.get_api_service_raw(provider)
            if existing is None:
                ConfigWriter.set_api_service(provider, {"enabled": True})
                log.info("tool_registry.bootstrap_api_service", {
                    "provider": provider, "action": "created_enabled",
                })
            elif "enabled" not in existing:
                existing["enabled"] = True
                ConfigWriter.set_api_service(provider, existing)
                log.info("tool_registry.bootstrap_api_service", {
                    "provider": provider, "action": "added_enabled",
                })

    @classmethod
    def _sync_api_service_states(cls) -> None:
        """Bi-directionally sync tool enabled state with their API service.

        - Service disabled  → force tool off.
        - Service enabled   → restore the tool to its factory/YAML default so
          that re-enabling a service (e.g. after adding a device) brings its
          tools back automatically.

        Calling contract — IMPORTANT:
            This method overwrites ``tool.info.enabled`` with the factory
            default whenever a service becomes enabled.  That would silently
            re-open any tool the user had explicitly disabled via the
            ``tool_settings`` overlay.  **Every call site that may flip a
            service's enabled flag MUST pair the call with
            :meth:`_apply_tool_settings` afterwards**, so the user overlay
            wins the final write::

                ToolRegistry._sync_api_service_states()
                ToolRegistry._apply_tool_settings()

            The bootstrap path (:meth:`_load_plugin_tools`) and the device
            sync helper (:func:`flocks.tool.device.sync.sync_service_tool_state`)
            already follow this discipline.
        """
        try:
            from flocks.config.config_writer import ConfigWriter
            api_services = ConfigWriter.list_api_services_raw()
        except Exception:
            return

        disabled_count = 0
        restored_count = 0
        for tool in cls._tools.values():
            configured_provider = tool.info.provider
            if not configured_provider:
                continue
            provider = _api_service_storage_key(configured_provider)
            svc = api_services.get(provider, {})
            svc_enabled = svc.get("enabled", False)
            if not svc_enabled:
                tool.info.enabled = False
                disabled_count += 1
            else:
                # Restore to factory default so tools re-appear when their
                # service is re-enabled (e.g. after a device is re-added).
                # _apply_tool_settings() runs after and can flip back to False
                # when the user has explicitly disabled a specific tool.
                default = cls._enabled_defaults.get(tool.info.name, True)
                if not tool.info.enabled and default:
                    tool.info.enabled = True
                    restored_count += 1

        if disabled_count or restored_count:
            disabled_providers = [
                p for p, svc in api_services.items()
                if not svc.get("enabled", False)
            ]
            log.debug("tool_registry.api_service_sync", {
                "disabled_tools": disabled_count,
                "restored_tools": restored_count,
                "disabled_providers": disabled_providers,
            })

    @classmethod
    def _snapshot_enabled_defaults(cls) -> None:
        """Idempotent safety-net for the ``_enabled_defaults`` snapshot.

        The *primary* write path is :meth:`register` (see comment on
        ``_enabled_defaults``); refresh paths keep the snapshot fresh via
        :meth:`_unregister_plugin_tools` / :meth:`_unregister_dynamic_tools`
        popping the entry and the subsequent ``register`` call overwriting
        it.  This method exists only as a defensive backstop for:

        - Tests that bypass :meth:`register` by poking at ``_tools``
          directly (``tests/tool/test_apply_tool_settings.py`` uses this
          to stage stub tools without invoking catalog-defaults logic).
        - Any future registration path that inserts into ``_tools``
          outside :meth:`register` — we'd rather have a best-effort
          factory value in the snapshot than hand out ``None`` via the
          HTTP API.

        ``setdefault`` is deliberate: this method is called at the end of
        :meth:`_load_plugin_tools`, which in turn runs on every
        :meth:`refresh_plugin_tools` cycle.  On the *second* and later
        cycles any built-in / previously-registered tool's
        ``info.enabled`` has already been mutated by the prior run's
        :meth:`_sync_api_service_states` / :meth:`_apply_tool_settings`,
        so a direct assignment here would overwrite the true factory
        default with the post-sync state.  Since :meth:`register` is the
        authoritative writer for anything that actually goes through it,
        a ``setdefault`` here only fills in genuinely missing entries and
        leaves correct snapshots untouched.
        """
        for name, t in cls._tools.items():
            cls._enabled_defaults.setdefault(name, bool(t.info.enabled))

    @classmethod
    def get_default_enabled(cls, name: str) -> Optional[bool]:
        """Return the YAML/registration default ``enabled`` for ``name``.

        Returns ``None`` if the tool was never seen during plugin loading
        (e.g. dynamic tools registered after init).  Callers should fall
        back to the live ``ToolInfo.enabled`` in that case.
        """
        with cls._refresh_lock:
            return cls._enabled_defaults.get(name)

    @classmethod
    def _apply_tool_settings(cls) -> None:
        """Apply user-level ``tool_settings`` from flocks.json on top of YAML defaults.

        The YAML file is treated as the factory default; the overlay in
        ``flocks.json`` (``tool_settings[<tool_name>]``) is the user's
        current choice and is applied last.

        Service gate: an overlay can NEVER enable a tool whose API service
        is currently ``enabled: false`` in ``api_services``.  Without this
        gate ``ToolRegistry.execute`` (which only checks
        ``tool.info.enabled``) would happily run a tool whose service has
        no credentials configured, producing repeated auth failures and
        eventually triggering the auto-disable threshold in
        :meth:`_record_failure`.

        An overlay can always *disable* a tool, regardless of service
        state.
        """
        try:
            from flocks.config.config_writer import ConfigWriter
            settings = ConfigWriter.list_tool_settings()
            api_services = ConfigWriter.list_api_services_raw()
        except Exception:
            return

        applied = 0
        unknown: List[str] = []
        blocked: List[str] = []
        for name, entry in settings.items():
            if not isinstance(entry, dict):
                continue
            tool = cls._tools.get(name)
            if tool is None:
                unknown.append(name)
                continue
            if "enabled" not in entry:
                continue

            desired = bool(entry["enabled"])
            if desired and tool.info.provider:
                svc = api_services.get(tool.info.provider, {})
                if not svc.get("enabled", False):
                    # Service disabled — refuse to "open" the tool via overlay.
                    # The overlay entry stays in flocks.json so that re-enabling
                    # the service later restores the user's intent automatically.
                    blocked.append(name)
                    continue

            tool.info.enabled = desired
            applied += 1

        if applied or unknown or blocked:
            log.info("tool_registry.tool_settings_applied", {
                "applied": applied,
                "stale": unknown,
                "blocked_by_service": blocked,
            })

    @classmethod
    def _register_plugin_extension_point(cls) -> None:
        """Register the TOOLS extension point with the unified PluginLoader.

        Plugin tool modules can either:
        - Use ``@ToolRegistry.register_function`` decorators (auto-registered on import).
        - Expose a ``TOOLS: list[dict]`` attribute with declarative tool definitions.
          Each dict must have at minimum ``name``, ``description``, and ``handler``
          (a callable or a string referencing a module-level function).
        - Use YAML config files (processed via ``yaml_to_tool`` factory).
        """
        from flocks.plugin import ExtensionPoint, PluginLoader
        from flocks.tool.tool_loader import yaml_to_tool

        # User-level plugin root: <flocks root>/plugins/
        from flocks.config.config import get_user_plugins_root

        _user_plugin_root = get_user_plugins_root()

        def _is_native_source(source: str) -> bool:
            """True if the source file is project-level (not user-global)."""
            try:
                Path(source).relative_to(_user_plugin_root)
                return False  # Under ~/.flocks/plugins/ → user-level → not native
            except ValueError:
                return True   # Under <cwd>/.flocks/plugins/ or elsewhere → project-level → native

        def _consume_tools(items: list, source: str) -> Optional[List[str]]:
            is_native = _is_native_source(source)
            errors: List[str] = []
            for spec in items:
                # YAML factory produces Tool instances directly
                if isinstance(spec, Tool):
                    existing = cls._tools.get(spec.info.name)
                    if existing is not None:
                        # ``PluginLoader.load_all()`` is invoked by multiple
                        # subsystems (ToolRegistry, Agent registry, etc.).  A
                        # re-scan that re-encounters the same plugin file is
                        # idempotent and should not produce a noisy warning;
                        # only flag genuine name collisions from a different
                        # source.
                        existing_source = getattr(existing.info, "source", None)
                        if existing_source not in (None, "plugin_yaml", "plugin_py"):
                            log.warn("plugin.tool.duplicate", {
                                "source": source,
                                "name": spec.info.name,
                                "existing_source": existing_source,
                            })
                        continue
                    if spec.info.source is None:
                        spec.info.source = "plugin_yaml"
                    spec.info.native = is_native
                    cls.register(spec)
                    continue

                if not isinstance(spec, dict):
                    log.warn("plugin.tool.invalid_spec", {"source": source})
                    errors.append("tool definition must be a Tool or mapping")
                    continue
                name = spec.get("name")
                handler = spec.get("handler")
                if not name or not handler:
                    log.warn("plugin.tool.missing_fields", {
                        "source": source,
                        "spec_keys": list(spec.keys()),
                    })
                    errors.append("tool definition requires name and handler")
                    continue
                existing = cls._tools.get(name)
                if existing is not None:
                    # Idempotent re-scan: same plugin source discovered again
                    # via another ``PluginLoader.load_all()`` pass.  Only warn
                    # on genuine cross-source collisions.
                    existing_source = getattr(existing.info, "source", None)
                    if existing_source not in (None, "plugin_yaml", "plugin_py"):
                        log.warn("plugin.tool.duplicate", {
                            "source": source,
                            "name": name,
                            "existing_source": existing_source,
                        })
                    continue

                if isinstance(handler, str):
                    import importlib as _imp
                    mod = _imp.import_module(source) if "." in source else None
                    handler = getattr(mod, handler, None) if mod else None
                    if handler is None:
                        log.warn("plugin.tool.handler_not_found", {
                            "source": source, "handler": spec.get("handler"),
                        })
                        errors.append(
                            f"tool {name}: handler {spec.get('handler')!r} not found"
                        )
                        continue

                if not callable(handler):
                    log.warn("plugin.tool.handler_not_callable", {
                        "source": source,
                        "name": name,
                    })
                    errors.append(f"tool {name}: handler must be callable")
                    continue

                params = [
                    ToolParameter(**p) if isinstance(p, dict) else p
                    for p in spec.get("parameters", [])
                ]
                cat_str = spec.get("category", "custom")
                category = ToolCategory(cat_str) if cat_str in ToolCategory.__members__.values() else ToolCategory.CUSTOM

                info = ToolInfo(
                    name=name,
                    description=spec.get("description", ""),
                    group=spec.get("group"),
                    category=category,
                    parameters=params,
                    source="plugin_py",
                    native=is_native,
                )
                tool = Tool(info=info, handler=handler)
                if Path(source).is_file():
                    tool._definition_path = Path(source)
                cls.register(tool)
            return errors

        def _dedup_key(item: Any) -> str:
            if isinstance(item, Tool):
                return item.info.name
            if isinstance(item, dict):
                return item.get("name", "")
            return ""

        PluginLoader.register_extension_point(ExtensionPoint(
            attr_name="TOOLS",
            subdir="tools",
            consumer=_consume_tools,
            item_type=None,
            dedup_key=_dedup_key,
            yaml_item_factory=yaml_to_tool,
            recursive=True,
            max_depth=2,
            exclude_subdirs=frozenset({"mcp", "generated"}),
        ))

    @classmethod
    def _register_builtin_tools(cls) -> None:
        """Register built-in tools by importing tool modules.

        Reconcile actual core handlers, including previously imported modules.
        Implicit native flags default to True; explicit False remains meaningful
        for discovery/search. Group ownership is independent of that flag, and
        imported user plugins never inherit core status from the import delta.
        """
        for package, modules in cls._builtin_module_groups:
            for mod_name in modules:
                try:
                    importlib.import_module(f"{package}.{mod_name}")
                except ImportError as e:
                    log.warn("builtin_tools.import_failed", {"module": f"{package}.{mod_name}", "error": str(e)})

        # Mark built-in tools native=True only when the decorator did not
        # explicitly declare native. This keeps the default convenient for
        # built-ins while preserving native=False for management tools that
        # should be discovered through tool_search.
        for tool in cls._tools.values():
            if getattr(tool, "_yaml_path", None) or getattr(tool, "_definition_path", None):
                continue
            if not cls._is_core_handler(tool.handler):
                continue
            tool.info.group_readonly = True
            fields_set = getattr(tool.info, "model_fields_set", None)
            if fields_set is None:
                fields_set = getattr(tool.info, "__fields_set__", set())
            if "native" in fields_set:
                continue
            tool.info.native = True

        # Sample tools for testing (only register if not already registered)
        if "get_time" not in cls._tools:
            @cls.register_function(
                name="get_time",
                group="系统管理",
                description="Get current date and time in ISO 8601 or Unix timestamp format",
                category=ToolCategory.SYSTEM,
                native=True,
                parameters=[
                    ToolParameter(
                        name="format",
                        type=ParameterType.STRING,
                        description=(
                            "Output format: 'iso' for ISO 8601, 'unix' for Unix seconds, "
                            "or 'unix_ms' for Unix milliseconds. Defaults to 'iso'."
                        ),
                        required=False,
                        default="iso",
                        enum=["iso", "unix", "unix_ms"],
                    )
                ]
            )
            async def get_time(ctx: ToolContext, format: str = "iso") -> ToolResult:
                from datetime import datetime

                if format not in {"iso", "unix", "unix_ms"}:
                    return ToolResult(
                        success=False,
                        error="format must be one of: iso, unix, unix_ms",
                    )

                now = datetime.now()
                if format == "unix":
                    output = str(int(now.timestamp()))
                elif format == "unix_ms":
                    output = str(int(now.timestamp() * 1000))
                else:
                    output = now.isoformat()

                return ToolResult(
                    success=True,
                    output=output,
                )

    @classmethod
    def _unregister_plugin_tools(cls) -> List[str]:
        """Remove all previously tracked plugin tools from the registry.

        Uses ``_plugin_tool_names`` (populated by ``_load_plugin_tools``)
        so that tools registered via any mechanism (YAML, ``TOOLS``
        attribute, or ``@register_function`` decorator) are correctly
        cleaned up.

        Also drops the matching entries from ``_enabled_defaults`` so a
        subsequent ``_load_plugin_tools`` call picks up the current YAML
        factory default rather than the one observed on a previous
        cycle.  Without this, editing a YAML file to flip ``enabled:``
        and hitting ``refresh_plugin_tools`` would leave the snapshot —
        and therefore ``reset_tool_setting`` — stuck on the old value.
        """
        removed: List[str] = []
        for name in cls._plugin_tool_names:
            if cls._tools.pop(name, None) is not None:
                removed.append(name)
            cls._enabled_defaults.pop(name, None)
        if removed:
            log.info("tool.plugin.unregistered", {"tools": removed})
        cls._plugin_tool_names = []
        return removed

    # ── File watcher ────────────────────────────────────────────────────────

    _watcher: Optional["ToolFileWatcher"] = None

    @classmethod
    def start_watcher(cls) -> None:
        """Start the file watcher that auto-reloads plugin tools on file changes."""
        if cls._watcher is None:
            cls._watcher = ToolFileWatcher()
        cls._watcher.start()

    @classmethod
    def refresh_plugin_tools(cls, changed_path: Optional[Path] = None) -> List[str]:
        """Reload plugin tools (YAML + Python) from disk.

        Unregisters stale plugin tools first so that deleted files are
        correctly removed from the registry. When a Hub operation supplies
        ``changed_path``, source failures outside that path are isolated and
        do not block the operation; failures inside it still roll back.
        """
        cls._ensure_initialized()
        with cls._refresh_lock:
            tools_before = cls._tools.copy()
            defaults_before = cls._enabled_defaults.copy()
            plugin_names_before = list(cls._plugin_tool_names)
            plugin_errors_before = list(cls._plugin_load_errors)
            enabled_before = {
                name: tool.info.enabled
                for name, tool in tools_before.items()
            }
            revision_before = cls._revision
            load_errors: List[str] = []

            def _restore_snapshot() -> None:
                for name, enabled in enabled_before.items():
                    tool = tools_before.get(name)
                    if tool is not None:
                        tool.info.enabled = enabled
                cls._tools.clear()
                cls._tools.update(tools_before)
                cls._enabled_defaults.clear()
                cls._enabled_defaults.update(defaults_before)
                cls._plugin_tool_names = plugin_names_before
                cls._plugin_load_errors = plugin_errors_before
                cls._revision = revision_before

            try:
                cls._unregister_plugin_tools()
                cls._load_plugin_tools(load_errors)
                changed_root = changed_path.resolve() if changed_path is not None else None
                fatal_errors: List[str] = []
                for error in load_errors:
                    if changed_root is None or error.startswith(
                        (
                            "plugin loader:",
                            "extension point not found:",
                            "entry point scan:",
                        )
                    ):
                        fatal_errors.append(error)
                        continue
                    if error.startswith("entry point "):
                        continue
                    source_text, separator, _detail = error.partition(": ")
                    if not separator:
                        fatal_errors.append(error)
                        continue
                    source_path = Path(source_text)
                    if not source_path.is_absolute():
                        fatal_errors.append(error)
                        continue
                    source_path = source_path.resolve()
                    if source_path == changed_root or changed_root in source_path.parents:
                        fatal_errors.append(error)
                if fatal_errors:
                    raise ToolRefreshError("plugin", fatal_errors)

                if load_errors:
                    cls._finalize_plugin_tools_load()

                cls._plugin_load_errors = load_errors
                cls._bump_revision("plugin_refresh")
                return cls.all_tool_ids()
            except Exception:
                _restore_snapshot()
                raise

    @classmethod
    def refresh_dynamic_tools(cls) -> List[str]:
        """Reload dynamically generated tools and return tool ids."""
        cls._ensure_initialized()
        with cls._refresh_lock:
            tools_before = cls._tools.copy()
            defaults_before = cls._enabled_defaults.copy()
            dynamic_modules_before = cls._dynamic_modules.copy()
            dynamic_tools_before = {
                name: list(tool_names)
                for name, tool_names in cls._dynamic_tools_by_module.items()
            }
            load_errors: List[str] = []

            try:
                cls._register_dynamic_tools(load_errors)
            except Exception:
                cls._tools.clear()
                cls._tools.update(tools_before)
                cls._enabled_defaults.clear()
                cls._enabled_defaults.update(defaults_before)
                cls._dynamic_modules = dynamic_modules_before
                cls._dynamic_tools_by_module = dynamic_tools_before
                raise
            if load_errors:
                cls._tools.clear()
                cls._tools.update(tools_before)
                cls._enabled_defaults.clear()
                cls._enabled_defaults.update(defaults_before)
                cls._dynamic_modules = dynamic_modules_before
                cls._dynamic_tools_by_module = dynamic_tools_before
                raise ToolRefreshError("dynamic", load_errors)

            cls._bump_revision("dynamic_refresh")
            return cls.all_tool_ids()

    @classmethod
    def _reset_failure_state(cls, tool_name: str) -> None:
        """Reset failure tracking for a tool after success."""
        with cls._refresh_lock:
            cls._failure_state.pop(tool_name, None)

    @classmethod
    async def _failure_auto_disable_enabled(cls) -> bool:
        """Return the configured repeated-failure behavior, defaulting on."""
        try:
            from flocks.config.config import Config

            config = await Config.get()
            if config.tool_failure is not None:
                return config.tool_failure.disable_on_repeated_failure
        except Exception:
            pass
        return True

    @classmethod
    def _should_track_failure(cls, tool: Tool) -> bool:
        """Track failures only for standalone custom tools that allow auto-disable.

        Device-backed tools have per-device switches; repeated upstream/API
        failures should not mutate the shared in-memory switch for every
        device instance.
        """
        return (
            tool.info.category == ToolCategory.CUSTOM
            and tool.info.name != "invalid"
            and tool.info.source != "device"
            and tool.info.disable_on_repeated_failure
        )

    @classmethod
    def _is_countable_error(cls, error: Optional[str]) -> bool:
        """Skip non-actionable or validation errors."""
        if not error or not isinstance(error, str):
            return False
        error_lower = error.lower()
        skip_phrases = [
            "missing required parameter",
            "invalid arguments",
            "tool not found",
            "tool is disabled",
        ]
        return not any(phrase in error_lower for phrase in skip_phrases)

    @classmethod
    def _failure_key(cls, tool_name: str, params: Dict[str, Any], error: Optional[str]) -> str:
        """Build a stable signature for repeated failure detection."""
        try:
            params_json = json.dumps(params, sort_keys=True, default=str)
        except (TypeError, ValueError):
            params_json = repr(params)
        return f"{tool_name}|{params_json}|{error or ''}"

    @classmethod
    def _record_failure(cls, tool: Tool, params: Dict[str, Any], error: Optional[str]) -> bool:
        """
        Track repeated identical errors and disable tool if threshold reached.

        Returns True if the tool was disabled.
        """
        if not cls._should_track_failure(tool) or not cls._is_countable_error(error):
            return False

        tool_name = tool.info.name
        key = cls._failure_key(tool_name, params, error)
        with cls._refresh_lock:
            state = cls._failure_state.get(tool_name, {"key": None, "count": 0})

            if state.get("key") == key:
                state["count"] = state.get("count", 0) + 1
            else:
                state = {"key": key, "count": 1}

            cls._failure_state[tool_name] = state

            if state["count"] >= cls._failure_disable_threshold and tool.info.enabled:
                tool.info.enabled = False
                try:
                    from flocks.config.config_writer import ConfigWriter

                    ConfigWriter.set_tool_setting(tool_name, {"enabled": False})
                except Exception as exc:
                    log.warn("tool.disabled.repeated_error.persist_failed", {
                        "tool": tool_name,
                        "error": str(exc),
                    })
                cls._bump_revision("failure_auto_disable")
                log.warn("tool.disabled.repeated_error", {
                    "tool": tool_name,
                    "count": state["count"],
                    "error": error,
                })
                return True

        return False

    @classmethod
    def _generated_tools_dirs(cls) -> List[Path]:
        """Return directories containing dynamically generated tools.

        Checks (in order):
        1. ``~/.flocks/plugins/tools/generated/``  (external plugin path)
        2. ``flocks/tool/security/``  (built-in threat intelligence tools)
        """
        from flocks.plugin.loader import DEFAULT_PLUGIN_ROOT

        dirs: List[Path] = []
        plugins_dir = DEFAULT_PLUGIN_ROOT / "tools" / "generated"
        if plugins_dir.is_dir():
            dirs.append(plugins_dir)
        security_dir = Path(__file__).resolve().parent / "security"
        if security_dir.is_dir():
            dirs.append(security_dir)
        return dirs

    @classmethod
    def _discover_dynamic_modules(cls) -> Dict[str, Path]:
        modules: Dict[str, Path] = {}
        seen_stems: set = set()
        for gen_dir in cls._generated_tools_dirs():
            for path in gen_dir.glob("*.py"):
                if path.name == "__init__.py" or path.name.startswith("_"):
                    continue
                if path.stem in seen_stems:
                    continue
                seen_stems.add(path.stem)
                module_name = f"_flocks_gen_{gen_dir.parent.name}_{path.stem}"
                if "security" in str(gen_dir) and "plugins" not in str(gen_dir):
                    module_name = f"flocks.tool.security.{path.stem}"
                modules[module_name] = path
        return modules

    @classmethod
    def _unregister_dynamic_tools(cls, module_name: str) -> None:
        old_tools = cls._dynamic_tools_by_module.get(module_name, [])
        if not old_tools:
            return
        for tool_name in old_tools:
            cls._tools.pop(tool_name, None)
            # Mirror ``_unregister_plugin_tools``: the factory-default
            # snapshot lives in lock-step with ``_tools``.  Reload of the
            # same module re-registers via ``register()`` which overwrites
            # the entry, but when a dynamic module is deleted entirely
            # (the ``module_name not in modules`` branch of
            # ``_register_dynamic_tools``) nothing re-adds it, so without
            # this pop a stale factory default would linger forever.
            cls._enabled_defaults.pop(tool_name, None)
        log.info("tool.dynamic.unregistered", {
            "module": module_name,
            "tools": old_tools,
        })

    @classmethod
    def _register_dynamic_tools(cls, errors: Optional[List[str]] = None) -> None:
        """Register dynamically generated tools by importing modules."""
        modules = cls._discover_dynamic_modules()

        # Remove tools for modules that no longer exist
        for module_name in list(cls._dynamic_tools_by_module.keys()):
            if module_name not in modules:
                cls._unregister_dynamic_tools(module_name)
                cls._dynamic_tools_by_module.pop(module_name, None)
                cls._dynamic_modules.pop(module_name, None)

        for module_name, path in modules.items():
            cls._unregister_dynamic_tools(module_name)
            before = set(cls._tools.keys())
            try:
                if module_name in sys.modules:
                    importlib.reload(sys.modules[module_name])
                    action = "reloaded"
                else:
                    importlib.import_module(module_name)
                    action = "imported"
            except Exception as e:
                log.warn("tool.dynamic.import_failed", {
                    "module": module_name,
                    "error": str(e),
                })
                if errors is not None:
                    errors.append(f"{path}: {e}")
                continue

            after = set(cls._tools.keys())
            new_tools = sorted(after - before)
            cls._dynamic_modules[module_name] = str(path)
            cls._dynamic_tools_by_module[module_name] = new_tools
            log.debug("tool.dynamic.registered", {
                "module": module_name,
                "tools": new_tools,
                "action": action,
            })


# ---------------------------------------------------------------------------
# Tool File Watcher
# ---------------------------------------------------------------------------


_TOOL_WATCH_SUBDIRS = ("api", "device", "python")


def _tool_event_paths(event: object) -> List[str]:
    candidate_paths: List[str] = []
    src = getattr(event, "src_path", "") or ""
    if src:
        candidate_paths.append(src)
    dest = getattr(event, "dest_path", "") or ""
    if dest:
        candidate_paths.append(dest)
    return candidate_paths


def _tool_path_matches_watch_scope(path: str, subdir: str | None = None) -> bool:
    """Return whether ``path`` is under ``plugins/tools/<type>/``."""
    parts = Path(path).parts
    allowed = {subdir} if subdir else set(_TOOL_WATCH_SUBDIRS)
    for idx, part in enumerate(parts):
        if part != "tools":
            continue
        if idx + 1 < len(parts) and parts[idx + 1] in allowed:
            return True
    return False


def _tool_event_should_reload(event: object) -> bool:
    """Return True if a watchdog filesystem event should trigger a plugin reload.

    Atomic-save editors (vim, VS Code "useAtomicSave", many GUI tools, …)
    persist edits by writing a sibling temp file then ``rename`` ing it onto
    the real target.  watchdog surfaces this as a ``moved`` event whose
    ``src_path`` is the throwaway temp filename and whose ``dest_path`` is the
    real ``tool.yaml`` / ``*.py``.  Filtering only by ``src_path`` (the
    pre-fix behaviour) misses the real edit entirely, so we have to inspect
    both endpoints.

    Exposed at module scope so it can be unit-tested without spinning up
    ``watchdog.observers.Observer`` against a temp directory.
    """
    candidate_paths = _tool_event_paths(event)
    if not candidate_paths:
        return False

    for path in candidate_paths:
        if not _tool_path_matches_watch_scope(path):
            continue
        if not (path.endswith(".yaml") or path.endswith(".py")):
            continue
        fname = os.path.basename(path)
        # Ignore Python bytecode / temp / hidden files that get touched
        # during normal imports but never carry plugin definitions.
        if fname.startswith(".") or fname.startswith("_") or "/__pycache__/" in path:
            continue
        return True
    return False


def _tool_event_touches_device_plugin(event: object) -> bool:
    """Return True when a reload event targets ``tools/device``."""
    return any(_tool_path_matches_watch_scope(path, "device") for path in _tool_event_paths(event))


class ToolFileWatcher:
    """Watch plugin tool directories and auto-reload plugin tools on change.

    Monitors the ``api/``, ``device/``, and ``python/`` subdirectories under:
    - ``~/.flocks/plugins/tools/``       (user-level)
    - ``<cwd>/.flocks/plugins/tools/``   (project-level)

    Triggers on ``*.yaml`` or ``*.py`` file changes with a 1.0 s debounce.
    Does **not** watch ``generated/`` or ``mcp/`` — those subdirectories have
    their own dedicated reload mechanisms.
    """

    _DEBOUNCE_SECONDS = 1.0
    _WATCH_SUBDIRS = _TOOL_WATCH_SUBDIRS

    def __init__(self) -> None:
        self._observer: Optional[object] = None
        self._debounce_timer: Optional[threading.Timer] = None
        self._lock = threading.Lock()
        self._loop: Optional[asyncio.AbstractEventLoop] = None

    # ---- public ----

    def start(self) -> None:
        if self._observer is not None:
            return

        try:
            from watchdog.events import FileSystemEvent, FileSystemEventHandler
            from watchdog.observers import Observer
        except ImportError:
            log.warn(
                "tool.watcher.watchdog_missing",
                {"msg": "watchdog not installed, tool file watcher disabled"},
            )
            return

        # Capture the running event loop so _do_refresh can safely schedule
        # back onto it from the watchdog daemon thread.
        try:
            self._loop = asyncio.get_event_loop()
        except RuntimeError:
            self._loop = None

        watch_dirs = self._collect_watch_dirs()
        if not watch_dirs:
            log.info("tool.watcher.no_dirs", {"msg": "no tool plugin directories to watch"})
            return

        watcher = self

        # Only react to events that change file CONTENT.  watchdog also emits
        # ``opened``/``closed``/``closed_no_write`` events whenever any process
        # (including this one) reads a YAML/Python file, and ``refresh_plugin_tools``
        # itself opens every plugin tool file on every reload.  Listening to those
        # access events creates an infinite reload feedback loop where the watcher
        # endlessly re-triggers itself every ~debounce-window seconds.
        _RELOAD_EVENT_TYPES = frozenset({"modified", "created", "deleted", "moved"})

        class _Handler(FileSystemEventHandler):
            def on_any_event(self, event: FileSystemEvent) -> None:
                if event.is_directory:
                    return
                if getattr(event, "event_type", "") not in _RELOAD_EVENT_TYPES:
                    return
                if not _tool_event_should_reload(event):
                    return
                watcher._schedule_refresh(device_changed=_tool_event_touches_device_plugin(event))

        handler = _Handler()
        observer = Observer()
        for d in watch_dirs:
            try:
                observer.schedule(handler, d, recursive=True)
                log.debug("tool.watcher.watching", {"directory": d})
            except Exception as e:
                log.warn("tool.watcher.schedule_error", {"directory": d, "error": str(e)})

        observer.daemon = True
        observer.start()
        self._observer = observer
        log.info("tool.watcher.started", {"directories": sorted(watch_dirs)})

    def stop(self) -> None:
        with self._lock:
            if self._debounce_timer is not None:
                self._debounce_timer.cancel()
                self._debounce_timer = None
        if self._observer is not None:
            try:
                self._observer.stop()  # type: ignore[union-attr]
                self._observer.join(timeout=2)  # type: ignore[union-attr]
            except Exception:
                pass
            self._observer = None
            log.info("tool.watcher.stopped")

    # ---- internal ----

    def _schedule_refresh(self, *, device_changed: bool = False) -> None:
        """Debounced plugin tool reload."""
        with self._lock:
            if self._debounce_timer is not None:
                self._debounce_timer.cancel()
            self._device_changed = getattr(self, "_device_changed", False) or device_changed
            self._debounce_timer = threading.Timer(
                self._DEBOUNCE_SECONDS, self._do_refresh
            )
            self._debounce_timer.daemon = True
            self._debounce_timer.start()

    def _do_refresh(self) -> None:
        # Schedule onto the asyncio event loop thread to avoid concurrent
        # modification of _tools while request handlers may be reading it.
        if self._loop is not None and self._loop.is_running():
            self._loop.call_soon_threadsafe(self._run_refresh)
        else:
            self._run_refresh()

    def _run_refresh(self) -> None:
        try:
            if getattr(self, "_device_changed", False):
                try:
                    from flocks.config.api_versioning import discover_api_service_descriptors
                    from flocks.tool.device.plugin_index import clear_device_template_cache

                    clear_device_template_cache()
                    discover_api_service_descriptors(refresh=True)
                except Exception as exc:
                    log.debug("tool.watcher.device_cache_clear_failed", {"error": str(exc)})
                finally:
                    self._device_changed = False
            ToolRegistry.refresh_plugin_tools()
            log.debug("tool.watcher.reloaded", {"reason": "plugin tool file changed on disk"})
        except Exception as e:
            log.warn("tool.watcher.reload_failed", {"error": str(e)})

    def _collect_watch_dirs(self) -> Set[str]:
        """Return plugin roots that exist and should be watched."""
        dirs: Set[str] = set()
        try:
            from flocks.plugin.loader import DEFAULT_PLUGIN_ROOT
            user_plugin_root = DEFAULT_PLUGIN_ROOT
        except Exception:
            from flocks.config.config import get_user_plugins_root

            user_plugin_root = get_user_plugins_root()

        if os.path.isdir(user_plugin_root):
            dirs.add(str(user_plugin_root))

        try:
            project_plugin_root = Path.cwd() / ".flocks" / "plugins"
            if os.path.isdir(project_plugin_root):
                dirs.add(str(project_plugin_root))
        except Exception:
            pass

        return dirs
