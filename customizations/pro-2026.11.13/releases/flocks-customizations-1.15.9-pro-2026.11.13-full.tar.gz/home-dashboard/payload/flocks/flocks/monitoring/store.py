"""Monitoring facts in tasks.db. Short, dedicated transactions avoid shared-connection races."""
from contextlib import asynccontextmanager, contextmanager
from contextvars import ContextVar
import asyncio
from weakref import WeakKeyDictionary
import json
import aiosqlite
from flocks.task.store import TaskStore

_diagnostic_reads = ContextVar('monitor_diagnostic_reads', default=False)


@contextmanager
def read_only_diagnostics():
    """Download-only scope; normal monitoring reads retain their behavior."""
    token = _diagnostic_reads.set(True)
    try:
        yield
    finally:
        _diagnostic_reads.reset(token)

DDL = '''
CREATE TABLE IF NOT EXISTS monitor_installations (
 owner TEXT NOT NULL, scope TEXT NOT NULL, project TEXT NOT NULL, policy TEXT NOT NULL,
 installed INTEGER NOT NULL DEFAULT 1, ready INTEGER NOT NULL DEFAULT 0,
 reason TEXT, scheduler_id TEXT, activation_pending INTEGER NOT NULL DEFAULT 0, PRIMARY KEY(owner, scope));
CREATE TABLE IF NOT EXISTS monitor_daily_sessions (
 owner TEXT NOT NULL, project TEXT NOT NULL, scope TEXT NOT NULL, business_date TEXT NOT NULL,
 session_id TEXT NOT NULL UNIQUE, timezone TEXT NOT NULL, state TEXT NOT NULL DEFAULT 'creating',
 PRIMARY KEY(owner, project, scope, business_date));
CREATE TABLE IF NOT EXISTS monitor_slots (
 scheduler_id TEXT NOT NULL, scheduled_for TEXT NOT NULL, execution_id TEXT UNIQUE,
 status TEXT NOT NULL, PRIMARY KEY(scheduler_id, scheduled_for));
CREATE TABLE IF NOT EXISTS monitor_attempts (
 sequence INTEGER PRIMARY KEY AUTOINCREMENT, id TEXT NOT NULL UNIQUE, execution_id TEXT NOT NULL,
 owner TEXT NOT NULL, project TEXT NOT NULL, scope TEXT NOT NULL, business_date TEXT NOT NULL,
 session_id TEXT NOT NULL, message_id TEXT NOT NULL, scheduled_for TEXT, started_at TEXT NOT NULL,
 finished_at TEXT, status TEXT NOT NULL, error TEXT, result TEXT NOT NULL DEFAULT '{}',
 navigation_confirmed INTEGER NOT NULL DEFAULT 0);
CREATE INDEX IF NOT EXISTS monitor_attempts_day ON monitor_attempts(owner, scope, business_date);
CREATE INDEX IF NOT EXISTS monitor_attempts_project_day ON monitor_attempts(owner, scope, project, business_date, sequence);
CREATE TABLE IF NOT EXISTS monitor_steps (
 id TEXT PRIMARY KEY, attempt_id TEXT NOT NULL, message_id TEXT NOT NULL, part_id TEXT NOT NULL,
 tool TEXT NOT NULL, input TEXT NOT NULL, status TEXT NOT NULL, started_at TEXT NOT NULL,
 finished_at TEXT, output TEXT, error TEXT);
CREATE TABLE IF NOT EXISTS monitor_observations (
 attempt_id TEXT NOT NULL, event_key TEXT NOT NULL, data TEXT NOT NULL,
 PRIMARY KEY(attempt_id, event_key));
CREATE INDEX IF NOT EXISTS monitor_observations_event ON monitor_observations(event_key, attempt_id);
CREATE TABLE IF NOT EXISTS monitor_cursors (
 owner TEXT NOT NULL, scope TEXT NOT NULL, device TEXT NOT NULL, through_time INTEGER NOT NULL,
 PRIMARY KEY(owner, scope, device));
CREATE TABLE IF NOT EXISTS monitor_investigations (
 owner TEXT NOT NULL, project TEXT NOT NULL, event_key TEXT NOT NULL,
 event TEXT NOT NULL, evidence TEXT NOT NULL DEFAULT '[]', result TEXT NOT NULL DEFAULT '{}',
 state TEXT NOT NULL DEFAULT 'pending', attempts INTEGER NOT NULL DEFAULT 0,
 updated_at TEXT NOT NULL, PRIMARY KEY(owner,project,event_key));
CREATE TABLE IF NOT EXISTS monitor_investigation_versions (
 owner TEXT NOT NULL, project TEXT NOT NULL, event_key TEXT NOT NULL, revision INTEGER NOT NULL,
 event TEXT NOT NULL, evidence TEXT NOT NULL, result TEXT NOT NULL, state TEXT NOT NULL,
 attempts INTEGER NOT NULL, archived_at TEXT NOT NULL,
 PRIMARY KEY(owner,project,event_key,revision));
CREATE TABLE IF NOT EXISTS monitor_model_recovery (
 owner TEXT NOT NULL, project TEXT NOT NULL, device TEXT NOT NULL,
 provider TEXT NOT NULL, model TEXT NOT NULL, failures INTEGER NOT NULL DEFAULT 0,
 model_failure TEXT, next_retry_at TEXT, probe_until TEXT, updated_at TEXT NOT NULL,
 PRIMARY KEY(owner,project,device,provider,model));
CREATE TABLE IF NOT EXISTS monitor_event_followup (
 owner TEXT NOT NULL, scope TEXT NOT NULL, project TEXT NOT NULL, device TEXT NOT NULL,
 event_key TEXT NOT NULL, policy_revision TEXT NOT NULL, event_version TEXT NOT NULL,
 event TEXT NOT NULL, decision TEXT NOT NULL DEFAULT '{}', state TEXT NOT NULL DEFAULT 'watching',
 watch_count INTEGER NOT NULL DEFAULT 0, last_round TEXT, queued_round TEXT,
 target_status INTEGER, disposition_id TEXT, result TEXT NOT NULL DEFAULT '{}',
 created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
 PRIMARY KEY(owner,scope,project,device,event_key));
CREATE INDEX IF NOT EXISTS monitor_event_followup_due ON monitor_event_followup(owner,scope,project,state,queued_round);
CREATE TABLE IF NOT EXISTS monitor_dispositions (
 id TEXT NOT NULL, owner TEXT NOT NULL, scope TEXT NOT NULL, event_key TEXT NOT NULL,
 comment TEXT NOT NULL, status TEXT NOT NULL, observed_status INTEGER, error TEXT,
 session_id TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
 mode TEXT NOT NULL DEFAULT 'manual', target_status INTEGER NOT NULL DEFAULT 40,
 project TEXT, decision TEXT NOT NULL DEFAULT '{}', PRIMARY KEY(owner, scope, id));
CREATE INDEX IF NOT EXISTS monitor_dispositions_event ON monitor_dispositions(owner,scope,event_key,created_at);
CREATE TABLE IF NOT EXISTS monitor_auto_settings (
 owner TEXT NOT NULL, scope TEXT NOT NULL, project TEXT NOT NULL, enabled INTEGER NOT NULL DEFAULT 0,
 revision TEXT NOT NULL, updated_at TEXT NOT NULL, PRIMARY KEY(owner,scope));
CREATE TABLE IF NOT EXISTS monitor_auto_queue (
 owner TEXT NOT NULL, scope TEXT NOT NULL, project TEXT NOT NULL, event_key TEXT NOT NULL,
 checked_at TEXT NOT NULL DEFAULT '', reason TEXT, PRIMARY KEY(owner,scope,project,event_key));
CREATE TABLE IF NOT EXISTS monitor_mail_settings (
 owner TEXT NOT NULL, scope TEXT NOT NULL, project TEXT NOT NULL, recipient TEXT NOT NULL,
 responsible_name TEXT NOT NULL, enabled INTEGER NOT NULL DEFAULT 0, revision TEXT NOT NULL,
 mailbox TEXT NOT NULL, updated_at TEXT NOT NULL, PRIMARY KEY(owner,scope));
CREATE TABLE IF NOT EXISTS monitor_mail_notices (
 id TEXT PRIMARY KEY, owner TEXT NOT NULL, scope TEXT NOT NULL, project TEXT NOT NULL,
 event_key TEXT NOT NULL, recipient TEXT NOT NULL, revision TEXT NOT NULL, mailbox TEXT NOT NULL,
 message_id TEXT NOT NULL UNIQUE, subject TEXT NOT NULL, body TEXT NOT NULL,
 event TEXT NOT NULL, state TEXT NOT NULL, error TEXT, session_id TEXT, created_at TEXT NOT NULL,
 updated_at TEXT NOT NULL, UNIQUE(owner,scope,project,event_key));
CREATE TABLE IF NOT EXISTS monitor_device_targets (
 owner TEXT NOT NULL, scope TEXT NOT NULL, project TEXT NOT NULL, device TEXT NOT NULL,
 device_name TEXT NOT NULL, recipient TEXT NOT NULL, responsible_name TEXT NOT NULL,
 revision TEXT NOT NULL, mailbox TEXT NOT NULL, updated_at TEXT NOT NULL,
 PRIMARY KEY(owner,scope,project,device));
CREATE TABLE IF NOT EXISTS monitor_mail_replies (
 sequence INTEGER PRIMARY KEY AUTOINCREMENT, id TEXT NOT NULL UNIQUE, owner TEXT NOT NULL,
 project TEXT NOT NULL, mailbox TEXT NOT NULL, message_id TEXT NOT NULL, sender TEXT NOT NULL,
 payload TEXT NOT NULL, state TEXT NOT NULL, result TEXT, error TEXT, received_at TEXT NOT NULL,
 updated_at TEXT NOT NULL, UNIQUE(mailbox,message_id));
CREATE TABLE IF NOT EXISTS monitor_mail_items (
 id TEXT PRIMARY KEY, reply_id TEXT NOT NULL, notice_id TEXT NOT NULL, owner TEXT NOT NULL,
 project TEXT NOT NULL, target INTEGER NOT NULL, reason TEXT NOT NULL, state TEXT NOT NULL,
 error TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
 UNIQUE(reply_id,notice_id));
CREATE TABLE IF NOT EXISTS monitor_mail_manual (
 id TEXT PRIMARY KEY, notice_id TEXT NOT NULL, owner TEXT NOT NULL, project TEXT NOT NULL,
 state TEXT NOT NULL, created_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS monitor_mail_manual_notice ON monitor_mail_manual(owner,notice_id,created_at);
CREATE TABLE IF NOT EXISTS monitor_mail_retries (
 id TEXT PRIMARY KEY, notice_id TEXT NOT NULL, owner TEXT NOT NULL, project TEXT NOT NULL,
 state TEXT NOT NULL, mail_state TEXT, created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS monitor_mail_retries_notice ON monitor_mail_retries(owner,notice_id);
CREATE TABLE IF NOT EXISTS monitor_mail_cursors (
 mailbox TEXT PRIMARY KEY, validity TEXT NOT NULL, last_uid INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS monitor_mail_unparsed (
 mailbox TEXT NOT NULL, validity TEXT NOT NULL, uid INTEGER NOT NULL, recorded_at TEXT NOT NULL,
 PRIMARY KEY(mailbox,validity,uid));
CREATE TABLE IF NOT EXISTS monitor_reports (
 owner TEXT NOT NULL, scope TEXT NOT NULL, business_date TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'pending', version INTEGER NOT NULL DEFAULT 0,
 content TEXT, error TEXT, PRIMARY KEY(owner, scope, business_date));
'''


_sqlite_schemas = {}
_sqlite_schema_locks = WeakKeyDictionary()


async def _schema_version(db):
    async with db.execute('PRAGMA schema_version') as cursor:
        return (await cursor.fetchone())[0]


async def _migrate_sqlite(db):
    path = TaskStore.get_db_path()
    info = path.stat()
    key = (str(path.resolve()), info.st_dev, info.st_ino)
    version = await _schema_version(db)
    if _sqlite_schemas.get(key) == version:
        return
    loop = asyncio.get_running_loop()
    lock = _sqlite_schema_locks.setdefault(loop, asyncio.Lock())
    async with lock:
        if _sqlite_schemas.get(key) == await _schema_version(db):
            return
        db.row_factory = aiosqlite.Row
        await db.executescript(DDL)
        await db.execute('BEGIN IMMEDIATE')  # Serialize additive migrations across concurrent readers.
        # Additive migrations also support databases created by earlier builds.
        for table, column in [('monitor_installations', 'activation_pending'), ('monitor_attempts', 'navigation_confirmed')]:
            columns = await db.execute(f'PRAGMA table_info({table})')
            if column not in {row['name'] for row in await columns.fetchall()}:
                await db.execute(f'ALTER TABLE {table} ADD COLUMN {column} INTEGER NOT NULL DEFAULT 0')
        columns = await db.execute('PRAGMA table_info(monitor_dispositions)')
        existing = {row['name'] for row in await columns.fetchall()}
        for column, declaration in [('mode', "TEXT NOT NULL DEFAULT 'manual'"),
                                    ('target_status', 'INTEGER NOT NULL DEFAULT 40'),
                                    ('project', 'TEXT'), ('decision', "TEXT NOT NULL DEFAULT '{}'")]:
            if column not in existing:
                await db.execute(f'ALTER TABLE monitor_dispositions ADD COLUMN {column} {declaration}')
        for table, additions in (
            ('monitor_investigations', [('revision', 'INTEGER NOT NULL DEFAULT 1'),
                ('failure_count', 'INTEGER NOT NULL DEFAULT 0'), ('next_retry_at', 'TEXT'),
                ('error_kind', 'TEXT'), ('retry_exhausted', 'INTEGER NOT NULL DEFAULT 0'),
                ('confirmed_risk', 'TEXT')]),
            ('monitor_attempts', [('summary', 'TEXT'), ('next_step', 'TEXT'), ('end_message_id', 'TEXT'), ('end_published', 'INTEGER NOT NULL DEFAULT 0')]),
            ('monitor_mail_notices', [('sent_at', 'TEXT')]),
            ('monitor_mail_manual', [('notes', "TEXT NOT NULL DEFAULT ''")]),
            ('monitor_mail_retries', [('message_id', 'TEXT')]),
        ):
            columns = await db.execute(f'PRAGMA table_info({table})')
            existing = {row['name'] for row in await columns.fetchall()}
            for column, declaration in additions:
                if column not in existing:
                    await db.execute(f'ALTER TABLE {table} ADD COLUMN {column} {declaration}')
            if table == 'monitor_investigations' and 'error_kind' not in existing:
                # Earlier builds mixed these generated system errors with
                # business decisions requiring human review. Migrate only
                # known system messages, leaving genuine ambiguity untouched.
                for prefix, kind in (
                    ('调查模型选择了未开放的数据源', 'model_format'),
                    ('调查模型输出达到长度上限', 'model_truncated'),
                    ('调查模型决策格式无效', 'model_format'),
                    ('调查模型没有返回完整决策', 'model_format'),
                    ('未配置调查模型', 'dependency'),
                    ('调查模型不可用', 'dependency'),
                ):
                    await db.execute("UPDATE monitor_investigations SET state='system_wait',error_kind=?,"
                        "retry_exhausted=1,failure_count=3 WHERE state='needs_review' "
                        "AND CASE WHEN json_valid(result) THEN json_extract(result,'$.reason') END LIKE ?", (kind, prefix + '%'))
        columns = await db.execute('PRAGMA table_info(monitor_reports)')
        if 'summary_content' not in {r['name'] for r in await columns.fetchall()}:
            await db.execute('ALTER TABLE monitor_reports ADD COLUMN summary_content TEXT')
        await db.commit()
        _sqlite_schemas[key] = await _schema_version(db)


async def _initialize_sqlite():
    """Migrate only a new/changed schema; ordinary reads never reserve a writer."""
    from flocks.task.diagnostics import observed_connect
    await TaskStore.init()
    async with observed_connect(TaskStore.get_db_path(), timeout=30) as db:
        db.row_factory = aiosqlite.Row
        await _migrate_sqlite(db)


@asynccontextmanager
async def connection():
    from flocks.enhancements.monitor_db import active, connection as pro_connection
    if active():
        async with pro_connection() as db:
            yield db
        return
    await TaskStore.init()
    from flocks.task.diagnostics import observed_connect
    async with observed_connect(TaskStore.get_db_path(), timeout=30) as db:
        db.row_factory = aiosqlite.Row
        await _migrate_sqlite(db)
        try:
            yield db
            await db.commit()
        except BaseException:
            await db.rollback()
            raise


async def rows(sql, args=()):
    if _diagnostic_reads.get():
        from .diagnostic_state import read_rows
        return await asyncio.to_thread(read_rows, sql, args)
    async with connection() as db:
        async with db.execute(sql, args) as cursor:
            return [dict(row) for row in await cursor.fetchall()]


async def write(sql, args=()):
    async with connection() as db:
        await db.execute(sql, args)


def encode(value):
    return json.dumps(value, ensure_ascii=False, default=str)
