"""Administrator-only, bounded evidence retrieval for the troubleshooting agent."""
from __future__ import annotations

import asyncio
import json

from flocks.auth.context import get_current_auth_user
from flocks.tool.registry import ToolRegistry, ToolCategory, ToolParameter, ParameterType, ToolContext, ToolResult


@ToolRegistry.register_function(
    name='task_failure_evidence', group='运行保障',
    description='Read sanitized failure evidence and correlated Flocks logs for one failed execution. Admin only; no repair, retry or arbitrary file access.',
    description_cn='只读查询失败任务及其关联的脱敏日志，仅管理员可用，不修改任务或配置。',
    category=ToolCategory.SYSTEM, native=True, always_load=False,
    requires_confirmation=False, tags=['task', 'diagnosis', 'read-only'],
    parameters=[ToolParameter(name='execution_id', type=ParameterType.STRING, description='Failed task execution ID from Task Center.')],
)
async def task_failure_evidence(ctx: ToolContext, execution_id: str) -> ToolResult:
    user = get_current_auth_user()
    if not user or user.role != 'admin':
        return ToolResult(success=False, error='查看运行日志需要管理员权限。')
    if not isinstance(execution_id, str) or not execution_id.strip() or len(execution_id) > 200:
        return ToolResult(success=False, error='请提供任务中心中的失败执行ID。')
    await ctx.ask(permission='task_failure_evidence', patterns=[execution_id])
    from flocks.task.manager import TaskManager
    from flocks.task.models import TaskStatus
    from flocks.task.diagnosis import collect_evidence
    execution = await TaskManager.get_execution(execution_id)
    if not execution:
        return ToolResult(success=False, error='未找到这条任务记录，请核对执行ID。')
    if execution.status != TaskStatus.FAILED:
        return ToolResult(success=False, error='这条任务不是失败状态，请核对最新执行记录。')
    try:
        bundle = await asyncio.to_thread(collect_evidence, execution)
    except OSError:
        return ToolResult(success=False, error='本次无法读取日志目录，请管理员核对日志路径和访问权限。')
    return ToolResult(success=True, output=json.dumps({
        'executionID': execution.id, 'status': 'failed', **bundle,
        'notice': '仅调查提供的范围；日志可能已轮转或过期。未进行修复或重试。',
    }, ensure_ascii=False))
