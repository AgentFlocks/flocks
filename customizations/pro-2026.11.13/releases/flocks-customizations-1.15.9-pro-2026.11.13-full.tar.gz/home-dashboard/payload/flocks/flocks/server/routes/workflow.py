"""
Workflow management routes

Provides API endpoints for workflow CRUD, execution, history, and AI generation.
"""

from __future__ import annotations

import asyncio
import copy
import hashlib
import hmac
import json
import os
import shutil
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional, Any, Dict, Literal
from fastapi import Depends, APIRouter, Body, HTTPException, Request, status, Query
from pydantic import BaseModel, Field, ConfigDict, field_validator
from pydantic_core import PydanticCustomError
import uuid

from flocks.workflow.models import Workflow, Node, Edge
from flocks.workflow.service_port import resolve_service_port
from flocks.workflow._async_runtime import register_primary_loop
from flocks.workflow.runner import RunWorkflowResult, run_workflow
from flocks.workflow.center import (
    WorkflowCenterError,
    WorkflowNotFoundError,
    WorkflowNotPublishedError,
    WorkflowPortUnavailableError,
    get_workflow_health,
    invoke_published_workflow,
    list_registry_entries,
    list_workflow_releases,
    publish_workflow,
    scan_skill_workflows,
    stop_workflow_service,
)
from flocks.session.recorder import Recorder
from flocks.session.session import SessionAgentMismatchError
from flocks.workflow.workflow_lint import lint_workflow
from flocks.workflow.validation import validate_workflow_python
from flocks.workflow.compiler import compile_workflow
from flocks.workflow.fs_store import (
    find_workspace_root as _find_workspace_root,
    is_safe_workflow_id as _is_safe_workflow_id,
    read_workflow_dir as shared_read_workflow_dir,
    read_workflow_from_fs as shared_read_workflow_from_fs,
    workflow_scan_dirs as _all_scan_dirs,
    normalize_workflow_group,
    patch_workflow_metadata,
    resolve_workflow_from_fs as shared_resolve_workflow_from_fs,
    is_managed_workflow,
    overlay_managed_workflows,
    refuse_managed_workflow_write,
    is_system_workflow_definition,
)
from flocks.ingest.kafka.constants import WORKFLOW_KAFKA_CONFIG_PREFIX
from flocks.ingest.syslog.constants import WORKFLOW_SYSLOG_CONFIG_PREFIX
from flocks.workflow.execution_store import (
    compact_history_for_storage,
    compact_execution_summary,
    compact_outputs_for_storage,
    compact_step_for_storage,
    create_execution_record,
    derive_loop_progress,
    ExecutionProgressWriter,
    ExecutionStepRecorder,
    load_execution_steps,
    normalize_execution_status as _normalize_execution_status,
    record_execution_result as _record_execution_result,
    resolve_execution_outcome as _resolve_execution_outcome,
)
from flocks.workflow.io import load_workflow, dump_workflow
from flocks.workflow.store import WorkflowStore
from flocks.workflow.definition_io import parse_definition, write_definition
from flocks.workflow.ownership import abandon_execution, execution_cancelled
from flocks.workflow.tool_context import build_workflow_tool_context
from flocks.workflow.tools import get_tool_registry
from flocks.workflow.visibility import is_hidden_workflow_data
from flocks.workflow.triggers import (
    TriggerDefinition,
    TriggerEvent,
    build_trigger_event,
    default_trigger_id,
    preview_trigger_mapping,
    set_workflow_json_triggers,
    workflow_json_declares_triggers,
    workflow_trigger_definitions_from_json,
)
from flocks.workflow.triggers.models import TriggerType
from flocks.workflow.triggers.dispatcher import TriggerDispatchError, evaluate_trigger_filter
from flocks.workflow.triggers.runtime import default_runtime as default_trigger_runtime
from flocks.workflow.triggers.compat import (
    kafka_trigger_to_legacy_config,
    legacy_kafka_trigger_from_config,
    legacy_schedule_trigger_from_config,
    legacy_syslog_trigger_from_config,
    schedule_trigger_to_legacy_config,
    syslog_trigger_to_legacy_config,
)
from flocks.config.config import Config
from flocks.hooks.execution import ExecutionStopped, current_execution_context
from flocks.storage.storage import Storage
from flocks.server.auth import get_optional_user
from flocks.server.routes.event import publish_event
from flocks.tool import ToolContext
from flocks.utils.log import Log
from flocks.config.config import get_user_plugins_root

from flocks.server.auth import require_admin

router = APIRouter()
webhook_router = APIRouter()
log = Log.create(service="workflow-routes")

_WORKFLOW_LIST_ENRICH_CONCURRENCY = 8
_WORKFLOW_API_HEALTH_INTERVAL_S = 5.0
_WORKFLOW_API_HEALTH_PROBE_CONCURRENCY = 4

_workflow_api_health_cache: Dict[str, bool] = {}
_workflow_api_health_monitor_task: Optional[asyncio.Task[None]] = None

_LEGACY_SINGLETON_TRIGGER_TYPES = frozenset({"schedule", "kafka", "syslog"})
_WEBHOOK_TRIGGER_TYPES = frozenset({"webhook", "custom_webhook"})
_WEBHOOK_AUTH_TYPES = frozenset({"api_key", "hmac"})
_WORKFLOW_INTEGRATION_CONFIG_VERSION = 1
_WORKFLOW_INTEGRATION_CONFIG_KIND = "workflow.integration-config"
_WORKFLOW_INTEGRATION_CONFIG_PREFIX = "workflow_integration_config/"
_WORKFLOW_CENTER_REGISTRY_PREFIX = "workflow_registry/"
_WORKFLOW_CENTER_RELEASE_PREFIX = "workflow_release/"
_WORKFLOW_CENTER_RUNTIME_PREFIX = "workflow_runtime/"
_WORKFLOW_CENTER_LOCAL_PID_PREFIX = "workflow_local_pid/"
_WORKFLOW_POLLER_CONFIG_PREFIX = "workflow_poller_config/"
_WORKFLOW_CONFIG_TRIGGER_TYPES = frozenset(
    {
        "manual",
        "schedule",
        "webhook",
        "syslog",
        "kafka",
        "internal_event",
        "custom_webhook",
        "custom_adapter",
        "plugin",
        "api",
        "publish",
        "api_service",
        "service",
    }
)
_WORKFLOW_CONFIG_SECRET_KEYS = frozenset({"apikey", "password", "token", "secret"})
_WORKFLOW_CONFIG_SECRET_REF_KEYS = frozenset({"secretref", "secretreference"})


@dataclass
class ActiveWorkflowExecution:
    """Tracks an in-flight workflow execution that can be cancelled."""

    workflow_id: str
    task: asyncio.Task[Any]
    cancel_event: threading.Event
    progress_writer: ExecutionProgressWriter


_active_workflow_executions: Dict[str, ActiveWorkflowExecution] = {}


# =============================================================================
# Request/Response Models
# =============================================================================


def _require_visible_workflow_name(value: Optional[str]) -> Optional[str]:
    """A workflow name must show something: spaces or tabs alone are no name."""
    if value is not None and not value.strip():
        raise PydanticCustomError("workflow_name_blank", "Workflow name must not be blank")
    return value


class WorkflowCreateRequest(BaseModel):
    """Request to create a workflow"""

    model_config = ConfigDict(populate_by_name=True)

    group: Optional[str] = None
    _validate_group = field_validator("group", mode="before")(normalize_workflow_group)

    name: str = Field(..., min_length=1, description="Workflow name")
    _validate_name = field_validator("name")(_require_visible_workflow_name)
    name_i18n: Optional[Dict[str, str]] = Field(None, alias="nameI18n", description="Localized workflow display names")
    description: Optional[str] = Field(None, description="Workflow description")
    category: Optional[str] = Field("default", description="Workflow category")
    workflow_json: Dict[str, Any] = Field(..., alias="workflowJson", description="Workflow JSON definition")
    created_by: Optional[str] = Field(None, alias="createdBy", description="Creator")
    source: Optional[Literal["project", "global"]] = Field(
        "global",
        description="Storage location: 'project' or 'global'; defaults to global user storage",
    )


class WorkflowUpdateRequest(BaseModel):
    """Request to update a workflow"""

    model_config = ConfigDict(populate_by_name=True)

    group: Optional[str] = None
    _validate_group = field_validator("group", mode="before")(normalize_workflow_group)

    name: Optional[str] = Field(None, description="Workflow name")
    _validate_name = field_validator("name")(_require_visible_workflow_name)
    name_i18n: Optional[Dict[str, str]] = Field(None, alias="nameI18n", description="Localized workflow display names")
    description: Optional[str] = Field(None, description="Workflow description")
    category: Optional[str] = Field(None, description="Workflow category")
    workflow_json: Optional[Dict[str, Any]] = Field(None, alias="workflowJson", description="Workflow JSON")
    markdown_content: Optional[str] = Field(
        None,
        alias="markdownContent",
        description="Human-editable workflow.md content",
    )
    edit_markdown_content: Optional[str] = Field(
        None,
        alias="editMarkdownContent",
        description="Legacy alias for markdownContent",
    )
    status: Optional[Literal["draft", "active", "archived"]] = Field(None, description="Status")


WorkflowCapabilityState = Literal["unconfigured", "starting", "running", "stopped", "error"]


class WorkflowCapabilityStatusResponse(BaseModel):
    configured: bool
    state: WorkflowCapabilityState


class WorkflowTriggerStatusItemResponse(BaseModel):
    id: str
    type: TriggerType
    name: Optional[str] = None
    state: WorkflowCapabilityState
    rawState: Optional[str] = None


class WorkflowTriggerCapabilityStatusResponse(WorkflowCapabilityStatusResponse):
    count: int = 0
    items: List[WorkflowTriggerStatusItemResponse] = Field(default_factory=list)


class WorkflowIntegrationStatusResponse(BaseModel):
    api: WorkflowCapabilityStatusResponse
    trigger: WorkflowTriggerCapabilityStatusResponse


class WorkflowResponse(BaseModel):
    """Workflow response"""

    model_config = ConfigDict(populate_by_name=True, by_alias=True)

    id: str = Field(..., description="Workflow ID")
    name: str = Field(..., description="Workflow name")
    group: Optional[str] = None
    group_readonly: bool = False
    nameI18n: Optional[Dict[str, str]] = Field(None, description="Localized workflow display names")
    description: Optional[str] = Field(None, description="Description")
    markdownContent: Optional[str] = Field(None, description="Workflow markdown documentation content")
    editMarkdownContent: Optional[str] = Field(None, description="Human-editable workflow markdown document content")
    category: str = Field("default", description="Category")
    workflowJson: Dict[str, Any] = Field(..., description="Workflow JSON")
    status: str = Field("draft", description="Status")
    source: Optional[str] = Field(None, description="Storage location: 'project', 'global' or 'managed'")
    managed: bool = Field(False, description="Served by the deployment's content source; read-only")
    createdBy: Optional[str] = Field(None, description="Creator")
    createdAt: int = Field(..., description="Created timestamp (ms)")
    updatedAt: int = Field(..., description="Updated timestamp (ms)")
    stats: Dict[str, Any] = Field(default_factory=dict, description="Statistics")
    definitionError: Optional[Dict[str, Any]] = None
    integrationStatus: Optional[WorkflowIntegrationStatusResponse] = Field(
        None,
        description="API publishing and trigger runtime summary",
    )


class WorkflowSummaryResponse(BaseModel):
    """Lightweight workflow data used by card lists."""

    id: str
    name: str
    group: Optional[str] = None
    group_readonly: bool = False
    nameI18n: Optional[Dict[str, str]] = None
    description: Optional[str] = None
    category: str = "default"
    status: str = "draft"
    source: Optional[str] = None
    createdAt: int
    updatedAt: int
    nodeCount: int = 0
    definitionError: Optional[Dict[str, Any]] = None
    stats: Dict[str, Any] = Field(default_factory=dict)
    integrationStatus: WorkflowIntegrationStatusResponse


class WorkflowRunRequest(BaseModel):
    """Request to run a workflow"""

    model_config = ConfigDict(populate_by_name=True)

    inputs: Optional[Dict[str, Any]] = Field(default_factory=dict, description="Input parameters")
    timeout_s: Optional[float] = Field(None, alias="timeoutS", description="Timeout in seconds")
    trace: bool = Field(False, description="Enable tracing")
    session_id: Optional[str] = Field(None, alias="sessionId", description="Optional parent session ID")
    message_id: Optional[str] = Field(None, alias="messageId", description="Optional parent message ID")
    agent: Optional[str] = Field(None, description="Optional agent name for tool context")


class WorkflowExecutionResponse(BaseModel):
    """Workflow execution response"""

    model_config = ConfigDict(populate_by_name=True, by_alias=True)

    id: str = Field(..., description="Execution ID")
    workflowId: str = Field(..., description="Workflow ID")
    inputParams: Dict[str, Any] = Field(default_factory=dict, description="Input parameters")
    outputResults: Optional[Dict[str, Any]] = Field(None, description="Output results")
    status: str = Field(..., description="Status: running/success/error/timeout/cancelled")
    startedAt: int = Field(..., description="Start timestamp (ms)")
    finishedAt: Optional[int] = Field(None, description="Finish timestamp (ms)")
    duration: Optional[float] = Field(None, description="Duration (seconds)")
    executionLog: List[Dict[str, Any]] = Field(default_factory=list, description="Execution log")
    errorMessage: Optional[str] = Field(None, description="Error message")
    triggerId: Optional[str] = Field(None, description="Trigger ID")
    triggerType: Optional[str] = Field(None, description="Trigger type")
    deliveryId: Optional[str] = Field(None, description="Trigger delivery ID")
    attempt: Optional[int] = Field(None, description="Trigger attempt")
    triggerSource: Optional[str] = Field(None, description="Trigger source")
    currentNodeId: Optional[str] = Field(None, description="Current running node ID")
    currentNodeType: Optional[str] = Field(None, description="Current running node type")
    currentPhase: Optional[str] = Field(None, description="Current execution phase")
    currentStepIndex: Optional[int] = Field(None, description="Current step index")
    stepCount: Optional[int] = Field(None, description="Persisted execution step count")
    stepLogOffset: Optional[int] = Field(None, description="Returned step log offset")
    stepLogLimit: Optional[int] = Field(None, description="Returned step log limit")
    stepLogTotal: Optional[int] = Field(None, description="Total persisted step logs")
    loopProgress: Optional[Dict[str, Any]] = Field(None, description="Best-effort loop progress metadata")


class WorkflowCenterPublishRequest(BaseModel):
    """Request to publish a workflow as an API service."""

    image: Optional[str] = Field(None, description="Docker image used to run service")
    driver: Optional[Literal["local", "docker"]] = Field(
        None,
        description="Service driver. Defaults to FLOCKS_WORKFLOW_SERVICE_DRIVER or local.",
    )
    port: Optional[int] = Field(None, ge=1, le=65535, description="Stable host listening port")


class WorkflowCenterInvokeRequest(BaseModel):
    """Request to invoke a published workflow service."""

    model_config = ConfigDict(populate_by_name=True)
    inputs: Dict[str, Any] = Field(default_factory=dict, description="Workflow invoke inputs")
    timeout_s: Optional[float] = Field(None, alias="timeoutS", description="Invoke timeout (seconds)")
    request_id: Optional[str] = Field(None, alias="requestId", description="Caller request id")


class WorkflowStatsResponse(BaseModel):
    """Workflow statistics response"""

    model_config = ConfigDict(populate_by_name=True, by_alias=True)

    workflowId: Optional[str] = Field(None, description="Workflow ID (null for aggregate)")
    callCount: int = Field(0, description="Total calls")
    successCount: int = Field(0, description="Successful calls")
    errorCount: int = Field(0, description="Failed calls")
    totalRuntime: float = Field(0.0, description="Total runtime (seconds)")
    avgRuntime: float = Field(0.0, description="Average runtime (seconds)")
    thumbsUp: int = Field(0, description="Thumbs up count")
    thumbsDown: int = Field(0, description="Thumbs down count")


# =============================================================================
# Filesystem Helpers (Single Source of Truth)
# =============================================================================


def _workflow_dir(workflow_id: str) -> Path:
    """Return the project-level directory for a workflow."""
    return _find_workspace_root() / ".flocks" / "plugins" / "workflows" / workflow_id


def _global_workflow_dir(workflow_id: str) -> Path:
    """Return the global-level directory for a workflow (<flocks root>/plugins/workflows/<id>/)."""
    return get_user_plugins_root() / "workflows" / workflow_id


def _existing_workflow_dir(workflow_id: str) -> Optional[Path]:
    """Return the highest-priority existing directory for a workflow."""
    result: Optional[Path] = None
    for root, _source in _all_scan_dirs():
        wf_dir = root / workflow_id
        if _read_workflow_dir(wf_dir, workflow_id, _source) is not None:
            result = wf_dir
    return result


def _workflow_config_dir(workflow_id: str, workflow_data: Optional[Dict[str, Any]] = None) -> Path:
    """Return the directory where workflow-local config.json should be written."""
    existing = _existing_workflow_dir(workflow_id)
    if existing is not None:
        return existing
    if workflow_data and workflow_data.get("source") == "global":
        return _global_workflow_dir(workflow_id)
    return _workflow_dir(workflow_id)


def _workflow_integration_config_key(workflow_id: str) -> str:
    """Storage key for the publish/integration template used by the UI."""
    return f"{_WORKFLOW_INTEGRATION_CONFIG_PREFIX}{workflow_id}"


_MANAGED_WORKFLOW_DETAIL = "This workflow is managed by the deployment and is read-only"


def _refuse_managed_workflow_change(workflow_id: str) -> None:
    """A managed workflow's definition is the deployment's: no edit or delete here."""
    if is_managed_workflow(workflow_id):
        raise HTTPException(status_code=403, detail=_MANAGED_WORKFLOW_DETAIL)


def _read_workflow_dir(wf_dir: Path, workflow_id: str, source: str) -> Optional[Dict[str, Any]]:
    return shared_read_workflow_dir(wf_dir, workflow_id, source, include_errors=True)


def resolve_workflow_from_fs(workflow_id: str) -> Optional[tuple[Path, Dict[str, Any]]]:
    return shared_resolve_workflow_from_fs(workflow_id, include_errors=True)


def _read_workflow_from_fs(workflow_id: str) -> Optional[Dict[str, Any]]:
    """Read workflow data from the filesystem.

    Search order (lowest → highest priority) visits project-bundled roots before
    global user roots; per-id dir is ``<root>/<id>/`` with ``workflow.json``
    inside.
    """
    data = shared_read_workflow_from_fs(workflow_id, include_errors=True)
    if data and data.get("definitionError"):
        raise HTTPException(status_code=422, detail=data["definitionError"]["message"])
    return data


async def _build_workflow_tool_context(
    *,
    workflow_id: str,
    action_name: str,
    session_id: Optional[str] = None,
    message_id: Optional[str] = None,
    agent: Optional[str] = None,
) -> ToolContext:
    """Build a real ToolContext for workflow execution."""
    context_kwargs: Dict[str, Any] = {}
    execution_context = current_execution_context()
    if execution_context:
        context_kwargs["execution_context"] = execution_context
    return await build_workflow_tool_context(
        workflow_id=workflow_id,
        action_name=action_name,
        session_id=session_id,
        message_id=message_id,
        agent=agent,
        event_publish_callback=publish_event,
        **context_kwargs,
    )


def _write_workflow_to_fs(
    workflow_id: str,
    workflow_json: Dict[str, Any],
    meta: Dict[str, Any],
    markdown_content: Optional[str] = None,
    edit_markdown_content: Optional[str] = None,
    *,
    global_store: bool = False,
    target_dir: Optional[Path] = None,
    create_only: bool = False,
) -> None:
    """Write workflow definition and metadata to the filesystem.

    When *global_store* is True the workflow is written under
    ``~/.flocks/plugins/workflows/<id>/`` instead of the project directory.
    """
    if create_only and target_dir is None:
        raise ValueError("Create-only migration requires an explicit destination")
    refuse_managed_workflow_write(workflow_id)
    wf_dir = target_dir or _existing_workflow_dir(workflow_id) or (
        _global_workflow_dir(workflow_id) if global_store else _workflow_dir(workflow_id)
    )
    meta = dict(meta)
    if is_system_workflow_definition(wf_dir):
        meta_path = wf_dir / "meta.json"
        native_meta = json.loads(meta_path.read_text(encoding="utf-8")) if meta_path.is_file() else {}
        native_group = normalize_workflow_group(native_meta.get("group"))
        transport = workflow_json.get("metadata")
        for values in (meta, transport if isinstance(transport, dict) else {}):
            if "group" in values and normalize_workflow_group(values["group"]) != native_group:
                raise ValueError("System workflow group is read-only")
        meta["group"] = native_group
    # Claim the migration destination atomically. Never redirect a migration to
    # an existing definition, nor clobber files created by another worker.
    wf_dir.mkdir(parents=True, exist_ok=not create_only)

    # The local group authority is meta.json, never the execution definition.
    workflow_json = dict(workflow_json)
    if isinstance(workflow_json.get("metadata"), dict):
        workflow_json["metadata"] = dict(workflow_json["metadata"])
        workflow_json["metadata"].pop("group", None)
    meta_to_save = {
        k: v
        for k, v in meta.items()
        if k not in ("workflowJson", "markdownContent", "editMarkdownContent", "stats", "source", "group_readonly", "definitionError")
    }
    definition_text = json.dumps(workflow_json, ensure_ascii=False, indent=2)
    metadata_text = json.dumps(meta_to_save, ensure_ascii=False, indent=2)
    # Validate both candidates before either file is replaced.
    parse_definition(definition_text, "workflow.json")
    parse_definition(metadata_text, "meta.json")
    write_definition(wf_dir / "workflow.json", definition_text, create_only=create_only)
    write_definition(wf_dir / "meta.json", metadata_text, create_only=create_only)

    if markdown_content is None and edit_markdown_content is not None:
        markdown_content = edit_markdown_content

    if markdown_content is not None:
        with open(wf_dir / "workflow.md", "x" if create_only else "w", encoding="utf-8") as f:
            f.write(markdown_content)

    legacy_edit_file = wf_dir / "workflow.edit.md"
    if not create_only and legacy_edit_file.exists():
        legacy_edit_file.unlink()


def _apply_new_workflow_runtime_defaults(workflow_json: Dict[str, Any]) -> Dict[str, Any]:
    """Return workflow JSON with runtime defaults for newly created workflows."""
    normalized = dict(workflow_json)
    metadata = normalized.get("metadata")
    if not isinstance(metadata, dict):
        metadata = {}
    else:
        metadata = dict(metadata)
    runtime = metadata.get("runtime")
    if not isinstance(runtime, dict):
        runtime = {}
    else:
        runtime = dict(runtime)

    runtime.setdefault("strict_edge_mapping", True)
    runtime.setdefault("dataflow_mode", "vertex_cache")
    metadata["runtime"] = runtime
    normalized["metadata"] = metadata
    return normalized


_RUNTIME_METADATA_SECTIONS = ("runtime", "runtime_defaults", "runtimeDefaults")
# Each setting is read from the metadata root or any runtime section, under
# either spelling (workflow_lint / execution_plan resolve them in that order).
_RUNTIME_SETTING_ALIASES = (
    ("strict_edge_mapping", "strictEdgeMapping"),
    ("dataflow_mode", "dataflowMode"),
)
_RUNTIME_SETTING_KEYS = frozenset(alias for aliases in _RUNTIME_SETTING_ALIASES for alias in aliases)


def _metadata_sets(metadata: Dict[str, Any], aliases: tuple[str, ...]) -> bool:
    scopes = [metadata, *(metadata.get(section) for section in _RUNTIME_METADATA_SECTIONS)]
    return any(
        isinstance(scope, dict) and any(scope.get(alias) is not None for alias in aliases)
        for scope in scopes
    )


def _inherit_saved_workflow_metadata(
    incoming: Dict[str, Any],
    saved: Dict[str, Any],
) -> Dict[str, Any]:
    """Fill metadata an update left out from the saved definition.

    The editor echoes metadata back, but API callers often send only nodes and
    edges; replacing metadata wholesale dropped strict edge mapping, so
    mapping-less edges then passed lint. Omitted metadata keeps the saved
    block. Otherwise runtime sections keep their saved keys under the request's
    own; a setting the request spells anywhere (null counts as unset) drops
    every saved spelling of it, so an inherited alias cannot outrank it.
    """
    saved_metadata = saved.get("metadata") if isinstance(saved, dict) else None
    merged = dict(incoming)
    if not isinstance(saved_metadata, dict) or not saved_metadata:
        return merged
    incoming_metadata = merged.get("metadata")
    if not isinstance(incoming_metadata, dict):
        merged["metadata"] = copy.deepcopy(saved_metadata)
        return merged

    overridden = {
        alias
        for aliases in _RUNTIME_SETTING_ALIASES
        if _metadata_sets(incoming_metadata, aliases)
        for alias in aliases
    }
    metadata = dict(incoming_metadata)
    for aliases in _RUNTIME_SETTING_ALIASES:
        for alias in aliases:
            if alias not in overridden and metadata.get(alias) is None and alias in saved_metadata:
                metadata[alias] = copy.deepcopy(saved_metadata[alias])
    for section in _RUNTIME_METADATA_SECTIONS:
        saved_section = saved_metadata.get(section)
        if not isinstance(saved_section, dict):
            continue
        inherited = {
            key: copy.deepcopy(value)
            for key, value in saved_section.items()
            if key not in overridden
        }
        incoming_section = metadata.get(section)
        if isinstance(incoming_section, dict):
            # A null setting means "not given" here too, like at the root.
            inherited.update(
                (key, value)
                for key, value in incoming_section.items()
                if value is not None or key not in _RUNTIME_SETTING_KEYS
            )
        if inherited:
            metadata[section] = inherited
    merged["metadata"] = metadata
    return merged


def _strict_edge_mapping_lint_errors(workflow: Workflow) -> List[Dict[str, Any]]:
    """Return strict edge-mapping lint errors that would fail execution."""
    return [
        item
        for item in lint_workflow(workflow)
        if item.get("severity") == "error" and item.get("kind") == "implicit_full_payload_edge"
    ]


def _schema_lint_errors(workflow: Workflow) -> List[Dict[str, Any]]:
    """Return lightweight schema lint errors that would fail execution."""
    return [
        item
        for item in lint_workflow(workflow)
        if item.get("severity") == "error" and str(item.get("kind", "")).startswith("schema_")
    ]


def _delete_workflow_from_fs(workflow_id: str) -> bool:
    """Remove a workflow directory from all known locations (primary + legacy plugins).

    Returns True if at least one directory was deleted.
    """
    deleted = False
    if not _is_safe_workflow_id(workflow_id):
        # ``<root>/..`` would be the parent of the workflow root; never rmtree it.
        log.warning("workflow.fs.delete_rejected", {"id": workflow_id, "reason": "unsafe_workflow_id"})
        return False
    for root, _source in _all_scan_dirs():
        wf_dir = root / workflow_id
        if wf_dir.is_dir():
            shutil.rmtree(wf_dir)
            log.info("workflow.fs.deleted", {"id": workflow_id, "dir": str(wf_dir)})
            deleted = True
    return deleted


async def _remove_storage_key_if_exists(key: str) -> None:
    try:
        await Storage.remove(key)
    except Storage.NotFoundError:
        pass
    except Exception as exc:
        log.warning("workflow.delete.storage_key_remove_failed", {"key": key, "error": str(exc)})


async def _remove_storage_prefix(prefix: str) -> None:
    try:
        keys = await Storage.list(prefix)
    except Exception as exc:
        log.warning("workflow.delete.storage_prefix_list_failed", {"prefix": prefix, "error": str(exc)})
        return

    for key in keys:
        try:
            await Storage.remove(key)
        except Storage.NotFoundError:
            pass
        except Exception as exc:
            log.warning("workflow.delete.storage_key_remove_failed", {"key": key, "error": str(exc)})


async def _stop_workflow_runtime_resources(workflow_id: str) -> None:
    for exec_id, active in list(_active_workflow_executions.items()):
        if active.workflow_id == workflow_id:
            active.cancel_event.set()

    try:
        await stop_workflow_service(workflow_id)
    except Exception as exc:
        log.debug("workflow.delete.stop_service_ignored", {"id": workflow_id, "error": str(exc)})

    try:
        await default_trigger_runtime.restart_workflow(workflow_id, {"triggers": []})
    except Exception as exc:
        log.debug("workflow.delete.stop_triggers_ignored", {"id": workflow_id, "error": str(exc)})


async def _cleanup_workflow_storage(workflow_id: str) -> None:
    try:
        await WorkflowStore.delete_stats(workflow_id)
        await WorkflowStore.delete_config(workflow_id)
        await WorkflowStore.delete_executions_for_workflow(workflow_id)
        await WorkflowStore.kv_remove(_api_service_key(workflow_id))
        await WorkflowStore.kv_remove(f"{_WORKFLOW_CENTER_REGISTRY_PREFIX}{workflow_id}")
        await WorkflowStore.kv_remove(f"{_WORKFLOW_CENTER_RUNTIME_PREFIX}{workflow_id}")
        await WorkflowStore.kv_remove(f"{_WORKFLOW_CENTER_LOCAL_PID_PREFIX}{workflow_id}")
        await WorkflowStore.kv_clear(f"{_WORKFLOW_CENTER_RELEASE_PREFIX}{workflow_id}/")
    except Exception as exc:
        log.warning(
            "workflow.delete.workflow_store_cleanup_failed",
            {
                "workflow_id": workflow_id,
                "error": str(exc),
            },
        )

    service_dir = Config.get_data_path() / "workflow-services" / "workflows" / workflow_id
    if service_dir.is_dir():
        shutil.rmtree(service_dir, ignore_errors=True)


def _scan_workflow_base_dir(base_dir: Path, source: str) -> Dict[str, Dict[str, Any]]:
    """Scan a single workflow base directory and return {id: data} dict."""
    results: Dict[str, Dict[str, Any]] = {}
    if not base_dir.is_dir():
        return results
    for entry in sorted(base_dir.iterdir()):
        if not entry.is_dir():
            continue
        data = _read_workflow_dir(entry, entry.name, source)
        if data is not None and (data.get("definitionError") or not is_hidden_workflow_data(data)):
            results[entry.name] = data
    return results


def _list_workflows_from_fs() -> List[Dict[str, Any]]:
    """Scan global and project workflow directories and return merged list.

    Scan order matches *_all_scan_dirs()* (lowest -> highest priority): project
    bundle roots first, then global user roots; under each root, immediate
    subdirectories with *workflow.json* are workflows.

    Later entries override earlier ones when the workflow directory name (*id*)
    is the same.
    """
    by_id: Dict[str, Dict[str, Any]] = {}
    for scan_path, source in _all_scan_dirs():
        by_id.update(_scan_workflow_base_dir(scan_path, source))
    # Workflows the deployment manages replace local ones of the same id.
    overlay_managed_workflows(by_id)
    return [data for data in by_id.values() if not is_hidden_workflow_data(data)]


_INTERRUPTED_EXECUTION_MESSAGE = "Execution interrupted: the worker stopped or lost execution ownership"


async def mark_interrupted_executions() -> int:
    """Finalize runs without a live owner; a restart is only one possible cause."""
    return await WorkflowStore.recover_expired_executions(_INTERRUPTED_EXECUTION_MESSAGE)


async def sync_workflows_from_filesystem() -> int:
    """Best-effort startup sync for filesystem-backed workflows.

    The filesystem is the source of truth for workflow definitions. Startup only
    needs to migrate any legacy Storage-only records to disk and report how many
    workflows are currently discoverable from the configured workflow roots.
    Execution records orphaned by the previous process are finalized here too.
    """
    # Workflow threads hand hook-bound coroutines back to this (the server's)
    # loop; see flocks.workflow._async_runtime.register_primary_loop.
    register_primary_loop()
    await _migrate_storage_to_filesystem()
    await mark_interrupted_executions()
    return len(_list_workflows_from_fs())


async def _migrate_storage_to_filesystem() -> None:
    """One-time migration: move Storage-only workflow definitions to the filesystem.

    After this migration the filesystem is the sole source of truth for workflow
    definitions. Storage is retained only for stats and execution history.

    Uses a marker file (.flocks/.storage_migrated) so the migration is safe
    across multiple workers / process restarts.
    """
    marker = _find_workspace_root() / ".flocks" / ".storage_migrated"
    if marker.exists():
        return

    try:
        keys = await Storage.list_keys("workflow/")
        migrated = 0
        for key in keys:
            remainder = key.removeprefix("workflow/")
            if "/" in remainder:
                continue
            workflow_id = remainder
            if not workflow_id or is_managed_workflow(workflow_id):
                # A managed id never gets a local definition.
                continue

            def already_on_disk() -> bool:
                return any(
                    (root / workflow_id / filename).is_file()
                    for root, _source in _all_scan_dirs()
                    for filename in ("workflow.json", "workflow.md", "workflow.edit.md")
                )

            if already_on_disk():
                continue
            # Migration has a fixed create-only destination. Ordinary updates
            # alone may resolve the highest-priority existing directory.
            wf_dir = _workflow_dir(workflow_id)
            try:
                data = await Storage.read(key)
                if not data or already_on_disk():
                    continue
                workflow_json = data.get("workflowJson", {})
                meta = {
                    "id": workflow_id,
                    "name": data.get("name", workflow_id),
                    "description": data.get("description"),
                    "category": data.get("category", "default"),
                    "status": data.get("status", "draft"),
                    "createdBy": data.get("createdBy"),
                    "createdAt": data.get("createdAt", int(time.time() * 1000)),
                    "updatedAt": data.get("updatedAt", int(time.time() * 1000)),
                }
                if "group" in data:
                    meta["group"] = normalize_workflow_group(data["group"])
                markdown_content = data.get("markdownContent")
                _write_workflow_to_fs(
                    workflow_id, workflow_json, meta, markdown_content,
                    target_dir=wf_dir, create_only=True,
                )
                migrated += 1
                log.info("workflow.migration.migrated", {"id": workflow_id})
            except Exception as exc:
                log.warning("workflow.migration.skip", {"key": key, "error": str(exc)})

        if migrated:
            log.info("workflow.migration.done", {"migrated": migrated})
        # Mark migration as completed so other workers skip it
        try:
            marker.touch()
        except Exception:
            pass
    except Exception as exc:
        log.warning("workflow.migration.failed", {"error": str(exc)})


# =============================================================================
# Storage Helpers (Stats & Execution only)
# =============================================================================


def _workflow_stats_key(workflow_id: str) -> str:
    return f"workflow/{workflow_id}/stats"


def _syslog_config_key(workflow_id: str) -> str:
    return f"{WORKFLOW_SYSLOG_CONFIG_PREFIX}{workflow_id}"


async def _read_legacy_trigger_defs(workflow_id: str) -> List[TriggerDefinition]:
    triggers: List[TriggerDefinition] = []
    for kind, converter in (
        ("workflow_kafka_config", legacy_kafka_trigger_from_config),
        ("workflow_poller_config", legacy_schedule_trigger_from_config),
        ("workflow_syslog_config", legacy_syslog_trigger_from_config),
    ):
        try:
            config = await WorkflowStore.get_config(workflow_id, kind=kind)
        except Exception:
            config = None
        trigger = converter(config)
        if trigger is not None:
            triggers.append(trigger)
    return triggers


async def _get_workflow_trigger_defs(
    workflow_id: str,
    workflow_data: Optional[Dict[str, Any]] = None,
) -> List[TriggerDefinition]:
    data = workflow_data or _read_workflow_from_fs(workflow_id)
    if not data:
        return []
    workflow_json = data.get("workflowJson") or {}
    triggers = workflow_trigger_definitions_from_json(workflow_json)
    # Once the workflow JSON explicitly declares a trigger list, it becomes the
    # single source of truth, even when the list is empty.
    if workflow_json_declares_triggers(workflow_json):
        return triggers
    return await _read_legacy_trigger_defs(workflow_id)


def _trigger_to_api_dict(trigger: TriggerDefinition) -> Dict[str, Any]:
    """Serialize a trigger for API responses with webhook secrets redacted.

    ``auth.apiKey`` is write-only: responses carry ``apiKeyConfigured`` instead
    (the same shape ``/config`` already uses), and saving a trigger without an
    ``apiKey`` keeps the stored one (see ``_merge_trigger_secrets``).
    """
    payload = trigger.model_dump(mode="json", by_alias=True, exclude_none=True)
    auth = payload.get("auth")
    if isinstance(auth, dict) and "apiKey" in auth:
        auth = dict(auth)
        auth.pop("apiKey", None)
        auth["apiKeyConfigured"] = True
        payload["auth"] = auth
    return payload


def _merge_trigger_secrets(
    trigger: TriggerDefinition,
    existing: Optional[TriggerDefinition],
) -> TriggerDefinition:
    """Carry a stored webhook apiKey over when a save omits it (write-only secret)."""
    auth = trigger.auth
    if auth is None:
        return trigger
    auth_payload = auth.model_dump(mode="json", by_alias=True, exclude_none=True)
    auth_payload.pop("apiKeyConfigured", None)
    if not auth_payload.get("apiKey") and existing is not None and existing.auth is not None:
        existing_key = existing.auth.apiKey
        if existing_key and _webhook_auth_type(existing) == _webhook_auth_type(trigger):
            auth_payload["apiKey"] = existing_key
    from flocks.workflow.triggers.models import TriggerAuth

    return trigger.model_copy(update={"auth": TriggerAuth.model_validate(auth_payload)})


def _drop_none_values(payload: Dict[str, Any]) -> Dict[str, Any]:
    return {key: value for key, value in payload.items() if value is not None}


def _normalized_config_key(key: Any) -> str:
    return str(key).replace("_", "").replace("-", "").lower()


def _sanitize_workflow_config_secrets(value: Any) -> Any:
    if isinstance(value, list):
        return [_sanitize_workflow_config_secrets(item) for item in value]
    if not isinstance(value, dict):
        return value

    sanitized: Dict[str, Any] = {}
    for key, nested in value.items():
        normalized_key = _normalized_config_key(key)
        is_secret_key = (
            normalized_key in _WORKFLOW_CONFIG_SECRET_KEYS
            or normalized_key.endswith(("apikey", "password", "token", "secret"))
        ) and normalized_key not in _WORKFLOW_CONFIG_SECRET_REF_KEYS
        if is_secret_key:
            if nested not in (None, ""):
                configured_key = "apiKeyConfigured" if normalized_key == "apikey" else f"{key}Configured"
                sanitized[configured_key] = True
            continue
        sanitized[str(key)] = _sanitize_workflow_config_secrets(nested)
    return sanitized


def _normalize_workflow_integration_config_template(
    workflow_id: str,
    workflow_data: Dict[str, Any],
    config: Dict[str, Any],
) -> Dict[str, Any]:
    if not isinstance(config, dict):
        raise HTTPException(status_code=422, detail="config must be a JSON object")

    payload = _sanitize_workflow_config_secrets(config)
    payload.pop("runtime", None)

    kind = payload.get("kind", _WORKFLOW_INTEGRATION_CONFIG_KIND)
    if kind != _WORKFLOW_INTEGRATION_CONFIG_KIND:
        raise HTTPException(
            status_code=422,
            detail=f"config.kind must be {_WORKFLOW_INTEGRATION_CONFIG_KIND}",
        )
    payload["kind"] = _WORKFLOW_INTEGRATION_CONFIG_KIND

    version = payload.get("version", _WORKFLOW_INTEGRATION_CONFIG_VERSION)
    if not isinstance(version, int):
        raise HTTPException(status_code=422, detail="config.version must be an integer")
    payload["version"] = version

    workflow = payload.get("workflow") or {}
    if not isinstance(workflow, dict):
        raise HTTPException(status_code=422, detail="config.workflow must be an object")
    if workflow.get("id") not in (None, workflow_id):
        raise HTTPException(status_code=409, detail="config.workflow.id does not match the route workflow id")
    workflow["id"] = workflow_id
    workflow.setdefault("name", workflow_data.get("name") or workflow_id)
    if workflow_data.get("category") is not None:
        workflow.setdefault("category", workflow_data.get("category"))
    if workflow_data.get("source") is not None:
        workflow.setdefault("source", workflow_data.get("source"))
    payload["workflow"] = workflow

    publish = payload.get("publish", {})
    if publish is None:
        publish = {}
    if not isinstance(publish, dict):
        raise HTTPException(status_code=422, detail="config.publish must be an object")
    payload["publish"] = publish

    if "triggers" not in payload and isinstance(payload.get("integrations"), list):
        payload["triggers"] = payload["integrations"]
    triggers = payload.get("triggers", [])
    if triggers is None:
        triggers = []
    if not isinstance(triggers, list):
        raise HTTPException(status_code=422, detail="config.triggers must be an array")
    for index, trigger in enumerate(triggers):
        if not isinstance(trigger, dict):
            raise HTTPException(status_code=422, detail=f"config.triggers[{index}] must be an object")
        trigger_type = str(trigger.get("type") or "").strip()
        if not trigger_type:
            raise HTTPException(status_code=422, detail=f"config.triggers[{index}].type is required")
        normalized_type = trigger_type.lower().replace("-", "_")
        if normalized_type not in _WORKFLOW_CONFIG_TRIGGER_TYPES:
            raise HTTPException(
                status_code=422,
                detail=f"Unsupported config trigger type: {trigger_type}",
            )
        trigger["type"] = normalized_type
    payload["triggers"] = triggers
    payload["updatedAt"] = int(time.time() * 1000)
    return payload


def _auth_for_config(auth: Optional[Any]) -> Optional[Dict[str, Any]]:
    if auth is None:
        return None
    if hasattr(auth, "model_dump"):
        auth_payload = auth.model_dump(mode="json", by_alias=True, exclude_none=True)
    elif isinstance(auth, dict):
        auth_payload = dict(auth)
    else:
        return None

    if "apiKey" in auth_payload:
        auth_payload.pop("apiKey", None)
        auth_payload["apiKeyConfigured"] = True
    return auth_payload


def _trigger_for_config(workflow_id: str, trigger: TriggerDefinition) -> Dict[str, Any]:
    payload = _trigger_to_api_dict(trigger)
    if trigger.auth is not None:
        payload["auth"] = _auth_for_config(trigger.auth)

    if trigger.type in ("webhook", "custom_webhook"):
        payload["invoke"] = {
            "method": str((trigger.source or {}).get("method") or "POST").upper(),
            "path": f"/webhook/workflows/{workflow_id}/{trigger.id}",
        }
    return payload


def _publish_for_config(service: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    service = service if isinstance(service, dict) else None
    status_value = str(service.get("status") or "stopped") if service else "stopped"
    return _drop_none_values(
        {
            "type": "api_service",
            "enabled": bool(service) and status_value not in {"stopped", "unpublished"},
            "status": status_value,
            "driver": service.get("driver") if service else None,
            "port": resolve_service_port(service) if service else None,
            "serviceUrl": service.get("serviceUrl") if service else None,
            "invokeUrl": service.get("invokeUrl") if service else None,
            "containerName": service.get("containerName") if service else None,
            "publishedAt": service.get("publishedAt") if service else None,
            "stoppedAt": service.get("stoppedAt") if service else None,
            "apiKeyConfigured": bool(service and service.get("apiKey")),
        }
    )


async def _build_workflow_integration_config(
    workflow_id: str,
    workflow_data: Dict[str, Any],
    *,
    triggers: Optional[List[TriggerDefinition]] = None,
    service: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    trigger_defs = triggers
    if trigger_defs is None:
        trigger_defs = await _get_workflow_trigger_defs(workflow_id, workflow_data)
    if service is None:
        service = await WorkflowStore.kv_get(_api_service_key(workflow_id))
    now_ms = int(time.time() * 1000)
    return {
        "version": _WORKFLOW_INTEGRATION_CONFIG_VERSION,
        "kind": "workflow.integration-config",
        "workflow": _drop_none_values(
            {
                "id": workflow_id,
                "name": workflow_data.get("name") or workflow_id,
                "category": workflow_data.get("category"),
                "source": workflow_data.get("source"),
            }
        ),
        "updatedAt": now_ms,
        "publish": _publish_for_config(service),
        "triggers": [_trigger_for_config(workflow_id, trigger) for trigger in trigger_defs],
    }


async def _build_workflow_integration_runtime(
    workflow_id: str,
    workflow_data: Dict[str, Any],
) -> Dict[str, Any]:
    triggers = await _get_workflow_trigger_defs(workflow_id, workflow_data)
    service = await WorkflowStore.kv_get(_api_service_key(workflow_id))
    statuses: Dict[str, Dict[str, Any]] = {}
    try:
        statuses = {
            item.get("triggerId"): item
            for item in await default_trigger_runtime.get_workflow_trigger_statuses(
                workflow_id,
                set_workflow_json_triggers(workflow_data.get("workflowJson") or {}, triggers),
            )
            if item.get("triggerId")
        }
    except Exception as exc:
        log.warning(
            "workflow.config.runtime_status_failed",
            {
                "id": workflow_id,
                "error": str(exc),
            },
        )

    return {
        "publish": _publish_for_config(service),
        "triggers": [
            {
                "trigger": _trigger_to_api_dict(trigger),
                "status": statuses.get(trigger.id),
            }
            for trigger in triggers
        ],
    }


async def _write_workflow_integration_config(
    workflow_id: str,
    workflow_data: Dict[str, Any],
    *,
    triggers: Optional[List[TriggerDefinition]] = None,
    service: Optional[Dict[str, Any]] = None,
) -> tuple[Path, Dict[str, Any]]:
    config_dir = _workflow_config_dir(workflow_id, workflow_data)
    config_dir.mkdir(parents=True, exist_ok=True)
    config = await _build_workflow_integration_config(
        workflow_id,
        workflow_data,
        triggers=triggers,
        service=service,
    )
    config_path = config_dir / "config.json"
    config_path.write_text(
        json.dumps(config, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return config_path, config


async def _read_stored_workflow_integration_config(workflow_id: str) -> Optional[Dict[str, Any]]:
    stored = await WorkflowStore.get_config(workflow_id)
    return stored if isinstance(stored, dict) else None


async def _read_file_workflow_integration_config(
    workflow_id: str,
    workflow_data: Dict[str, Any],
    config_path: Path,
) -> Optional[Dict[str, Any]]:
    if not config_path.is_file():
        return None
    raw_config = json.loads(config_path.read_text(encoding="utf-8"))
    if not isinstance(raw_config, dict):
        raise HTTPException(status_code=422, detail="workflow config file must contain a JSON object")
    return _normalize_workflow_integration_config_template(workflow_id, workflow_data, raw_config)


async def _load_workflow_integration_config_template(
    workflow_id: str,
    workflow_data: Dict[str, Any],
    config_path: Path,
) -> tuple[Optional[Dict[str, Any]], str]:
    """Load publish template from Storage first, then migrate legacy config.json."""
    stored = await _read_stored_workflow_integration_config(workflow_id)
    if stored is not None:
        return stored, "storage"

    file_config = await _read_file_workflow_integration_config(workflow_id, workflow_data, config_path)
    if file_config is not None:
        await WorkflowStore.put_config(workflow_id, file_config)
        log.info(
            "workflow.config.migrated_from_file",
            {
                "id": workflow_id,
                "path": str(config_path),
                "storage_key": _workflow_integration_config_key(workflow_id),
            },
        )
        return file_config, "file_migrated"

    return None, "missing"


def _replace_or_append_trigger(
    triggers: List[TriggerDefinition],
    trigger: TriggerDefinition,
) -> List[TriggerDefinition]:
    updated = [existing for existing in triggers if existing.id != trigger.id]
    updated.append(trigger)
    return updated


def _legacy_singleton_trigger_id(triggers: List[TriggerDefinition], trigger_type: str) -> str:
    """Id for a legacy poller/kafka/syslog config save.

    These endpoints edit the workflow's only trigger of that type, so they keep
    its id (run history and status are keyed by it) instead of appending a
    ``<type>-default`` sibling that the singleton check would reject.
    """
    existing = next((item for item in triggers if item.type == trigger_type), None)
    return existing.id if existing is not None and existing.id else default_trigger_id(trigger_type)


def _disable_legacy_trigger_of_type(
    workflow_id: str,
    trigger_type: str,
) -> tuple[Optional[str], Optional[Dict[str, Any]]]:
    now_ms = int(time.time() * 1000)
    if trigger_type == "kafka":
        return (
            _kafka_config_key(workflow_id),
            {"workflowId": workflow_id, "enabled": False, "updatedAt": now_ms},
        )
    if trigger_type == "schedule":
        return (
            f"workflow_poller_config/{workflow_id}",
            {"workflowId": workflow_id, "enabled": False, "updatedAt": now_ms},
        )
    if trigger_type == "syslog":
        return (
            _syslog_config_key(workflow_id),
            {"workflowId": workflow_id, "enabled": False, "updatedAt": now_ms},
        )
    return None, None


async def _sync_trigger_legacy_state(workflow_id: str, trigger: TriggerDefinition) -> Optional[Dict[str, Any]]:
    if trigger.type == "kafka":
        config = kafka_trigger_to_legacy_config(workflow_id, trigger)
        await WorkflowStore.put_config(workflow_id, config, kind="workflow_kafka_config")
        from flocks.ingest.kafka.manager import default_manager as _kafka_default_manager

        return await _kafka_default_manager.restart_workflow(workflow_id)
    if trigger.type == "schedule":
        config = schedule_trigger_to_legacy_config(workflow_id, trigger)
        await WorkflowStore.put_config(workflow_id, config, kind="workflow_poller_config")
        from flocks.workflow.poller_manager import default_manager as _poller_default_manager

        return await _poller_default_manager.restart_workflow(workflow_id)
    if trigger.type == "syslog":
        config = syslog_trigger_to_legacy_config(workflow_id, trigger)
        await WorkflowStore.put_config(workflow_id, config, kind="workflow_syslog_config")
        from flocks.ingest.syslog.manager import default_manager as _syslog_default_manager

        return await _syslog_default_manager.restart_workflow(workflow_id)
    return await default_trigger_runtime.get_trigger_status(workflow_id, trigger)


async def _remove_legacy_trigger_state(workflow_id: str, trigger: TriggerDefinition) -> None:
    """Remove legacy trigger configs so deleted unified triggers do not reappear."""
    if trigger.type == "kafka":
        try:
            from flocks.ingest.kafka.manager import default_manager as _kafka_default_manager

            await _kafka_default_manager.stop_workflow(workflow_id)
        except Exception:
            pass
        await WorkflowStore.delete_config(workflow_id, kind="workflow_kafka_config")
        return
    if trigger.type == "schedule":
        try:
            from flocks.workflow.poller_manager import default_manager as _poller_default_manager

            await _poller_default_manager.stop_workflow(workflow_id)
        except Exception:
            pass
        await WorkflowStore.delete_config(workflow_id, kind="workflow_poller_config")
        return
    if trigger.type == "syslog":
        try:
            from flocks.ingest.syslog.manager import default_manager as _syslog_default_manager

            await _syslog_default_manager.stop_workflow(workflow_id)
        except Exception:
            pass
        await WorkflowStore.delete_config(workflow_id, kind="workflow_syslog_config")


async def _persist_workflow_triggers(
    workflow_id: str,
    workflow_data: Dict[str, Any],
    triggers: List[TriggerDefinition],
) -> Dict[str, Any]:
    workflow_json = workflow_data.get("workflowJson") or {}
    updated_json = set_workflow_json_triggers(workflow_json, triggers)
    if any(trigger.enabled for trigger in triggers):
        try:
            validate_workflow_python(Workflow.from_dict(updated_json))
        except Exception as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
    data = dict(workflow_data)
    data["workflowJson"] = updated_json
    data["updatedAt"] = int(time.time() * 1000)
    is_global = data.get("source") == "global"
    _write_workflow_to_fs(
        workflow_id,
        updated_json,
        data,
        data.get("markdownContent"),
        global_store=is_global,
    )
    return data


async def _run_workflow_execution_task(
    *,
    workflow_id: str,
    workflow_json: Dict[str, Any],
    req: WorkflowRunRequest,
    exec_id: str,
    cancel_event: threading.Event,
    progress_writer: ExecutionProgressWriter,
    tool_context: Optional[ToolContext] = None,
) -> None:
    """Execute a workflow in the background and keep the execution record updated."""
    start_time = time.time()
    step_recorder = ExecutionStepRecorder()
    pending_step_index: Optional[int] = None
    pending_step: Optional[Dict[str, Any]] = None
    execution_summary: Dict[str, Any] = {
        "id": exec_id,
        "workflowId": workflow_id,
        "inputParams": compact_outputs_for_storage(req.inputs or {}),
        "status": "running",
        "startedAt": int(start_time * 1000),
        "executionLog": [],
        "currentPhase": "queued",
        "currentStepIndex": 0,
        "stepCount": 0,
    }
    if req.session_id or req.message_id:
        execution_summary.update(
            {
                "sessionId": req.session_id,
                "messageId": req.message_id,
                "agent": req.agent,
            }
        )

    def _on_step_start(_run_id, step_index, node, _inputs):
        nonlocal pending_step_index, pending_step
        node_id = getattr(node, "id", None)
        node_type = getattr(node, "type", None)
        loop_progress = derive_loop_progress(
            node_id=node_id,
            global_step_index=step_index,
            inputs=_inputs,
            outputs=None,
        )
        pending_step_index = step_index
        pending_step = compact_step_for_storage(
            {
                "node_id": node_id,
                "node_type": node_type,
                "inputs": _inputs if isinstance(_inputs, dict) else {},
                "outputs": {},
                "error": "Run cancelled before node completed",
            }
        )
        progress_update = {
            "currentNodeId": node_id,
            "currentNodeType": node_type,
            "currentPhase": "cancelling" if cancel_event.is_set() else "running",
            "currentStepIndex": step_index,
            "loopProgress": loop_progress,
            "updatedAt": int(time.time() * 1000),
        }
        execution_summary.update(progress_update)
        progress_writer.submit(progress_update)
        return step_index

    def _on_step_complete(step_result) -> None:
        nonlocal pending_step_index, pending_step
        step_recorder.on_step_complete(step_result)
        pending_step_index = None
        pending_step = None
        progress_update = dict(step_recorder.summary)
        if cancel_event.is_set():
            progress_update["currentPhase"] = "cancelling"
        execution_summary.update(progress_update)
        progress_writer.submit(progress_update)

    result: Optional[RunWorkflowResult] = None
    execution_error: Optional[Exception] = None
    try:
        try:
            # The worker thread's tool calls must hop back onto this server
            # loop (channels bound to it stay usable); see
            # flocks.workflow._async_runtime.register_primary_loop.
            register_primary_loop()
            result = await asyncio.to_thread(
                run_workflow,
                workflow=workflow_json,
                inputs=req.inputs or {},
                timeout_s=req.timeout_s,
                trace=req.trace,
                on_step_start=_on_step_start,
                on_step_complete=_on_step_complete,
                cancel=lambda: cancel_event.is_set() or execution_cancelled(exec_id),
                tool_context=tool_context,
            )
        except Exception as exc:
            execution_error = exc

        duration = time.time() - start_time
        current_data = dict(execution_summary)
        final_step_batch = step_recorder.take_steps()
        if pending_step_index is not None and pending_step is not None:
            final_step_batch.append((pending_step_index, pending_step))
        final_step_batch.sort(key=lambda item: item[0])
        final_steps = max(
            max((step_index for step_index, _ in final_step_batch), default=0),
            pending_step_index or 0,
        )
        final_history = [step for _, step in final_step_batch]

        if execution_error is None:
            assert result is not None
            status_value, error_message = _resolve_execution_outcome(result)
            if cancel_event.is_set() and status_value == "success":
                status_value = "cancelled"
                error_message = error_message or f"Run cancelled: run_id={result.run_id or exec_id}"
            final_steps = max(result.steps, final_steps)
            current_data.update(
                {
                    "outputResults": compact_outputs_for_storage(result.outputs),
                    "status": status_value,
                    "finishedAt": int(time.time() * 1000),
                    "duration": duration,
                    "executionLog": final_history,
                    "stepCount": final_steps,
                    "errorMessage": error_message,
                    "currentNodeId": result.last_node_id,
                    "currentNodeType": current_data.get("currentNodeType"),
                    "currentPhase": status_value,
                    "currentStepIndex": final_steps,
                    "updatedAt": int(time.time() * 1000),
                }
            )
        else:
            current_data.update(
                {
                    "status": "cancelled" if cancel_event.is_set() else "error",
                    "finishedAt": int(time.time() * 1000),
                    "duration": duration,
                    "errorMessage": f"{type(execution_error).__name__}: {execution_error}",
                    "executionLog": final_history,
                    "stepCount": final_steps,
                    "currentPhase": "cancelled" if cancel_event.is_set() else "error",
                    "currentStepIndex": final_steps,
                    "updatedAt": int(time.time() * 1000),
                }
            )

        await progress_writer.close_and_drain()
        await _record_execution_result(
            workflow_id,
            exec_id,
            current_data,
            steps=final_step_batch,
        )
        if execution_error is None:
            log.info(
                "workflow.executed",
                {
                    "id": workflow_id,
                    "exec_id": exec_id,
                    "status": current_data["status"],
                    "duration": duration,
                },
            )
        else:
            log.error(
                "workflow.execute.error",
                {
                    "id": workflow_id,
                    "exec_id": exec_id,
                    "error": str(execution_error),
                },
            )
    finally:
        cancel_event.set()
        await abandon_execution(exec_id)
        _active_workflow_executions.pop(exec_id, None)


_DEFAULT_STATS: Dict[str, Any] = {
    "callCount": 0,
    "successCount": 0,
    "errorCount": 0,
    "totalRuntime": 0.0,
    "avgRuntime": 0.0,
    "thumbsUp": 0,
    "thumbsDown": 0,
}


def _compute_avg_runtime(stats: Dict[str, Any]) -> Dict[str, Any]:
    """Ensure avgRuntime is computed and present in stats dict."""
    call_count = stats.get("callCount", 0)
    total = stats.get("totalRuntime", 0.0)
    stats["avgRuntime"] = (total / call_count) if call_count > 0 else 0.0
    return stats


async def _get_workflow_stats(workflow_id: str) -> Dict[str, Any]:
    """Get workflow statistics"""
    try:
        data = await WorkflowStore.get_stats(workflow_id)
        if data is None:
            return dict(_DEFAULT_STATS)
        return _compute_avg_runtime(data)
    except Exception:
        return dict(_DEFAULT_STATS)


# =============================================================================
# API Endpoints - Workflow CRUD
# =============================================================================


def _filter_workflow_list_data(
    all_data: List[Dict[str, Any]],
    *,
    category: Optional[str],
    status: Optional[str],
    exclude_id: Optional[str],
) -> List[Dict[str, Any]]:
    return [
        data
        for data in all_data
        if not category or data.get("category") == category
        if not status or data.get("status") == status
        if not exclude_id or data.get("id") != exclude_id
    ]


@router.get("/workflow", response_model=List[WorkflowResponse])
async def list_workflows(
    category: Optional[str] = Query(None, description="Filter by category"),
    status: Optional[str] = Query(None, description="Filter by status"),
    exclude_id: Optional[str] = Query(
        None, alias="excludeId", description="Exclude workflow by ID (e.g. exclude self when selecting sub-workflows)"
    ),
):
    """
    Get workflow list

    Reads directly from the filesystem (.flocks/workflow/). Runs a one-time
    migration on first call to move any Storage-only workflows to the filesystem.
    """
    try:
        await _migrate_storage_to_filesystem()

        filtered_data = _filter_workflow_list_data(
            _list_workflows_from_fs(),
            category=category,
            status=status,
            exclude_id=exclude_id,
        )

        semaphore = asyncio.Semaphore(_WORKFLOW_LIST_ENRICH_CONCURRENCY)

        async def enrich_workflow(data: Dict[str, Any]) -> Optional[WorkflowResponse]:
            try:
                async with semaphore:
                    workflow_id = data["id"]
                    stats = await _get_workflow_stats(workflow_id)
                enriched_data = {
                    **data,
                    "stats": stats,
                }
                return WorkflowResponse(**enriched_data)
            except Exception as e:
                log.warning("workflow.list.skip", {"id": data.get("id"), "error": str(e)})
                return None

        enriched = await asyncio.gather(*(enrich_workflow(data) for data in filtered_data))
        workflows = [workflow for workflow in enriched if workflow is not None]

        workflows.sort(key=lambda w: w.updatedAt, reverse=True)

        log.info(
            "workflow.list", {"count": len(workflows), "category": category, "status": status, "exclude_id": exclude_id}
        )
        return workflows
    except Exception as e:
        log.error("workflow.list.error", {"error": str(e)})
        raise HTTPException(status_code=500, detail=f"Failed to list workflows: {str(e)}")


@router.get("/workflow-summaries", response_model=List[WorkflowSummaryResponse])
async def list_workflow_summaries(
    category: Optional[str] = Query(None, description="Filter by category"),
    status: Optional[str] = Query(None, description="Filter by status"),
    exclude_id: Optional[str] = Query(None, alias="excludeId", description="Exclude workflow by ID"),
):
    """Return lightweight workflow card data with cached integration states."""
    try:
        await _migrate_storage_to_filesystem()
        filtered_data = _filter_workflow_list_data(
            _list_workflows_from_fs(),
            category=category,
            status=status,
            exclude_id=exclude_id,
        )
        semaphore = asyncio.Semaphore(_WORKFLOW_LIST_ENRICH_CONCURRENCY)

        async def build_summary(data: Dict[str, Any]) -> Optional[WorkflowSummaryResponse]:
            try:
                async with semaphore:
                    workflow_id = data["id"]
                    stats, integration_status = await asyncio.gather(
                        _get_workflow_stats(workflow_id),
                        _get_workflow_integration_status(workflow_id, data),
                    )
                workflow_json = data.get("workflowJson") or {}
                nodes = workflow_json.get("nodes") if isinstance(workflow_json, dict) else []
                return WorkflowSummaryResponse(
                    id=workflow_id,
                    name=data.get("name") or workflow_id,
                    group=data.get("group"),
                    group_readonly=data.get("group_readonly", False),
                    nameI18n=data.get("nameI18n"),
                    description=data.get("description"),
                    category=data.get("category") or "default",
                    status=data.get("status") or "draft",
                    source=data.get("source"),
                    createdAt=int(data.get("createdAt") or 0),
                    updatedAt=int(data.get("updatedAt") or 0),
                    nodeCount=len(nodes) if isinstance(nodes, list) else 0,
                    definitionError=data.get("definitionError"),
                    stats=stats,
                    integrationStatus=integration_status,
                )
            except Exception as exc:
                log.warning("workflow.summary.skip", {"id": data.get("id"), "error": str(exc)})
                return None

        enriched = await asyncio.gather(*(build_summary(data) for data in filtered_data))
        summaries = [summary for summary in enriched if summary is not None]
        summaries.sort(key=lambda item: item.updatedAt, reverse=True)
        return summaries
    except Exception as exc:
        log.error("workflow.summary.error", {"error": str(exc)})
        raise HTTPException(status_code=500, detail=f"Failed to list workflow summaries: {str(exc)}")


@router.post("/workflow", response_model=WorkflowResponse, status_code=status.HTTP_201_CREATED)
async def create_workflow(req: WorkflowCreateRequest):
    """
    Create a new workflow

    Validates the workflow JSON and writes it to the filesystem as the source
    of truth. Stats are initialised in Storage on first access.
    """
    try:
        workflow_json = _apply_new_workflow_runtime_defaults(req.workflow_json)
        try:
            group = normalize_workflow_group(
                req.group if "group" in req.model_fields_set else workflow_json["metadata"].get("group")
            )
            workflow_json["metadata"].pop("group", None)
            workflow_model = Workflow.from_dict(workflow_json)
            validate_workflow_python(workflow_model)
        except Exception as e:
            raise HTTPException(status_code=400, detail=f"Invalid workflow JSON: {str(e)}")
        strict_mapping_errors = _strict_edge_mapping_lint_errors(workflow_model)
        if strict_mapping_errors:
            raise HTTPException(
                status_code=400,
                detail=(f"Workflow strict edge mapping failed: {strict_mapping_errors[:5]}"),
            )
        schema_errors = _schema_lint_errors(workflow_model)
        if schema_errors:
            raise HTTPException(
                status_code=400,
                detail=(f"Workflow schema lint failed: {schema_errors[:5]}"),
            )

        workflow_id = str(uuid.uuid4())
        now_ms = int(time.time() * 1000)

        source = req.source or "global"
        meta = {
            "id": workflow_id,
            "name": req.name,
            "group": group,
            "nameI18n": req.name_i18n,
            "description": req.description,
            "category": req.category or "default",
            "status": "draft",
            "createdBy": req.created_by,
            "createdAt": now_ms,
            "updatedAt": now_ms,
        }

        _write_workflow_to_fs(workflow_id, workflow_json, meta, global_store=(source == "global"))

        stats = await _get_workflow_stats(workflow_id)
        data = {
            **meta,
            "workflowJson": workflow_json,
            "markdownContent": None,
            "editMarkdownContent": None,
            "stats": stats,
            "source": source,
        }

        log.info("workflow.created", {"id": workflow_id, "name": req.name})
        await publish_event("workflow.created", {"id": workflow_id, "name": req.name})
        return WorkflowResponse(**data)
    except HTTPException:
        raise
    except Exception as e:
        log.error("workflow.create.error", {"error": str(e)})
        raise HTTPException(status_code=500, detail=f"Failed to create workflow: {str(e)}")


# Stays above GET /workflow/{workflow_id}: routes match in registration
# order, so a later /workflow/stats would be read as a workflow ID.
@router.get("/workflow/stats", response_model=WorkflowStatsResponse)
async def get_aggregate_stats():
    """
    Get aggregate workflow statistics

    Returns statistics across all workflows.
    """
    try:
        aggregate = {
            "workflowId": None,
            "callCount": 0,
            "successCount": 0,
            "errorCount": 0,
            "totalRuntime": 0.0,
            "avgRuntime": 0.0,
            "thumbsUp": 0,
            "thumbsDown": 0,
        }

        all_workflows = _list_workflows_from_fs()
        workflow_count = 0
        for wf in all_workflows:
            try:
                stats = await _get_workflow_stats(wf["id"])
                aggregate["callCount"] += stats.get("callCount", 0)
                aggregate["successCount"] += stats.get("successCount", 0)
                aggregate["errorCount"] += stats.get("errorCount", 0)
                aggregate["totalRuntime"] += stats.get("totalRuntime", 0.0)
                aggregate["thumbsUp"] += stats.get("thumbsUp", 0)
                aggregate["thumbsDown"] += stats.get("thumbsDown", 0)
                workflow_count += 1
            except Exception:
                continue

        if aggregate["callCount"] > 0:
            aggregate["avgRuntime"] = aggregate["totalRuntime"] / aggregate["callCount"]

        log.info("workflow.stats.aggregate", {"workflows": workflow_count})
        return WorkflowStatsResponse(**aggregate)
    except Exception as e:
        log.error("workflow.stats.error", {"error": str(e)})
        raise HTTPException(status_code=500, detail=f"Failed to get statistics: {str(e)}")


@router.get("/workflow/{workflow_id}", response_model=WorkflowResponse)
async def get_workflow(workflow_id: str):
    """
    Get workflow details

    Reads directly from the filesystem. AI edits to workflow.json or workflow.md
    are always reflected immediately without any sync step.
    """
    try:
        data = shared_read_workflow_from_fs(workflow_id, include_errors=True)
        if not data:
            raise HTTPException(status_code=404, detail=f"Workflow not found: {workflow_id}")

        stats = await _get_workflow_stats(workflow_id)
        data["stats"] = stats

        return WorkflowResponse(**data)
    except HTTPException:
        raise
    except Exception as e:
        log.error("workflow.get.error", {"id": workflow_id, "error": str(e)})
        raise HTTPException(status_code=500, detail=f"Failed to get workflow: {str(e)}")


class WorkflowRestoreRequest(BaseModel):
    file: Literal["workflow.json", "meta.json"] = "workflow.json"


@router.post("/workflow/{workflow_id}/restore", response_model=WorkflowResponse)
async def restore_workflow_definition(workflow_id: str, req: WorkflowRestoreRequest):
    """Explicitly restore the previous readable definition; never auto-run it."""
    from flocks.tool import nofollow
    from flocks.workflow.definition_io import WorkflowDefinitionError

    _refuse_managed_workflow_change(workflow_id)
    selected = resolve_workflow_from_fs(workflow_id)
    if selected is None:
        raise HTTPException(status_code=404, detail=f"Workflow not found: {workflow_id}")
    wf_dir, data = selected
    issue = data.get("definitionError")
    if not issue or issue["file"] != req.file:
        raise HTTPException(status_code=409, detail="Workflow definition changed or is already valid; reload before restoring")
    path = wf_dir / req.file
    try:
        backup = nofollow.read_text(str(path) + ".last-valid")
        if backup is None:
            raise HTTPException(status_code=404, detail="No valid workflow backup is available")
        write_definition(path, backup.text, before=nofollow.read_text(str(path)), validate_graph=True)
    except WorkflowDefinitionError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except (nofollow.StaleFile, nofollow.LinkOnTheWay, FileNotFoundError) as exc:
        raise HTTPException(status_code=409, detail="Workflow changed; reload before restoring") from exc
    log.info("workflow.definition.restored", {"id": workflow_id, "file": req.file})
    await publish_event("workflow.updated", {"id": workflow_id})
    return await get_workflow(workflow_id)


@router.put("/workflow/{workflow_id}", response_model=WorkflowResponse)
async def update_workflow(workflow_id: str, req: WorkflowUpdateRequest):
    """
    Update workflow

    Reads from the filesystem, applies changes, and writes back to the selected
    native directory. Metadata-only updates touch only meta.json, so organizing
    a Markdown draft never creates an executable workflow.json.
    """
    try:
        _refuse_managed_workflow_change(workflow_id)
        selected = resolve_workflow_from_fs(workflow_id)
        if selected is None:
            raise HTTPException(status_code=404, detail=f"Workflow not found: {workflow_id}")
        wf_dir, data = selected
        if data.get("definitionError") and req.workflow_json is None:
            raise HTTPException(status_code=422, detail=data["definitionError"]["message"])

        # Guard both edit surfaces before writing metadata, graph, or Markdown.
        if data["group_readonly"]:
            fixed_group = normalize_workflow_group(data.get("group"))
            transport = (req.workflow_json or {}).get("metadata")
            group_updates = []
            if "group" in req.model_fields_set:
                group_updates.append(req.group)
            if isinstance(transport, dict) and "group" in transport:
                group_updates.append(transport["group"])
            for group in group_updates:
                try:
                    unchanged = normalize_workflow_group(group) == fixed_group
                except ValueError:
                    unchanged = False
                if not unchanged:
                    raise HTTPException(status_code=403, detail="System workflow group is read-only")

        workflow_json = data["workflowJson"]
        markdown_content = data.get("markdownContent")

        if "group" in req.model_fields_set:
            data["group"] = req.group
        if req.name is not None:
            data["name"] = req.name
        if req.name_i18n is not None:
            data["nameI18n"] = req.name_i18n
        if req.description is not None:
            data["description"] = req.description
        if req.category is not None:
            data["category"] = req.category
        if req.status is not None:
            data["status"] = req.status
        if req.workflow_json is not None:
            try:
                # Lint and save the merged definition, not the bare request body.
                incoming_json = _inherit_saved_workflow_metadata(req.workflow_json, workflow_json)
                workflow_model = Workflow.from_dict(incoming_json)
                validate_workflow_python(workflow_model)
                strict_mapping_errors = _strict_edge_mapping_lint_errors(workflow_model)
                if strict_mapping_errors:
                    raise HTTPException(
                        status_code=400,
                        detail=(f"Workflow strict edge mapping failed: {strict_mapping_errors[:5]}"),
                    )
                schema_errors = _schema_lint_errors(workflow_model)
                if schema_errors:
                    raise HTTPException(
                        status_code=400,
                        detail=(f"Workflow schema lint failed: {schema_errors[:5]}"),
                    )
                workflow_json = incoming_json
                if isinstance(workflow_json.get("metadata"), dict):
                    workflow_json["metadata"] = dict(workflow_json["metadata"])
                    workflow_json["metadata"].pop("group", None)
            except Exception as e:
                if isinstance(e, HTTPException):
                    raise
                raise HTTPException(status_code=400, detail=f"Invalid workflow JSON: {str(e)}")
        if req.markdown_content is not None:
            markdown_content = req.markdown_content
        elif req.edit_markdown_content is not None:
            markdown_content = req.edit_markdown_content
        if req.status == "active" and req.workflow_json is None:
            try:
                validate_workflow_python(Workflow.from_dict(workflow_json))
            except Exception as exc:
                raise HTTPException(status_code=400, detail=str(exc)) from exc
        data.pop("definitionError", None)
        data["updatedAt"] = int(time.time() * 1000)

        if req.workflow_json is None and req.markdown_content is None and req.edit_markdown_content is None:
            metadata_updates = req.model_dump(
                include={"group", "name", "name_i18n", "description", "category", "status"},
                exclude_unset=True,
                exclude_none=True,
                by_alias=True,
            )
            metadata_updates["updatedAt"] = data["updatedAt"]
            patch_workflow_metadata(wf_dir, metadata_updates, workflow_data=data)
        else:
            _write_workflow_to_fs(
                workflow_id,
                workflow_json,
                data,
                markdown_content,
                target_dir=wf_dir,
            )

        stats = await _get_workflow_stats(workflow_id)
        data["workflowJson"] = workflow_json
        data["markdownContent"] = markdown_content
        data["editMarkdownContent"] = markdown_content
        data["stats"] = stats

        log.info("workflow.updated", {"id": workflow_id})
        await publish_event("workflow.updated", {"id": workflow_id, "name": data.get("name")})
        return WorkflowResponse(**data)
    except HTTPException:
        raise
    except Exception as e:
        log.error("workflow.update.error", {"id": workflow_id, "error": str(e)})
        raise HTTPException(status_code=500, detail=f"Failed to update workflow: {str(e)}")


@router.delete("/workflow/{workflow_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_workflow(workflow_id: str):
    """
    Delete workflow

    Removes the workflow directory from the filesystem (source of truth) and
    cleans up associated runtime data (stats, execution history) from Storage.
    """
    try:
        data = _read_workflow_from_fs(workflow_id)
        if not data:
            raise HTTPException(status_code=404, detail=f"Workflow not found: {workflow_id}")
        _refuse_managed_workflow_change(workflow_id)

        # Stop runtime resources before removing the filesystem source of truth.
        await _stop_workflow_runtime_resources(workflow_id)

        # Remove from filesystem (source of truth)
        _delete_workflow_from_fs(workflow_id)

        from flocks.hub import local as hub_local

        try:
            hub_local.remove_installed_record("workflow", workflow_id)
        except Exception as exc:
            log.warning("workflow.delete.hub_record_remove_failed", {"id": workflow_id, "error": str(exc)})

        await _cleanup_workflow_storage(workflow_id)

        log.info("workflow.deleted", {"id": workflow_id})
        await publish_event("workflow.deleted", {"id": workflow_id})
        return None
    except HTTPException:
        raise
    except Exception as e:
        log.error("workflow.delete.error", {"id": workflow_id, "error": str(e)})
        raise HTTPException(status_code=500, detail=f"Failed to delete workflow: {str(e)}")


# =============================================================================
# API Endpoints - Workflow Operations
# =============================================================================


@router.post("/workflow/{workflow_id}/run", response_model=WorkflowExecutionResponse)
async def run_workflow_endpoint(workflow_id: str, req: WorkflowRunRequest):
    """
    Execute workflow

    Runs the workflow with provided inputs and returns execution results.
    """
    exec_id: Optional[str] = None
    dispatched = False
    try:
        data = _read_workflow_from_fs(workflow_id)
        if not data:
            raise HTTPException(status_code=404, detail=f"Workflow not found: {workflow_id}")

        workflow_json = data["workflowJson"]
        try:
            validate_workflow_python(Workflow.from_dict(workflow_json))
        except Exception as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        tool_context = await _build_workflow_tool_context(
            workflow_id=workflow_id,
            action_name="run",
            session_id=req.session_id,
            message_id=req.message_id,
            agent=req.agent,
        )

        exec_data = await create_execution_record(
            workflow_id,
            input_params=req.inputs or {},
        )
        exec_id = str(exec_data["id"])
        if req.session_id or req.message_id:
            exec_data.update(
                {
                    "sessionId": req.session_id,
                    "messageId": req.message_id,
                    "agent": req.agent,
                    "updatedAt": int(time.time() * 1000),
                }
            )
            await WorkflowStore.upsert_execution(compact_execution_summary(exec_data))
        progress_writer = ExecutionProgressWriter(exec_data)

        cancel_event = threading.Event()
        task = asyncio.create_task(
            _run_workflow_execution_task(
                workflow_id=workflow_id,
                workflow_json=workflow_json,
                req=req,
                exec_id=exec_id,
                cancel_event=cancel_event,
                progress_writer=progress_writer,
                tool_context=tool_context,
            ),
            name=f"workflow-run-{exec_id}",
        )
        _active_workflow_executions[exec_id] = ActiveWorkflowExecution(
            workflow_id=workflow_id,
            task=task,
            cancel_event=cancel_event,
            progress_writer=progress_writer,
        )

        # Guarantee cleanup of the registry entry even when the task is
        # cancelled or fails before reaching its own ``finally`` block (e.g.
        # if the event loop is shutting down).  This prevents the ``Active*``
        # map from growing forever when tasks are abandoned.
        def _cleanup_active(_t: asyncio.Task, _eid: str = exec_id) -> None:
            _active_workflow_executions.pop(_eid, None)
            # A task cancelled before its first step never enters the runner's
            # finally block: end its record instead of leaving it running.
            asyncio.create_task(abandon_execution(_eid), name=f"workflow-release-{_eid}")

        task.add_done_callback(_cleanup_active)
        dispatched = True

        log.info(
            "workflow.execution.started",
            {
                "id": workflow_id,
                "exec_id": exec_id,
            },
        )
        return WorkflowExecutionResponse(**exec_data)
    except HTTPException:
        raise
    except SessionAgentMismatchError as exc:
        # The requested session is dedicated to another agent.
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    except Exception as e:
        log.error("workflow.run.error", {"id": workflow_id, "error": str(e)})
        raise HTTPException(status_code=500, detail=f"Failed to run workflow: {str(e)}")
    finally:
        if exec_id is not None and not dispatched:
            await abandon_execution(exec_id)


@router.post("/workflow/{workflow_id}/history/{exec_id}/cancel")
async def cancel_workflow_execution(workflow_id: str, exec_id: str):
    """Request cooperative cancellation of a running workflow execution."""
    try:
        exec_data = await WorkflowStore.get_execution(exec_id)
        if not exec_data:
            raise HTTPException(status_code=404, detail=f"Execution not found: {exec_id}")
        if exec_data.get("workflowId") != workflow_id:
            raise HTTPException(status_code=404, detail="Execution not found for this workflow")

        active = _active_workflow_executions.get(exec_id)
        if active is None:
            if exec_data.get("status") == "running" and await WorkflowStore.request_execution_cancel(exec_id):
                return {
                    "status": "accepted", "message": "Cancellation sent to the execution owner",
                    "executionId": exec_id,
                }
            return {
                "status": "ignored",
                "message": f"Execution {exec_id} is already {exec_data.get('status', 'completed')}",
                "executionId": exec_id,
            }

        if active.workflow_id != workflow_id:
            raise HTTPException(status_code=404, detail="Execution not found for this workflow")

        active.cancel_event.set()
        progress_update = {
            "currentPhase": "cancelling",
            "errorMessage": exec_data.get("errorMessage") or "Cancellation requested",
            "updatedAt": int(time.time() * 1000),
        }
        exec_data.update(progress_update)
        await active.progress_writer.update(progress_update)
        log.info(
            "workflow.execution.cancel_requested",
            {
                "id": workflow_id,
                "exec_id": exec_id,
            },
        )
        return {
            "status": "accepted",
            "message": f"Cancellation requested for execution {exec_id}",
            "executionId": exec_id,
        }
    except HTTPException:
        raise
    except Exception as e:
        log.error(
            "workflow.execution.cancel.error",
            {
                "id": workflow_id,
                "exec_id": exec_id,
                "error": str(e),
            },
        )
        raise HTTPException(status_code=500, detail=f"Failed to cancel execution: {str(e)}")


@router.post("/workflow/{workflow_id}/validate")
async def validate_workflow(workflow_id: str):
    """
    Validate workflow

    Lints the workflow and returns validation errors/warnings.
    """
    try:
        data = _read_workflow_from_fs(workflow_id)
        if not data:
            raise HTTPException(status_code=404, detail=f"Workflow not found: {workflow_id}")

        workflow_json = data["workflowJson"]

        try:
            workflow = Workflow.from_dict(workflow_json)
            # Run lint checks (errors + warnings)
            lint_results = lint_workflow(workflow)
            lint_errors = [r for r in lint_results if r.get("severity") == "error"]

            log.info("workflow.validated", {"id": workflow_id, "issues": len(lint_results), "errors": len(lint_errors)})
            return {
                "valid": len(lint_errors) == 0,
                "issues": lint_results,
            }
        except Exception as e:
            return {
                "valid": False,
                "issues": [{"type": "error", "message": str(e)}],
            }
    except HTTPException:
        raise
    except Exception as e:
        log.error("workflow.validate.error", {"id": workflow_id, "error": str(e)})
        raise HTTPException(status_code=500, detail=f"Failed to validate workflow: {str(e)}")


# =============================================================================
# API Endpoints - Workflow Center (Skill -> Register -> Publish Service)
# =============================================================================


@router.post("/workflow-center/scan-workflows")
async def workflow_center_scan_workflows():
    """Scan .flocks/workflow and register discovered workflows."""
    try:
        items = await scan_skill_workflows()
        return {"count": len(items), "items": items}
    except Exception as e:
        log.error("workflow.center.scan.error", {"error": str(e)})
        raise HTTPException(status_code=500, detail=f"Failed to scan skill workflows: {str(e)}")


@router.post("/workflow-center/scan-skill", deprecated=True)
async def workflow_center_scan_skill_alias():
    """Backward-compatible alias for scan-workflows."""
    return await workflow_center_scan_workflows()


@router.get("/workflow-center")
async def workflow_center_list():
    """List workflow center registry entries."""
    try:
        items = await list_registry_entries()
        return {"count": len(items), "items": items}
    except Exception as e:
        log.error("workflow.center.list.error", {"error": str(e)})
        raise HTTPException(status_code=500, detail=f"Failed to list workflow center entries: {str(e)}")


@router.post("/workflow-center/{workflow_id}/publish")
async def workflow_center_publish(workflow_id: str, req: Optional[WorkflowCenterPublishRequest] = None):
    """Publish workflow as an API service."""
    try:
        result = await publish_workflow(
            workflow_id,
            image=req.image if req else None,
            driver=req.driver if req else None,
            port=req.port if req else None,
        )
        return result
    except WorkflowNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except WorkflowCenterError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        log.error("workflow.center.publish.error", {"workflow_id": workflow_id, "error": str(e)})
        raise HTTPException(status_code=500, detail=f"Failed to publish workflow: {str(e)}")


@router.post("/workflow-center/{workflow_id}/stop")
async def workflow_center_stop(workflow_id: str):
    """Stop published workflow docker service."""
    try:
        result = await stop_workflow_service(workflow_id)
        return result
    except WorkflowNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except WorkflowCenterError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        log.error("workflow.center.stop.error", {"workflow_id": workflow_id, "error": str(e)})
        raise HTTPException(status_code=500, detail=f"Failed to stop workflow service: {str(e)}")


@router.post("/workflow-center/{workflow_id}/invoke")
async def workflow_center_invoke(workflow_id: str, req: WorkflowCenterInvokeRequest):
    """Proxy invoke request to active published workflow service.

    Also records execution stats (callCount / successCount / errorCount) so
    that the UI invocation counter is updated for every published-service call,
    not just agent-driven /run calls.
    """
    started = time.time()
    exec_data = await create_execution_record(
        workflow_id,
        input_params=req.inputs or {},
    )
    exec_id = str(exec_data["id"])
    try:
        result = await invoke_published_workflow(
            workflow_id,
            inputs=req.inputs,
            timeout_s=req.timeout_s,
            request_id=req.request_id,
        )
        duration = time.time() - started
        raw_status = result.get("status", "SUCCEEDED") if isinstance(result, dict) else "SUCCEEDED"
        status_value = _normalize_execution_status(raw_status)
        success = status_value == "success"
        # workflow_center_invoke proxies to an external published service; no
        # step callbacks run locally so executionLog stays as the empty list
        # set by create_execution_record.  We still run compact_history here
        # as a forward-compatible guard in case a future code path populates it.
        exec_data.update(
            {
                "outputResults": compact_outputs_for_storage(
                    result.get("outputs", {}) if isinstance(result, dict) else {}
                ),
                "executionLog": compact_history_for_storage(exec_data.get("executionLog")),
                "status": status_value,
                "finishedAt": int(time.time() * 1000),
                "duration": duration,
                "currentPhase": status_value,
            }
        )
        await _record_execution_result(workflow_id, exec_id, exec_data)
        return result
    except asyncio.CancelledError:
        await abandon_execution(exec_id)
        raise
    except (WorkflowNotFoundError, WorkflowNotPublishedError) as e:
        duration = time.time() - started
        exec_data.update(
            {"status": "error", "finishedAt": int(time.time() * 1000), "duration": duration, "errorMessage": str(e)}
        )
        await _record_execution_result(workflow_id, exec_id, exec_data)
        raise HTTPException(status_code=404, detail=str(e))
    except WorkflowCenterError as e:
        duration = time.time() - started
        exec_data.update(
            {"status": "error", "finishedAt": int(time.time() * 1000), "duration": duration, "errorMessage": str(e)}
        )
        await _record_execution_result(workflow_id, exec_id, exec_data)
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        duration = time.time() - started
        exec_data.update(
            {"status": "error", "finishedAt": int(time.time() * 1000), "duration": duration, "errorMessage": str(e)}
        )
        await _record_execution_result(workflow_id, exec_id, exec_data)
        log.error("workflow.center.invoke.error", {"workflow_id": workflow_id, "error": str(e)})
        raise HTTPException(status_code=500, detail=f"Failed to invoke workflow service: {str(e)}")


@router.get("/workflow-center/{workflow_id}/health")
async def workflow_center_health(workflow_id: str):
    """Get published workflow service health."""
    try:
        return await get_workflow_health(workflow_id)
    except WorkflowNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except WorkflowCenterError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        log.error("workflow.center.health.error", {"workflow_id": workflow_id, "error": str(e)})
        raise HTTPException(status_code=500, detail=f"Failed to get workflow health: {str(e)}")


@router.get("/workflow-center/{workflow_id}/releases")
async def workflow_center_releases(workflow_id: str):
    """List workflow release history."""
    try:
        items = await list_workflow_releases(workflow_id)
        return {"count": len(items), "items": items}
    except WorkflowNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except WorkflowCenterError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        log.error("workflow.center.releases.error", {"workflow_id": workflow_id, "error": str(e)})
        raise HTTPException(status_code=500, detail=f"Failed to list workflow releases: {str(e)}")


# =============================================================================
# API Endpoints - Workflow History
# =============================================================================


@router.get("/workflow/{workflow_id}/history", response_model=List[WorkflowExecutionResponse])
async def get_workflow_history(
    workflow_id: str,
    limit: int = Query(50, ge=1, le=100, description="Max results"),
    trigger_id: Optional[str] = Query(None, alias="triggerId"),
    trigger_type: Optional[str] = Query(None, alias="triggerType"),
):
    """
    Get workflow execution history

    Returns list of recent executions for this workflow.
    """
    try:
        data = _read_workflow_from_fs(workflow_id)
        if not data:
            raise HTTPException(status_code=404, detail=f"Workflow not found: {workflow_id}")

        # Keep the list endpoint on summary rows only.  Do not materialize
        # append-only step logs here; details load them separately.
        rows = await WorkflowStore.list_executions(
            workflow_id,
            limit=limit,
            trigger_id=trigger_id,
            trigger_type=trigger_type,
        )
        executions = []
        for exec_data in rows:
            item = dict(exec_data)
            item["executionLog"] = []
            executions.append(WorkflowExecutionResponse(**item))

        log.info("workflow.history", {"id": workflow_id, "count": len(executions)})
        return executions
    except HTTPException:
        raise
    except Exception as e:
        log.error("workflow.history.error", {"id": workflow_id, "error": str(e)})
        raise HTTPException(status_code=500, detail=f"Failed to get workflow history: {str(e)}")


@router.get("/workflow/{workflow_id}/history/{exec_id}", response_model=WorkflowExecutionResponse)
async def get_execution_details(
    workflow_id: str,
    exec_id: str,
    step_offset: int = Query(0, ge=0, alias="stepOffset"),
    step_limit: int = Query(500, ge=0, le=1000, alias="stepLimit"),
):
    """
    Get execution details

    Returns detailed information about a specific workflow execution.
    """
    try:
        exec_data = await WorkflowStore.get_execution(exec_id)
        if not exec_data:
            raise HTTPException(status_code=404, detail=f"Execution not found: {exec_id}")

        # Verify workflow ID matches
        if exec_data.get("workflowId") != workflow_id:
            raise HTTPException(status_code=404, detail="Execution not found for this workflow")

        if step_limit == 0:
            inline_log = exec_data.get("executionLog")
            inline_count = len(inline_log) if isinstance(inline_log, list) else 0
            steps, total_steps = [], exec_data.get("stepCount") or inline_count
        else:
            steps, total_steps = await load_execution_steps(
                exec_id,
                offset=step_offset,
                limit=step_limit,
            )
            if total_steps == 0:
                legacy_steps = compact_history_for_storage(exec_data.get("executionLog"))
                total_steps = len(legacy_steps)
                steps = legacy_steps[step_offset : step_offset + step_limit]
        exec_data = dict(exec_data)
        exec_data["executionLog"] = steps
        exec_data["stepLogOffset"] = step_offset
        exec_data["stepLogLimit"] = step_limit
        exec_data["stepLogTotal"] = total_steps
        exec_data["stepCount"] = exec_data.get("stepCount") or total_steps
        return WorkflowExecutionResponse(**exec_data)
    except HTTPException:
        raise
    except Exception as e:
        log.error("workflow.execution.get.error", {"id": exec_id, "error": str(e)})
        raise HTTPException(status_code=500, detail=f"Failed to get execution: {str(e)}")


# =============================================================================
# API Endpoints - Workflow Statistics
# =============================================================================


@router.get("/workflow/{workflow_id}/stats", response_model=WorkflowStatsResponse)
async def get_workflow_stats_endpoint(workflow_id: str):
    """
    Get workflow statistics

    Returns statistics for a specific workflow.
    """
    try:
        if not _read_workflow_from_fs(workflow_id):
            raise HTTPException(status_code=404, detail=f"Workflow not found: {workflow_id}")

        stats = await _get_workflow_stats(workflow_id)

        # Calculate average runtime
        avg_runtime = 0.0
        if stats["callCount"] > 0:
            avg_runtime = stats["totalRuntime"] / stats["callCount"]

        result = {
            "workflowId": workflow_id,
            "callCount": stats["callCount"],
            "successCount": stats["successCount"],
            "errorCount": stats["errorCount"],
            "totalRuntime": stats["totalRuntime"],
            "avgRuntime": avg_runtime,
            "thumbsUp": stats["thumbsUp"],
            "thumbsDown": stats["thumbsDown"],
        }

        return WorkflowStatsResponse(**result)
    except HTTPException:
        raise
    except Exception as e:
        log.error("workflow.stats.get.error", {"id": workflow_id, "error": str(e)})
        raise HTTPException(status_code=500, detail=f"Failed to get workflow statistics: {str(e)}")


# =============================================================================
# API Endpoints - Import/Export
# =============================================================================


@router.post("/workflow/import", response_model=WorkflowResponse, status_code=status.HTTP_201_CREATED)
async def import_workflow(workflow_json: Dict[str, Any]):
    """
    Import workflow

    Imports a workflow from a JSON definition and writes it to the filesystem.
    """
    try:
        try:
            workflow_model = Workflow.from_dict(workflow_json)
        except Exception as e:
            raise HTTPException(status_code=400, detail=f"Invalid workflow JSON: {str(e)}")
        strict_mapping_errors = _strict_edge_mapping_lint_errors(workflow_model)
        if strict_mapping_errors:
            raise HTTPException(
                status_code=400,
                detail=(
                    "Workflow strict edge mapping failed: "
                    f"{strict_mapping_errors[:5]}"
                ),
            )
        schema_errors = _schema_lint_errors(workflow_model)
        if schema_errors:
            raise HTTPException(
                status_code=400,
                detail=(
                    "Workflow schema lint failed: "
                    f"{schema_errors[:5]}"
                ),
            )

        workflow_json = dict(workflow_json)
        metadata = dict(workflow_json.get("metadata") or {})
        try:
            group = normalize_workflow_group(metadata.pop("group", None))
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc))
        workflow_json["metadata"] = metadata
        raw_name = workflow_json.get("name")
        # Same rule as create: a blank name falls back to the default one.
        name = raw_name if isinstance(raw_name, str) and raw_name.strip() else "Imported Workflow"
        description = metadata.get("description")
        category = metadata.get("category", "default")

        workflow_id = str(uuid.uuid4())
        now_ms = int(time.time() * 1000)

        meta = {
            "id": workflow_id,
            "name": name,
            "group": group,
            "description": description,
            "category": category,
            "status": "draft",
            "createdBy": None,
            "createdAt": now_ms,
            "updatedAt": now_ms,
        }

        _write_workflow_to_fs(workflow_id, workflow_json, meta, global_store=True)

        stats = await _get_workflow_stats(workflow_id)
        data = {
            **meta,
            "workflowJson": workflow_json,
            "markdownContent": None,
            "editMarkdownContent": None,
            "stats": stats,
            "source": "global",
        }

        log.info("workflow.imported", {"id": workflow_id, "name": name})
        await publish_event("workflow.created", {"id": workflow_id, "name": name})
        return WorkflowResponse(**data)
    except HTTPException:
        raise
    except Exception as e:
        log.error("workflow.import.error", {"error": str(e)})
        raise HTTPException(status_code=500, detail=f"Failed to import workflow: {str(e)}")


@router.get("/workflow/{workflow_id}/export")
async def export_workflow(workflow_id: str):
    """
    Export workflow

    Exports workflow as JSON for download/sharing.
    """
    try:
        data = _read_workflow_from_fs(workflow_id)
        if not data:
            raise HTTPException(status_code=404, detail=f"Workflow not found: {workflow_id}")

        workflow_json = dict(data["workflowJson"])
        workflow_json["metadata"] = dict(workflow_json.get("metadata") or {})
        workflow_json["metadata"]["group"] = normalize_workflow_group(data.get("group"))
        workflow_json["metadata"]["exportedFrom"] = "flocks"
        workflow_json["metadata"]["exportedAt"] = int(time.time() * 1000)
        workflow_json["name"] = data["name"]

        log.info("workflow.exported", {"id": workflow_id})
        return workflow_json
    except HTTPException:
        raise
    except Exception as e:
        log.error("workflow.export.error", {"id": workflow_id, "error": str(e)})
        raise HTTPException(status_code=500, detail=f"Failed to export workflow: {str(e)}")


# =============================================================================
# API Endpoints - Publish / API Service
# =============================================================================

_API_SERVICE_PREFIX = "workflow_api_service/"
_KAFKA_CONFIG_PREFIX = WORKFLOW_KAFKA_CONFIG_PREFIX
_REGISTRY_PREFIX_MAIN = "workflow_registry/"
_RUNTIME_PREFIX_MAIN = "workflow_runtime/"


def _api_service_key(workflow_id: str) -> str:
    return f"{_API_SERVICE_PREFIX}{workflow_id}"


def _runtime_key_main(workflow_id: str) -> str:
    return f"{_RUNTIME_PREFIX_MAIN}{workflow_id}"


def _workflow_id_from_api_service_key(key: Any) -> str:
    return str(key).removeprefix(_API_SERVICE_PREFIX)


def _kafka_config_key(workflow_id: str) -> str:
    return f"{_KAFKA_CONFIG_PREFIX}{workflow_id}"


async def _prepare_workflow_api_registry(workflow_id: str) -> tuple[Dict[str, Any], int]:
    """Write the current workflow snapshot to the workflow center registry."""
    # The snapshot is the definition on disk: never for a managed workflow.
    refuse_managed_workflow_write(workflow_id)
    data = _read_workflow_from_fs(workflow_id)
    if not data:
        raise WorkflowNotFoundError(f"Workflow not found: {workflow_id}")

    workflow_json = data["workflowJson"]
    service_dir = Config.get_data_path() / "workflow-services" / "workflows" / workflow_id
    service_dir.mkdir(parents=True, exist_ok=True)
    workflow_path = service_dir / "workflow.json"
    workflow_path.write_text(json.dumps(workflow_json), encoding="utf-8")

    fp = hashlib.sha256(workflow_path.read_bytes()).hexdigest()
    now_ms = int(time.time() * 1000)

    existing_registry = await WorkflowStore.kv_get(f"{_REGISTRY_PREFIX_MAIN}{workflow_id}") or {}
    registry_entry = {
        "workflowId": workflow_id,
        "name": data["name"],
        "sourceType": "main_storage",
        "workflowPath": str(workflow_path),
        "fingerprint": fp,
        "publishStatus": existing_registry.get("publishStatus", "unpublished"),
        "registeredAt": existing_registry.get("registeredAt", now_ms),
        "updatedAt": now_ms,
        "activeReleaseId": existing_registry.get("activeReleaseId"),
        "serviceKey": existing_registry.get("serviceKey"),
        "serviceUrl": existing_registry.get("serviceUrl"),
        "servicePort": existing_registry.get("servicePort"),
    }
    await WorkflowStore.kv_put(f"{_REGISTRY_PREFIX_MAIN}{workflow_id}", registry_entry)
    return data, now_ms


def _workflow_api_autostart_enabled() -> bool:
    raw = os.getenv("FLOCKS_WORKFLOW_API_AUTOSTART", "1").strip().lower()
    return raw not in {"0", "false", "no", "off"}


def _service_driver_from_record(service: Dict[str, Any]) -> Optional[Literal["local", "docker"]]:
    driver = str(service.get("driver") or "").strip().lower()
    if driver in {"local", "docker"}:
        return driver  # type: ignore[return-value]
    return None


def _is_manually_stopped_service(service: Dict[str, Any]) -> bool:
    return str(service.get("status") or "").strip().lower() == "stopped" and bool(service.get("stoppedAt"))


async def _normalize_listed_api_service(key: Any, entry: Any) -> Optional[Dict[str, Any]]:
    if not isinstance(entry, dict):
        return None

    service = dict(entry)
    workflow_id = str(service.get("workflowId") or _workflow_id_from_api_service_key(key))
    service["workflowId"] = workflow_id
    runtime = await WorkflowStore.kv_get(_runtime_key_main(workflow_id))

    if isinstance(runtime, dict) and runtime:
        service_url = runtime.get("serviceUrl") or service.get("serviceUrl") or ""
        service["serviceUrl"] = service_url
        service["invokeUrl"] = f"{service_url}/invoke" if service_url else service.get("invokeUrl", "")
        service["status"] = (
            "running" if runtime.get("status") in {"active", "running"} else service.get("status", "running")
        )
        service["driver"] = runtime.get("driver") or service.get("driver")
        service["containerName"] = runtime.get("containerName") or service.get("containerName", "")
        service["image"] = runtime.get("image") or service.get("image")
        service["port"] = resolve_service_port(runtime) or resolve_service_port(service)
        return service

    status = str(service.get("status") or "").strip().lower()
    if status in {"running", "publishing"}:
        service["status"] = "stopped"
        service["health"] = {
            **(service.get("health") if isinstance(service.get("health"), dict) else {}),
            "ok": False,
            "stale": True,
            "reason": "missing_runtime",
        }
    return service


def _summarize_capability_state(raw_state: Any) -> WorkflowCapabilityState:
    state = str(raw_state or "").strip().lower()
    if state in {"running", "listening", "ready", "active"}:
        return "running"
    if state in {"failed", "error"}:
        return "error"
    if state in {"stopped", "unpublished", "paused", "disabled"}:
        return "stopped"
    return "starting"


async def refresh_workflow_api_health_cache() -> Dict[str, int]:
    """Refresh API health outside list requests with process-wide bounded concurrency."""
    keys = await WorkflowStore.kv_list_keys(_API_SERVICE_PREFIX)
    services = await asyncio.gather(*(WorkflowStore.kv_get(key) for key in keys))
    active_workflow_ids = [
        str(service.get("workflowId") or _workflow_id_from_api_service_key(key))
        for key, service in zip(keys, services)
        if isinstance(service, dict) and service and _summarize_capability_state(service.get("status")) == "running"
    ]
    semaphore = asyncio.Semaphore(_WORKFLOW_API_HEALTH_PROBE_CONCURRENCY)

    async def probe(workflow_id: str) -> tuple[str, bool]:
        async with semaphore:
            try:
                health = await get_workflow_health(workflow_id)
                return workflow_id, bool(health.get("ok"))
            except Exception as exc:
                log.warning("workflow.api_health_monitor.probe_failed", {"id": workflow_id, "error": str(exc)})
                return workflow_id, False

    results = await asyncio.gather(*(probe(workflow_id) for workflow_id in active_workflow_ids))
    _workflow_api_health_cache.clear()
    _workflow_api_health_cache.update(results)
    return {
        "checked": len(results),
        "healthy": sum(1 for _, healthy in results if healthy),
    }


async def run_workflow_api_health_monitor() -> None:
    """Continuously maintain the health snapshot consumed by workflow cards."""
    while True:
        try:
            await mark_interrupted_executions()
            await refresh_workflow_api_health_cache()
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            log.warning("workflow.api_health_monitor.refresh_failed", {"error": str(exc)})
        await asyncio.sleep(_WORKFLOW_API_HEALTH_INTERVAL_S)


def start_workflow_api_health_monitor() -> asyncio.Task[None]:
    global _workflow_api_health_monitor_task
    if _workflow_api_health_monitor_task is None or _workflow_api_health_monitor_task.done():
        _workflow_api_health_monitor_task = asyncio.create_task(
            run_workflow_api_health_monitor(),
            name="workflow-api-health-monitor",
        )
    return _workflow_api_health_monitor_task


async def _get_workflow_integration_status(
    workflow_id: str,
    workflow_data: Dict[str, Any],
) -> WorkflowIntegrationStatusResponse:
    api_summary = WorkflowCapabilityStatusResponse(configured=False, state="unconfigured")
    try:
        service = await WorkflowStore.kv_get(_api_service_key(workflow_id))
        if isinstance(service, dict) and service:
            normalized_service = await _normalize_listed_api_service(
                _api_service_key(workflow_id),
                service,
            )
            state = _summarize_capability_state((normalized_service or service).get("status"))
            if state == "running":
                cached_health = _workflow_api_health_cache.get(workflow_id)
                if cached_health is None:
                    persisted_health = service.get("health")
                    if isinstance(persisted_health, dict) and isinstance(persisted_health.get("ok"), bool):
                        cached_health = persisted_health["ok"]
                if cached_health is False:
                    state = "error"
                elif cached_health is None:
                    state = "starting"
            api_summary = WorkflowCapabilityStatusResponse(configured=True, state=state)
    except Exception as exc:
        log.warning("workflow.list.api_status_failed", {"id": workflow_id, "error": str(exc)})
        api_summary = WorkflowCapabilityStatusResponse(configured=False, state="error")

    try:
        triggers = await _get_workflow_trigger_defs(workflow_id, workflow_data)
        if not triggers:
            trigger_summary = WorkflowTriggerCapabilityStatusResponse(
                configured=False,
                state="unconfigured",
            )
        else:
            statuses = await default_trigger_runtime.get_workflow_trigger_statuses(
                workflow_id,
                set_workflow_json_triggers(workflow_data.get("workflowJson") or {}, triggers),
            )
            statuses_by_id = {
                item.get("triggerId"): item for item in statuses if isinstance(item, dict) and item.get("triggerId")
            }
            trigger_items: List[WorkflowTriggerStatusItemResponse] = []
            for trigger in triggers:
                runtime_status = statuses_by_id.get(trigger.id)
                raw_state = runtime_status.get("state") if runtime_status else None
                trigger_items.append(
                    WorkflowTriggerStatusItemResponse(
                        id=trigger.id,
                        type=trigger.type,
                        name=trigger.name,
                        state=_summarize_capability_state(raw_state) if raw_state else "error",
                        rawState=raw_state,
                    )
                )
            summarized_states = [item.state for item in trigger_items]
            if "error" in summarized_states:
                state = "error"
            elif "stopped" in summarized_states:
                state = "stopped"
            elif summarized_states and all(item == "running" for item in summarized_states):
                state = "running"
            else:
                state = "starting"
            trigger_summary = WorkflowTriggerCapabilityStatusResponse(
                configured=True,
                state=state,
                count=len(triggers),
                items=trigger_items,
            )
    except Exception as exc:
        log.warning("workflow.list.trigger_status_failed", {"id": workflow_id, "error": str(exc)})
        trigger_summary = WorkflowTriggerCapabilityStatusResponse(configured=True, state="error")

    return WorkflowIntegrationStatusResponse(api=api_summary, trigger=trigger_summary)


async def _record_api_publish_failure(
    workflow_id: str,
    existing_service: Dict[str, Any],
    error: Exception,
) -> None:
    """Mark a failed restart only when no prior runtime survived the attempt."""
    if not existing_service:
        return
    try:
        runtime = await WorkflowStore.kv_get(_runtime_key_main(workflow_id))
        if isinstance(runtime, dict) and runtime:
            return
        failed_service = {
            **existing_service,
            "status": "error",
            "lastStartError": str(error),
            "lastStartAttemptAt": int(time.time() * 1000),
            "health": {"ok": False, "reason": "publish_failed"},
        }
        await WorkflowStore.kv_put(_api_service_key(workflow_id), failed_service)
    except Exception as persist_error:
        log.warning(
            "workflow.api.publish_failure_persist_failed",
            {"id": workflow_id, "error": str(persist_error)},
        )


async def reconcile_published_workflow_api_services() -> Dict[str, int]:
    """Restart persisted workflow API services after the main server restarts."""
    stats = {"checked": 0, "healthy": 0, "restarted": 0, "failed": 0, "skipped": 0}
    if not _workflow_api_autostart_enabled():
        return stats

    keys = await WorkflowStore.kv_list_keys(_API_SERVICE_PREFIX)
    for key in keys:
        service = await WorkflowStore.kv_get(key)
        if not isinstance(service, dict):
            continue

        workflow_id = str(service.get("workflowId") or _workflow_id_from_api_service_key(key))
        if _is_manually_stopped_service(service):
            stats["skipped"] += 1
            continue

        stats["checked"] += 1
        try:
            health = await get_workflow_health(workflow_id)
        except Exception as exc:
            health = {"ok": False, "error": str(exc)}

        if health.get("ok"):
            service["status"] = "running"
            service["health"] = health
            await WorkflowStore.kv_put(_api_service_key(workflow_id), service)
            stats["healthy"] += 1
            continue

        now_ms = int(time.time() * 1000)
        service["lastStartAttemptAt"] = now_ms
        try:
            data, _ = await _prepare_workflow_api_registry(workflow_id)
            active_record = await publish_workflow(
                workflow_id,
                image=service.get("image") or None,
                driver=_service_driver_from_record(service),
                api_key=service.get("apiKey") or None,
                port=resolve_service_port(service),
            )

            service_url = active_record.get("serviceUrl", "")
            service.update(
                {
                    "workflowId": workflow_id,
                    "workflowName": service.get("workflowName") or data["name"],
                    "serviceUrl": service_url,
                    "invokeUrl": f"{service_url}/invoke",
                    "apiKey": service.get("apiKey") or active_record.get("apiKey"),
                    "status": "running",
                    "containerName": active_record.get("containerName", ""),
                    "driver": active_record.get("driver") or service.get("driver"),
                    "image": active_record.get("image") or service.get("image"),
                    "port": resolve_service_port(active_record) or resolve_service_port(service),
                    "restartedAt": int(time.time() * 1000),
                }
            )
            service.pop("lastStartError", None)
            service["health"] = {"ok": True, "restarted": True}
            await WorkflowStore.kv_put(_api_service_key(workflow_id), service)
            stats["restarted"] += 1
        except Exception as exc:
            service["status"] = "error"
            service["health"] = health
            service["lastStartError"] = str(exc)
            await WorkflowStore.kv_put(_api_service_key(workflow_id), service)
            log.warning("workflow.api.autostart_failed", {"id": workflow_id, "error": str(exc)})
            stats["failed"] += 1
    return stats


class WorkflowServiceResponse(BaseModel):
    workflowId: str
    workflowName: str
    serviceUrl: str
    invokeUrl: str
    apiKey: str
    status: str
    publishedAt: int
    containerName: Optional[str] = None
    driver: Optional[Literal["local", "docker"]] = None
    image: Optional[str] = None
    port: Optional[int] = None


class KafkaConfigRequest(BaseModel):
    """Per-workflow Kafka consumer configuration."""

    enabled: bool = False
    inputBroker: Optional[str] = None
    inputTopic: Optional[str] = None
    inputGroupId: Optional[str] = None
    inputKey: str = "kafka_message"
    autoOffsetReset: str = "latest"
    inputs: Dict[str, Any] = Field(default_factory=dict)


def _strip_execution_only_comments(value: Any) -> Any:
    if isinstance(value, list):
        return [_strip_execution_only_comments(item) for item in value]
    if not isinstance(value, dict):
        return value
    return {
        key: _strip_execution_only_comments(nested)
        for key, nested in value.items()
        if not str(key).startswith("_comment")
    }


class TriggerEventPayloadRequest(BaseModel):
    """Sample event payload for trigger preview/testing."""

    model_config = ConfigDict(populate_by_name=True)

    body: Any = None
    headers: Dict[str, Any] = Field(default_factory=dict)
    query: Dict[str, Any] = Field(default_factory=dict)
    path_params: Dict[str, Any] = Field(default_factory=dict, alias="pathParams")


class TriggerPreviewResponse(BaseModel):
    """Preview result for trigger mapping and filtering."""

    model_config = ConfigDict(populate_by_name=True, by_alias=True)

    triggerId: str
    triggerType: str
    matched: bool
    inputs: Dict[str, Any] = Field(default_factory=dict)
    filterError: Optional[str] = None


class TriggerSaveResponse(BaseModel):
    """Persisted trigger definition with runtime status."""

    model_config = ConfigDict(populate_by_name=True, by_alias=True)

    trigger: Dict[str, Any]
    status: Optional[Dict[str, Any]] = None


class WorkflowPollerConfigRequest(BaseModel):
    """Per-workflow background poller configuration."""

    enabled: bool = False
    intervalSeconds: int = Field(30, ge=1)
    cronExpression: Optional[str] = None
    timeoutSeconds: int = Field(7200, ge=1)
    noOverlap: bool = True
    inputs: Dict[str, Any] = Field(default_factory=dict)


class SyslogConfigRequest(BaseModel):
    """Per-workflow syslog listener configuration (experimental)."""

    model_config = ConfigDict(populate_by_name=True)

    enabled: bool = False
    protocol: Literal["udp", "tcp"] = "udp"
    host: str = "0.0.0.0"
    port: int = Field(5140, ge=1, le=65535, description="Listener port (1-65535)")
    msg_format: str = Field("auto", alias="format")
    input_key: str = Field("syslog_message", alias="inputKey")

    @field_validator("protocol", mode="before")
    @classmethod
    def _normalize_protocol(cls, value: Any) -> Any:
        return value.strip().lower() if isinstance(value, str) else value


@router.post("/workflow/{workflow_id}/publish")
async def publish_workflow_as_api(
    workflow_id: str,
    req: Optional[WorkflowCenterPublishRequest] = None,
):
    """
    Publish workflow as an API service.

    Writes the workflow JSON to disk, registers it with the workflow center,
    starts the selected runtime, and returns the service URL and generated API key.
    """
    existing_service: Dict[str, Any] = {}
    try:
        _refuse_managed_workflow_change(workflow_id)
        data, now_ms = await _prepare_workflow_api_registry(workflow_id)

        # Preserve existing API key across re-publishes so callers don't break.
        # The runtime must receive the same key before it starts so /invoke can
        # enforce the key returned to callers.
        existing_service = await WorkflowStore.kv_get(_api_service_key(workflow_id)) or {}
        api_key = existing_service.get("apiKey") or (uuid.uuid4().hex + uuid.uuid4().hex)
        requested_port = req.port if req and req.port is not None else resolve_service_port(existing_service)

        # Use center.py to publish the selected runtime.
        active_record = await publish_workflow(
            workflow_id,
            image=req.image if req else None,
            driver=req.driver if req else None,
            api_key=api_key,
            port=requested_port,
        )

        service_url = active_record.get("serviceUrl", "")
        invoke_url = f"{service_url}/invoke"
        container_name = active_record.get("containerName", "")
        driver = active_record.get("driver") or (req.driver if req else None)
        image = active_record.get("image") or (req.image if req else None)
        host_port = resolve_service_port(active_record) or requested_port

        service_info = {
            "workflowId": workflow_id,
            "workflowName": data["name"],
            "serviceUrl": service_url,
            "invokeUrl": invoke_url,
            "apiKey": api_key,
            "status": "running",
            "publishedAt": now_ms,
            "containerName": container_name,
            "driver": driver,
            "image": image,
            "port": host_port,
        }
        await WorkflowStore.kv_put(_api_service_key(workflow_id), service_info)

        log.info("workflow.api.published", {"id": workflow_id, "url": service_url})
        return service_info
    except WorkflowNotFoundError as e:
        raise HTTPException(status_code=404, detail=str(e))
    except WorkflowPortUnavailableError as e:
        await _record_api_publish_failure(workflow_id, existing_service, e)
        raise HTTPException(status_code=409, detail=str(e))
    except HTTPException:
        raise
    except WorkflowCenterError as e:
        await _record_api_publish_failure(workflow_id, existing_service, e)
        log.error("workflow.publish.center_error", {"id": workflow_id, "error": str(e)})
        raise HTTPException(status_code=500, detail=f"发布失败: {str(e)}")
    except Exception as e:
        log.error("workflow.publish.error", {"id": workflow_id, "error": str(e)})
        raise HTTPException(status_code=500, detail=f"Failed to publish workflow: {str(e)}")


@router.post("/workflow/{workflow_id}/unpublish")
async def unpublish_workflow_api(workflow_id: str):
    """
    Stop a published workflow API service.
    """
    try:
        existing = await WorkflowStore.kv_get(_api_service_key(workflow_id))
        if not existing:
            raise HTTPException(status_code=404, detail="No published service found for this workflow")

        try:
            await stop_workflow_service(workflow_id)
        except (WorkflowNotFoundError, WorkflowNotPublishedError):
            pass

        existing["status"] = "stopped"
        existing["stoppedAt"] = int(time.time() * 1000)
        await WorkflowStore.kv_put(_api_service_key(workflow_id), existing)

        log.info("workflow.api.unpublished", {"id": workflow_id})
        return {"ok": True}
    except HTTPException:
        raise
    except Exception as e:
        log.error("workflow.unpublish.error", {"id": workflow_id, "error": str(e)})
        raise HTTPException(status_code=500, detail=f"Failed to stop workflow service: {str(e)}")


def _redact_service_api_key_for_user(
    service: Optional[Dict[str, Any]],
    request: Optional[Request],
) -> Optional[Dict[str, Any]]:
    """Only administrators (incl. the API-token service identity) see the plaintext key.

    ``request`` is ``None`` for in-process callers (tests / internal reuse), which
    keep the full record.
    """
    if request is None or not isinstance(service, dict) or not service.get("apiKey"):
        return service
    user = get_optional_user(request)
    if user is not None and user.role == "admin":
        return service
    redacted = dict(service)
    redacted.pop("apiKey", None)
    redacted["apiKeyConfigured"] = True
    return redacted


@router.get("/workflow/{workflow_id}/service")
async def get_workflow_service(workflow_id: str, request: Request = None):
    """
    Get published API service info for a workflow.
    Returns null if not published.
    """
    try:
        service = await WorkflowStore.kv_get(_api_service_key(workflow_id))
        normalized = await _normalize_listed_api_service(_api_service_key(workflow_id), service)
        return _redact_service_api_key_for_user(normalized, request)
    except Exception as e:
        log.error("workflow.service.get.error", {"id": workflow_id, "error": str(e)})
        raise HTTPException(status_code=500, detail=f"Failed to get service info: {str(e)}")


@router.delete("/workflow/{workflow_id}/service")
async def delete_workflow_service(workflow_id: str):
    """Delete the stored API service configuration for a workflow."""
    try:
        existing = await WorkflowStore.kv_get(_api_service_key(workflow_id))
        if not existing:
            raise HTTPException(status_code=404, detail="No published service found for this workflow")

        try:
            await stop_workflow_service(workflow_id)
        except (WorkflowNotFoundError, WorkflowNotPublishedError):
            pass

        try:
            await WorkflowStore.kv_remove(_api_service_key(workflow_id))
        except Exception:
            pass
        else:
            registry_key = f"{_REGISTRY_PREFIX_MAIN}{workflow_id}"
            registry = await WorkflowStore.kv_get(registry_key)
            if isinstance(registry, dict) and "servicePort" in registry:
                registry.pop("servicePort", None)
                await WorkflowStore.kv_put(registry_key, registry)

        log.info("workflow.api.service_deleted", {"id": workflow_id})
        return {"ok": True, "workflowId": workflow_id}
    except HTTPException:
        raise
    except Exception as e:
        log.error("workflow.service.delete.error", {"id": workflow_id, "error": str(e)})
        raise HTTPException(status_code=500, detail=f"Failed to delete workflow service: {str(e)}")


@router.get("/workflow/{workflow_id}/config")
async def get_workflow_config(workflow_id: str):
    """Read workflow publish template from Storage, migrating config.json if needed."""
    data = _read_workflow_from_fs(workflow_id)
    if not data:
        raise HTTPException(status_code=404, detail=f"Workflow not found: {workflow_id}")

    config_path = _workflow_config_dir(workflow_id, data) / "config.json"
    runtime = await _build_workflow_integration_runtime(workflow_id, data)
    try:
        config, source = await _load_workflow_integration_config_template(workflow_id, data, config_path)
        if config is not None:
            return {
                "exists": True,
                "path": str(config_path),
                "storageKey": _workflow_integration_config_key(workflow_id),
                "source": source,
                "config": config,
                "runtime": runtime,
            }

        config = await _build_workflow_integration_config(workflow_id, data)
        return {
            "exists": False,
            "path": str(config_path),
            "storageKey": _workflow_integration_config_key(workflow_id),
            "source": "generated",
            "config": config,
            "runtime": runtime,
        }
    except HTTPException:
        raise
    except Exception as exc:
        log.error("workflow.config.get.error", {"id": workflow_id, "error": str(exc)})
        raise HTTPException(status_code=500, detail=f"Failed to read workflow config: {str(exc)}")


@router.put("/workflow/{workflow_id}/config")
async def update_workflow_config(
    workflow_id: str,
    config: Dict[str, Any] = Body(...),
):
    """Update the publish template in Storage without mutating runtime state."""
    data = _read_workflow_from_fs(workflow_id)
    if not data:
        raise HTTPException(status_code=404, detail=f"Workflow not found: {workflow_id}")

    try:
        normalized_config = _normalize_workflow_integration_config_template(workflow_id, data, config)
        config_path = _workflow_config_dir(workflow_id, data) / "config.json"
        await WorkflowStore.put_config(workflow_id, normalized_config)
        log.info(
            "workflow.config.updated",
            {
                "id": workflow_id,
                "storage_key": _workflow_integration_config_key(workflow_id),
            },
        )
        return {
            "ok": True,
            "exists": True,
            "path": str(config_path),
            "storageKey": _workflow_integration_config_key(workflow_id),
            "source": "storage",
            "config": normalized_config,
            "runtime": await _build_workflow_integration_runtime(workflow_id, data),
        }
    except HTTPException:
        raise
    except Exception as exc:
        log.error("workflow.config.update.error", {"id": workflow_id, "error": str(exc)})
        raise HTTPException(status_code=500, detail=f"Failed to update workflow config: {str(exc)}")


@router.post("/workflow/{workflow_id}/config/sync")
async def sync_workflow_config(workflow_id: str):
    """Ensure a publish template exists in Storage, migrating config.json if present."""
    data = _read_workflow_from_fs(workflow_id)
    if not data:
        raise HTTPException(status_code=404, detail=f"Workflow not found: {workflow_id}")
    try:
        config_path = _workflow_config_dir(workflow_id, data) / "config.json"
        config, source = await _load_workflow_integration_config_template(workflow_id, data, config_path)
        if config is not None:
            return {
                "ok": True,
                "path": str(config_path),
                "exists": True,
                "storageKey": _workflow_integration_config_key(workflow_id),
                "source": source,
                "config": config,
                "runtime": await _build_workflow_integration_runtime(workflow_id, data),
            }

        config = await _build_workflow_integration_config(workflow_id, data)
        await WorkflowStore.put_config(workflow_id, config)
        log.info(
            "workflow.config.synced",
            {
                "id": workflow_id,
                "storage_key": _workflow_integration_config_key(workflow_id),
            },
        )
        return {
            "ok": True,
            "path": str(config_path),
            "exists": True,
            "storageKey": _workflow_integration_config_key(workflow_id),
            "source": "storage",
            "config": config,
            "runtime": await _build_workflow_integration_runtime(workflow_id, data),
        }
    except Exception as exc:
        log.error("workflow.config.sync.error", {"id": workflow_id, "error": str(exc)})
        raise HTTPException(status_code=500, detail=f"Failed to sync workflow config: {str(exc)}")


@router.get("/workflow-services")
async def list_workflow_services(request: Request = None):
    """
    List all published workflow API services.
    """
    try:
        keys = await WorkflowStore.kv_list_keys(_API_SERVICE_PREFIX)
        services = []
        for key in keys:
            entry = await WorkflowStore.kv_get(key)
            service = await _normalize_listed_api_service(key, entry)
            if service:
                services.append(_redact_service_api_key_for_user(service, request))
        services.sort(key=lambda s: s.get("publishedAt", 0), reverse=True)
        return services
    except Exception as e:
        log.error("workflow.services.list.error", {"error": str(e)})
        raise HTTPException(status_code=500, detail=f"Failed to list services: {str(e)}")


def _find_trigger_or_404(triggers: List[TriggerDefinition], trigger_id: str) -> TriggerDefinition:
    trigger = next((item for item in triggers if item.id == trigger_id), None)
    if trigger is None:
        raise HTTPException(status_code=404, detail=f"Trigger not found: {trigger_id}")
    return trigger


def _validate_trigger_type_constraints(triggers: List[TriggerDefinition]) -> None:
    singleton_ids_by_type: Dict[str, List[str]] = {}
    for trigger in triggers:
        if trigger.type not in _LEGACY_SINGLETON_TRIGGER_TYPES:
            continue
        singleton_ids_by_type.setdefault(trigger.type, []).append(trigger.id or "")

    duplicates = {
        trigger_type: trigger_ids for trigger_type, trigger_ids in singleton_ids_by_type.items() if len(trigger_ids) > 1
    }
    if not duplicates:
        return

    first_type = sorted(duplicates)[0]
    trigger_ids = [trigger_id for trigger_id in duplicates[first_type] if trigger_id]
    detail = (
        f"Only one {first_type} trigger is supported per workflow; "
        f"found: {', '.join(trigger_ids) or 'multiple triggers'}"
    )
    raise HTTPException(status_code=409, detail=detail)


def _webhook_auth_type(trigger: TriggerDefinition) -> str:
    auth = trigger.auth
    return str(getattr(auth, "type", "") or "").strip().lower()


def _validate_webhook_trigger_auth(trigger: TriggerDefinition) -> None:
    if trigger.type not in _WEBHOOK_TRIGGER_TYPES:
        return

    auth = trigger.auth
    auth_type = _webhook_auth_type(trigger)
    if auth is None or auth_type in {"", "none"}:
        raise HTTPException(
            status_code=400,
            detail="Webhook triggers must configure authentication with auth.type 'api_key' or 'hmac'.",
        )
    if auth_type not in _WEBHOOK_AUTH_TYPES:
        raise HTTPException(status_code=400, detail=f"Unsupported webhook auth type: {auth.type}")
    if auth_type == "api_key" and not (auth.apiKey or auth.secretRef):
        raise HTTPException(
            status_code=400,
            detail="Webhook api_key auth requires either apiKey or secretRef.",
        )
    if auth_type == "hmac" and not auth.secretRef:
        raise HTTPException(status_code=400, detail="Webhook hmac auth requires secretRef.")


def _validate_cron_expression(cron_expression: str) -> None:
    """Reject cron strings croniter cannot schedule (5/6/7 columns accepted)."""
    from croniter import croniter

    try:
        if not croniter.is_valid(cron_expression):
            raise ValueError("invalid cron expression")
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Invalid cron expression: {cron_expression!r} ({exc})")


def _validate_schedule_trigger_source(trigger: TriggerDefinition) -> None:
    if trigger.type != "schedule":
        return
    source = trigger.source if isinstance(trigger.source, dict) else {}
    cron_expression = str(source.get("cron") or source.get("cronExpression") or "").strip()
    mode = str(source.get("mode") or "").strip().lower()
    if cron_expression:
        _validate_cron_expression(cron_expression)
    elif mode == "cron":
        raise HTTPException(status_code=400, detail="Schedule trigger with mode 'cron' requires source.cron")


def _validate_trigger_definitions(triggers: List[TriggerDefinition]) -> None:
    _validate_trigger_type_constraints(triggers)
    for trigger in triggers:
        _validate_webhook_trigger_auth(trigger)
        _validate_schedule_trigger_source(trigger)


@router.get("/workflow/{workflow_id}/triggers")
async def list_workflow_triggers(workflow_id: str):
    """List unified triggers for a workflow with runtime status."""
    data = _read_workflow_from_fs(workflow_id)
    if not data:
        raise HTTPException(status_code=404, detail=f"Workflow not found: {workflow_id}")
    triggers = await _get_workflow_trigger_defs(workflow_id, data)
    statuses = {
        item.get("triggerId"): item
        for item in await default_trigger_runtime.get_workflow_trigger_statuses(
            workflow_id,
            set_workflow_json_triggers(data.get("workflowJson") or {}, triggers),
        )
    }
    return [
        {
            "trigger": _trigger_to_api_dict(trigger),
            "status": statuses.get(trigger.id),
        }
        for trigger in triggers
    ]


@router.post("/workflow/{workflow_id}/triggers", response_model=TriggerSaveResponse)
async def create_workflow_trigger(workflow_id: str, trigger: TriggerDefinition):
    """Create or replace a unified trigger definition."""
    # Triggers live in the definition, which a managed workflow does not let us rewrite.
    _refuse_managed_workflow_change(workflow_id)
    data = _read_workflow_from_fs(workflow_id)
    if not data:
        raise HTTPException(status_code=404, detail=f"Workflow not found: {workflow_id}")
    existing = await _get_workflow_trigger_defs(workflow_id, data)
    trigger = _merge_trigger_secrets(trigger, next((item for item in existing if item.id == trigger.id), None))
    updated = _replace_or_append_trigger(existing, trigger)
    _validate_trigger_definitions(updated)
    persisted = await _persist_workflow_triggers(workflow_id, data, updated)
    await default_trigger_runtime.restart_workflow(workflow_id, persisted.get("workflowJson") or {})
    status = await default_trigger_runtime.get_trigger_status(workflow_id, trigger)
    return TriggerSaveResponse(trigger=_trigger_to_api_dict(trigger), status=status)


@router.put("/workflow/{workflow_id}/triggers/{trigger_id}", response_model=TriggerSaveResponse)
async def update_workflow_trigger(workflow_id: str, trigger_id: str, trigger: TriggerDefinition):
    """Update a unified trigger definition."""
    # Triggers live in the definition, which a managed workflow does not let us rewrite.
    _refuse_managed_workflow_change(workflow_id)
    data = _read_workflow_from_fs(workflow_id)
    if not data:
        raise HTTPException(status_code=404, detail=f"Workflow not found: {workflow_id}")
    existing = await _get_workflow_trigger_defs(workflow_id, data)
    current = _find_trigger_or_404(existing, trigger_id)
    updated_trigger = _merge_trigger_secrets(trigger.model_copy(update={"id": trigger_id}), current)
    updated = _replace_or_append_trigger(existing, updated_trigger)
    _validate_trigger_definitions(updated)
    persisted = await _persist_workflow_triggers(workflow_id, data, updated)
    await default_trigger_runtime.restart_workflow(workflow_id, persisted.get("workflowJson") or {})
    status = await default_trigger_runtime.get_trigger_status(workflow_id, updated_trigger)
    return TriggerSaveResponse(trigger=_trigger_to_api_dict(updated_trigger), status=status)


@router.delete("/workflow/{workflow_id}/triggers/{trigger_id}")
async def delete_workflow_trigger(workflow_id: str, trigger_id: str):
    """Delete a unified trigger definition."""
    # Triggers live in the definition, which a managed workflow does not let us rewrite.
    _refuse_managed_workflow_change(workflow_id)
    data = _read_workflow_from_fs(workflow_id)
    if not data:
        raise HTTPException(status_code=404, detail=f"Workflow not found: {workflow_id}")
    existing = await _get_workflow_trigger_defs(workflow_id, data)
    trigger = _find_trigger_or_404(existing, trigger_id)
    remaining = [item for item in existing if item.id != trigger_id]
    persisted = await _persist_workflow_triggers(workflow_id, data, remaining)
    await default_trigger_runtime.restart_workflow(workflow_id, persisted.get("workflowJson") or {})
    # After the restart re-synced legacy configs, drop the deleted trigger's
    # legacy record so ``/poller-config`` etc. read back as unconfigured.
    await _remove_legacy_trigger_state(workflow_id, trigger)
    return {"ok": True, "triggerId": trigger_id}


@router.get("/workflow/{workflow_id}/triggers/{trigger_id}/status")
async def get_workflow_trigger_status(workflow_id: str, trigger_id: str):
    data = _read_workflow_from_fs(workflow_id)
    if not data:
        raise HTTPException(status_code=404, detail=f"Workflow not found: {workflow_id}")
    triggers = await _get_workflow_trigger_defs(workflow_id, data)
    trigger = _find_trigger_or_404(triggers, trigger_id)
    return await default_trigger_runtime.get_trigger_status(workflow_id, trigger)


@router.post("/workflow/{workflow_id}/triggers/{trigger_id}/preview-mapping", response_model=TriggerPreviewResponse)
async def preview_workflow_trigger_mapping(
    workflow_id: str,
    trigger_id: str,
    payload: TriggerEventPayloadRequest,
):
    data = _read_workflow_from_fs(workflow_id)
    if not data:
        raise HTTPException(status_code=404, detail=f"Workflow not found: {workflow_id}")
    triggers = await _get_workflow_trigger_defs(workflow_id, data)
    trigger = _find_trigger_or_404(triggers, trigger_id)
    event = build_trigger_event(
        workflow_id=workflow_id,
        trigger=trigger,
        body=payload.body,
        headers=payload.headers,
        query=payload.query,
        path_params=payload.path_params,
    )
    matched, filter_error = evaluate_trigger_filter(trigger, event)
    try:
        mapped_inputs = preview_trigger_mapping(trigger, event)
    except TriggerDispatchError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return TriggerPreviewResponse(
        triggerId=trigger.id or trigger_id,
        triggerType=trigger.type,
        matched=matched,
        inputs=mapped_inputs,
        filterError=filter_error,
    )


async def _dispatch_trigger_event(
    *,
    workflow_id: str,
    workflow_json: Dict[str, Any],
    trigger: TriggerDefinition,
    event: TriggerEvent,
    verified_auth: Optional[Dict[str, str]] = None,
) -> Dict[str, Any]:
    """Dispatch a trigger event: 400 for a bad filter, 403 when an extension refuses."""
    try:
        return await default_trigger_runtime.dispatch_event(
            workflow_id=workflow_id,
            workflow_json=workflow_json,
            trigger=trigger,
            event=event,
            verified_auth=verified_auth,
        )
    except TriggerDispatchError as exc:
        raise HTTPException(status_code=400, detail=f"Trigger filter error: {exc}") from exc
    except ExecutionStopped as exc:
        # The message is the reason the extension gave (for example an
        # ingress policy's "headless_evidence_missing"); pass it on so the
        # caller does not have to read the server log to learn why.
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=f"Workflow trigger stopped by extension: {exc}",
        ) from exc


@router.post("/workflow/{workflow_id}/triggers/{trigger_id}/test")
async def test_workflow_trigger(
    workflow_id: str,
    trigger_id: str,
    payload: TriggerEventPayloadRequest,
):
    data = _read_workflow_from_fs(workflow_id)
    if not data:
        raise HTTPException(status_code=404, detail=f"Workflow not found: {workflow_id}")
    workflow_json = data.get("workflowJson") or {}
    triggers = await _get_workflow_trigger_defs(workflow_id, data)
    trigger = _find_trigger_or_404(triggers, trigger_id)
    event = build_trigger_event(
        workflow_id=workflow_id,
        trigger=trigger,
        body=payload.body,
        headers=payload.headers,
        query=payload.query,
        path_params=payload.path_params,
    )
    result = await _dispatch_trigger_event(
        workflow_id=workflow_id,
        workflow_json=workflow_json,
        trigger=trigger,
        event=event,
    )
    return {
        "ok": True,
        "trigger": _trigger_to_api_dict(trigger),
        **result,
    }


@router.get("/workflow-trigger-plugins")
async def list_workflow_trigger_plugins():
    return default_trigger_runtime.list_plugin_specs()


_WEBHOOK_REPLAY_WINDOW_ENV = "FLOCKS_WEBHOOK_REPLAY_WINDOW_S"
_WEBHOOK_REPLAY_WINDOW_DEFAULT_S = 300.0
# Headers an external system may use to give a delivery a stable identity.
_WEBHOOK_DELIVERY_ID_HEADERS = ("x-flocks-delivery-id", "x-idempotency-key", "idempotency-key", "x-delivery-id")


def _webhook_replay_window_s() -> float:
    raw = os.getenv(_WEBHOOK_REPLAY_WINDOW_ENV, "").strip()
    if not raw:
        return _WEBHOOK_REPLAY_WINDOW_DEFAULT_S
    try:
        return max(0.0, float(raw))
    except ValueError:
        return _WEBHOOK_REPLAY_WINDOW_DEFAULT_S


def _webhook_client_delivery_id(headers: Dict[str, str]) -> Optional[str]:
    for name in _WEBHOOK_DELIVERY_ID_HEADERS:
        value = headers.get(name)
        if value and value.strip():
            return value.strip()[:200]
    return None


def _webhook_delivery_key(workflow_id: str, trigger_id: str, client_delivery_id: Optional[str], raw_body: bytes) -> str:
    if client_delivery_id:
        return f"{workflow_id}/{trigger_id}/id:{client_delivery_id}"
    return f"{workflow_id}/{trigger_id}/body:{hashlib.sha256(raw_body).hexdigest()}"


async def _register_webhook_delivery(key: str, delivery_id: str, claim_token: str) -> Optional[str]:
    """Claim a delivery; return the first deliveryId when *key* is a replay.

    Replays are keyed per (workflow, trigger) by a client-supplied delivery id,
    else by the body digest, within ``FLOCKS_WEBHOOK_REPLAY_WINDOW_S`` seconds
    (default 300; ``0`` disables).  Whether one is recorded is up to the store
    (WorkflowStore.claim_webhook_delivery).  *claim_token* names this
    request's claim, so only this request can release it.
    """
    window = _webhook_replay_window_s()
    if window <= 0:
        return None
    return await WorkflowStore.claim_webhook_delivery(key, delivery_id, window, claim_token)


def _dispatch_stopped_before_run(exc: BaseException) -> bool:
    """Whether a failed trigger dispatch ended before the workflow could run.

    A filter error, or an extension refusing the event in ``ingress.before``;
    the 400/403 raised for them carries the original as its cause.
    """
    cause = exc.__cause__ if isinstance(exc, HTTPException) else exc
    if isinstance(cause, TriggerDispatchError):
        return True
    return isinstance(cause, ExecutionStopped) and cause.stop_stage == "ingress.before"


def _resolve_trigger_secret(secret_ref: Optional[str]) -> Optional[str]:
    if not secret_ref:
        return None
    try:
        from flocks.security import get_secret_manager

        return get_secret_manager().get(secret_ref)
    except Exception:
        return None


def _normalize_hmac_signature(signature: Optional[str]) -> Optional[str]:
    if not signature:
        return None
    value = signature.strip()
    if value.lower().startswith("sha256="):
        return value.split("=", 1)[1].strip()
    return value


def _webhook_secret_fingerprint(secret: str) -> str:
    """Secret-safe stable id of a trigger key, as the service runtime emits it."""
    return f"sha256:{hashlib.sha256(secret.encode('utf-8')).hexdigest()}"


def _authorize_webhook_trigger(
    trigger: TriggerDefinition,
    headers: Dict[str, str],
    query: Dict[str, str],
    *,
    raw_body: bytes,
) -> Dict[str, str]:
    """Check the caller against the trigger's own secret and say what passed."""
    auth = trigger.auth
    auth_type = _webhook_auth_type(trigger)
    if auth is None or auth_type in {"none", ""}:
        raise HTTPException(
            status_code=401,
            detail="Webhook trigger must configure authentication with auth.type 'api_key' or 'hmac'.",
        )
    if auth_type == "api_key":
        expected = auth.apiKey or _resolve_trigger_secret(auth.secretRef)
        if not expected:
            raise HTTPException(status_code=401, detail="Webhook trigger API key is not configured")
        header_name = (auth.headerName or "x-api-key").lower()
        actual = headers.get(header_name) or query.get(auth.queryParam or "api_key")
        if not actual or not hmac.compare_digest(str(actual).encode("utf-8"), str(expected).encode("utf-8")):
            raise HTTPException(status_code=401, detail="Invalid webhook API key")
        return {"auth_scheme": "api_key", "api_key_id": _webhook_secret_fingerprint(expected)}
    if auth_type == "hmac":
        expected = _resolve_trigger_secret(auth.secretRef)
        if not expected:
            raise HTTPException(status_code=401, detail="Webhook trigger secret is not configured")
        signature = _normalize_hmac_signature(headers.get((auth.headerName or "x-flocks-signature").lower()))
        expected_signature = hmac.new(
            expected.encode("utf-8"),
            raw_body,
            hashlib.sha256,
        ).hexdigest()
        if not signature or not hmac.compare_digest(signature, expected_signature):
            raise HTTPException(status_code=401, detail="Invalid webhook signature")
        return {"auth_scheme": "hmac", "key_id": _webhook_secret_fingerprint(expected)}
    raise HTTPException(status_code=400, detail=f"Unsupported webhook auth type: {auth.type}")


@webhook_router.post("/webhook/workflows/{workflow_id}/{trigger_id}")
async def invoke_workflow_webhook_trigger(
    workflow_id: str,
    trigger_id: str,
    request: Request,
):
    """Invoke a webhook/custom_webhook trigger and dispatch the workflow."""
    data = _read_workflow_from_fs(workflow_id)
    if not data:
        raise HTTPException(status_code=404, detail=f"Workflow not found: {workflow_id}")
    workflow_json = data.get("workflowJson") or {}
    triggers = await _get_workflow_trigger_defs(workflow_id, data)
    trigger = _find_trigger_or_404(triggers, trigger_id)
    if trigger.type not in {"webhook", "custom_webhook"}:
        raise HTTPException(status_code=400, detail=f"Trigger is not a webhook trigger: {trigger_id}")
    if not trigger.enabled:
        raise HTTPException(status_code=403, detail=f"Trigger is disabled: {trigger_id}")

    headers = {key.lower(): value for key, value in request.headers.items()}
    query = {key: value for key, value in request.query_params.items()}
    raw_body = await request.body()
    verified_auth = _authorize_webhook_trigger(trigger, headers, query, raw_body=raw_body)

    try:
        body = json.loads(raw_body.decode("utf-8"))
    except Exception:
        body = raw_body.decode("utf-8", errors="replace")

    client_delivery_id = _webhook_client_delivery_id(headers)
    event = build_trigger_event(
        workflow_id=workflow_id,
        trigger=trigger,
        body=body,
        headers=headers,
        query=query,
        path_params={"workflow_id": workflow_id, "trigger_id": trigger_id},
        raw=body,
        source=(trigger.source or {}).get("path") or str(request.url.path),
        delivery_id=client_delivery_id,
    )
    delivery_key = _webhook_delivery_key(workflow_id, trigger_id, client_delivery_id, raw_body)
    recorded_delivery_id = event.source.deliveryId or ""
    claim_token = uuid.uuid4().hex  # secret-guard: allow 误报：uuid4 生成的 claim token
    original_delivery_id = await _register_webhook_delivery(delivery_key, recorded_delivery_id, claim_token)
    if original_delivery_id is not None:
        log.info(
            "workflow.webhook.duplicate_delivery",
            {"id": workflow_id, "trigger_id": trigger_id, "delivery_id": original_delivery_id},
        )
        return {
            "ok": True,
            "duplicate": True,
            "matched": False,
            "executed": False,
            "inputs": {},
            "deliveryId": original_delivery_id,
        }
    from flocks.workflow.execution_store import for_webhook_delivery

    try:
        if _webhook_replay_window_s() > 0:
            # The run this delivery starts belongs to its claim.
            with for_webhook_delivery(delivery_key, claim_token):
                result = await _dispatch_trigger_event(
                    workflow_id=workflow_id,
                    workflow_json=workflow_json,
                    trigger=trigger,
                    event=event,
                    verified_auth=verified_auth,
                )
        else:
            result = await _dispatch_trigger_event(
                workflow_id=workflow_id,
                workflow_json=workflow_json,
                trigger=trigger,
                event=event,
                verified_auth=verified_auth,
            )
    except BaseException as exc:
        # A delivery refused before the workflow ran may be sent again (say,
        # once the operator fixed what the 403 named) and must not then be
        # dropped as a duplicate. Any other failure may follow side effects,
        # so it stays recorded and a retry is answered as a duplicate.
        if _dispatch_stopped_before_run(exc) and _webhook_replay_window_s() > 0:
            try:
                await WorkflowStore.release_webhook_delivery(delivery_key, claim_token)
            except Exception as release_error:
                log.warning("workflow.webhook.release_failed", {"id": workflow_id, "error": str(release_error)})
        raise
    return {
        "ok": True,
        "duplicate": False,
        "matched": result.get("matched", True),
        "executed": result.get("executed", False),
        "inputs": result.get("inputs", {}),
        "deliveryId": event.source.deliveryId,
    }


@router.post("/workflow/{workflow_id}/kafka-config")
async def save_kafka_config(workflow_id: str, req: KafkaConfigRequest):
    """
    Save Kafka input configuration for a workflow.

    When ``enabled`` is true this also (re)starts the Kafka consumer and blocks
    until it has either connected to the broker or failed.  Connection failures
    are surfaced as ``409 Conflict`` so the UI can show an actionable error
    instead of falsely claiming the consumer is running.
    """
    # The trigger lives in the definition, which a managed workflow does not let us rewrite.
    _refuse_managed_workflow_change(workflow_id)
    try:
        data = _read_workflow_from_fs(workflow_id)
        if not data:
            raise HTTPException(status_code=404, detail=f"Workflow not found: {workflow_id}")

        if req.enabled:
            try:
                validate_workflow_python(data.get("workflowJson") or {})
            except Exception as exc:
                raise HTTPException(status_code=400, detail=str(exc)) from exc
        config = {
            "workflowId": workflow_id,
            "enabled": req.enabled,
            "inputBroker": req.inputBroker,
            "inputTopic": req.inputTopic,
            "inputGroupId": req.inputGroupId,
            "inputKey": req.inputKey,
            "autoOffsetReset": req.autoOffsetReset,
            "inputs": _strip_execution_only_comments(req.inputs),
            "updatedAt": int(time.time() * 1000),
        }
        await WorkflowStore.put_config(workflow_id, config, kind="workflow_kafka_config")
        triggers = await _get_workflow_trigger_defs(workflow_id, data)
        unified_trigger = TriggerDefinition.model_validate(
            {
                "id": _legacy_singleton_trigger_id(triggers, "kafka"),
                "type": "kafka",
                "enabled": req.enabled,
                "source": {
                    "inputBroker": req.inputBroker or "",
                    "inputTopic": req.inputTopic or "",
                    "inputGroupId": req.inputGroupId or "",
                    "autoOffsetReset": req.autoOffsetReset,
                },
                "mapping": {
                    req.inputKey or "kafka_message": "$.body",
                },
                "inputs": _strip_execution_only_comments(req.inputs),
                "updatedAt": config["updatedAt"],
            }
        )
        updated_triggers = _replace_or_append_trigger(triggers, unified_trigger)
        _validate_trigger_type_constraints(updated_triggers)
        await _persist_workflow_triggers(
            workflow_id,
            data,
            updated_triggers,
        )

        from flocks.ingest.kafka.manager import default_manager as _kafka_default_manager

        status = await _kafka_default_manager.restart_workflow(workflow_id)
        state = (status or {}).get("state")
        if req.enabled and state == "failed":
            err = (status or {}).get("error") or "consumer_connect_failed"
            raise HTTPException(
                status_code=409,
                detail=f"Kafka consumer failed to start: {err}",
            )
        return {"ok": True, "consumer": status}
    except HTTPException:
        raise
    except Exception as e:
        log.error("workflow.kafka_config.save.error", {"id": workflow_id, "error": str(e)})
        raise HTTPException(status_code=500, detail=f"Failed to save Kafka config: {str(e)}")


@router.get("/workflow/{workflow_id}/kafka-config")
async def get_kafka_config(workflow_id: str):
    """
    Get saved Kafka configuration for a workflow.
    """
    try:
        config = await WorkflowStore.get_config(workflow_id, kind="workflow_kafka_config")
        if config is None:
            data = _read_workflow_from_fs(workflow_id)
            if data:
                triggers = await _get_workflow_trigger_defs(workflow_id, data)
                trigger = next((item for item in triggers if item.type == "kafka"), None)
                if trigger is not None:
                    config = kafka_trigger_to_legacy_config(workflow_id, trigger)
        return config  # None / null if not configured
    except Exception as e:
        log.error("workflow.kafka_config.get.error", {"id": workflow_id, "error": str(e)})
        raise HTTPException(status_code=500, detail=f"Failed to get Kafka config: {str(e)}")


@router.get("/workflow/{workflow_id}/kafka-status")
async def get_kafka_status(workflow_id: str):
    """Return the *runtime* status of the Kafka consumer for a workflow.

    Reflects the actual connection state (connecting/running/failed/stopped) and
    queue depth so the UI can show whether a saved-but-not-yet-connected
    consumer is actually running.  The persisted config only captures *intent*.
    """
    try:
        from flocks.ingest.kafka.manager import default_manager as _kafka_default_manager

        return _kafka_default_manager.get_consumer_status(workflow_id)
    except Exception as e:
        log.error("workflow.kafka_status.get.error", {"id": workflow_id, "error": str(e)})
        raise HTTPException(status_code=500, detail=f"Failed to get Kafka status: {str(e)}")


@router.post("/workflow/{workflow_id}/poller-config")
async def save_workflow_poller_config(workflow_id: str, req: WorkflowPollerConfigRequest):
    """Save background poller configuration for a workflow."""
    # The trigger lives in the definition, which a managed workflow does not let us rewrite.
    _refuse_managed_workflow_change(workflow_id)
    try:
        data = _read_workflow_from_fs(workflow_id)
        if not data:
            raise HTTPException(status_code=404, detail=f"Workflow not found: {workflow_id}")

        if req.enabled:
            try:
                validate_workflow_python(data.get("workflowJson") or {})
            except Exception as exc:
                raise HTTPException(status_code=400, detail=str(exc)) from exc
        cron_expression = (req.cronExpression or "").strip()
        if cron_expression:
            # Validate before anything is persisted; a bad expression must not
            # leave an enabled config behind that fails on every restart.
            _validate_cron_expression(cron_expression)
        trigger_source: Dict[str, Any]
        if cron_expression:
            trigger_source = {
                "mode": "cron",
                "intervalSeconds": req.intervalSeconds,
                "cron": cron_expression,
            }
        else:
            trigger_source = {
                "mode": "interval",
                "intervalSeconds": req.intervalSeconds,
            }

        config = {
            "workflowId": workflow_id,
            "enabled": req.enabled,
            "intervalSeconds": req.intervalSeconds,
            "cronExpression": cron_expression or None,
            "timeoutSeconds": req.timeoutSeconds,
            "noOverlap": req.noOverlap,
            "inputs": req.inputs,
            "updatedAt": int(time.time() * 1000),
        }
        await WorkflowStore.put_config(workflow_id, config, kind="workflow_poller_config")
        triggers = await _get_workflow_trigger_defs(workflow_id, data)
        unified_trigger = TriggerDefinition.model_validate(
            {
                "id": _legacy_singleton_trigger_id(triggers, "schedule"),
                "type": "schedule",
                "enabled": req.enabled,
                "source": trigger_source,
                "runtime": {
                    "timeoutSeconds": req.timeoutSeconds,
                    "noOverlap": req.noOverlap,
                },
                "inputs": req.inputs,
                "updatedAt": config["updatedAt"],
            }
        )
        updated_triggers = _replace_or_append_trigger(triggers, unified_trigger)
        _validate_trigger_type_constraints(updated_triggers)
        await _persist_workflow_triggers(
            workflow_id,
            data,
            updated_triggers,
        )

        from flocks.workflow.poller_manager import default_manager as _poller_default_manager

        poller_status = await _poller_default_manager.restart_workflow(workflow_id)
        if req.enabled and (poller_status or {}).get("state") == "failed":
            err = (poller_status or {}).get("error") or "poller_start_failed"
            raise HTTPException(
                status_code=409,
                detail=f"Workflow poller failed to start: {err}",
            )
        return {"ok": True, "status": poller_status}
    except HTTPException:
        raise
    except Exception as e:
        log.error("workflow.poller_config.save.error", {"id": workflow_id, "error": str(e)})
        raise HTTPException(status_code=500, detail=f"Failed to save poller config: {str(e)}")


@router.get("/workflow/{workflow_id}/poller-config")
async def get_workflow_poller_config(workflow_id: str):
    """Get saved poller configuration for a workflow."""
    try:
        config = await WorkflowStore.get_config(workflow_id, kind="workflow_poller_config")
        if config is None:
            data = _read_workflow_from_fs(workflow_id)
            if data:
                triggers = await _get_workflow_trigger_defs(workflow_id, data)
                trigger = next((item for item in triggers if item.type == "schedule"), None)
                if trigger is not None:
                    config = schedule_trigger_to_legacy_config(workflow_id, trigger)
        return config
    except Exception as e:
        log.error("workflow.poller_config.get.error", {"id": workflow_id, "error": str(e)})
        raise HTTPException(status_code=500, detail=f"Failed to get poller config: {str(e)}")


@router.get("/workflow/{workflow_id}/poller-status")
async def get_workflow_poller_status(workflow_id: str):
    """Return the runtime status of a workflow poller."""
    try:
        from flocks.workflow.poller_manager import default_manager as _poller_default_manager

        return _poller_default_manager.get_status(workflow_id)
    except Exception as e:
        log.error("workflow.poller_status.get.error", {"id": workflow_id, "error": str(e)})
        raise HTTPException(status_code=500, detail=f"Failed to get poller status: {str(e)}")


@router.post("/workflow/{workflow_id}/poller-run-once")
async def run_workflow_poller_once(workflow_id: str):
    """Trigger one immediate poller execution for a workflow."""
    try:
        data = _read_workflow_from_fs(workflow_id)
        if not data:
            raise HTTPException(status_code=404, detail=f"Workflow not found: {workflow_id}")

        from flocks.workflow.poller_manager import default_manager as _poller_default_manager

        poller_status = await _poller_default_manager.run_once(workflow_id)
        return {"ok": True, "status": poller_status}
    except HTTPException:
        raise
    except Exception as e:
        log.error("workflow.poller_run_once.error", {"id": workflow_id, "error": str(e)})
        raise HTTPException(status_code=500, detail=f"Failed to run workflow poller once: {str(e)}")


@router.post("/workflow/{workflow_id}/syslog-config")
async def save_syslog_config(workflow_id: str, req: SyslogConfigRequest):
    """
    Save syslog listener configuration for a workflow.

    When ``enabled`` is true, this also (re)starts the UDP/TCP listener and
    blocks until the underlying socket has either bound successfully or the
    bind has failed (e.g. ``EADDRINUSE``, invalid host).  Bind failures are
    surfaced as ``409 Conflict`` so the UI can show an actionable error
    instead of falsely claiming "Listening".
    """
    # The trigger lives in the definition, which a managed workflow does not let us rewrite.
    _refuse_managed_workflow_change(workflow_id)
    try:
        data = _read_workflow_from_fs(workflow_id)
        if not data:
            raise HTTPException(status_code=404, detail=f"Workflow not found: {workflow_id}")

        if req.enabled:
            try:
                validate_workflow_python(data.get("workflowJson") or {})
            except Exception as exc:
                raise HTTPException(status_code=400, detail=str(exc)) from exc
        config = {
            "workflowId": workflow_id,
            "enabled": req.enabled,
            "protocol": req.protocol,
            "host": req.host,
            "port": req.port,
            "format": req.msg_format,
            "inputKey": req.input_key,
            "updatedAt": int(time.time() * 1000),
        }
        await WorkflowStore.put_config(workflow_id, config, kind="workflow_syslog_config")
        triggers = await _get_workflow_trigger_defs(workflow_id, data)
        unified_trigger = TriggerDefinition.model_validate(
            {
                "id": _legacy_singleton_trigger_id(triggers, "syslog"),
                "type": "syslog",
                "enabled": req.enabled,
                "source": {
                    "protocol": req.protocol,
                    "host": req.host,
                    "port": req.port,
                    "format": req.msg_format,
                },
                "mapping": {
                    req.input_key or "syslog_message": "$.body",
                },
                "updatedAt": config["updatedAt"],
            }
        )
        updated_triggers = _replace_or_append_trigger(triggers, unified_trigger)
        _validate_trigger_type_constraints(updated_triggers)
        await _persist_workflow_triggers(
            workflow_id,
            data,
            updated_triggers,
        )

        from flocks.ingest.syslog.manager import default_manager as _syslog_default_manager

        status = await _syslog_default_manager.restart_workflow(workflow_id)
        state = (status or {}).get("state")
        if req.enabled and state == "failed":
            err = (status or {}).get("error") or "listener_bind_failed"
            raise HTTPException(
                status_code=409,
                detail=f"Syslog listener failed to bind: {err}",
            )
        return {"ok": True, "listener": status}
    except HTTPException:
        raise
    except Exception as e:
        log.error("workflow.syslog_config.save.error", {"id": workflow_id, "error": str(e)})
        raise HTTPException(status_code=500, detail=f"Failed to save syslog config: {str(e)}")


@router.get("/workflow/{workflow_id}/syslog-config")
async def get_syslog_config(workflow_id: str):
    """Get saved syslog configuration for a workflow."""
    try:
        config = await WorkflowStore.get_config(workflow_id, kind="workflow_syslog_config")
        if config is None:
            data = _read_workflow_from_fs(workflow_id)
            if data:
                triggers = await _get_workflow_trigger_defs(workflow_id, data)
                trigger = next((item for item in triggers if item.type == "syslog"), None)
                if trigger is not None:
                    config = syslog_trigger_to_legacy_config(workflow_id, trigger)
        return config
    except Exception as e:
        log.error("workflow.syslog_config.get.error", {"id": workflow_id, "error": str(e)})
        raise HTTPException(status_code=500, detail=f"Failed to get syslog config: {str(e)}")


@router.get("/workflow/{workflow_id}/syslog-status")
async def get_syslog_status(workflow_id: str):
    """Return the *runtime* status of the syslog listener for a workflow.

    This reflects the actual bind state (binding/listening/failed/stopped) and
    queue depth, so the UI can show whether a saved-but-not-yet-bound listener
    is actually running.  The persisted config (``/syslog-config``) only
    captures *intent*, which is why the UI must consult this endpoint to
    truthfully render "Listening".
    """
    try:
        from flocks.ingest.syslog.manager import default_manager as _syslog_default_manager

        return _syslog_default_manager.get_listener_status(workflow_id)
    except Exception as e:
        log.error("workflow.syslog_status.get.error", {"id": workflow_id, "error": str(e)})
        raise HTTPException(status_code=500, detail=f"Failed to get syslog status: {str(e)}")


# =============================================================================
# API Endpoints - Run Single Node
# =============================================================================


class RunNodeRequest(BaseModel):
    """Request to execute a single workflow node."""

    model_config = ConfigDict(populate_by_name=True)

    node_id: str = Field(..., description="Node ID to execute")
    inputs: Dict[str, Any] = Field(default_factory=dict, description="Input data for the node")
    session_id: Optional[str] = Field(None, alias="sessionId", description="Optional parent session ID")
    message_id: Optional[str] = Field(None, alias="messageId", description="Optional parent message ID")
    agent: Optional[str] = Field(None, description="Optional agent name for tool context")


class RunNodeResponse(BaseModel):
    """Response from executing a single workflow node."""

    model_config = ConfigDict(populate_by_name=True)

    node_id: str
    outputs: Dict[str, Any] = Field(default_factory=dict)
    stdout: str = ""
    error: Optional[str] = None
    traceback: Optional[str] = None
    duration_ms: Optional[float] = None
    success: bool = True


@router.post("/workflow/{workflow_id}/run-node", response_model=RunNodeResponse)
async def run_single_node(workflow_id: str, req: RunNodeRequest):
    """
    Execute a single workflow node in isolation.

    Runs one node with the provided inputs and returns its outputs.
    Intended for step-by-step testing and debugging by agents.
    """
    try:
        data = _read_workflow_from_fs(workflow_id)
        if not data:
            raise HTTPException(status_code=404, detail=f"Workflow not found: {workflow_id}")

        workflow_json = data["workflowJson"]
        tool_context = await _build_workflow_tool_context(
            workflow_id=workflow_id,
            action_name=f"run-node:{req.node_id}",
            session_id=req.session_id,
            message_id=req.message_id,
            agent=req.agent,
        )

        try:
            from flocks.workflow.models import Workflow as WfModel
            from flocks.workflow.engine import WorkflowEngine
            from flocks.workflow.runner import WorkflowSandboxUnavailable, workflow_python_runtime

            wf = WfModel.from_dict(workflow_json)
            try:
                # The same runtime rule as a whole run: in the sandbox when one is
                # required, refused when it is not there.  Off the event loop:
                # finding the sandbox can mean starting a container (or pulling
                # its image), and the server's other requests and lease renewals
                # must not wait for that.
                runtime = await asyncio.to_thread(
                    workflow_python_runtime,
                    tool_context,
                    tool_registry=get_tool_registry(tool_context=tool_context),
                )
            except WorkflowSandboxUnavailable as exc:
                raise HTTPException(status_code=409, detail=str(exc)) from exc
            engine = WorkflowEngine(wf, runtime=runtime)

            register_primary_loop()
            step_result = await asyncio.to_thread(engine.run_node, req.node_id, req.inputs)

            log.info(
                "workflow.run_node",
                {
                    "workflow_id": workflow_id,
                    "node_id": req.node_id,
                    "success": step_result.error is None,
                    "duration_ms": step_result.duration_ms,
                },
            )

            return RunNodeResponse(
                node_id=step_result.node_id,
                outputs=step_result.outputs,
                stdout=step_result.stdout or "",
                error=step_result.error,
                traceback=step_result.traceback,
                duration_ms=step_result.duration_ms,
                success=step_result.error is None,
            )
        except KeyError as e:
            raise HTTPException(status_code=400, detail=f"Node not found: {e}")
        except HTTPException:
            raise
        except Exception as e:
            log.error("workflow.run_node.error", {"workflow_id": workflow_id, "node_id": req.node_id, "error": str(e)})
            return RunNodeResponse(
                node_id=req.node_id,
                outputs={},
                error=str(e),
                success=False,
            )
    except HTTPException:
        raise
    except Exception as e:
        log.error("workflow.run_node.fatal", {"workflow_id": workflow_id, "error": str(e)})
        raise HTTPException(status_code=500, detail=f"Failed to run node: {str(e)}")


# =============================================================================
# API Endpoints - Sample Inputs
# =============================================================================


class SampleInputsRequest(BaseModel):
    """Request to save sample inputs for a workflow."""

    model_config = ConfigDict(populate_by_name=True)

    sampleInputs: Dict[str, Any] = Field(default_factory=dict, description="Sample input data")


@router.get("/workflow/{workflow_id}/sample-inputs")
async def get_sample_inputs(workflow_id: str):
    """
    Get saved sample inputs for a workflow.

    Sample inputs are stored in workflowJson.metadata.sampleInputs and used
    to pre-populate the Run tab test form.
    """
    try:
        data = _read_workflow_from_fs(workflow_id)
        if not data:
            raise HTTPException(status_code=404, detail=f"Workflow not found: {workflow_id}")

        workflow_json = data.get("workflowJson", {})
        metadata = workflow_json.get("metadata") or {}
        sample_inputs = metadata.get("sampleInputs", {})
        return {"sampleInputs": sample_inputs}
    except HTTPException:
        raise
    except Exception as e:
        log.error("workflow.sample_inputs.get.error", {"id": workflow_id, "error": str(e)})
        raise HTTPException(status_code=500, detail=f"Failed to get sample inputs: {str(e)}")


@router.post("/workflow/{workflow_id}/sample-inputs")
async def save_sample_inputs(workflow_id: str, req: SampleInputsRequest):
    """
    Save sample inputs for a workflow.

    Persists sample inputs into workflowJson.metadata.sampleInputs so they
    survive server restarts and are available for pre-filling the Run tab.
    """
    try:
        _refuse_managed_workflow_change(workflow_id)
        data = _read_workflow_from_fs(workflow_id)
        if not data:
            raise HTTPException(status_code=404, detail=f"Workflow not found: {workflow_id}")

        workflow_json = data.get("workflowJson", {})
        if "metadata" not in workflow_json or workflow_json["metadata"] is None:
            workflow_json["metadata"] = {}
        workflow_json["metadata"]["sampleInputs"] = req.sampleInputs

        meta = {
            k: v
            for k, v in data.items()
            if k not in ("workflowJson", "markdownContent", "editMarkdownContent", "stats", "source", "group_readonly")
        }
        meta["updatedAt"] = int(time.time() * 1000)
        markdown_content = data.get("markdownContent")
        is_global = data.get("source") == "global"
        _write_workflow_to_fs(
            workflow_id,
            workflow_json,
            meta,
            markdown_content,
            global_store=is_global,
        )

        log.info("workflow.sample_inputs.saved", {"id": workflow_id})
        return {"ok": True}
    except HTTPException:
        raise
    except Exception as e:
        log.error("workflow.sample_inputs.save.error", {"id": workflow_id, "error": str(e)})
        raise HTTPException(status_code=500, detail=f"Failed to save sample inputs: {str(e)}")


@router.get("/soc-workspace/diagnostics")
async def export_soc_workspace_diagnostics(user=Depends(require_admin)):
    """Admin-only, payload-free support bundle. Does not restart or run workflows."""
    from fastapi.responses import JSONResponse
    from flocks.workflow import soc_diagnostics
    from flocks.ingest.syslog.manager import default_manager as syslog
    from flocks.workflow.poller_manager import default_manager as poller

    states = {}
    for wf in soc_diagnostics.WORKFLOWS:
        listener = syslog.get_listener_status(wf)
        schedule = poller.get_status(wf)
        states[wf] = {
            "syslog": {k: listener.get(k) for k in ("state", "port", "protocol", "queueSize", "queueCapacity", "workerCount", "dispatchState", "dispatchRetryAt", "sqlite_errorcode", "sqlite_errorname")},
            "schedule": {k: schedule.get(k) for k in ("state", "activeRuns", "lastRunAt", "lastStatus", "lastDurationMs", "nextRunAt", "lastRunId")},
            "listener_task_alive": bool(syslog._tasks.get(wf) and not syslog._tasks[wf].done()),
            "poller_task_alive": bool(poller._tasks.get(wf) and not poller._tasks[wf].done()),
            "listener_has_error": bool(listener.get("error")),
            "dispatch_has_error": bool(listener.get("dispatchError")),
            "schedule_has_error": bool(schedule.get("error") or schedule.get("lastError")),
            "previous_run_still_active": schedule.get("lastError") == "previous_run_still_active",
        }
    try:
        bundle = await asyncio.wait_for(asyncio.to_thread(soc_diagnostics.export_bundle), timeout=15)
    except (OSError, TimeoutError):
        raise HTTPException(503, "SOC 诊断导出暂时不可用，请直接收集 soc-workspace-diagnostics.jsonl 及轮转文件") from None
    bundle["trigger_runtime"] = states
    return JSONResponse(bundle, headers={
        "Content-Disposition": f'attachment; filename="soc-workspace-diagnostics-{int(time.time())}.json"',
        "Cache-Control": "no-store",
    })
