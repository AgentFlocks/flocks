"""Public progress from the model's text stream; private reasoning stays private."""
from contextvars import ContextVar
import json
import time
from types import SimpleNamespace

progress_callback = ContextVar('monitor_progress', default=None)


def public_progress(document):
    """Read only a top-level reason string, including its complete JSON escapes."""
    text = document.lstrip()
    if text.startswith('```json'):
        text = text[7:].lstrip()
    elif text.startswith('```'):
        text = text[3:].lstrip()
    if not text.startswith('{'):
        return ''
    decoder = json.JSONDecoder()
    pos = 1
    try:
        while True:
            while pos < len(text) and text[pos] in ' \r\n\t,':
                pos += 1
            key, pos = decoder.raw_decode(text, pos)
            while pos < len(text) and text[pos].isspace():
                pos += 1
            if text[pos] != ':':
                return ''
            pos += 1
            while pos < len(text) and text[pos].isspace():
                pos += 1
            if key == 'reason' and text[pos] == '"':
                start = pos + 1
                pos = start
                while pos < len(text):
                    if text[pos] == '"':
                        break
                    if text[pos] == '\\':
                        width = 6 if pos + 1 < len(text) and text[pos + 1] == 'u' else 2
                        if pos + width > len(text):
                            break
                        pos += width
                    else:
                        pos += 1
                value = json.loads('"' + text[start:pos] + '"')
                # A provider may split a surrogate pair between chunks.
                return ''.join(c for c in value[:600] if not 0xD800 <= ord(c) <= 0xDFFF)
            _, pos = decoder.raw_decode(text, pos)
    except (ValueError, IndexError):
        return ''


async def decision_response(provider, model_id, messages, **options):
    callback = progress_callback.get()
    if callback is None or not callable(getattr(provider, 'chat_stream', None)):
        return await provider.chat(model_id, messages, **options)
    content, finish, usage, tools = '', None, {}, []
    shown, last_publish = '', 0
    async for chunk in provider.chat_stream(model_id, messages, **options):
        if chunk.finish_reason:
            finish = chunk.finish_reason
        if chunk.usage:
            usage = chunk.usage
        if chunk.tool_calls:
            tools.extend(chunk.tool_calls)
        # Never forward reasoning, tool input, raw JSON or other private fields.
        if chunk.event_type not in (None, 'text', 'text-delta') or not chunk.delta:
            continue
        content += chunk.delta
        if len(content) > 100_000:
            raise ValueError('Monitoring model response exceeded its bounded document size')
        visible = public_progress(content)
        stamp = time.monotonic()
        if visible and visible != shown and (not shown or stamp - last_publish >= .05):
            await callback(visible)
            shown, last_publish = visible, stamp
    visible = public_progress(content)
    if visible and visible != shown:
        await callback(visible)
    return SimpleNamespace(content=content, finish_reason=finish, usage=usage, tool_calls=tools)
