"""Parse syslog lines (RFC 5424, RFC 3164, and Sangfor SE) without external deps."""

from __future__ import annotations

import re
from datetime import datetime
from typing import Any, Dict, Optional

from flocks.ingest.syslog.sangfor import VARIANTS, decode_se_json

_PRI_RE = re.compile(r"^<(\d{1,3})>")
# After stripping PRI: MMM DD hh:mm:ss hostname tag: msg
_RFC3164_REST_RE = re.compile(
    r"^([A-Za-z]{3}\s+\d{1,2}\s+\d{2}:\d{2}:\d{2})\s+(\S+)\s*(.*)$",
    re.DOTALL,
)
# Non-standard but common: <PRI>ISO_TS HOSTNAME APP[PID]: msg  (no RFC5424 version)
_ISO3164_REST_RE = re.compile(
    r"^(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:[+-]\d{2}:\d{2}|Z)?)"
    r"\s+(\S+)"                                                           # hostname
    r"\s+(\S+?)\s*:\s*"                                                   # app_name/tag:
    r"([\s\S]*)$",                                                        # message
    re.DOTALL,
)
_SE_ISO_TS_RE = re.compile(
    r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})?"
)
_SE_SPACE_TS_RE = re.compile(r"\d{4}-\d{2}-\d{2}\s+\d{2}:\s*\d{2}:\s*\d{2}")
# BSD TAG with process id: "sshd[1234]" -> app_name=sshd, pid=1234
_TAG_PID_RE = re.compile(r"^(.+?)\[([^\[\]]+)\]$")


def _split_tag_pid(tag: str) -> tuple[str, str]:
    """Split ``app[pid]`` into ``(app, pid)``; a bare tag yields ``pid == ""``."""
    m = _TAG_PID_RE.match(tag.strip())
    if not m:
        return tag.strip(), ""
    return m.group(1).strip(), m.group(2).strip()


def _pri_parts(pri: int) -> tuple[int, int]:
    facility = pri >> 3
    severity = pri & 7
    return facility, severity


def _normalize_ts(ts: Optional[str]) -> str:
    if not ts:
        return ""
    ts = ts.strip()
    # RFC5424 full-date
    if "T" in ts:
        try:
            # Zulu
            if ts.endswith("Z"):
                return datetime.fromisoformat(ts.replace("Z", "+00:00")).isoformat()
            return datetime.fromisoformat(ts).isoformat()
        except ValueError:
            return ts
    # RFC3164: Oct 11 22:14:15 (no year — use current year best-effort)
    try:
        now = datetime.now()
        dt = datetime.strptime(f"{now.year} {ts}", "%Y %b %d %H:%M:%S")
        return dt.isoformat()
    except ValueError:
        return ts


def parse_syslog(raw: str, format_hint: str = "auto") -> Dict[str, Any]:
    """
    Parse one syslog payload into a dict suitable for workflow inputs.

    format_hint: "auto" | "rfc3164" | "rfc5424" | "se"
    """
    text = raw.decode("utf-8", errors="replace") if isinstance(raw, (bytes, bytearray)) else raw
    original_text = text
    text = text.strip()
    if not text:
        return {
            "raw": text,
            "facility": 0,
            "severity": 0,
            "timestamp": "",
            "hostname": "",
            "app_name": "",
            "message": "",
            "format": "empty",
        }

    m_pri = _PRI_RE.match(text)
    if not m_pri:
        if format_hint == "se" or (format_hint == "auto" and _looks_like_se(text)):
            return _parse_se(text, raw=original_text, facility=1, severity=6)
        if format_hint in ("auto", "rfc3164"):
            iso = _ISO3164_REST_RE.match(text)
            if iso:
                return _parse_iso3164(iso, raw=original_text, facility=0, severity=0)
        return {
            "raw": text,
            "facility": 0,
            "severity": 0,
            "timestamp": "",
            "hostname": "",
            "app_name": "",
            "message": text,
            "format": "unparsed",
        }

    pri = int(m_pri.group(1))
    facility, severity = _pri_parts(pri)
    rest = text[m_pri.end() :]

    if format_hint == "se" or (format_hint == "auto" and _looks_like_se(rest)):
        return _parse_se(rest, raw=original_text, facility=facility, severity=severity)
    if format_hint == "rfc3164":
        return _parse_rfc3164(rest, raw=text, facility=facility, severity=severity)
    if format_hint == "rfc5424":
        return _parse_rfc5424(rest, raw=text, facility=facility, severity=severity)

    # auto: RFC5424 if second token is a single digit version number
    if rest and rest[0].isdigit():
        first_space = rest.find(" ")
        if first_space > 0 and rest[:first_space].isdigit():
            return _parse_rfc5424(rest, raw=text, facility=facility, severity=severity)

    return _parse_rfc3164(rest, raw=text, facility=facility, severity=severity)


def _looks_like_se(rest: str) -> bool:
    parts = rest.strip().split("|!", 3)
    return len(parts) == 4 and parts[1].strip() in VARIANTS


def _normalize_se_ts(prefix: str) -> str:
    iso_match = _SE_ISO_TS_RE.search(prefix)
    if iso_match:
        return _normalize_ts(iso_match.group(0))
    space_match = _SE_SPACE_TS_RE.search(prefix)
    if space_match:
        timestamp = re.sub(r"\s*:\s*", ":", space_match.group(0))
        try:
            return datetime.fromisoformat(timestamp).isoformat()
        except ValueError:
            pass
    return prefix.strip()


def _parse_se(
    rest: str,
    *,
    raw: str,
    facility: int,
    severity: int,
) -> Dict[str, Any]:
    parts = rest.strip().split("|!", 3)
    if len(parts) != 4:
        return {
            "raw": raw,
            "facility": facility,
            "severity": severity,
            "timestamp": "",
            "hostname": "",
            "app_name": "",
            "message": rest.strip(),
            "format": "se",
            "log_type": "",
            "client_ip": "",
            "data": None,
            "parse_status": "error",
            "parse_error": "SE envelope must contain timestamp, log type, device IP and JSON body",
        }

    timestamp, log_type, client_ip, message = (part.strip() for part in parts)
    parse_error = ""
    try:
        if log_type not in VARIANTS:
            raise ValueError(f"Unsupported SE log type: {log_type}")
        message, data = decode_se_json(message)
    except (ValueError, TypeError) as exc:
        data = None
        parse_error = str(exc)

    return {
        "raw": raw,
        "facility": facility,
        "severity": severity,
        "timestamp": _normalize_se_ts(timestamp),
        "hostname": client_ip,
        "app_name": log_type,
        "message": message,
        "format": "se",
        "log_type": log_type,
        "client_ip": client_ip,
        "data": data,
        "parse_status": "error" if parse_error else "ok",
        "parse_error": parse_error,
    }


def _next_rfc5424_token(s: str) -> tuple[str, str]:
    """Pop one syslog field from *s*; structured data may start with '['."""
    s = s.lstrip()
    if not s:
        return "", ""
    if s[0] == "[":
        depth = 0
        for j, c in enumerate(s):
            if c == "[":
                depth += 1
            elif c == "]":
                depth -= 1
                if depth == 0:
                    return s[: j + 1], s[j + 1 :].lstrip()
        return s, ""
    sp = s.find(" ")
    if sp == -1:
        return s, ""
    return s[:sp], s[sp + 1 :].lstrip()


def _parse_rfc5424(
    rest: str,
    *,
    raw: str,
    facility: int,
    severity: int,
) -> Dict[str, Any]:
    s = rest.lstrip()
    if not s:
        return _parse_rfc3164(rest, raw=raw, facility=facility, severity=severity)

    i = 0
    while i < len(s) and s[i].isdigit():
        i += 1
    version = s[:i].strip()
    s = s[i:].lstrip()
    if not version.isdigit():
        return _parse_rfc3164(rest, raw=raw, facility=facility, severity=severity)

    ts, s = _next_rfc5424_token(s)
    hostname, s = _next_rfc5424_token(s)
    app_name, s = _next_rfc5424_token(s)
    procid, s = _next_rfc5424_token(s)
    _msgid, s = _next_rfc5424_token(s)
    _sdata, s = _next_rfc5424_token(s)
    msg = s.strip()

    parsed: Dict[str, Any] = {
        "raw": raw,
        "facility": facility,
        "severity": severity,
        "timestamp": _normalize_ts(ts),
        "hostname": hostname if hostname != "-" else "",
        "app_name": app_name if app_name != "-" else "",
        "message": msg,
        "format": "rfc5424",
    }
    if procid and procid != "-":
        parsed["pid"] = procid
    return parsed


def _parse_iso3164(
    m: "re.Match[str]",
    *,
    raw: str,
    facility: int,
    severity: int,
) -> Dict[str, Any]:
    """Handle non-standard <PRI>ISO_TS HOSTNAME APP[PID]: msg (no RFC5424 version)."""
    app_name, pid = _split_tag_pid(m.group(3))
    parsed: Dict[str, Any] = {
        "raw": raw,
        "facility": facility,
        "severity": severity,
        "timestamp": _normalize_ts(m.group(1)),
        "hostname": m.group(2),
        "app_name": app_name,
        "message": m.group(4).strip(),
        "format": "iso3164",
    }
    if pid:
        parsed["pid"] = pid
    return parsed


def _parse_rfc3164(
    rest: str,
    *,
    raw: str,
    facility: int,
    severity: int,
) -> Dict[str, Any]:
    # Forwarders commonly use an ISO timestamp with a BSD TAG rather than a
    # versioned RFC5424 header. Recognize it even when the listener explicitly
    # selects rfc3164, or whitespace follows PRI. Never search for arbitrary
    # JSON: only remove a complete, recognized syslog envelope.
    iso = _ISO3164_REST_RE.match(rest.strip())
    if iso:
        return _parse_iso3164(iso, raw=raw, facility=facility, severity=severity)
    m = _RFC3164_REST_RE.match(rest.strip())
    if m:
        ts = m.group(1)
        hostname = m.group(2)
        remainder = (m.group(3) or "").strip()
        app_name = ""
        pid = ""
        message = remainder
        # TAG: message (tag is alphanumeric, often "sshd" or "su"; BSD
        # syslog appends the process id as "sshd[1234]").
        if remainder and ":" in remainder:
            tag, _, body = remainder.partition(":")
            if tag and " " not in tag and tag.isprintable():
                app_name, pid = _split_tag_pid(tag)
                message = body.strip()
        parsed: Dict[str, Any] = {
            "raw": raw,
            "facility": facility,
            "severity": severity,
            "timestamp": _normalize_ts(ts),
            "hostname": hostname,
            "app_name": app_name,
            "message": message,
            "format": "rfc3164",
        }
        if pid:
            parsed["pid"] = pid
        return parsed

    return {
        "raw": raw,
        "facility": facility,
        "severity": severity,
        "timestamp": "",
        "hostname": "",
        "app_name": "",
        "message": rest.strip(),
        "format": "rfc3164",
    }
