"""Bounded, credential-scrubbed task evidence and read-only agent diagnosis."""
from __future__ import annotations

import asyncio
from collections import OrderedDict
from datetime import datetime, timedelta, timezone
import hashlib
import json
from pathlib import Path
import re
import time

from flocks.utils.log import get_log_dir, scrub_credentials

AGENT = "flocks-troubleshooter"
MAX_FILES = 8
MAX_BYTES = 512 * 1024
_CACHE: OrderedDict = OrderedDict()
_PENDING: dict = {}


def clean(value, limit=2500):
    # Scrub before truncating: cutting a credential in half can defeat patterns.
    return scrub_credentials(str(value or ""))[:limit]


def collect_evidence(execution, log_root=None):
    root = Path(log_root or get_log_dir()).resolve()
    dates = set()
    for stamp in (execution.started_at, execution.completed_at, execution.updated_at):
        if stamp:
            for delta in (-1, 0, 1):
                dates.add((stamp + timedelta(days=delta)).date().isoformat())
    identifiers = [value for value in (execution.id, execution.session_id) if value and len(value) >= 8]
    patterns = [re.compile(r"(?<![\w-])" + re.escape(value) + r"(?![\w-])") for value in identifiers]
    evidence = []
    if execution.error:
        evidence.append({"id": "E1", "source": "任务失败记录", "text": clean(execution.error, 6000)})
    scope = {"filesScanned": 0, "matchedLines": 0, "tailLimitedFiles": 0,
             "unreadableFiles": 0, "dates": sorted(dates), "limit": "最多8个日志文件，每个只读末尾512KB，最多20条关联记录"}
    candidates = []
    # Only daily flocks logs and legacy timestamp logs. Never follow symlinks.
    for day in sorted(dates, reverse=True):
        directory = root / day
        if directory.is_dir() and not directory.is_symlink():
            candidates.extend(sorted(directory.glob("*.log*"), reverse=True)[:MAX_FILES])
        candidates.extend(sorted(root.glob(day + "T*.log*"), reverse=True)[:MAX_FILES])
    for path in candidates[:MAX_FILES]:
        if path.is_symlink() or not path.is_file() or not path.resolve().is_relative_to(root):
            continue
        try:
            size = path.stat().st_size
            with path.open("rb") as stream:
                offset = max(0, size - MAX_BYTES)
                stream.seek(offset)
                raw = stream.read(MAX_BYTES)
            if offset:
                scope["tailLimitedFiles"] += 1
                raw = raw.partition(b"\n")[2]
            scope["filesScanned"] += 1
            for line in reversed(raw.decode("utf-8", errors="replace").splitlines()):
                if any(pattern.search(line) for pattern in patterns):
                    scope["matchedLines"] += 1
                    if len(evidence) < (21 if execution.error else 20):
                        evidence.append({"id": f"E{len(evidence)+1}", "source": str(path.relative_to(root)), "text": clean(line)})
        except OSError:
            scope["unreadableFiles"] += 1
    return {"evidence": evidence, "scope": scope}


def basic_result(execution, bundle, reason):
    text = (execution.error or "").lower()
    summary = "任务没有完成，目前的记录还不足以确认具体原因。"
    blocker = "需要结合失败步骤和相关日志进一步确认。"
    steps = ["核对下方排查依据，补充失败步骤的日志，再决定是否重试。"]
    recognized = False
    rules = [
        (("modulenotfounderror", "no module named"), "任务需要的程序组件没有找到，所以工作流无法继续。", "加载程序组件时就被阻断，尚不能完成后续处理。", "请管理员核对完整报错里的组件名称，确认当前安装的补丁与基础版本配套、相关文件已完整部署；不要盲目重试。"),
        (("no space left", "磁盘空间不足", "errno 28"), "任务要保存文件时，磁盘没有足够空间，无法继续。", "文件写入被阻断。", "检查任务目录所在磁盘的剩余空间，请管理员确认可清理的内容。"),
        (("timeout", "timed out", "超时"), "任务等待外部服务返回结果，但超过了允许等待的时间。", "未能按时拿到响应；仅凭超时不能确定是网络还是服务本身的问题。", "先核对报错中对应的服务是否可访问，再检查该服务同一时间的日志。"),
        (("401", "unauthorized", "认证失败"), "任务访问服务时，身份认证没有通过。", "服务未接受本次认证，尚不能确定凭据失效的具体原因。", "由管理员核对对应服务的凭据配置和认证日志；不要在对话中粘贴密钥。"),
        (("403", "forbidden", "permission denied", "权限不足"), "任务访问所需资源时被拒绝，无法继续。", "当前账号或进程没有获得本次操作所需的访问权限。", "请管理员核对报错对应资源的访问权限。"),
        (("connection refused", "连接被拒绝"), "任务尝试连接服务时，对方拒绝了连接。", "尚未建立到目标服务的连接。", "核对目标地址、端口和服务运行状态。"),
        (("model not found", "模型不存在"), "任务需要的模型当前无法找到，不能继续分析。", "模型选择或配置没有匹配到可用模型。", "在模型管理中核对任务使用的模型及其 Provider。"),
    ]
    for needles, summary_text, blocker_text, next_step in rules:
        if any((re.search(r"(?<!\d)" + needle + r"(?!\d)", text) if needle.isdigit() else needle in text) for needle in needles):
            summary, blocker, steps = summary_text, blocker_text, [next_step]
            recognized = True
            break
    return {"recognized": recognized, "mode": "basic", "summary": summary, "blocker": blocker, "nextSteps": steps,
            "uncertainty": reason + " 以上为报错基础解读，根因仍需核实。", "evidenceIDs": [e["id"] for e in bundle["evidence"][:1]]}


async def analyze(execution, bundle, model_override=None):
    from flocks.agent.registry import Agent
    from flocks.config.config import Config
    from flocks.provider.provider import Provider, ChatMessage

    agent = await Agent.get(AGENT)
    if agent is None or agent.hidden:
        return basic_result(execution, bundle, "排障助手未启用，未发起模型调查。")
    selected = agent.model
    model = model_override or ({"provider_id": selected.provider_id, "model_id": selected.model_id} if selected else await Config.resolve_default_llm())
    if not model:
        return basic_result(execution, bundle, "尚未配置可用模型。")
    provider = Provider.get(model["provider_id"])
    if not provider:
        return basic_result(execution, bundle, "配置的模型服务当前不可用。")
    if model_override and Provider.resolve_model(model["provider_id"], model["model_id"]) is None:
        return basic_result(execution, bundle, "所选模型当前未配置或已被移除，请重新选择。")
    instruction = (agent.prompt or "") + """
本次为任务卡片调查。只输出JSON对象，不要Markdown：
{"summary":"一句话说明任务为什么停了，最多100字", "blocker":"具体卡住的步骤，最多180字", "nextSteps":["可操作建议，最多4项"], "uncertainty":"已知限制及待核实根因，最多200字", "evidenceIDs":["引用输入中确实存在的证据ID"]}
不得把可能原因写成已确认事实。没有明确的节点顺序证据时，不得说“首个节点”或断言后续步骤完全未执行。解释针对失败发生时，不代表系统当前状态；历史问题是否已恢复需另查后续执行记录。summary使用普通中文，不粘贴模块路径、错误代码和原始堆栈，技术名称仅在依据中核对。不要输出任何命令或凭据。所有判断必须引用提供的证据。没有证据时明确说无法确认。
"""
    payload = {"task": {"id": execution.id, "status": execution.status.value,
                        "startedAt": str(execution.started_at or ""), "failedAt": str(execution.completed_at or execution.updated_at),
                        "executionMode": execution.execution_mode.value}, **bundle}
    response = await asyncio.wait_for(provider.chat(model["model_id"], [
        ChatMessage(role="system", content=instruction),
        ChatMessage(role="user", content=json.dumps(payload, ensure_ascii=False)),
    ], max_tokens=1200, temperature=0.1), timeout=40)
    raw = response.content.strip()
    if raw.startswith("```"):
        raw = raw.split("\n", 1)[1].rsplit("```", 1)[0]
    result = json.loads(raw)
    known = {item["id"] for item in bundle["evidence"]}
    refs = result.get("evidenceIDs")
    steps = result.get("nextSteps")
    if (not isinstance(result.get("summary"), str) or not result["summary"].strip()
        or not isinstance(result.get("blocker"), str) or not isinstance(result.get("uncertainty"), str)
        or not isinstance(refs, list) or not refs or any(not isinstance(ref, str) or ref not in known for ref in refs)
        or not isinstance(steps, list) or not steps or any(not isinstance(item, str) for item in steps)):
        raise ValueError("Unusable diagnosis")
    # Known error classes have a narrow, plain-language direct blocker. Keep
    # the model's suggested investigation and uncertainty, without turning
    # unsupported stage/order guesses into the lead explanation.
    recorded = basic_result(execution, bundle, "")
    return {"mode": "agent", "summary": recorded["summary"] if recorded["recognized"] else clean(result["summary"], 400),
            "blocker": recorded["blocker"] if recorded["recognized"] else clean(result["blocker"], 600),
            "nextSteps": [clean(item, 400) for item in steps[:4]], "uncertainty": clean(result["uncertainty"], 600), "evidenceIDs": refs[:20]}


async def _run(execution, model_override=None):
    try:
        bundle = await asyncio.to_thread(collect_evidence, execution)
    except OSError:
        bundle = {"evidence": [{"id": "E1", "source": "任务失败记录", "text": clean(execution.error, 6000)}] if execution.error else [],
                  "scope": {"filesScanned": 0, "matchedLines": 0, "tailLimitedFiles": 0, "unreadableFiles": 1,
                            "dates": [], "limit": "日志目录暂时无法读取，本次只使用任务失败记录"}}
        result = basic_result(execution, bundle, "本次无法读取日志目录，请管理员核对日志路径和访问权限。")
    else:
        try:
            result = await analyze(execution, bundle, model_override)
        except Exception:
            # Never reflect provider errors: these can contain URLs or credentials.
            result = basic_result(execution, bundle, "模型调查未完成，可稍后重新排查。")
    if not bundle["scope"]["matchedLines"]:
        result["uncertainty"] += " 本次扫描未找到与执行ID或会话ID匹配的日志，不能排除日志轮转、过期或扫描范围限制。"
    result.pop("recognized", None)
    return {**result, **bundle, "agent": AGENT, "executionID": execution.id,
            "analyzedAt": datetime.now(timezone.utc).isoformat(),
            "notice": "此解释针对当次失败，不代表系统当前仍有相同问题。只读排查，未修改配置或重试任务；重试前请核对后续成功记录与已有部分结果。"}


async def diagnose(execution, *, refresh=False, model_override=None):
    key = hashlib.sha256(f"{execution.id}|{execution.updated_at}|{execution.error}|{json.dumps(model_override, sort_keys=True)}".encode()).hexdigest()
    if refresh:
        _CACHE.pop(key, None)
    cached = _CACHE.get(key)
    if cached and time.monotonic() - cached[0] < 1800:
        return cached[1]
    pending = _PENDING.get(key)
    if pending is None:
        if len(_PENDING) >= 4:
            from fastapi import HTTPException
            raise HTTPException(429, "正在排查的任务较多，请稍后重试")
        async def work():
            try:
                result = await _run(execution, model_override)
                # Failed model calls remain retryable instead of caching the failure.
                if result["mode"] == "agent":
                    _CACHE[key] = (time.monotonic(), result)
                    while len(_CACHE) > 128:
                        _CACHE.popitem(last=False)
                return result
            finally:
                _PENDING.pop(key, None)
        pending = _PENDING[key] = asyncio.create_task(work())
    return await asyncio.shield(pending)
