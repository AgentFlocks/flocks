"""Small read-only usage query for the Home card; never triggers historical backfill."""
from __future__ import annotations

import asyncio
import sqlite3
import threading
import time
from collections import OrderedDict
from contextlib import closing
from datetime import datetime, timezone
from pathlib import Path

from fastapi import APIRouter, HTTPException, Query, Request
from flocks.server.auth import require_user
from flocks.storage.storage import Storage

router = APIRouter()
_CACHE: OrderedDict[tuple, tuple[float, dict]] = OrderedDict()
_LOCK = threading.Lock()
_CACHE_SECONDS = 15


def utc_range(start: str, end: str) -> tuple[str, str]:
    try:
        first = datetime.fromisoformat(start.replace("Z", "+00:00"))
        last = datetime.fromisoformat(end.replace("Z", "+00:00"))
        if first.utcoffset() is None or last.utcoffset() is None:
            raise ValueError("timezone required")
        if not 0 < (last - first).total_seconds() <= 26 * 3600:
            raise ValueError("expected one calendar day")
        return (first.astimezone(timezone.utc).isoformat(timespec="seconds"),
                last.astimezone(timezone.utc).isoformat(timespec="seconds"))
    except (ValueError, TypeError) as error:
        raise HTTPException(422, "Expected timezone-aware dates spanning at most 26 hours") from error


def read_total(path: Path, start: str, end: str) -> dict:
    from flocks.enhancements.monitor_db import active
    if active():
        from flocks.db.sync_query import connect
        with connect(readonly=True, timeout=2) as db:
            total = (db.execute("SELECT COALESCE(SUM(total_tokens),0) FROM usage_records WHERE created_at::timestamptz >= ?::timestamptz AND created_at::timestamptz < ?::timestamptz", (start,end)).fetchone()[0]
                     if db.table_exists('usage_records') else 0)
        return {"total_tokens":max(0,int(total)),"as_of":datetime.now(timezone.utc).isoformat()}
    # Resolve from Storage, so custom data directories work on other machines.
    path = path.expanduser().resolve()
    with _LOCK:
        if not path.exists():
            return {"total_tokens": 0, "as_of": datetime.now(timezone.utc).isoformat()}
        identity_check = getattr(Storage, "_assert_active_db_identity", None)
        if callable(identity_check):
            identity_check(path)
        def signature(file: Path):
            try:
                info = file.stat()
                return (info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns)
            except FileNotFoundError:
                return None
        key = (str(path), start, end, signature(path), signature(path.with_name(path.name + "-wal")))
        cached = _CACHE.get(key)
        if cached and time.monotonic() - cached[0] < _CACHE_SECONDS:
            _CACHE.move_to_end(key)
            return cached[1]
        deadline = time.monotonic() + 2
        with closing(sqlite3.connect(path.as_uri() + "?mode=ro", uri=True, timeout=0.25)) as conn:
            conn.execute("PRAGMA query_only = ON")
            conn.set_progress_handler(lambda: int(time.monotonic() >= deadline), 1000)
            exists = conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='usage_records'").fetchone()
            total = conn.execute(
                "SELECT COALESCE(SUM(total_tokens), 0) FROM usage_records WHERE created_at >= ? AND created_at < ?",
                (start, end),
            ).fetchone()[0] if exists else 0
        value = {"total_tokens": max(0, int(total)), "as_of": datetime.now(timezone.utc).isoformat()}
        _CACHE[key] = (time.monotonic(), value)
        while len(_CACHE) > 64:
            _CACHE.popitem(last=False)
        return value


@router.get("/today-token", summary="Today's recorded platform token total")
async def today_token(request: Request, start_date: str = Query(...), end_date: str = Query(...)):
    require_user(request)
    start, end = utc_range(start_date, end_date)
    try:
        return await asyncio.to_thread(read_total, Storage.get_db_path(), start, end)
    except Exception as error:
        # Do not report a failed query as zero usage or return database paths to clients.
        raise HTTPException(503, "Token usage temporarily unavailable") from error
