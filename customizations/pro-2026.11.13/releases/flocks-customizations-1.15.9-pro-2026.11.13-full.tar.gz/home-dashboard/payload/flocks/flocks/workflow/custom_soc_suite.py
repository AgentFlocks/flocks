"""Bounded, offline SOC workflow stages. Only the final stage writes local reports.

Fixtures are synthetic. Supplied data is unverified, not proof of collection or
remediation. This module never connects to a network, sends mail or changes tasks.
"""
from __future__ import annotations

import hashlib
import ipaddress
import json
import math
import os
import re
import stat
import statistics
import uuid
from collections import Counter, defaultdict
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
from pathlib import Path

MAX_RECORDS = 1000
MAX_INPUT_BYTES = 1_000_000
MAX_REPORT_BYTES = 1_500_000
DNS_RCODES = {"NOERROR", "FORMERR", "SERVFAIL", "NXDOMAIN", "NOTIMP", "REFUSED", "YXDOMAIN", "YXRRSET", "NXRRSET", "NOTAUTH", "NOTZONE", "DSOTYPENI", "BADVERS", "BADKEY", "BADTIME", "BADMODE", "BADNAME", "BADALG", "BADTRUNC", "BADCOOKIE"}
DNS_QUERY_TYPES = {"A", "AAAA", "NS", "CNAME", "SOA", "PTR", "MX", "TXT", "SRV", "CAA", "NAPTR", "DNAME", "DNSKEY", "DS", "RRSIG", "NSEC", "NSEC3", "NSEC3PARAM", "TLSA", "SSHFP", "HTTPS", "SVCB", "ANY", "AXFR", "IXFR", "OPT", "LOC", "SPF", "RP", "HINFO", "CERT", "URI"}
SETTINGS_PATH = Path(__file__).with_name("custom_soc_suite_settings.json")
WORKFLOWS = {
    "custom-soc-ndr-egress": ("恶意外联与周期通信研判", "sessions", "egress"),
    "custom-soc-ndr-dns": ("DNS异常解析与隧道行为排查", "dns_records", "dns"),
    "custom-soc-ndr-lateral": ("内网横向移动与异常远程访问分析", "sessions", "lateral"),
    "custom-soc-ndr-exfil": ("异常上传与数据外传排查", "sessions", "exfil"),
    "custom-soc-device-health": ("安全设备健康巡检与异常复核", "devices", "device"),
    "custom-soc-alert-fusion": ("多源告警关联降噪与分级研判", "alerts", "alert"),
    "custom-soc-closure-report": ("安全任务闭环检查与运营日报", "tasks", "closure"),
}
REQUIRED = {
    "egress": {"src": str, "dst": str, "timestamp": str, "destination_scope": str, "bytes_out": (int, float), "bytes_in": (int, float)},
    "dns": {"client": str, "query": str, "timestamp": str, "rcode": str, "query_type": str},
    "lateral": {"src": str, "dst": str, "timestamp": str, "port": int, "connection_state": str},
    "exfil": {"src": str, "dst": str, "timestamp": str, "destination_scope": str, "bytes_out": (int, float), "bytes_in": (int, float)},
    "device": {"device_id": str, "observed_at": str, "online": bool, "cpu_pct": (int, float), "memory_pct": (int, float), "disk_pct": (int, float), "log_delay_s": (int, float), "heartbeat_age_s": (int, float), "policy_synced": bool},
    "alert": {"alert_id": str, "asset": str, "timestamp": str, "rule_id": str, "source": str, "severity": str, "signature": str},
    "closure": {"task_id": str, "owner": str, "status": str, "updated_at": str, "due_at": str, "remediation_evidence": bool, "retest_passed": bool, "recurrence_detected": bool},
}
OPTIONAL = {
    "egress": {"reputation": str, "authorized_business": bool},
    "dns": {}, "lateral": {"authorized_admin": bool},
    "exfil": {"baseline_out_bytes": (int, float), "authorized_business": bool},
    "device": {}, "alert": {"benign_evidence": bool},
    "closure": {"remediation_at": str, "retest_at": str},
}


class SuiteError(ValueError):
    """Public-safe validation or storage error; never include input values."""


def _now():
    return datetime.now(timezone.utc)


def _date(value):
    if not isinstance(value, str) or len(value) > 40:
        raise SuiteError("时间必须是带时区的 ISO 8601 字符串。")
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
        if parsed.tzinfo is None:
            raise ValueError()
        return parsed.astimezone(timezone.utc)
    except ValueError as error:
        raise SuiteError("时间格式无效或缺少时区。") from error


def _json_size(value, limit):
    try:
        encoded = json.dumps(value, ensure_ascii=False, allow_nan=False)
    except (TypeError, ValueError, RecursionError) as error:
        raise SuiteError("输入必须是有限、可序列化的 JSON 数据。") from error
    if len(encoded.encode("utf-8")) > limit:
        raise SuiteError("数据超过允许的大小上限。")


def _safe(value, maximum=180):
    text = str(value)
    text = re.sub(r"(?i)\bBearer\s+\S+", "Bearer [已隐藏]", text)
    text = re.sub(r"(?i)(?:api[_-]?key|access[_-]?token|refresh[_-]?token|password|passwd|secret|authorization|token|密码|口令|密钥)\s*[:=：]\s*\S+", "[敏感字段已隐藏]", text)
    text = re.sub(r"\bsk-[A-Za-z0-9_-]{12,}\b", "[密钥已隐藏]", text)
    text = re.sub(r"https?://\S+", "[外链已隐藏]", text)
    text = "".join(ch for ch in text if ord(ch) >= 32)
    return text[:maximum]


def _label(value):
    # Never put arbitrary DNS labels, credential-like text, or payloads in reports.
    return "实体-" + hashlib.sha256(str(value).encode()).hexdigest()[:10]


def _settings():
    try:
        fd = os.open(SETTINGS_PATH, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_NONBLOCK", 0))
        with os.fdopen(fd, "rb") as stream:
            info = os.fstat(stream.fileno())
            if not stat.S_ISREG(info.st_mode) or info.st_size > 16_384:
                raise ValueError()
            settings = json.loads(stream.read(16_385))
        email = settings.get("emailDisplay")
        owner = settings.get("ownerName")
        if settings.get("schemaVersion") != 1 or not isinstance(email, str) or not email.strip() or len(email) > 254:
            raise ValueError()
        if owner is not None and (not isinstance(owner, str) or len(owner) > 100):
            raise ValueError()
        return {"recipient_display": _safe(email, 254), "owner_display": _safe(owner or "未配置负责人"), "status": "not_sent", "mode": "report_only"}
    except (OSError, ValueError, TypeError, AttributeError) as error:
        raise SuiteError("通知展示配置缺失或无效，请安装 custom_soc_suite_settings.json；本套件不发送邮件。") from error


def _samples(kind, scenario, now):
    if scenario == "insufficient":
        return []
    risk = scenario == "risk"
    stamp = lambda minutes=0: (now - timedelta(minutes=minutes)).isoformat()
    if kind == "egress":
        return [{"src": "10.0.0.10", "dst": "198.51.100.10", "timestamp": stamp(i), "destination_scope": "external", "bytes_out": 800, "bytes_in": 400, "reputation": "known_malicious" if risk else "benign", "authorized_business": not risk} for i in range(8)]
    if kind == "dns":
        return [{"client": "10.0.0.10", "query": (f"q{i:02d}a8z2b9y3c7x4d6w5e0v1f8u2g9t3h7s4j6r5k0p1n8m2.example.test" if risk else "updates.example.test"), "timestamp": stamp(i), "rcode": "NXDOMAIN" if risk else "NOERROR", "query_type": "TXT" if risk else "A"} for i in range(12)]
    if kind == "lateral":
        return [{"src": "10.0.0.10", "dst": f"10.0.1.{i + 1}", "timestamp": stamp(), "port": 445 if risk else 443, "connection_state": "established", "authorized_admin": not risk} for i in range(7)]
    if kind == "exfil":
        return [{"src": "10.0.0.10", "dst": "203.0.113.10", "timestamp": stamp(), "destination_scope": "external", "bytes_out": 800_000_000 if risk else 100_000, "bytes_in": 10_000, "baseline_out_bytes": 20_000_000, "authorized_business": not risk}]
    if kind == "device":
        return [{"device_id": "ndr-01", "observed_at": stamp(i * 5), "online": True, "cpu_pct": 25, "memory_pct": 40, "disk_pct": 96 if risk else 50, "log_delay_s": 900 if risk else 15, "heartbeat_age_s": 10, "policy_synced": True} for i in range(3)]
    if kind == "alert":
        return [{"alert_id": f"alert-{i}", "asset": "10.0.0.10", "timestamp": stamp(), "rule_id": "c2-rule", "source": "ndr" if i % 2 else "gateway", "severity": "high" if risk else "low", "signature": "outbound-cluster", "benign_evidence": not risk} for i in range(6)]
    return [{"task_id": "case-001", "owner": "运营值班组", "status": "completed", "updated_at": stamp(60), "due_at": stamp(30), "remediation_evidence": not risk, "retest_passed": not risk, "recurrence_detected": False, "remediation_at": stamp(90), "retest_at": stamp(45)}]


def _business_inputs(inputs):
    """Discard bounded native trigger transport metadata, never use it as authority."""
    if not isinstance(inputs, dict):
        raise SuiteError("输入必须是对象。")
    _json_size(inputs, MAX_INPUT_BYTES)
    metadata_present = "_flocks" in inputs or "_trigger" in inputs
    if metadata_present:
        context = inputs.get("_flocks")
        if inputs.get("_trigger") != "manual" or not isinstance(context, dict) or set(context) != {"trigger"}:
            raise SuiteError("手动触发元数据格式无效。")
        trigger = context["trigger"]
        fields = {"id", "type", "source", "deliveryId", "receivedAt", "attempt"}
        if not isinstance(trigger, dict) or set(trigger) != fields or trigger.get("type") != "manual":
            raise SuiteError("手动触发元数据格式无效。")
        for key in ("id", "type", "source", "deliveryId"):
            if not isinstance(trigger[key], str) or len(trigger[key]) > 256:
                raise SuiteError("手动触发元数据超出允许的形态或大小。")
        for key in ("receivedAt", "attempt"):
            if type(trigger[key]) is not int or not 0 <= trigger[key] <= 2**63 - 1:
                raise SuiteError("手动触发元数据超出允许的形态或大小。")
    business = {key: value for key, value in inputs.items() if key not in {"_flocks", "_trigger"}}
    if "suite_inputs" in business:
        if set(business) != {"suite_inputs"} or not metadata_present or not isinstance(business["suite_inputs"], dict):
            raise SuiteError("手动触发事件正文必须是参数对象。")
        business = business["suite_inputs"]
    return business


def _prepare(workflow_id, inputs):
    title, dataset, kind = WORKFLOWS[workflow_id]
    inputs = _business_inputs(inputs)
    if not isinstance(inputs, dict) or set(inputs) - {"scenario", dataset, "evaluation_time"}:
        raise SuiteError("输入包含不支持的字段；不接受输出路径、命令或通知发送参数。")
    _json_size(inputs, MAX_INPUT_BYTES)
    scenario = inputs.get("scenario", "risk")
    if not isinstance(scenario, str) or scenario not in {"normal", "risk", "insufficient"}:
        raise SuiteError("scenario 仅支持 normal、risk、insufficient。")
    now = _date(inputs["evaluation_time"]) if "evaluation_time" in inputs else _now()
    supplied = dataset in inputs
    records = inputs[dataset] if supplied else _samples(kind, scenario, now)
    if not isinstance(records, list) or len(records) > MAX_RECORDS:
        raise SuiteError("数据必须为数组且每轮不超过 1000 条。")
    for record in records:
        if not isinstance(record, dict) or len(record) > 40:
            raise SuiteError("每条记录必须是字段数不超过 40 的对象。")
        for key, value in record.items():
            if not isinstance(key, str) or len(key) > 80 or isinstance(value, (dict, list)):
                raise SuiteError("记录只接受有界的平面字段。")
            if isinstance(value, str) and len(value) > 1024:
                raise SuiteError("单字段文本长度不得超过 1024 字符。")
    allowed = set(REQUIRED[kind]) | set(OPTIONAL[kind])
    return {"workflow_id": workflow_id, "title": title, "kind": kind, "evaluation_time": now.isoformat(),
            "metadata": {"data_origin": "user_provided_unverified" if supplied else "builtin_synthetic", "scenario": scenario if not supplied else None, "source_count": len(records), "analysis_only": True, "network_calls": 0, "task_mutations": 0},
            "notification": _settings(), "records": [{k: v for k, v in record.items() if k in allowed} for record in records]}


def _normalize(state):
    kind = state["kind"]
    result = []
    invalid = 0
    for index, record in enumerate(state["records"]):
        try:
            for key, expected in {**REQUIRED[kind], **OPTIONAL[kind]}.items():
                if key not in record:
                    if key in REQUIRED[kind]:
                        raise ValueError()
                    continue
                value = record[key]
                if not isinstance(value, expected) or (isinstance(value, bool) and expected is not bool):
                    raise ValueError()
                if isinstance(value, str) and not value.strip() and key != "owner":
                    raise ValueError()
                if isinstance(value, (int, float)) and not isinstance(value, bool) and (not math.isfinite(value) or value < 0 or value > 1e15):
                    raise ValueError()
                if key.endswith("_pct") and value > 100:
                    raise ValueError()
            time_key = "observed_at" if kind == "device" else "updated_at" if kind == "closure" else "timestamp"
            observed = _date(record[time_key])
            if observed > _date(state["evaluation_time"]) + timedelta(minutes=5):
                raise ValueError()
            if kind in {"egress", "exfil"} and record["destination_scope"] not in {"external", "internal"}:
                raise ValueError()
            if kind == "lateral" and (not 1 <= record["port"] <= 65535 or record["connection_state"] not in {"established", "rejected", "unknown"}):
                raise ValueError()
            if kind == "lateral":
                ipaddress.ip_address(record["src"])
                ipaddress.ip_address(record["dst"])
            if kind == "dns":
                client = str(ipaddress.ip_address(record["client"].strip()))
                rcode, query_type = record["rcode"].strip().upper(), record["query_type"].strip().upper()
                if rcode not in DNS_RCODES or query_type not in DNS_QUERY_TYPES:
                    raise ValueError()
                query = record["query"].strip()
                if query != ".":
                    query = query[:-1] if query.endswith(".") else query
                    # IDNA names and common SRV/DKIM underscores are accepted;
                    # raw payloads, empty labels and oversized names are not.
                    query = query.encode("idna").decode("ascii").lower()
                    if not query or len(query) > 253 or any(not re.fullmatch(r"[a-z0-9_-]{1,63}|\*", label) for label in query.split(".")):
                        raise ValueError()
                record = {**record, "client": client, "query": query, "rcode": rcode, "query_type": query_type}
            if kind == "alert" and record["severity"] not in {"low", "medium", "high", "critical"}:
                raise ValueError()
            if kind == "closure":
                if record["status"] not in {"pending", "running", "failed", "completed", "closed"}:
                    raise ValueError()
                _date(record["due_at"])
                for key in ("retest_at", "remediation_at"):
                    if key in record:
                        _date(record[key])
            result.append({**record, "evidence_id": f"R{index + 1:04d}"})
        except (ValueError, TypeError, OverflowError):
            invalid += 1
    return {**state, "records": result, "quality": {"valid_count": len(result), "invalid_count": invalid, "empty_input": state["metadata"]["source_count"] == 0}}


def _finding(rule, title, rows, *, severity="medium", status="pending_verification", metrics=None):
    return {"rule": rule, "title": title, "severity": severity, "status": status,
            "evidence_ids": [row["evidence_id"] for row in rows][:100], "evidence_count": len(rows), "metrics": metrics or {}}


def _groups(rows, key):
    groups = defaultdict(list)
    for row in rows:
        groups[key(row)].append(row)
    return groups.values()


def _entropy(value):
    return -sum((n / len(value)) * math.log2(n / len(value)) for n in Counter(value).values()) if value else 0


def _internal(value):
    try:
        addr = ipaddress.ip_address(value)
        return addr.is_private and not addr.is_loopback and not addr.is_multicast and not addr.is_unspecified
    except ValueError:
        return False


def _analyze(state):
    rows, kind = state["records"], state["kind"]
    findings, suppressed = [], 0
    if kind == "egress":
        for group in _groups([r for r in rows if r["destination_scope"] == "external"], lambda r: (r["src"], r["dst"])):
            reputation = any(r.get("reputation") == "known_malicious" for r in group)
            if all(r.get("authorized_business") is True for r in group) and not reputation:
                suppressed += len(group)
                continue
            stamps = sorted(_date(r["timestamp"]).timestamp() for r in group)
            intervals = [b - a for a, b in zip(stamps, stamps[1:])]
            average = statistics.mean(intervals) if intervals else 0
            cv = statistics.pstdev(intervals) / average if average else 1
            periodic = len(group) >= 6 and 10 <= average <= 3600 and cv <= 0.15 and statistics.mean(r["bytes_out"] for r in group) <= 65_536
            if reputation or periodic:
                findings.append(_finding("egress-reputation-periodicity", "恶意信誉命中或稳定周期通信，需核对业务归属", group, severity="high" if reputation else "medium", metrics={"entity": _label(group[0]["src"]), "sessions": len(group), "known_malicious": reputation, "periodic": periodic, "interval_seconds": round(average, 2), "interval_cv": round(cv, 3)}))
    elif kind == "dns":
        for group in _groups(rows, lambda r: r["client"]):
            failed = sum(r["rcode"].upper() == "NXDOMAIN" for r in group)
            encoded = [r for r in group if len(r["query"].split('.')[0]) >= 40 and _entropy(r["query"].split('.')[0]) >= 3.5]
            txt = sum(r["query_type"].upper() == "TXT" for r in encoded)
            if (len(group) >= 10 and failed / len(group) >= 0.5) or (len(encoded) >= 5 and txt >= 3):
                findings.append(_finding("dns-anomaly", "异常解析比例或高熵长标签集中出现，需核验隧道行为", group, metrics={"entity": _label(group[0]["client"]), "queries": len(group), "nxdomain_ratio": round(failed / len(group), 3), "long_encoded_queries": len(encoded), "txt_encoded_queries": txt}))
    elif kind == "lateral":
        candidates = [r for r in rows if _internal(r["src"]) and _internal(r["dst"]) and r["port"] in {22, 135, 139, 445, 3389, 5985, 5986} and not r.get("authorized_admin", False)]
        for group in _groups(candidates, lambda r: (r["src"], int(_date(r["timestamp"]).timestamp()) // 3600)):
            targets = len({r["dst"] for r in group})
            established = len({r["dst"] for r in group if r["connection_state"] == "established"})
            if targets >= 5:
                findings.append(_finding("lateral-fanout", "内网远程服务扇出异常；TCP建连不等于登录成功", group, severity="high" if established >= 3 else "medium", metrics={"entity": _label(group[0]["src"]), "targets": targets, "established_targets": established}))
    elif kind == "exfil":
        for group in _groups([r for r in rows if r["destination_scope"] == "external" and not r.get("authorized_business", False)], lambda r: (r["src"], r["dst"], int(_date(r["timestamp"]).timestamp()) // 3600)):
            outgoing, incoming = sum(r["bytes_out"] for r in group), sum(r["bytes_in"] for r in group)
            baselines = [r["baseline_out_bytes"] for r in group if r.get("baseline_out_bytes", 0) > 0]
            baseline = max(baselines) if baselines else None
            ratio = outgoing / max(incoming, 1)
            if outgoing >= 100 * 1024 * 1024 and ratio >= 10:
                findings.append(_finding("exfil-upload", "外部目的地上传量异常，需核对授权传输和敏感性", group, severity="high" if baseline and outgoing >= 5 * baseline else "medium", metrics={"entity": _label(group[0]["src"]), "bytes_out": outgoing, "out_in_ratio": round(ratio, 2), "baseline_available": baseline is not None, "baseline_multiple": round(outgoing / baseline, 2) if baseline else None}))
    elif kind == "device":
        def problems(row):
            return [name for name, hit in (("离线", not row["online"]), ("CPU高负载", row["cpu_pct"] >= 90), ("内存高负载", row["memory_pct"] >= 90), ("磁盘高水位", row["disk_pct"] >= 90), ("日志延迟", row["log_delay_s"] > 300), ("心跳超时", row["heartbeat_age_s"] > 120), ("策略未同步", not row["policy_synced"])) if hit]
        for group in _groups(rows, lambda r: r["device_id"]):
            group.sort(key=lambda r: _date(r["observed_at"]))
            any_problem = any(problems(row) for row in group)
            age = lambda row: (_date(state["evaluation_time"]) - _date(row["observed_at"])).total_seconds()
            fresh = 0 <= age(group[-1]) <= 900
            distinct = len({_date(r["observed_at"]) for r in group[-2:]}) == 2
            fresh_pair = all(0 <= age(row) <= 900 for row in group[-2:])
            recovered = any_problem and len(group) >= 3 and distinct and fresh_pair and all(not problems(r) for r in group[-2:])
            if any_problem or not fresh:
                findings.append(_finding("device-recheck", "连续两次有效复测正常" if recovered else "设备异常持续或复测证据不足", group, status="verified_recovered" if recovered else "pending_verification", severity="info" if recovered else "high", metrics={"entity": _label(group[0]["device_id"]), "latest_issues": problems(group[-1]), "fresh_observation": fresh, "consecutive_retests": 2 if recovered else 0}))
    elif kind == "alert":
        for group in _groups(rows, lambda r: (r["asset"], r["signature"], int(_date(r["timestamp"]).timestamp()) // 900)):
            benign = all(r.get("benign_evidence") is True and r["severity"] in {"low", "medium"} for r in group)
            if benign:
                suppressed += len(group)
                continue
            sources = len({r["source"] for r in group})
            high = any(r["severity"] in {"high", "critical"} for r in group) or sources >= 2
            findings.append(_finding("alert-correlation", "多源印证或高危告警，进入升级队列" if high else "单源告警保留人工研判，不直接抑制", group, severity="high" if high else "medium", metrics={"entity": _label(group[0]["asset"]), "source_count": sources, "original_alerts": len(group), "unique_alert_ids": len({r["alert_id"] for r in group})}))
    elif kind == "closure":
        for row in rows:
            retest = _date(row["retest_at"]) if row.get("retest_at") else None
            remediation = _date(row["remediation_at"]) if row.get("remediation_at") else None
            proof = bool(row["remediation_evidence"] and row["retest_passed"] and retest and remediation and remediation <= retest <= _date(state["evaluation_time"]))
            claimed = row["status"] in {"completed", "closed"}
            verified = claimed and proof and not row["recurrence_detected"] and bool(row["owner"].strip())
            overdue = not verified and _date(row["due_at"]) < _date(state["evaluation_time"])
            if not verified:
                reasons = [name for name, hit in (("缺少负责人", not row["owner"].strip()), ("超过处置期限", overdue), ("缺少有效处置及复测证据", claimed and not proof), ("复发需重新打开", row["recurrence_detected"]), ("仍待处理", not claimed)) if hit]
                findings.append(_finding("closure-evidence", "；".join(reasons), [row], severity="high" if overdue or row["recurrence_detected"] else "medium", metrics={"entity": _label(row["task_id"]), "claimed_complete": claimed, "proof_valid": proof, "overdue": overdue, "recurrence": row["recurrence_detected"]}))
    active = [finding for finding in findings if finding["status"] != "verified_recovered"]
    decision = "risk" if active else "insufficient" if not rows or state["quality"]["invalid_count"] else "normal"
    return {**state, "findings": findings, "suppressed_count": suppressed, "decision": decision}


def _decide(state, branch):
    if state.get("decision") != branch:
        raise SuiteError("分支与规则结果不一致。")
    business = "action_required" if branch == "risk" else "pending_verification" if branch == "insufficient" else "completed" if state["kind"] == "closure" or any(f["status"] == "verified_recovered" for f in state["findings"]) else "no_rule_hits"
    actions = ["核对来源记录与业务归属", "由负责人确认后另行执行处置", "补充复测证据后再判断闭环"] if branch == "risk" else ["补齐缺失字段或提供新的有效记录", "重新运行规则分析；未补齐前不作成功闭环结论"] if branch == "insufficient" else ["保留本轮分析记录，持续观察；无规则命中不等于安全保证"]
    return {**state, "business_status": business, "actions": actions}


def _compile(state):
    overview = {"input_count": state["metadata"]["source_count"], "valid_count": state["quality"]["valid_count"],
                "invalid_count": state["quality"]["invalid_count"], "finding_count": len(state["findings"]),
                "active_finding_count": sum(f["status"] != "verified_recovered" for f in state["findings"]),
                "verified_recovery_count": sum(f["status"] == "verified_recovered" for f in state["findings"]),
                "suppressed_count": state["suppressed_count"]}
    if state["kind"] == "closure":
        overview.update(task_status_counts=dict(Counter(r["status"] for r in state["records"])),
                        overdue_count=sum(f["metrics"].get("overdue", False) for f in state["findings"]),
                        verified_closed_count=len(state["records"]) - len(state["findings"]))
    report = {"schema_version": 1, "workflow_id": state["workflow_id"], "title": state["title"], "evaluation_time": state["evaluation_time"],
              "analysis_status": "completed", "business_status": state["business_status"], "branch": state["decision"],
              "metadata": state["metadata"], "quality": state["quality"], "overview": overview, "notification": state["notification"],
              "findings": state["findings"], "suppressed_count": state["suppressed_count"], "actions": state["actions"],
              "limitations": ["内置数据为合成样本；外部提供数据未核验采集真实性。", "本轮仅作规则分析与报告编制，未发送通知、实施处置或修改任务状态。", "前四类工作流仅使用NDR会话/DNS字段，不推断主机登录、进程或真实敏感文件内容。", "证据ID指向本轮输入数组行号；原始域名、资产名称和凭证不写入报告。"]}
    return {**state, "report": report, "markdown": _markdown(report)}


def _markdown(report):
    label = {"action_required": "待处置", "pending_verification": "待核验", "completed": "输入证据满足闭环检查", "no_rule_hits": "未见本轮规则命中"}
    quote = lambda text: re.sub(r"([\\`*_{}\[\]()#+!|<>])", r"\\\1", _safe(text, 800))
    lines = ["# " + report["title"], "", "- 评估时点：" + report["evaluation_time"], "- 数据来源：" + report["metadata"]["data_origin"], "- 分析完成 ≠ 业务处置完成；本轮结论：" + label[report["business_status"]], "- 有效记录：" + str(report["quality"]["valid_count"]) + "；无效记录：" + str(report["quality"]["invalid_count"]), "- 通知展示收件人：" + quote(report["notification"]["recipient_display"]) + "（未发送）", "", "## 运营概况", "- 待核验发现：" + str(report["overview"]["active_finding_count"]) + "；输入证据已验证恢复：" + str(report["overview"]["verified_recovery_count"]), "- 有良性依据的抑制记录：" + str(report["suppressed_count"])]
    if "task_status_counts" in report["overview"]:
        lines += ["- 任务状态分布：" + quote(json.dumps(report["overview"]["task_status_counts"], ensure_ascii=False)), "- 超期任务：" + str(report["overview"]["overdue_count"]) + "；满足闭环证据检查：" + str(report["overview"]["verified_closed_count"])]
    lines += ["", "## 发现与证据"]
    for finding in report["findings"]:
        lines += ["", "### " + quote(finding["title"]), "- 状态：" + finding["status"] + "；级别：" + finding["severity"], "- 证据行号：" + ", ".join(finding["evidence_ids"]), "- 指标：" + quote(json.dumps(finding["metrics"], ensure_ascii=False))]
    if not report["findings"]:
        lines.append("资料不足，不能作成功闭环结论。" if report["branch"] == "insufficient" else "有效输入中未命中本轮升级规则；不代表不存在其它风险。")
    lines += ["", "## 后续动作"] + ["- " + quote(item) for item in report["actions"]]
    lines += ["", "## 使用边界"] + ["- " + quote(item) for item in report["limitations"]]
    return "\n".join(lines) + "\n"


@contextmanager
def _report_directory(workflow_id):
    if os.open not in os.supports_dir_fd or not hasattr(os, "O_NOFOLLOW"):
        raise SuiteError("当前平台不支持安全的目录描述符写入；报告未写入。")
    # The explicitly configured ~/.flocks deployment alias may be a symlink.
    # Resolve it once; every output descendant is opened with no-follow dirfds.
    home = Path.home().resolve(strict=True)
    alias = home / ".flocks"
    alias.mkdir(mode=0o700, exist_ok=True)
    root = alias.resolve(strict=True)
    fd = os.open(root, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        parts = ["workspace", "outputs", _now().astimezone().date().isoformat(), "security-operations", workflow_id]
        for part in parts:
            try:
                os.mkdir(part, mode=0o700, dir_fd=fd)
            except FileExistsError:
                pass
            following = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=fd)
            os.close(fd)
            fd = following
        yield fd, root.joinpath(*parts)
    finally:
        os.close(fd)


def _publish(state):
    # Compile again from structured state; never accept arbitrary supplied paths
    # or a Markdown body masquerading as an output destination.
    state = _compile(state)
    report = state["report"]
    _json_size(report, MAX_REPORT_BYTES)
    identifier = _now().strftime("%H%M%S%f") + "-" + uuid.uuid4().hex[:10]
    contents = {identifier + ".md": state["markdown"].encode(), identifier + ".json": json.dumps(report, ensure_ascii=False, indent=2, allow_nan=False).encode()}
    written = []
    try:
        with _report_directory(state["workflow_id"]) as (directory, path):
            try:
                for name, content in contents.items():
                    fd = os.open(name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600, dir_fd=directory)
                    written.append(name)
                    with os.fdopen(fd, "wb") as stream:
                        stream.write(content)
                        stream.flush()
                        os.fsync(stream.fileno())
            except BaseException:
                for name in written:
                    os.unlink(name, dir_fd=directory)
                raise
            paths = [str(path / name) for name in contents]
    except OSError as error:
        raise SuiteError("报告目录不可安全写入，请检查目录权限或符号链接配置。") from error
    return {"report": report, "markdown": state["markdown"], "output_files": paths}


def run_stage(workflow_id, stage, inputs):
    if workflow_id not in WORKFLOWS:
        raise SuiteError("工作流ID不受此套件管理。")
    if stage == "prepare":
        return {"state": _prepare(workflow_id, inputs)}
    if not isinstance(inputs, dict) or set(inputs) != {"state"} or not isinstance(inputs.get("state"), dict):
        raise SuiteError("节点输入状态无效。")
    state = inputs["state"]
    _json_size(state, MAX_REPORT_BYTES)
    if state.get("workflow_id") != workflow_id or state.get("kind") != WORKFLOWS[workflow_id][2]:
        raise SuiteError("节点状态与工作流不匹配。")
    try:
        if stage == "normalize":
            result = _normalize(state)
        elif stage == "analyze":
            result = _analyze(state)
        elif stage in {"risk", "normal", "insufficient"}:
            result = _decide(state, stage)
        elif stage == "compile":
            result = _compile(state)
        elif stage == "publish":
            return _publish(state)
        else:
            raise SuiteError("未知工作流阶段。")
        return {"state": result}
    except (KeyError, TypeError, IndexError, AttributeError) as error:
        raise SuiteError("节点状态不完整或字段类型无效。") from error
