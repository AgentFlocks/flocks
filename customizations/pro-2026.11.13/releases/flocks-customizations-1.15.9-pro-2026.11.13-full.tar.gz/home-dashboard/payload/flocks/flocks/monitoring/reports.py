"""One atomic daily projection; failed exports retry independently of business work."""
import asyncio
import hashlib
import json
import os
import re
import tempfile
from datetime import datetime, timezone
from zoneinfo import ZoneInfo
from flocks.workspace.manager import WorkspaceManager
from .store import rows, write, connection
from . import sampling
from .models import MonitoringPolicy

_locks: dict[tuple, asyncio.Lock] = {}


async def snapshot(owner, scope, day):
    # A single read transaction supplies the dashboard and report consistently.
    async with connection() as db:
        await db.execute('BEGIN')
        async def select(sql, args=()):
            cur = await db.execute(sql, args)
            return [dict(x) for x in await cur.fetchall()]
        installations = await select('SELECT * FROM monitor_installations WHERE owner=? AND scope=?', (owner, scope))
        runs = await select('SELECT * FROM monitor_attempts WHERE owner=? AND scope=? AND business_date=? ORDER BY started_at DESC,sequence DESC', (owner, scope, day))
        current_run = await select("SELECT a.id,a.session_id,a.message_id,a.started_at FROM monitor_attempts a JOIN monitor_installations i ON i.owner=a.owner AND i.scope=a.scope AND i.project=a.project WHERE a.owner=? AND a.scope=? AND a.status='running' AND i.installed=1 ORDER BY a.sequence DESC LIMIT 1", (owner, scope))
        observations = await select('SELECT o.*,a.sequence,a.session_id,a.message_id,a.started_at,a.project FROM monitor_observations o JOIN monitor_attempts a ON a.id=o.attempt_id WHERE a.owner=? AND a.scope=? AND a.business_date=? ORDER BY a.sequence', (owner, scope, day))
        dispositions = await select('SELECT * FROM monitor_dispositions WHERE owner=? AND scope=? ORDER BY created_at', (owner, scope))
        from .event_list import _assessment_projection, _event_projection, _result_projection
        investigations = await select(
            f'SELECT i.event_key,i.state,{_event_projection("i.event")} AS event,'
            f'{_assessment_projection()} AS assessment_proofs,{_result_projection("i.result")} AS result '
            'FROM monitor_investigations i WHERE i.owner=? AND i.project='
            '(SELECT project FROM monitor_installations WHERE owner=? AND scope=?) '
            'AND EXISTS(SELECT 1 FROM monitor_observations o JOIN monitor_attempts a ON a.id=o.attempt_id '
            'WHERE a.owner=i.owner AND a.scope=? AND a.project=i.project AND a.business_date=? AND o.event_key=i.event_key)',
            (owner, owner, scope, scope, day))
        from .followup import PROJECTION_COLUMNS
        followups = await select(f'SELECT {PROJECTION_COLUMNS} FROM monitor_event_followup f WHERE owner=? AND scope=? AND project=(SELECT project FROM monitor_installations WHERE owner=? AND scope=?) AND EXISTS(SELECT 1 FROM monitor_observations o JOIN monitor_attempts a ON a.id=o.attempt_id WHERE a.owner=f.owner AND a.scope=f.scope AND a.project=f.project AND a.business_date=? AND o.event_key=f.event_key)', (owner, scope, owner, scope, day))
        mail_notices = await select('SELECT id,state,created_at,updated_at,sent_at FROM monitor_mail_notices WHERE owner=? AND project=(SELECT project FROM monitor_installations WHERE owner=? AND scope=?)', (owner, owner, scope))
        mail_replies = await select('SELECT state,received_at FROM monitor_mail_replies WHERE owner=? AND project=(SELECT project FROM monitor_installations WHERE owner=? AND scope=?)', (owner, owner, scope))
        mail_settings = await select('SELECT enabled FROM monitor_mail_settings WHERE owner=? AND project=(SELECT project FROM monitor_installations WHERE owner=? AND scope=?)', (owner, owner, scope))
        auto_settings = await select('SELECT * FROM monitor_auto_settings WHERE owner=? AND scope=?', (owner, scope))
        auto_queue = await select('SELECT * FROM monitor_auto_queue WHERE owner=? AND scope=?', (owner, scope))
        steps = await select('SELECT s.* FROM monitor_steps s JOIN monitor_attempts a ON a.id=s.attempt_id WHERE a.owner=? AND a.scope=? AND a.business_date=? ORDER BY s.started_at', (owner, scope, day))
        report = await select('SELECT status,version,error FROM monitor_reports WHERE owner=? AND scope=? AND business_date=?', (owner, scope, day))
        daily = await select('SELECT session_id FROM monitor_daily_sessions WHERE owner=? AND scope=? AND business_date=?', (owner, scope, day))
        scheduler = []
        queued = []
        if installations:
            scheduler = await select('SELECT status,trigger FROM task_schedulers WHERE id=?', (installations[0]['scheduler_id'],))
            queued = await select("SELECT e.id,e.status,e.created_at,e.error,s.scheduled_for,s.status AS slot_status FROM task_executions e LEFT JOIN monitor_slots s ON s.execution_id=e.id WHERE e.scheduler_id=? AND e.status IN ('queued','running','cancelled') ORDER BY e.created_at DESC LIMIT 200", (installations[0]['scheduler_id'],))
    events = {}
    for item in observations:
        event = json.loads(item['data'])
        event.update(sessionID=item['session_id'], messageID=item['message_id'], attemptID=item['attempt_id'], observedAt=item['started_at'], projectID=item['project'])
        events[item['event_key']] = event
    for disposition in dispositions:
        event = events.get(disposition['event_key'])
        if event is None or disposition['mode'] in ('automatic', 'mail', 'mail_manual', 'followup') and disposition['project'] != event['projectID']:
            continue
        event['dispositionRecord'] = disposition
        # Re-sampling an unchanged terminal event must not undo a verified test.
        decision = json.loads(disposition['decision'] or '{}')
        same_sample = (event.get('development_sample') is True and decision.get('development_sample') is True
                       and event.get('dealStatus') == disposition['target_status']
                       and event.get('endTime') is not None and event['endTime'] == decision.get('observed_end_time')
                       and event.get('host') == decision.get('observed_host'))
        verified = disposition['status'] == 'verified' and (disposition['updated_at'] >= event['observedAt'] or same_sample)
        event['closure'] = {40: 'closed', 60: 'ignored', 70: 'contained'}.get(disposition['target_status'], 'open') if verified else 'open'
        from .disposition import status_label
        event['disposition'] = f"{status_label(disposition['target_status'])}，回查确认" if verified else '待确认处置结果' if disposition['status'] in ('writing', 'pending', 'mismatch') else '待跟进'
    cases = {case['event_key']: case for case in investigations}
    from .assessment import assess_event, apply_followup
    from .followup import projection
    followups = {item['event_key']: projection(item) for item in followups}
    for event in events.values():
        # Keep the daily projection aligned with the event ledger and notification
        # rule. Old severity-only observations are not confirmed risk findings.
        persisted_assessment = event.get('assessment', {})
        current_assessment = assess_event(event, cases.get(event['key'], {}),
            handling='closed' if event.get('closure') == 'closed' else None)
        from .investigation import fingerprint
        historic = (isinstance(persisted_assessment, dict)
            and persisted_assessment.get('policy_version') in {1, 2}
            and persisted_assessment.get('event_revision') == fingerprint(event)
            and persisted_assessment.get('status') in {'risk_open', 'risk_closed', 'benign', 'insufficient', 'ended'})
        # A new activity version cannot rewrite the facts of a historical day.
        event['assessment'] = (persisted_assessment if historic and not current_assessment['is_current'] else current_assessment)
        if event.get('closure') == 'closed' and event['assessment']['verdict'] == 'risk':
            event['assessment'] = {**event['assessment'], 'status': 'risk_closed', 'label': '有风险 · 已处置', 'notify_eligible': False}
        if event['assessment']['status'] == 'risk_closed' and event.get('closure') != 'closed':
            event['closure'] = 'closed'
            event['closureSource'] = 'xdr'
            event['disposition'] = 'XDR 来源状态为处置完成'
        event['assessment'] = apply_followup(event['assessment'], event, followups.get(event['key']))
        lifecycle = followups.get(event['key'], {})
        if event['assessment'].get('ended') and event['assessment'].get('xdr_closed') and event.get('dealStatus') in {40, 60}:
            event['closure'] = 'closed' if event['dealStatus'] == 40 else 'ignored'
            event['closureSource'] = 'xdr'
            event['disposition'] = event['assessment']['label']
        elif event['assessment'].get('ended') and lifecycle.get('xdr_closed') and lifecycle.get('observed_status') in {40, 60}:
            event['closure'] = 'closed' if lifecycle['observed_status'] == 40 else 'ignored'
            event['closureSource'] = 'external' if lifecycle.get('external') else 'monitor_verified'
            event['disposition'] = event['assessment']['label']
        elif event['assessment'].get('monitoring_ended') and not event['assessment'].get('xdr_closed'):
            event['closure'] = 'ended'
            event['closureSource'] = 'monitoring'
            event['disposition'] = '已归档：XDR 本轮查询未返回，保留原研判与历史记录'
        event['risk'] = event['assessment']['verdict']
        event['reason'] = event['assessment']['reason']
        if event['closure'] == 'ignored':
            event['originalRisk'] = event['risk']
            # Source ignore is kept as a closure fact, never promoted to benign.
            pass
    installation = installations[0] if installations else None
    automatic = False  # Legacy evidence-only writes are retired.
    queue = [entry for entry in auto_queue if installation and entry['project'] == installation['project']]
    for entry in queue:
        if entry['event_key'] in events:
            events[entry['event_key']]['automaticReason'] = entry['reason']

    for run in runs:
        run['result'] = json.loads(run['result'])
        run['steps'] = [step for step in steps if step['attempt_id'] == run['id']]
        # Project older records without rewriting their stored audit facts.
        run['status'] = {'partial': 'completed', 'interrupted': 'failed', 'cancelled': 'failed'}.get(run['status'], run['status'])
    trigger = json.loads(scheduler[0]['trigger']) if scheduler else {}
    business_timezone = json.loads(installation['policy'])['timezone'] if installation else 'Asia/Shanghai'
    tz = ZoneInfo(business_timezone)
    today = datetime.now(timezone.utc).astimezone(tz).date().isoformat()
    queued = [entry for entry in queued if datetime.fromisoformat(entry['scheduled_for'] or entry['created_at']).astimezone(tz).date().isoformat() == day]

    policy = MonitoringPolicy.model_validate_json(installation['policy']) if installation else None
    development = bool(policy and sampling.enabled(policy))
    from .investigation import status_summary
    from .mailflow import health_snapshot
    from .runtime import mail_followup
    backlog = await status_summary(policy) if policy else {}
    mail_health = (await mail_followup('mail.receive', lambda: health_snapshot(owner, installation['project']),
                   {'enabled': bool(mail_settings and mail_settings[0]['enabled']),
                    'receive': {'state': 'unknown'}, 'send': {'state': 'unknown'},
                    'errors': ['邮件连接状态暂无法读取；不据此判断投递失败或没有回信。']})
                   if installation else {'enabled': False, 'errors': []})
    investigated_events = len(events)
    completed_investigations = sum(e.get('investigation', {}).get('state') == 'ready' for e in events.values())
    return {'businessDate': day, 'developmentSample': development,
            'currentRun': current_run[0] if current_run else None,
            'investigation': backlog,
            'investigationEngine': 'agent-v1',
            'roundTimeoutSeconds': policy.timeout_seconds if policy else None,
            'installation': {'installed': bool(installation and installation['installed']),
            'ready': bool(installation and installation['ready']), 'reason': installation['reason'] if installation else '请从添加场景安装安全运营监测',
            'status': scheduler[0]['status'] if scheduler else 'not_installed',
            'projectID': installation['project'] if installation else None},
            'timezone': business_timezone,
            'scheduledNextRun': (trigger.get('next_run') or trigger.get('nextRun')) if scheduler and scheduler[0]['status'] == 'active' else None,
            'sessionID': daily[0]['session_id'] if daily else None,
            'nextRun': (trigger.get('next_run') or trigger.get('nextRun')) if day == today and scheduler and scheduler[0]['status'] == 'active' else None,
            'automatic': {'enabled': automatic, 'rule': 'xdr-evidence-v1', 'queued': len(queue)},
            'runs': runs, 'events': sorted(events.values(), key=lambda e: e['observedAt'], reverse=True), 'queued': queued,
            'report': report[0] if report else {'status': 'pending', 'version': 0, 'error': None},
            'metrics': {'definitions': int(bool(installation and installation['installed'])),
                        'started': len({r['execution_id'] for r in runs}), 'attempts': len(runs),
                        'events': len(events), 'risk': sum(e['risk'] == 'risk' for e in events.values()),
                        'investigatedEvents': investigated_events,
                        'investigationCompletedEvents': completed_investigations,
                        'investigationCompletionRate': completed_investigations / investigated_events if investigated_events else None,
                        'openRisk': sum(e['assessment']['status'] == 'risk_open' for e in events.values()),
                        'closed': sum(e['closure'] == 'closed' for e in events.values()),
                        'riskClosed': sum(e['assessment']['status'] == 'risk_closed' for e in events.values()),
                        'contained': sum(e['closure'] == 'contained' for e in events.values()),
                        'unknown': sum(e['risk'] == 'unknown' and not e['assessment'].get('ended') for e in events.values()),
                        'benign': sum(e['assessment']['status'] == 'benign' for e in events.values()),
                        'insufficient': sum(e['assessment']['status'] == 'insufficient' for e in events.values()),
                        'ignored': sum(e.get('closure') == 'ignored' for e in events.values()),
                        'monitoringEnded': sum(e.get('closure') == 'ended' for e in events.values())},
            'mail': {'enabled': bool(mail_settings and mail_settings[0]['enabled']), 'health': mail_health,
                     'sentToday': sum(bool(n['sent_at'] or n['state']=='sent') and datetime.fromisoformat(n['sent_at'] or n['updated_at']).astimezone(tz).date().isoformat()==day for n in mail_notices),
                     'receivedToday': sum(datetime.fromisoformat(r['received_at']).astimezone(tz).date().isoformat()==day for r in mail_replies),
                     'pending': sum(r['state'] in ('pending','interpreted') for r in mail_replies),
                     'needsReview': sum(r['state']=='needs_review' for r in mail_replies),
                     'sendUnknown': sum(n['state']=='send_unknown' for n in mail_notices)},
            'disposition': '责任人邮件反馈后标记并回查'}


def render(data):
    metrics = data['metrics']
    lines = [f"# 安全运营监测执行时间线 · {data['businessDate']}", '', f"业务时区：{data['timezone']}。每十分钟触发检查；同一监测串行执行，忙碌时只保留一次待执行任务。仅已证实需处置的风险逐条邮件通知责任人，下一轮解读回信、标记并回查。无风险和证据不足在本地分别记录，后者尚未排除风险。状态标记不代表组件执行了主机隔离或修复。", '',
             f"启动轮次：{metrics['started']}；尝试：{metrics['attempts']}；去重事件：{metrics['events']}；风险：{metrics['risk']}；待判定：{metrics['unknown']}。", '']
    lines += [f"未闭环风险：{metrics['openRisk']}；处置完成：{metrics['closed']}；已遏制：{metrics['contained']}；已忽略：{metrics['ignored']}。", '']
    if any(r['result'].get('development_sample') for r in data['runs']):
        lines += [sampling.DESCRIPTION, '联调中的忽略标记仅验证回写链路，不代表事件被判定为误报或威胁已消除。', '']
    if data['events']:
        lines += ['## 去重事件', '']
        for event in data['events']:
            # Treat remote strings as plain text; they must not inject Markdown.
            name = str(event['name']).replace('\n', ' ')
            for char in ('\\', '[', ']', '*', '_', '`', '<', '>'):
                name = name.replace(char, '\\' + char)
            closure = {'closed': '已闭环（XDR 回查确认）', 'contained': '已遏制（XDR 回查确认，仍需跟进）', 'ignored': '已忽略（XDR 回查确认）', 'ended': '已归档（XDR 未再返回）'}.get(event['closure'], '未闭环')
            lines += [f"- {name} · {event['risk']} · {closure}；[关联对话](/sessions?session={event['sessionID']}&focusMessage={event['messageID']})"]
            if event.get('dispositionRecord'):
                item = event['dispositionRecord']
                lines += [f"  - 处置记录：{item['id']}；来源：{item['mode']}；目标：{item['target_status']}；状态：{item['status']}；回查值：{item['observed_status']}；更新时间：{item['updated_at']}。"]
        lines += ['']
    for run in sorted(data['runs'], key=lambda r: (r['started_at'], r.get('sequence', 0)), reverse=True):
        lines += [f"## 轮次 {run['execution_id']} · 尝试 {run['id']}", '',
                  f"状态：{ {'completed': '完成', 'failed': '失败', 'running': '执行中'}.get(run['status'], run['status'])}；计划：{run['scheduled_for'] or '手动'}；开始：{run['started_at']}；结束：{run['finished_at'] or '执行中'}。", '',
                  f"[查看本轮对话](/sessions?session={run['session_id']}&focusMessage={run['message_id']})", '']
        if run.get('summary'):
            lines += [run['summary'], run.get('next_step') or '', '']
        if run['error']:
            lines += [f"异常：{run['error']}", '']
        for step in run['steps']:
            lines += [f"- {step['tool']}：{step['status']}。{step['error'] or step['output'] or ''}"]
        lines += ['', '状态标记和回查结果见上方步骤及去重事件；处置中、已遏制不计为处置完成。', '']
    return '\n'.join(lines)


def newest_timeline_content(content):
    """Project previously saved Markdown in descending order without rewriting audit data."""
    headings = list(re.finditer(r'^## 轮次 [^\n]+ · 尝试 [^\n]+\n', content, re.MULTILINE))
    if len(headings) < 2:
        return content
    blocks = [content[item.start():headings[i + 1].start() if i + 1 < len(headings) else len(content)]
              for i, item in enumerate(headings)]
    def started(block):
        match = re.search(r'^状态：[^\n]*；开始：([^；\n]+)；', block, re.MULTILINE)
        try:
            return datetime.fromisoformat(match.group(1)).timestamp() if match else float('-inf')
        except ValueError:
            return float('-inf')
    return content[:headings[0].start()] + ''.join(sorted(blocks, key=started, reverse=True))


def render_summary(data):
    m, mail = data['metrics'], data.get('mail', {})
    lines = [f"# 当日告警总结 · {data['businessDate']}", '',
             f"当天执行 {m['started']} 轮，查询到 {m['events']} 条去重事件。风险 {m['risk']} 条，待判定 {m['unknown']} 条。",
             f"处置完成 {m['closed']} 条，已遏制 {m['contained']} 条，已忽略 {m['ignored']} 条，仍未闭环风险 {m['openRisk']} 条。", '',
             f"当天记录事件中，截至报告生成有 {m.get('monitoringEnded', 0)} 条未再检出、停止跟进（XDR 完整查询未返回），不计为已确认处置或风险消除。", '',
             '## 邮件与处置进展', '',
             f"当天确认发送 {mail.get('sentToday', 0)} 封，收到 {mail.get('receivedToday', 0)} 封回复。",
             f"截至当前，待处理回复 {mail.get('pending', 0)} 封，反馈待核验 {mail.get('needsReview', 0)} 封，发件结果未知 {mail.get('sendUnknown', 0)} 封。",
             '邮件状态与是否收到回信不决定监测任务成败；发信失败或未收到回信时，可在发信记录更新处置状态。', '',
             '## 需要继续跟进', '']
    for event in data['events']:
        if event['closure'] not in ('closed', 'ignored', 'ended'):
            name = str(event['name']).replace('\n', ' ')
            for char in ('\\', '[', ']', '*', '_', '`', '<', '>'):
                name = name.replace(char, '\\' + char)
            lines.append(f"- {name}：{event['disposition']}。")
    if not data['events']:
        lines.append('当天没有已提交的事件；查询失败不能视为没有告警。')
    backlog = data.get('investigation', {})
    lines += ['', '## 调查可靠性与依赖状态', '',
              f"当天去重调查对象 {m.get('investigatedEvents', m['events'])} 条，其中已形成调查结论 {m.get('investigationCompletedEvents', 0)} 条。"]
    rate = m.get('investigationCompletionRate')
    lines.append(f'调查完成率：{rate:.1%}。' if rate is not None else '调查完成率：无事件，不计入成功率。')
    lines.append(f"截至报告生成时，待续查 {backlog.get('pending', 0)} 条、延期 {backlog.get('deferred', 0)} 条、系统故障 {backlog.get('system_wait', 0)} 条、业务待人工核对 {backlog.get('needs_review', 0)} 条。")
    if backlog.get('retry_exhausted'):
        lines.append(f"其中 {backlog['retry_exhausted']} 条已停止自动恢复；修复依赖后需手动重新启动监测。")
    health = mail.get('health', {})
    if health.get('enabled'):
        lines.append('邮件收信状态：' + {'healthy': '正常', 'unavailable': '不可用', 'unknown': '尚未验证', 'disabled': '未启用'}.get(health.get('receive', {}).get('state'), '未知') + '。')
        lines.extend(health.get('errors', []))
    failed = sum(r['status'] not in ('completed', 'running') for r in data['runs'])
    lines += ['', '## 数据完整性', '', f"失败轮次：{failed}。统计以已提交事实及回查结果为准，发信和收到回信不等于处置完成。",
              '当天持续更新；跨日收到的反馈归入实际收到当天，原事件保留关联。邮件存量统计反映生成报告时的进度。']
    if any(r['result'].get('development_sample') for r in data['runs']):
        lines += ['', sampling.DESCRIPTION, '含联调抽样轮次，不能视为全天全量告警统计。测试忽略不代表消除威胁或确认误报。']
    return '\n'.join(lines)


async def export_report(owner, scope, day):
    lock = _locks.setdefault((owner, scope, day), asyncio.Lock())
    async with lock:
        try:
            data = await snapshot(owner, scope, day)
            content = render(data)
            summary_content = render_summary(data)
            digest = hashlib.sha256(f'{owner}:{scope}'.encode()).hexdigest()[:16]
            directory = WorkspaceManager.get_instance().get_workspace_dir().expanduser() / 'outputs' / day
            directory.mkdir(parents=True, exist_ok=True)
            target = directory / f'host-security-monitor-{digest}.md'
            fd, temp = tempfile.mkstemp(prefix='.monitor-', dir=directory)
            try:
                with os.fdopen(fd, 'w', encoding='utf-8') as handle:
                    handle.write(content)
                    handle.flush()
                    os.fsync(handle.fileno())
                os.replace(temp, target)
            finally:
                if os.path.exists(temp):
                    os.unlink(temp)
            summary_target = directory / f'host-security-monitor-{digest}-summary.md'
            fd, temp = tempfile.mkstemp(prefix='.monitor-summary-', dir=directory)
            try:
                with os.fdopen(fd, 'w', encoding='utf-8') as handle:
                    handle.write(summary_content)
                    handle.flush()
                    os.fsync(handle.fileno())
                os.replace(temp, summary_target)
            finally:
                if os.path.exists(temp):
                    os.unlink(temp)
            await write("UPDATE monitor_reports SET status='updated',version=version+CASE WHEN content IS ? AND summary_content IS ? THEN 0 ELSE 1 END,content=?,summary_content=?,error=NULL WHERE owner=? AND scope=? AND business_date=?", (content, summary_content, content, summary_content, owner, scope, day))
        except Exception:
            await write("UPDATE monitor_reports SET status='failed',error=? WHERE owner=? AND scope=? AND business_date=?", ('日报导出失败，等待独立重试', owner, scope, day))


async def retry_exports():
    for item in await rows("SELECT owner,scope,business_date FROM monitor_reports WHERE status IN ('pending','failed')"):
        await export_report(item['owner'], item['scope'], item['business_date'])
