"""Existing email transport plus a durable IMAP catch-up cursor for monitoring."""
import hashlib
import json
import sqlite3
from datetime import datetime, timezone
from flocks.channel.base import OutboundContext
from flocks.channel.outbound.deliver import OutboundDelivery
from flocks.channel.registry import default_registry
from flocks.channel.builtin.email.config import parse_allowed_senders
from flocks.task.store import TaskStore
from .mail_template import TEMPLATE_VERSION

# Temporary development policy, explicitly requested for target-machine testing.
# From/allowlist matching does not authenticate a sender. Restore this to True
# before production; saved unverified feedback must not authorize new writes.
REQUIRE_AUTHENTICATED_FEEDBACK = False


class TransportNotReady(ValueError):
    """Delivery was not accepted: preflight failed or SMTP explicitly rejected it.

    Only this positive transport fact permits a new send attempt. A timeout
    after sending DATA is uncertain and must not be classified as this error.
    """


def mailbox_key(cfg):
    return hashlib.sha256(json.dumps([cfg.get(k, '') for k in ('imapHost', 'imapPort', 'username', 'address')]).encode()).hexdigest()


def transport(recipient=None, *, for_send=False):
    plugin = default_registry.get('email')
    cfg = getattr(plugin, '_resolved', {})
    if not plugin or not cfg:
        raise ValueError('请先连接 Flocks 邮件通道')
    # Configuration still requires the original connected-channel check. An
    # existing notification can attempt SMTP independently of IMAP polling,
    # while the plugin's lifecycle gate rejects an explicit stop or disable.
    ready = getattr(plugin, 'send_ready', plugin.status.connected) if for_send else plugin.status.connected
    if not ready:
        raise ValueError('邮件通道已停用或尚未启动，请先启用邮件通道' if for_send else '请先连接 Flocks 邮件通道')
    if REQUIRE_AUTHENTICATED_FEEDBACK and not cfg.get('authservId'):
        raise ValueError('邮件通道需配置可信 authservId，以核验责任人回信身份')
    if recipient and not cfg.get('allowAll') and recipient not in parse_allowed_senders(cfg):
        raise ValueError('责任人邮箱不在邮件通道允许收件人列表中')
    return plugin, cfg


async def send(notice, session_id):
    try:
        _, cfg = transport(notice['recipient'], for_send=True)
    except ValueError as exc:
        raise TransportNotReady(str(exc)) from exc
    if mailbox_key(cfg) != notice['mailbox']:
        raise TransportNotReady('邮件账号已变化，请重新保存邮件跟进配置')
    # Persisted presentation survives a manual retry without generating a new
    # message. Older notices keep their original plain-text delivery.
    event = notice.get('event', {})
    try:
        event = json.loads(event) if isinstance(event, str) else event
    except (ValueError, TypeError):
        event = {}
    presentation = event.get('mail_presentation', {}) if isinstance(event, dict) else {}
    html_body = presentation.get('html_body') if isinstance(presentation, dict) and presentation.get('version') in {1, TEMPLATE_VERSION} else None
    html_body = html_body if isinstance(html_body, str) and len(html_body) <= 100_000 else None
    ctx = OutboundContext(channel_id='email', to=notice['recipient'], text=notice['body'],
                          subject=notice['subject'], message_id=notice['message_id'],
                          new_thread=True, single_message=True, format_hint='plain', html_body=html_body)
    results = await OutboundDelivery.deliver(ctx, max_retries=1, session_id=session_id)
    if len(results) == 1 and getattr(results[0], 'delivery_state', 'unknown') == 'not_sent':
        raise TransportNotReady(results[0].error or '邮件未发送，请检查邮件通道后重试')
    return len(results) == 1 and results[0].success and results[0].message_id == notice['message_id']


def poll_range(cfg, imap):
    """Called on the IMAP thread. Search even already-read mail after opt-in.

    No cursor is advanced until the entire bounded fetch batch is consumed.
    SMTP and IMAP do not participate in our SQLite transactions.
    """
    from flocks.enhancements.monitor_db import active
    path = TaskStore.get_db_path()
    if not active() and not path.exists():
        return None
    with _mail_database(readonly=True) as db:
        if not db.execute("SELECT 1 FROM sqlite_master WHERE name='monitor_mail_settings'").fetchone():
            return None
        key = mailbox_key(cfg)
        since = db.execute('SELECT MIN(stamp) FROM (SELECT updated_at AS stamp FROM monitor_mail_settings WHERE mailbox=? '
                           'UNION ALL SELECT created_at AS stamp FROM monitor_mail_notices WHERE mailbox=?)', (key, key)).fetchone()[0]
        if not since:
            return None
        response = imap.response('UIDVALIDITY')[1]
        validity = str(response[0].decode() if response and isinstance(response[0], bytes) else response[0] if response else '')
        if not validity.isdigit():
            raise ValueError('IMAP UIDVALIDITY missing; cannot safely checkpoint monitoring mail')
        row = db.execute('SELECT validity,last_uid FROM monitor_mail_cursors WHERE mailbox=?', (key,)).fetchone()
        if row and row[0] == validity:
            return key, validity, ['UID', f'{row[1] + 1}:*'], row[1]
        date = datetime.fromisoformat(since).strftime('%d-%b-%Y')
        return key, validity, ['SINCE', date], 0


def checkpoint(poll, last_uid):
    if not poll or last_uid is None:
        return
    with _mail_database(readonly=False) as db:
        db.execute('INSERT INTO monitor_mail_cursors VALUES(?,?,?) ON CONFLICT(mailbox) DO UPDATE '
                   'SET last_uid=CASE WHEN monitor_mail_cursors.validity=excluded.validity THEN MAX(monitor_mail_cursors.last_uid,excluded.last_uid) '
                   'ELSE excluded.last_uid END,validity=excluded.validity', (poll[0], poll[1], last_uid))


def record_unparsed(poll, uid):
    """Retain a durable locator before passing an unsupported message.

    The original message stays in IMAP. No body, sender or credentials enter
    diagnostics; an operator can inspect this record and the mailbox later.
    """
    with _mail_database(readonly=False) as db:
        db.execute('INSERT OR IGNORE INTO monitor_mail_unparsed VALUES(?,?,?,?)',
                   (poll[0], poll[1], int(uid), datetime.now(timezone.utc).isoformat()))


async def diagnose_poll(cfg, error_type, health=None):
    """Exportable transport failure with no mailbox address or exception body."""
    from .store import rows
    from . import diagnostics as diag
    try:
        for row in await rows('SELECT owner,scope FROM monitor_mail_settings WHERE mailbox=?', (mailbox_key(cfg),)):
            async with diag.trace_scope(row['owner'], row['scope'], 'mail-poll'):
                diag.event('mail.result', failure=True, stage='mail.receive', mail_state='pending',
                           reason='unavailable', error_type=error_type, mail_direction='receive',
                           mail_stage=(health or {}).get('stage', 'unknown'),
                           consecutive_failures=(health or {}).get('consecutive_failures', 0))
    except Exception:
        pass  # Observability never prevents mailbox recovery.


from contextlib import contextmanager
@contextmanager
def _mail_database(*, readonly):
    from flocks.enhancements.monitor_db import active, sync_connection
    if active():
        with sync_connection(readonly=readonly, timeout=8) as db:
            yield db
    else:
        with sqlite3.connect(TaskStore.get_db_path(), timeout=30) as db:
            yield db
