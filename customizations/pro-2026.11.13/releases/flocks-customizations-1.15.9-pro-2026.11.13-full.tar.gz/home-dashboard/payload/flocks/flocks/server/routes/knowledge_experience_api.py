"""Authenticated APIs for persisted, evidence-linked knowledge experiences."""
from __future__ import annotations

import asyncio
import logging

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field

from flocks.auth.service import AuthService
from flocks.server.auth import require_admin, require_user
from flocks.server.routes import knowledge_experience as engine

router = APIRouter()
_runs: dict[str, tuple[asyncio.Task, str | None]] = {}
_errors: dict[str, tuple[str, tuple]] = {}
_scopes: dict[str, str] = {}
_log = logging.getLogger(__name__)


async def guard_managed_workflow(request: Request):
    """Protect this owner-bound workflow through native task/workflow entrypoints.

    Other workflows and tasks retain their existing behavior. Native workflow
    authors are trusted code authors; this is not an arbitrary-code sandbox.
    """
    if request.method in {"GET", "HEAD", "OPTIONS"}:
        return
    from flocks.server.routes.knowledge_experience_runtime import (
        WORKFLOW_ID, KnowledgeInstallationError, _path_scope, _read_json, _state_path,
    )
    from flocks.task.store import TaskStore
    affected = request.path_params.get("workflow_id") == WORKFLOW_ID
    # Match native route templates, not body fields or a user-controlled suffix.
    # Queue-based Task Center runs remain administrative: those workers do not
    # carry the browser caller and must never silently run as the bound owner.
    route_path = getattr(request.scope.get("route"), "path", "").removeprefix("/api")
    if affected and request.method == "POST" and route_path in {
        "/workflow/{workflow_id}/run",
        "/workflow/{workflow_id}/run-node",
        "/workflow/{workflow_id}/triggers/{trigger_id}/test",
    }:
        return await _active_user(request)
    scheduler_id = request.path_params.get("scheduler_id")
    execution_ids = [request.path_params["execution_id"]] if "execution_id" in request.path_params else []
    if scheduler_id:
        scheduler = await TaskStore.get_scheduler(scheduler_id)
        affected |= scheduler is not None and scheduler.workflow_id == WORKFLOW_ID
    content_type = request.headers.get("content-type", "").partition(";")[0].strip().lower()
    if not content_type or content_type == "application/json" or (content_type.startswith("application/") and content_type.endswith("+json")):
        try:
            body = await request.json()
        except ValueError:
            body = {}
        if isinstance(body, dict):
            affected |= body.get("workflowID", body.get("workflow_id")) == WORKFLOW_ID
            batch = body.get("executionIds", body.get("execution_ids", []))
            if isinstance(batch, list):
                execution_ids.extend(value for value in batch if isinstance(value, str))
    for execution_id in dict.fromkeys(execution_ids):
        execution = await TaskStore.get_execution(execution_id)
        affected |= execution is not None and execution.workflow_id == WORKFLOW_ID
        if execution is not None and execution.scheduler_id:
            parent = await TaskStore.get_scheduler(execution.scheduler_id)
            affected |= parent is not None and parent.workflow_id == WORKFLOW_ID
    if not affected:
        return
    user = await _active_user(request, admin=True)
    try:
        with _path_scope():
            state = _read_json(_state_path())
    except (KnowledgeInstallationError, OSError) as error:
        raise HTTPException(503, "知识工作流安装状态暂时不可读取，请检查存储配置与权限。") from error
    if not state or state.get("owner_id") != user.id:
        raise HTTPException(403, "仅绑定的管理员可以操作此领域知识工作流")


async def managed_workflow_context(request: Request):
    # Native run creates an asyncio task and the patched engine propagates its
    # context into node workers. Identity comes only from verified authentication.
    from flocks.auth.context import reset_current_auth_user, set_current_auth_user

    caller = await guard_managed_workflow(request)
    token = set_current_auth_user(caller) if caller is not None else None
    try:
        yield
    finally:
        if token is not None:
            reset_current_auth_user(token)


managed_dependencies = [Depends(managed_workflow_context)]


class RefreshRequest(BaseModel):
    category: str | None = Field(default=None, pattern=r"^[a-z0-9-]+$", max_length=80)


def _publication(document: dict) -> tuple:
    return tuple(document.get(key) for key in ("version", "updated_at", "last_attempt_at"))


def _daily_locked(document: dict) -> bool:
    # Date/timezone and publication validity are resolved by the deterministic
    # engine. Do not infer today's date from the browser or API server locale.
    daily = document.get("daily")
    return bool(isinstance(daily, dict) and daily.get("enabled") is True and
                daily.get("locked") is True and document.get("status") == "ready" and
                document.get("version") and document.get("content"))


def _read_failure(error: ValueError | OSError) -> HTTPException:
    # Only an unknown category/version is a 404. Configuration and storage
    # failures must not masquerade as a missing API or a never-generated summary.
    if isinstance(error, engine.ExperienceNotFound):
        return HTTPException(404, str(error))
    if isinstance(error, engine.ExperienceError):
        # Engine errors contain deliberately static, public-safe explanations.
        return HTTPException(503, str(error))
    return HTTPException(503, "知识资料或存储暂时不可用，请检查目录配置与访问权限。")


async def _active_user(request: Request, *, admin: bool = False):
    user = require_admin(request) if admin else require_user(request)
    # Re-check persisted permissions: a long-running session must not retain a
    # disabled account's access or a former admin's legacy scope.
    actual = await AuthService.get_user_by_id(user.id)
    if not actual or actual.status != "active" or (admin and actual.role != "admin"):
        raise HTTPException(403, "账号状态或权限已变更，请重新登录")
    return actual


@router.post("/refresh", status_code=202, responses={200: {"description": "该领域今日已完成，返回现有版本，不启动更新。"}})
async def refresh_experience(request: Request, body: RefreshRequest):
    user = await _active_user(request)
    try:
        scope = await asyncio.to_thread(engine.scope_key, user)
        previous = await asyncio.to_thread(engine.read_experience, user, body.category) if body.category else {}
    except (ValueError, OSError) as error:
        raise _read_failure(error) from error
    # A published domain is complete for this server-side day even while another
    # domain is updating. Return it without creating a task or touching failures.
    if _daily_locked(previous):
        return JSONResponse(status_code=200, content={
            "status": "unchanged", "version": previous["version"], "daily": previous["daily"],
        })
    # The reads above yield control; another request may have started meanwhile.
    if user.id in _runs and not _runs[user.id][0].done():
        raise HTTPException(409, "经验更新正在进行，请稍后查看")
    from flocks.server.routes.knowledge_experience_runtime import run_for_user
    has_publication = bool(previous.get("version") and previous.get("content"))
    preservation = "已保留最近成功的总结。" if has_publication else "尚未生成可用总结。"

    async def run():
        try:
            # Persisted engine attempts are authoritative, including partial failures.
            await run_for_user(user, category=body.category)
        except asyncio.CancelledError:
            _errors[user.id] = (f"更新被中断，{preservation}", _publication(previous))
            raise
        except Exception:
            _errors[user.id] = (f"更新失败，{preservation}请检查模型与服务状态后重试。", _publication(previous))
            _log.warning("knowledge experience update failed")

    _errors.pop(user.id, None)
    _scopes[user.id] = scope
    task = asyncio.create_task(run(), name=f"knowledge-experience:{user.id}")
    _runs[user.id] = (task, body.category)
    return {"status": "running"}


@router.get("/{category}/history")
async def history(request: Request, category: str):
    user = await _active_user(request)
    try:
        return await asyncio.to_thread(engine.list_history, user, category)
    except (ValueError, OSError) as error:
        raise _read_failure(error) from error


@router.get("/{category}")
async def experience(request: Request, category: str, version: str | None = None):
    user = await _active_user(request)
    try:
        scope = await asyncio.to_thread(engine.scope_key, user)
        result = await asyncio.to_thread(engine.read_experience, user, category, version=version)
    except (ValueError, OSError) as error:
        raise _read_failure(error) from error
    if not version and _daily_locked(result):
        return result
    run = _runs.get(user.id)
    if not version and run and _scopes.get(user.id) == scope and (run[1] is None or run[1] == category):
        if not run[0].done():
            result = {**result, "status": "running"}
        elif run[1] == category and user.id in _errors and result.get("status") != "running":
            message, publication = _errors[user.id]
            if publication == _publication(result):
                result = {**result, "status": "failed", "error": message}
            else:
                _errors.pop(user.id, None)
    return result
