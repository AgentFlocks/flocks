"""Read-only task-center projections; execution and recovery state stay intact."""
from __future__ import annotations

from contextlib import asynccontextmanager
from datetime import datetime, timedelta, timezone

from flocks.task.store import TaskStore


def _postgres():
    from flocks.db_backend import backend_choice
    return backend_choice().backend == 'postgres'


def _monitor_failure(postgres):
    marker = ("execution_input_snapshot::jsonb #> '{context,monitoring}'" if postgres
              else "json_extract(execution_input_snapshot, '$.context.monitoring')")
    # The daily-session prefix also identifies older rows without a snapshot.
    return ("(status = 'failed' AND (COALESCE(CAST(" + marker + " AS TEXT), 'null') "
            "NOT IN ('null', 'false', '0', '') OR substr(COALESCE(session_id, ''), 1, 12) = 'ses_monitor_'))")


@asynccontextmanager
async def _reader():
    # Borrow the installed store's own connection. No schema migration, write
    # transaction, monitoring advisory lock or replacement task engine.
    db = await TaskStore._db()
    yield db


async def _rows(db, sql, params, postgres):
    if postgres:
        from flocks.db.markers import rewrite_markers
        sql = rewrite_markers(sql, lambda index: f'${index}')
    async with db.execute(sql, tuple(params)) as cursor:
        return [dict(row) for row in await cursor.fetchall()]


async def list_task_center_executions(*, scheduler_id=None, status=None, priority=None,
        delivery_status=None, title=None, started_after=None, started_before=None,
        sort_by='queued_at', sort_order='desc', offset=0, limit=20):
    postgres = _postgres()
    clauses, params = ['NOT ' + _monitor_failure(postgres)], []
    for name, value in [('scheduler_id', scheduler_id), ('status', status),
                        ('priority', priority), ('delivery_status', delivery_status)]:
        if value:
            clauses.append(f'{name} = ?')
            params.append(getattr(value, 'value', value))
    if title and title.strip():
        search = title.strip().replace('\\', '\\\\').replace('%', '\\%').replace('_', '\\_')
        clauses.append("title " + ('ILIKE' if postgres else 'LIKE') + " ? ESCAPE '\\'")
        params.append('%' + search + '%')
    for boundary, operator in [(started_after, '>='), (started_before, '<=')]:
        if boundary is not None:
            if postgres:
                instant = "(CASE WHEN started_at ~ '(Z|[+-][0-9]{2}(:?[0-9]{2})?)$' THEN started_at::timestamptz ELSE started_at::timestamp AT TIME ZONE 'UTC' END)"
                clauses.append(instant + ' ' + operator + ' CAST(? AS timestamptz)')
                params.append(boundary.isoformat())
            else:
                from flocks.task.store import _timestamp_microseconds
                clauses.append('task_timestamp_us(started_at) ' + operator + ' ?')
                params.append(_timestamp_microseconds(boundary.isoformat()))
    where = ' WHERE ' + ' AND '.join(clauses)
    allowed = {'created_at', 'updated_at', 'priority', 'queued_at', 'started_at', 'completed_at'}
    column = sort_by if sort_by in allowed else 'queued_at'
    direction = 'ASC' if sort_order.lower() == 'asc' else 'DESC'
    async with _reader() as db:
        count = await _rows(db, 'SELECT COUNT(*) AS total FROM task_executions' + where, params, postgres)
        rows = await _rows(db, 'SELECT * FROM task_executions' + where +
            f' ORDER BY {column} {direction}, id {direction} LIMIT ? OFFSET ?', [*params, limit, offset], postgres)
    return [TaskStore._row_to_execution(row) for row in rows], count[0]['total']


async def task_center_dashboard(counts):
    postgres = _postgres()
    week_start = datetime.now(timezone.utc) - timedelta(days=7)
    instant = 'COALESCE(completed_at, started_at, queued_at, created_at)'
    if postgres:
        instant = '(' + instant + ')::timestamptz'
        boundary = 'CAST(? AS timestamptz)'
        value = week_start.isoformat()
    else:
        from flocks.task.store import _timestamp_microseconds
        instant = 'task_timestamp_us(' + instant + ')'
        boundary = '?'
        value = _timestamp_microseconds(week_start.isoformat())
    async with _reader() as db:
        rows = await _rows(db, 'SELECT COUNT(*) AS total FROM task_executions WHERE '
            "status = 'failed' AND NOT " + _monitor_failure(postgres) +
            ' AND ' + instant + ' >= ' + boundary, [value], postgres)
    return {**counts, 'failed_week': rows[0]['total']}
