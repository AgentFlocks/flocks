import{j as t,N as e}from"./react-vendor-CU8YRgkx.js";function i(){return t.jsx(e,{to:"/settings/voice-input",replace:!0})}export{i as default};
