const e="Flocks Notifications",o="Flocks Community Announcement | Model Usage Allowances in October",n=`Dear Flocks community,

Thank you for your continued support of Flocks and for sharing your experience and feedback with the community. To support ongoing platform maintenance and the long-term use of more security operations scenarios, we will adjust model usage allowances on October 1, introducing monetary billing and self-service top-ups.

The current free token policy remains in effect throughout September.

**Starting October 1, the changes are as follows:**

1. **Daily free usage remains available.** Each person will continue to receive 10 million tokens of free model usage per day.
2. **Self-service top-ups are available when you need more usage.** Sign in to [https://portal.agentflocks.com](https://portal.agentflocks.com) with your X community account to top up for usage beyond your daily free allowance. Enterprise users can also contact ThreatBook sales to discuss their team's future model usage and related services.
3. **Existing additional support will also change.** Starting October 1, the shared free token pool and temporary allowances previously granted to individual users, including daily allowances above 30 million tokens, will be discontinued. The new allowance rules will apply uniformly.

We understand that they will affect some community members' existing usage plans. If you run scheduled tasks such as inspections or alert analysis, review model pricing, task frequency, and daily consumption to prepare your allowance and budget in advance. For those using temporary increases or relying on the shared pool, this may change future available allowances and usage costs. We are therefore providing about a month's notice. Please share any specific issues you encounter in the group or privately with the group owner.

For enterprise purchasing, please contact ThreatBook sales.

Thank you for your continued support. We look forward to working with you to keep improving the security operations use cases already running successfully.

Project: [https://github.com/AgentFlocks/flocks](https://github.com/AgentFlocks/flocks)  
Documentation: [https://agentflocks.github.io/flocks-docs/](https://agentflocks.github.io/flocks-docs/)  
Top-ups: [https://portal.agentflocks.com](https://portal.agentflocks.com)

The Flocks Team  
September 9, 2026`,t="Usage allowances and version highlights are collected here.",s="The code could not be loaded. Please refresh the page and try again.",a="Close notification",i="Got it",r="Don't remind me about this",l="Don't remind me again",c={title:e,tokenPolicyTitle:o,tokenPolicyBody:n,subtitle:t,qrUnavailable:s,close:a,gotIt:i,dismissThis:r,dismissForever:l};export{a as close,c as default,l as dismissForever,r as dismissThis,i as gotIt,s as qrUnavailable,t as subtitle,e as title,n as tokenPolicyBody,o as tokenPolicyTitle};
